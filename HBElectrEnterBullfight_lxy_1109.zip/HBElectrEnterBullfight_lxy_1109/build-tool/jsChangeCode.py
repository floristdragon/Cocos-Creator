#! /usr/bin/env python  
# -*- coding: utf-8 -*-  
import os  
import time  
import sys
import random

class Stack(object) :
    def __init__(self):
        #类的构造函数
        self.stack = []

    def __str__(self):
        #类的字符串输出方法，类似于java的.toString()方法
        return str(self.stack)

    def getSize(self) :
        #获取栈当前大小
        return len(self.stack)

    def push(self, x) :
        #入栈，栈满抛异常
        if self.isfull() :
            return
        self.stack.append(x)

    def pop(self) :
        #出栈，栈空抛异常
        if self.isempty() :
            return
        topElement = self.stack[-1] 
        self.stack.pop()
        return topElement
    def popEqual(self, equ): #从栈顶开始删除所有的equ
        if self.isempty() :
            return
        topElement = self.stack[-1]
        if topElement==equ:
            self.stack.pop()
            self.popEqual(equ)
    def popRichEqual(self, equ): #从栈顶开始删除，不管是不是equ, 直到遇到并删完equ才停止
        ishave = False
        if not self.isHaveEqual(equ):
            return
        stlen = self.getSize()
        for i in range(stlen-1, -1, -1):
            if self.stack[i]==equ:
                self.stack.pop()
                if i>0 and self.stack[i-1]==equ:
                    continue
                break
            else:
                self.stack.pop()
    def isHaveEqual(self, equ):
        for i in range(stlen-1, -1, -1):
            if self.stack[i]==equ:
                return True
        return False


    def getTop(self) :
        if self.isempty() :
            return ''
        return self.stack[-1] 


    def isempty(self) :
        #判断栈空
        if len(self.stack) == 0 :
            return True
        return False
    def clear(self):
        self.stack = []

    def isfull(self) :
        #判断栈满
        return False  

'''
《添加代码》
static char* pAllAddCodeArray[] = {
",", ";", "\n", "{"
};
1、分号、换行、左大括号，最近的是哪个
   分号：可在后面添加
   换行：先检测前面是否有逗号，没有则可换行添加，有则不加
   左大括号：可在后面添加
2、大括号"{}"之间的数据，遇到逗号可添加逗号的，遇到分号可添加分号的
'''
'''
《修改变量名》
遇到"var","let", "_"开始，声明的变量，均可全局替换
1、"let"遇到无"{"匹配的"}",就终止替换
2、"var"在前一个"{"到无匹配"{"的"}"，就终止替换，若前面没有遇到过"{",那就全局替换
3、"_"开始的，表示变量，变量声明的为":"前为变量名，后面为值，以","截止, 遇到无"{"匹配的"}",就终止替换
'''

gCharRandSeed = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$'
gNumberRandSeed = '0123456789'
gOptFileCounts = 0 
gFKuoHaoStack = Stack()
gRandValueArray = []
def randNumSeed(seed, imin, imax):
    numRand = random.randint(imin, imax)
    sa = []
    for i in range(numRand):
        sa.append(random.choice(seed))
    salt = ''
    salt += ''.join(sa)
    #print "====randNumSeed=====> %s" % salt
    return salt
def baseGenerateVariable(tou):
    global gCharRandSeed  
    global gNumberRandSeed  
    #print "==baseGenerateVariable===%d" % len(gRandValueArray)
    for x in range(10000):
        rva = tou
        rva += randNumSeed(gCharRandSeed, 1, 5)
        rva += randNumSeed(gNumberRandSeed, 1, 5)
        ishavevar = 0
        for k,v in enumerate(gRandValueArray):
            if rva==v:
                ishavevar = 1
                break
        if ishavevar==0:
            gRandValueArray.append(rva)
            return rva

def generateVariable():
    return baseGenerateVariable('_E0F')
def generateVariableEx():
    return baseGenerateVariable('_F0F')

def generateValue(isBool, isNum, isStr):
    global gCharRandSeed  
    global gNumberRandSeed  
    if isBool:
        if random.randint(0, 1)==1:
            return 'true'
        else:
            return 'false'
    elif isNum:
        return '1'+randNumSeed(gNumberRandSeed, 1, 5)
    elif isStr:
        return '"E0F'+randNumSeed(gCharRandSeed, 1, 5) + '"'
def generateOperator():
    rval = random.randint(0, 3)
    if rval==0:
        return '+'
    elif rval==1:
        return '-'
    elif rval==2:
        return '*'
    elif rval==3:
        return '/'
def generateLocalCode(filename):
    if filename=='include.js' or filename=='globalConfig.js':
        return ""
    elif filename=="UserManager.js" or filename=="UserInfo.js":
        return ""
    elif filename=="RoomManager.js" or filename=="RoomInfo.js":
        return ""
    elif filename=="SoundManager.js" or filename=="ItemManager.js":
        return ""
    elif filename=="ConfigManager.js":
        return ""
    
    itype = random.randint(1, 10)
    varib1 = generateVariable()
    num1 = generateValue(False, True, False)
    num2 = generateValue(False, True, False)
    str1 = generateValue(False, False, True)
    bool1 = generateValue(True, False, False)
    toCodeStr = ""
    toRandValue = random.randint(1, 1000)
    toRandValue = str(toRandValue)
    if itype==1 :
        toCodeStr += "\tif(window.g_UserManager){\n"
        toCodeStr += "\tlet sid = g_UserManager.getSelfUserID()+"+num1+";\n"
        toCodeStr += "\tlet sinfo = g_UserManager.getSelfUserInfo();if(sinfo)sinfo.setDiamond("+num1+");\n"
        toCodeStr += "\tconsole.log('=====>>>>', sid, "+str1+");\n"
        toCodeStr += "\t}\n"
    elif itype==2: #这个会导致堆栈溢出
        toCodeStr += "\tif(window.g_SoundManager){\n"
        toCodeStr += "\tg_SoundManager.playMusic();g_SoundManager.playEffect();\n"
        toCodeStr += "\tconsole.log('=====>>>>', g_SoundManager.getEffectVolume()+"+num1+");\n"
        toCodeStr += "\t}\n"
    elif itype==3:
        toCodeStr += "\tif(window.g_RoomManager){\n"
        toCodeStr += "\tlet cgameid = g_RoomManager.getCurGameID();let croomid = g_RoomManager.getCurRoomID()\n"
        toCodeStr += "\tg_RoomManager.setCurGameRoom(cgameid, croomid);\n"
        toCodeStr += "\tconsole.log('=====>>>>', cgameid, croomid,"+num1+");\n"
        toCodeStr += "\t}\n"
    elif itype==4 :
        toCodeStr += "\tif(window.g_ItemManager){\n"
        toCodeStr += "\tlet dd = g_ItemManager.getItem(Math.random()*100)+"+num1+";\n"
        toCodeStr += "\tg_ItemManager.updateItem("+num1+"," + num2 + ");\n"
        toCodeStr += "\tconsole.log('=====>>>>', dd, g_ItemManager.getGold(), "+num1+");\n"
        toCodeStr += "\t}\n"
    elif itype==5 :
        toCodeStr += "\tif(window.g_ConfigManager){\n"
        toCodeStr += "\tlet " + varib1 + '=' + str1 + ';\n'
        toCodeStr += "\tconsole.log('=====>>>>', g_ConfigManager.getGlobalConfig());\n"
        toCodeStr += "\tg_ConfigManager.setKey("+varib1+"," + str1+");\n"
        toCodeStr += '\tlet serverIp = g_ConfigManager.getGlobalConfig("ServerIP")+' + str1+';'
        toCodeStr += '\tlet serverPort = g_ConfigManager.getGlobalConfig("ServerPort");'
        toCodeStr += '\tcc.log("=======serverIp==serverPort===========", serverIp, serverPort, '+varib1 +');'
        toCodeStr += "\t}\n"
    return toCodeStr


def generateCode(filename):
    varib1 = generateVariable()
    varib2 = generateVariable()
    varib3 = generateVariable()
    varib4 = generateVariable()
    num1 = generateValue(False, True, False)
    num2 = generateValue(False, True, False)
    num3 = generateValue(False, True, False)
    str1 = generateValue(False, False, True)
    str2 = generateValue(False, False, True)
    str3 = generateValue(False, False, True)
    bool1 = generateValue(True, False, False)
    bool2 = generateValue(True, False, False)
    bool3 = generateValue(True, False, False)
    itype = random.randint(1, 6)
        
    toCodeStr = '{\n'
    toRandValue = random.randint(1, 4)
    toRandValue = str(toRandValue)
    if itype==1: #一行加减乘除
        toCodeStr += "\tlet " + varib1 + '=' + num1 + ';\n'
        toCodeStr += "\tlet " + varib2 + '=' + num2 + '; let ' + varib3 + '= 0;\n'
        toCodeStr += "\tfor(let ip=0; ip<" + toRandValue + "; ip++){\n"
        toCodeStr += "\t"+varib3 + '+= ip + ' + varib1 + generateOperator() + varib2 + ';\n'
        toCodeStr += "\t}\n"
        toCodeStr += '\tconsole.log("===3=43df==", ' + varib1 + ',' + varib2 + ',' + varib3 + ');\n'
    elif itype==2: #判断语句
        toCodeStr += "\tlet " + varib1 + '=' + bool1 + ';\n'
        toCodeStr += "\tif(Math.random()*100<50){ console.log('333333333===', " + varib1 + ");}\n"
        toCodeStr += "\tlet " + varib2 + '=' + str1 + ';\n'
        toCodeStr += "\tlet " + varib3 + '=' + str2 + ';\n'
        toCodeStr += "\tfor(let tt=0; tt<" + toRandValue + "; tt++){\n"
        toCodeStr += "\tif(Math.random()*10<3){ console.log('3243r24=w=', tt, " + varib2 + ");}\n"
        toCodeStr += "\tif(Math.random()*9<7){ console.log('332cfgdfs=1==', tt, " + varib3 + ");}\n"
        toCodeStr += "\t}\n"
    elif itype==3: #函数
        toCodeStr += "\tlet " + varib1 + '=' + num1 + ';\n'
        toCodeStr += "\tlet " + varib3 + '= [' + num2 + ',' + num3 + ',' + num1 + '];\n'
        toCodeStr += "\tlet " + varib4 + '=' + bool2 + ';\n'
        toCodeStr += "\tlet " + varib2 + '= function(a, b){ return a + b ' + generateOperator() + varib1 + '; };\n'
        toCodeStr += "\tif(" + num1 + ">100){ console.log(" + varib2 + "(" + varib1 + ',' + varib4 + '));} else{\n'
        toCodeStr += '\tconsole.log("================", ' + varib2 + ',' + varib3 + '); }\n'
    else:
        tolocalstr = generateLocalCode(filename)
        if tolocalstr=="" or len(tolocalstr)<=0:
            #print "===generateLocalCode=Empty====="
            return ""
        toCodeStr += tolocalstr
    toCodeStr += "}\n"
        
    return toCodeStr
#生产表的成员变量
def generateTableParem(bFunc):
    varib1 = generateVariable()
    varib2 = generateVariable()
    varib3 = generateVariable()
    varib4 = generateVariable()
    num1 = generateValue(False, True, False)
    num2 = generateValue(False, True, False)
    num3 = generateValue(False, True, False)
    str1 = generateValue(False, False, True)
    str2 = generateValue(False, False, True)
    str3 = generateValue(False, False, True)
    bool1 = generateValue(True, False, False)
    bool2 = generateValue(True, False, False)
    bool3 = generateValue(True, False, False)
    toCodeStr = ''
    if bFunc:
        toCodeStr += varib4 + "(a, b){\n"
        toCodeStr += "return a" + generateOperator() + "b; "
        toCodeStr += "},\n"
        toCodeStr += varib3 + "(a){\n"
        toCodeStr += "return " + varib4 + "(Math.random()*10, 3)" + generateOperator() + "b; "
        toCodeStr += "},\n"
    else:
        toCodeStr += '__' + varib1 + " : " + num1 + ',\n'
        toCodeStr += '__' + varib2 + " : " + str1 + ',\n'
        toCodeStr += '__' + varib3 + " : " + str3 + ',\n'
        toCodeStr += '__' + varib4 + " : " + bool1 + ',\n'

    return toCodeStr


def findIsJSTable(linestr):
    if linestr.find("module.exports")>=0:
        if linestr.rfind("}")<0 and linestr.rfind("{")>=0:
            return 2 #添加函数
    if linestr.find("properties:")>=0 or linestr.find("properties :")>=0 or linestr.find("properties  :")>=0:
        if linestr.rfind("}")<0 and linestr.rfind("{")>=0:
            return 1 #添加变量
    if linestr.find("cc.Class")>=0 and linestr.find("(")>=0 and linestr.find("{")>=0:
        if linestr.rfind("}")<0 and linestr.rfind(")")<0 and linestr.rfind(";")<0:
            return 2 #添加函数

    return 0
    
def findHouZhuiJS(filename):
    tohouzhuistr = ''
    for i in range(len(filename)-1, -1, -1):
        #print "===findHouZhuiJS==== %d" % i
        if filename[i]==' ':
            continue
        elif filename[i]=='s' or filename[i]=='j':
            tohouzhuistr += filename[i]
        elif filename[i]=='.':
            tohouzhuistr += filename[i]
            break
        else:
            break
    #print "%s ==findHouZhuiJS===> %s" % (filename, tohouzhuistr)
    return tohouzhuistr=='sj.'
#从后到前，截取一段
def isTextAddCode(filetext, ilenpos, maxlen):
    global gCharRandSeed  
    global gNumberRandSeed  
    #逆序判断
    toRevInterSeed = "),=|&!+-/%*.^\\]@#"  #存在这些就断开
    isAddCode = True
    toReverAllStr = ''
    for i in range(ilenpos-1, -1, -1):
        textChar = filetext[i]
        #print "textChar====%s" % textChar
        if gCharRandSeed.find(textChar)>=0 or gNumberRandSeed.find(textChar)>=0:
            toReverAllStr += textChar
        else:
            if len(toReverAllStr)<=0:
                if toRevInterSeed.find(textChar)>=0:
                    isAddCode = False
                    break
                if textChar=='{' or textChar==';':
                    break
                continue
            else:
                break

    toReverAllStr = toReverAllStr[::-1]
    #print "===isTextAddCode==11==toReverAllStr== %s %s" % (toReverAllStr, isAddCode)
    if not isAddCode or toReverAllStr=="return" or toReverAllStr=='else':
        return False
        
    #正序判断
    toZhengAllStr = ''
    isAddCode = True
    for i in range(ilenpos+1, maxlen):
        textChar = filetext[i]
        if textChar==' ' or textChar=='\t' or textChar=='\n':
            if len(toZhengAllStr)<=0:
                continue
            else:
                break
        else:
            #print("=========%s", textChar)
            if len(toZhengAllStr)<=0:
                toZhengAllStr += textChar
                if toZhengAllStr=='}' or toZhengAllStr==')' or toZhengAllStr==',' or toZhengAllStr==';':
                    isAddCode = False
                    break
            elif gCharRandSeed.find(textChar)<0 and gNumberRandSeed.find(textChar)<0:
                break
            else:
                toZhengAllStr += textChar                

    #print "===isTextAddCode==22==toZhengAllStr== %s %s" % (toZhengAllStr,isAddCode)
    if not isAddCode or toZhengAllStr=='else': 
        return False
    #print "===isTextAddCode==33======"
    return True
def isTextStartFunction(filetext, ilenpos, maxlen):
    # 判断在'{'之前
    isInfunc = True
    twoFlagStr = ""
    toReverAllStr = ''
    for i in range(ilenpos-1, -1, -1):
        yTextChar = filetext[i]
        if yTextChar==' ' or yTextChar=='\n' or yTextChar=='\t':
            continue
        elif yTextChar==')':
            break
        else:
            if yTextChar=='=':
                twoFlagStr += yTextChar
            elif yTextChar=='>':
                twoFlagStr += yTextChar
                if twoFlagStr!="=>":
                    isInfunc = False
                    break
            else:
                isInfunc = False
                break
    #print "===isTextStartFunction== %s %s" % (twoFlagStr, isInfunc)
    return isInfunc

# 在js文件适当位置添加js代码
def checkAddJSCodeToFile(allfiletext, filename):
    global gFKuoHaoStack
    gFKuoHaoStack.clear()

    funcFlagStack = Stack()
    intervalStr = ''
    allTextArray = []
    allTextLen = len(allfiletext)
    for i in range(allTextLen):
        iTextChar = allfiletext[i]
        allTextArray.append(iTextChar)
        #print "======iTextChar========%s" % iTextChar
        iNextChar = ''
        iLastChar = ''
        if i<allTextLen-1:
            iNextChar = allfiletext[i+1]
        if i>0 :
            iLastChar = allfiletext[i-1]
        if iTextChar!=' ' and iTextChar!='\n' and iTextChar!='\t':
            intervalStr += iTextChar

        #注释
        # 优先注释'/*' '*/'
        if gFKuoHaoStack.getTop()=='/*':
            if iTextChar=='/' and iLastChar=='*':
                gFKuoHaoStack.popEqual('/*')
            continue

        # 注释'//'
        if gFKuoHaoStack.getTop()=='//':
            if iTextChar=='\n':
                gFKuoHaoStack.popEqual('//')
            continue

        # 开始注释
        if iTextChar=='/' and (iNextChar=='/' or iNextChar=='*'):
            gFKuoHaoStack.push(iTextChar+iNextChar)
            continue

        #字符串
        if iLastChar!='\\' and (iTextChar == '"' or iTextChar == "'"):
            oppoFlag = '"'
            if iTextChar==oppoFlag:
                oppoFlag = "'"
            if gFKuoHaoStack.getTop()==iTextChar: #遇到相同的
                gFKuoHaoStack.pop()
            elif gFKuoHaoStack.getTop()==oppoFlag: #遇到相反的
                pass
            else:
                gFKuoHaoStack.push(iTextChar)  #仅有单个则push
            continue
        if gFKuoHaoStack.getTop() == '"' or gFKuoHaoStack.getTop() == "'":
            #print "====checkAddJSCodeToFile==45555== %s" % iTextChar
            continue

        # 函数插入代码，被注释影响就不插入了
        if iTextChar=='{':
            if isTextStartFunction(allfiletext, i, allTextLen) :
                funcFlagStack.push(True)
            else:
                funcFlagStack.push(False)
        elif iTextChar=='}':
            funcFlagStack.pop()
        else :
            # if iTextChar=='(':
            #     gFKuoHaoStack.push(iTextChar)
            #     continue
            # elif iTextChar==')':
            #     gFKuoHaoStack.pop()
            #     continue
            #print "===checkAddJSCodeToFile=addCode=11== %s  %s" % (gFKuoHaoStack.getTop(),funcFlagStack.getTop())
            if iTextChar=='\n' and funcFlagStack.getTop()==True :
                #print "===checkAddJSCodeToFile=addCode=22== %s" % intervalStr
                if len(intervalStr)>0 and isTextAddCode(allfiletext, i, allTextLen):
                    allTextArray.append(generateCode(filename))
                    intervalStr=''
    allsalt = ''
    allsalt += ''.join(allTextArray)
    return allsalt
#############################################################################################
# 简单替换代码，仅仅替换以下划线为开头的成员变量，
# 即先查找"this._*"，如有，则全局替换变量
def checkReplaceJSCodeToFile(allfiletext, filename):
    global gCharRandSeed  
    global gNumberRandSeed  

    maxParamLen = 0
    allRepArray = []
    allRepRandVarArray = []
    allTextLen = len(allfiletext)
    for i in range(allTextLen):
        iTextChar = allfiletext[i]
        if i<8:
            continue
        if iTextChar=='_':
            toThisText = allfiletext[i-5:i+1]
            #print "=====checkReplaceJSCodeToFile===1==%s" % toThisText
            if toThisText=='this._':
                toParamText = ''
                for x in range(i, allTextLen):
                    textChar = allfiletext[x]
                    if gCharRandSeed.find(textChar)>=0 or gNumberRandSeed.find(textChar)>=0:
                        toParamText += textChar
                    else:
                        break
                if toParamText=='_super':
                    continue
                toParamLen = len(toParamText)
                if toParamLen>0:
                    allRepArray.append(toParamText)
                    allRepRandVarArray.append(generateVariableEx())
                    if maxParamLen<toParamLen:
                        maxParamLen = toParamLen
                    print "=====checkReplaceJSCodeToFile===2==%s %d" % (toParamText,maxParamLen)
    delItemLen = 0
    allTextArray = []
    for i in range(allTextLen):
        iTextChar = allfiletext[i]
        if delItemLen>0:
            delItemLen-=1
            continue
        if iTextChar!='_' or i>allTextLen-maxParamLen:
            allTextArray.append(iTextChar)
            continue
        repIndex = -1
        for repi in range(len(allRepArray)):
            repItemText = allRepArray[repi]
            toSubText = allfiletext[i : i + len(repItemText)]
            if toSubText==repItemText:
                print "===checkReplaceJSCodeToFile===3===%s %s" % (toSubText, allRepRandVarArray[repi])
                repIndex = repi
                break

        if repIndex>=0:
            delItemLen = len(allRepArray[repIndex])-1
            allTextArray.append(allRepRandVarArray[repIndex])
            print "===checkReplaceJSCodeToFile===4===%d %d %s" % (repIndex, delItemLen, allRepRandVarArray[repIndex])
        else:
            delItemLen = 0
            allTextArray.append(iTextChar)

    allsalt = ''
    allsalt += ''.join(allTextArray)
    return allsalt

def openAllFiles(sourceDir, targetDir, isEncrypt):  
    global gOptFileCounts  
    global gRandValueArray
    print u"%s 当前处理文件夹%s已处理%s 个文件" %(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())), sourceDir,gOptFileCounts)  

    for fname in os.listdir(sourceDir):  
        sourceF = os.path.join(sourceDir, fname)  
        targetF = os.path.join(targetDir, fname)  
        
        if os.path.isfile(sourceF):  
            #创建目录  
            print "==%s===openAllFiles===file=== %s" % (isEncrypt, fname)
            if not os.path.exists(targetDir):  
                os.makedirs(targetDir)  
            if not isEncrypt or not findHouZhuiJS(sourceF):
                open(targetF, "wb").write(open(sourceF, "rb").read()) 
                continue
            gOptFileCounts += 1 
            gRandValueArray = [] #情况随机的变量名字

            file_object = open(sourceF)
            all_the_text = file_object.read()
            file_object.close()

            #修改变量名和函数名称
            allfiletextEx = checkReplaceJSCodeToFile(all_the_text, fname)
            #插入代码
            allfiletext = checkAddJSCodeToFile(allfiletextEx, fname)
            #print "%s==>%s" % (fname, allfiletext)
            open(targetF, "w").write(allfiletext)
        if os.path.isdir(sourceF):  
            if fname!="gamenet" : #对网络层不做处理
                #print "=====openAllFiles===dir=11== %s" % fname
                openAllFiles(sourceF, targetF, True)  
            else:
                openAllFiles(sourceF, targetF, False) 
           
if __name__ == "__main__":  
    try:  
        import psyco  
        psyco.profile()  
    except ImportError:  
        pass
    if len(sys.argv)<2 :
        print 'Unknown option: Input less then 2 param.'
        sys.exit()
    sourceDir = sys.argv[1]
    targetDir = sys.argv[2]
    openAllFiles(sourceDir,targetDir, True)


    
