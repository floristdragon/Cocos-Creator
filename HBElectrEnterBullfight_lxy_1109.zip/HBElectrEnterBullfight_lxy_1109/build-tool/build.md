﻿**生成manifest文件**

```shell

//beta
node version-generator.js -v 1.0.0 -u   http://39.108.141.178:8080/hotfix/creator/  -s ../build/jsb-link/ -d ../assets/update

//realease
node version-generator.js -v 1.0.0 -u  http://39.108.141.178:8080/hotfix/creator/ -s ../build/jsb-link/ -d ../assets/hotfix

```
