console.log("============require======include=====================");
let SocketClient = require("SocketClientNov7th");

window.g_RoomManager = require("RoomManagerNov7th"); //房间信息管理
window.g_UserManager = require("UserManagerNov7th"); //用户信息管理
window.g_ItemManager = require("ItemManagerNov7th"); //物品管理器
window.g_ConfigManager = require("ConfigManagerNov7th"); //本地配置数据
window.g_SoundManager = require("SoundManagerNov7th"); //音频管理器
window.g_NetManager = new SocketClient(); //网络连接管理
window.g_ProtDef = require("mProtocolNov7th"); //协议模块和协议的定义

window.g_GameScene = null; //当前场景得全局句柄