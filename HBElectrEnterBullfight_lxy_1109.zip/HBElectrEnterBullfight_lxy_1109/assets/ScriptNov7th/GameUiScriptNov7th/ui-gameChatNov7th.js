cc.Class({
    extends: cc.Component,

    properties: {
        O_editNode: cc.EditBox,
        O_ShuruNode: cc.Node,
        O_chatUserInfo: cc.Prefab,

        O_worldLayer: cc.Node,
        O_roomLayer: cc.Node,
        O_siliaoLayer: cc.Node,

        O_worldToggleNode: cc.Node,
        O_roomToggleNode: cc.Node,
        O_siliaoToggleNode: cc.Node,

        O_siliaoTips: cc.Node,

        _chattype: 1,
        _scrollViewNode: null,
        _isInRoomChat: false,
        _curPos: null,
    },

    onLoad: function() {
        this._curPos = this.O_worldToggleNode.position;

    },

    openChatViewNov7thFunc() {
        this.node.active = true;
        if (this._isInRoomChat) {
            this.onRoomToggleBtnNov7thFunc();
            this.O_roomToggleNode.active = true;
            this.node.setLocalZOrder(151);
        } else {
            var toggleWorld = this.O_worldToggleNode.getComponent(cc.Toggle);
            var toggleSiliao = this.O_siliaoToggleNode.getComponent(cc.Toggle);
            if (toggleWorld.isChecked) {
                this.onWorldToggleBtnNov7thFunc();
            } else if (toggleSiliao.isChecked) {
                this.onSiliaoToggleBtnNov7thFunc();
            }

        }
    },

    onSendEventNov7thFunc: function() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        if (g_GameScene.rejectClickEventNov7thFunc(3)) return;

        let sendstr = this.O_editNode.string;
        this.O_editNode.string = "";

        if (!sendstr) return;

        let talkProtab = {};
        talkProtab.ctype = 4;
        talkProtab.content = sendstr;
        talkProtab.msgtype = this._chattype;
        if (talkProtab.msgtype == 2) {
            talkProtab.gameId = g_RoomManager.getCurGameIdNov7thFunc();
            talkProtab.roomId = g_RoomManager.getCurRoomIdNov7thFunc();
        }
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SSendChatMsg, talkProtab);

        cc.log("=============onSendEventNov7thFunc========this._chattype======", this._chattype);
    },

    onWorldToggleBtnNov7thFunc: function(event) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.O_worldLayer.active = true;
        this.O_siliaoLayer.active = false;
        this.O_roomLayer.active = false;
        this._chattype = 1;
        this.O_ShuruNode.active = true;
        cc.log("=============onWorldToggleBtnNov7thFunc========this._chattype======", this._chattype);
    },

    onSiliaoToggleBtnNov7thFunc: function(event) {
        this.O_siliaoTips.active = false;
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SReqChatMsg);
        this.O_worldLayer.active = false;
        this.O_siliaoLayer.active = true;
        this.O_roomLayer.active = false;
        this._chattype = 3;
        this.O_ShuruNode.active = false;
        cc.log("=============onSiliaoToggleBtnNov7thFunc========this._chattype======", this._chattype);
    },

    onRoomToggleBtnNov7thFunc: function(event) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.O_worldLayer.active = false;
        this.O_siliaoLayer.active = false;
        this.O_roomLayer.active = true;
        this._chattype = 2;
        this.O_ShuruNode.active = true;

        if (this._isInRoomChat) {
            this.O_worldToggleNode.active = false;
            var worldtoggle = this.O_worldToggleNode.getComponent(cc.Toggle);
            worldtoggle.isChecked = false;

            this.O_siliaoToggleNode.active = false;
            var siliaotoggle = this.O_siliaoToggleNode.getComponent(cc.Toggle);
            siliaotoggle.isChecked = false;

            this.O_roomToggleNode.position = this._curPos;
        }
        cc.log("=============onRoomToggleBtnNov7thFunc========this._chattype======", this._chattype);
    },
    addChatMsgNov7thFunc(msgtab) {
        if (msgtab.msgtype == 1) {
            this._scrollViewNode = this.node.getChildByName('worldLayer').getComponent('ui-scrollViewNov7th');
            this._scrollViewNode.setMoveAddNodeNov7thFunc(true);
            this._scrollViewNode.setLimitNodeMaxNov7thFunc(30);
        } else if (msgtab.msgtype == 2) {
            this._scrollViewNode = this.node.getChildByName('roomLayer').getComponent('ui-scrollViewNov7th');
            this._scrollViewNode.setMoveAddNodeNov7thFunc(true);
            this._scrollViewNode.setLimitNodeMaxNov7thFunc(30);
        } else if (msgtab.msgtype == 3) {
            this._scrollViewNode = this.node.getChildByName('siliaoLayer').getComponent('ui-scrollViewNov7th');
            this._scrollViewNode.setMoveAddNodeNov7thFunc(true);
            this._scrollViewNode.setLimitNodeMaxNov7thFunc(30);
        }

        let infoNode = cc.instantiate(this.O_chatUserInfo);
        let infoscript = infoNode.getComponent('ui-gameChatInfoNov7th');
        infoscript.setTalkInfoNov7thFunc(msgtab);

        this._scrollViewNode.addScrollNodeNov7thFunc(infoNode, 0);
        cc.log("=======onProtAddTalks==========msgtab=========", msgtab);
    },

    onHideChatPanelNov7thFunc: function() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.node.active = false;
    },

    showSiliaoTipsNov7thFunc: function(flag) {
        cc.log("========siliaoFlag==================", flag);
        if (flag) {
            this.O_siliaoTips.active = true;
        }
    },
    hideSiliaoTipsNov7thFunc: function() {
        this.O_siliaoTips.active = false;
    },

    setRoomChatStateNov7thFunc(isRoom) {
        this._isInRoomChat = isRoom;
    },
});