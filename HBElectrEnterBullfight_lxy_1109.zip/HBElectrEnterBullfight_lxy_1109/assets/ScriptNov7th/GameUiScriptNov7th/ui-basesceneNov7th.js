//场景切换函数
function switchSceneNov7thFunc(sceneName) {
    g_GameScene.showLoadFlowerNov7thFunc(true);
    cc.game.off(cc.game.EVENT_HIDE);
    cc.game.off(cc.game.EVENT_SHOW);
    cc.log("=========cc.director.preloadScene======begin===============");
    cc.director.preloadScene(sceneName, function() {
        cc.log("=========cc.director.preloadScene======End===============");
        g_GameScene.showLoadFlowerNov7thFunc(false);
        g_NetManager.removeAllListener();
        g_SoundManager.clearAllNov7thFunc();
        cc.director.loadScene(sceneName);
    });
}
///////////////////////////////////////////////////////////////////////////
//协议回调
function lonProtRecvErrcodeNov7thFunc(mainId, assitId, attachtab) {
    cc.log("======onProtRecvErrcode=====11=======", mainId, assitId, attachtab);
    let errcode = assitId;
    let errvar = g_ProtDef.GetErrVarByCode(errcode);
    cc.log("======onProtRecvErrcode=====22=======", errvar, errcode);
    if (errvar == "SYS_SERVER_SHUTDOWN" || errvar == "M_LOGIN_REDO_LOGIN") {
        g_UserManager.clearAllUserNov7thFunc();
        g_GameScene.showPopupWindowNov7thFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode), function(flag) {
            cc.log("===========redo=login============");
            g_GameScene.switchStartSceneNov7thFunc();
        });
    } else if (errvar == "M_LOGIN_REPLACE") {
        g_UserManager.clearAllUserNov7thFunc();
        let totip = g_ProtDef.GetErrDiscByCode(errcode) + attachtab.addr;
        g_GameScene.showPopupWindowNov7thFunc(true, false, "提示", totip, function(flag) {
            cc.log("===========redo=login============");
            g_GameScene.switchStartSceneNov7thFunc();
        });
    } else {
        if (g_GameScene.onRecvErrcodeNov7thFunc) g_GameScene.onRecvErrcodeNov7thFunc(assitId, attachtab);
    }
}

function lonProtRecvUpdateItemNov7thFunc(mainId, assitId, protTab) {
    cc.log("======onProtRecvUpdateItem=========", protTab);
    if (assitId == g_ProtDef.AItem_S2CUpdate) {
        for (let id in protTab.itemtab) {
            g_ItemManager.updateItemNov7thFunc(id, protTab.itemtab[id]);
        }
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////

let l_mmOnceEnterBack = false;
let l_mmOnceEnterForce = false;
module.exports = cc.Class({
    extends: cc.Component,

    properties: {
        mO_loadflowerprefab: cc.Prefab,
        mO_popupprefab: cc.Prefab,

        //////////////////////////////////////////
        _mmloadflowerNode: null,

        _mmRejectEventMap: null,
    },
    /*
    //在编译时候就会调用ctor, 即在cocos库还没加入时候
    ctor: function () {
        cc.log("=====ui-loadflower=======ctor======");
    },*/
    // use this for initialization
    //在加载时候调用，但父节点不会主动调用,需要调用this._super();来调用
    //已经不用onload去调用了，因为onLoad是在当前脚本加载完毕后调用的，其他后面的脚本都未加载
    //切换场景初始化统一用init
    onLoad: function() {

        cc.view.setDesignResolutionSize(this.node.width, this.node.height, cc.ResolutionPolicy.EXACT_FIT);
        g_GameScene = this;
        this._mmRejectEventMap = {};
        //每切换一个场景都会调用这里，覆盖掉原有的注册协议回调
        cc.log("=====ui-loadflower=======onLoad======");
        let self = this;
        //网络回调注册
        g_NetManager.onbegin = function() {
            console.log("=========g_NetManager.onbegin=============");
            self.showLoadFlowerNov7thFunc(true);
        };
        g_NetManager.onopen = function() {
            console.log("=========g_NetManager.onopen=============");
            self.showLoadFlowerNov7thFunc(false);
        };
        g_NetManager.onclose = function(linkcount) {
            console.log("=========g_NetManager.onclose=============", linkcount);
            self.showLoadFlowerNov7thFunc(false);
            self.showPopupRetryWindowNov7thFunc("提示", "网络连接异常", function(okflag) {
                cc.log("===========showPopupRetryWindowNov7thFunc=============", okflag);
                g_NetManager.connect();
            });
        };
        //注册进入后台，进入前台时候回调
        let enterBackNov7thFunc = function() {
            cc.log("========cc.game.on(cc.game.EVENT_HIDE==========");
            if (l_mmOnceEnterBack) {
                l_mmOnceEnterBack = false;
                return;
            }
            l_mmOnceEnterBack = true;
            g_SoundManager.stopAllNov7thFunc();
            if (self.onEnterBackgroundNov7thFunc) self.onEnterBackgroundNov7thFunc();
        };
        let enterForceNov7thFunc = function() {
            cc.log("========cc.game.on(cc.game.EVENT_SHOW==========");
            if (l_mmOnceEnterForce) {
                l_mmOnceEnterForce = false;
                return;
            }
            l_mmOnceEnterForce = true;
            g_SoundManager.openAllNov7thFunc();
            if (self.onEnterForegroundNov7thFunc) self.onEnterForegroundNov7thFunc();
        };
        cc.game.off(cc.game.EVENT_HIDE);
        cc.game.off(cc.game.EVENT_SHOW);
        cc.game.on(cc.game.EVENT_HIDE, enterBackNov7thFunc);
        cc.game.on(cc.game.EVENT_SHOW, enterForceNov7thFunc);

        //错误码、创建房间、加入房间、解散房间等等，只要需要跨场景通知的协议，或者要上层看不见的协议都在这里
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Errcode, null, lonProtRecvErrcodeNov7thFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Item, null, lonProtRecvUpdateItemNov7thFunc);
    },
    //进入后台回调, 可以继承重写
    onEnterBackgroundNov7thFunc() {

    },
    //进入前台回调, 可以继承重写
    onEnterForegroundNov7thFunc() {

    },
    onRecvErrcodeNov7thFunc(errcode, attachtab) {
        cc.log("====onRecvErrcodeNov7thFunc==========", errcode, attachtab)
    },
    ////////////////////////////////////////////////////
    showLoadFlowerNov7thFunc(isVisible) {
        if (!this._mmloadflowerNode) {
            this._mmloadflowerNode = cc.instantiate(this.mO_loadflowerprefab);
            this._mmloadflowerNode.parent = this.node;
            this._mmloadflowerNode.setLocalZOrder(10000);
        }
        this._mmloadflowerNode.getComponent("ui-netFlowerNov7th").showFlowerNov7thFunc(isVisible);
    },
    //callback 参数1位确定，否则为取消
    showPopupWindowNov7thFunc(isOk, isCancel, text1, text2, callback, target) {
        let popupnode = cc.instantiate(this.mO_popupprefab);
        popupnode.parent = this.node;
        popupnode.setLocalZOrder(10000);
        popupnode.getComponent("ui-promptWindowNov7th").showWindowNov7thFunc(isOk, isCancel, false, text1, text2, callback, target);
    },

    showPopupRetryWindowNov7thFunc(text1, text2, callback, target) {
        let popupnode = cc.instantiate(this.mO_popupprefab);
        popupnode.parent = this.node;
        popupnode.setLocalZOrder(10000);
        popupnode.getComponent("ui-promptWindowNov7th").showWindowNov7thFunc(false, false, true, text1, text2, callback, target);
    },

    rejectClickEventNov7thFunc(delay) {
        if (!delay || delay <= 0) return false;
        let self = this;
        let rejkey = "reject-default-key";
        let rejfunc = function() {
            self._mmRejectEventMap[rejkey] = null;
        };
        cc.log("=======rejectClickEventNov7thFunc=========", delay, this._mmRejectEventMap);
        if (!this._mmRejectEventMap[rejkey]) {
            this._mmRejectEventMap[rejkey] = 1;
            this.scheduleOnce(rejfunc, delay);
            return false;
        }
        this.showPopupWindowNov7thFunc(true, false, "提示", "操作过于频繁，请稍候！");
        return true;
    },
    ////////////////////////////////////////////////////////////////
    switchLobbySceneNov7thFunc() {
        switchSceneNov7thFunc("lobbyScene");
    },
    switchStartSceneNov7thFunc() {
        g_NetManager.closeNet();
        switchSceneNov7thFunc("startScene");
    },
    ////////////////////////////////////////////////////////////////
    // switchErRenDdzSceneNov7thFunc(){
    //     switchSceneNov7thFunc("errenddz");
    // },
    // switchClassicDdzSceneNov7thFunc(){
    //     switchSceneNov7thFunc("classicddz");
    // },
    switchBullfightSceneNov7thFunc() {
        switchSceneNov7thFunc("wurendn");
    },
    // switchWuRenSanGongSceneNov7thFunc(){
    //     switchSceneNov7thFunc("wurensg");
    // },
});