var configManager = require("ConfigManagerNov7th");
var nativeVoice = require("nativeVoiceNov7th");

var CIFMusicKEY = "Music_PLAY";
var CIFEffectKEY = "Effect_PLAY";
var CIFMusicVolKEY = "Music_Volumn";
var CIFEffectVolKEY = "Music_Volumn";
var mAllEffectTab = {};
var lisSoundOpenNov7thFunc = function(isMusic) {
    if (isMusic) {
        return configManager.getKeyNov7thFunc(CIFMusicKEY, "1") == "1";
    } else {
        return configManager.getKeyNov7thFunc(CIFEffectKEY, "1") == "1";
    }
};
var lsetSoundOpenNov7thFunc = function(isMusic, isOpen) {
    let openflag = "0";
    if (isOpen) openflag = "1";
    if (isMusic) {
        configManager.setKeyNov7thFunc(CIFMusicKEY, openflag);
    } else {
        configManager.setKeyNov7thFunc(CIFEffectKEY, openflag);
    }
    configManager.flushNov7thFunc();
};
var lgetSoundVolumnNov7thFunc = function(isMusic) {
    let toVolumn;
    if (isMusic) {
        toVolumn = configManager.getKeyNov7thFunc(CIFMusicVolKEY, "1");
    } else {
        toVolumn = configManager.getKeyNov7thFunc(CIFEffectVolKEY, "1");
    }
    return parseFloat(toVolumn);
};
var lsetSoundVolumnNov7thFunc = function(isMusic, volumn) {
    if (volumn < 0) volumn = 0;
    if (volumn > 1.0) volumn = 1.0;
    let toVolumn = "" + volumn;
    if (isMusic) {
        configManager.setKeyNov7thFunc(CIFMusicVolKEY, toVolumn);
    } else {
        configManager.setKeyNov7thFunc(CIFEffectVolKEY, toVolumn);
    }
    configManager.flushNov7thFunc();
};
///////////////////////////////////////////////////////////////////////////
//用于操控音效的声音大小
var lsetAllEffectVolumnNov7thFunc = function(volumn) {
    for (let id in mAllEffectTab) {
        cc.audioEngine.setVolume(id, volumn);
    }
};
var lplayBeginEffectNov7thFunc = function(voiceid) {
    mAllEffectTab[voiceid] = 0;
};
var lplayFinishEffectNov7thFunc = function(voiceid) {
    mAllEffectTab[voiceid] = null;
};
var exIsOpenMusicBK = true;
var exIsOpenEffectBK = true;
///////////////////////////////////////////////////////////////////////////
module.exports = {
    _musicVolume: 1.0,
    _effectVolume: 1.0,

    _musicPlayID: -1,
    _musicPath: null,


    _voiceRecord: null,
    /////////////////////////////////////////////////////////////////////////
    getVoiceRecordNov7thFunc() {
        if (!this._voiceRecord) {
            this._voiceRecord = nativeVoice;
            this._voiceRecord.initNov7thFunc(this);
        }
        return this._voiceRecord;
    },
    //加载并播放音乐
    //url以"asset/resources/"为相对路径
    //callback在播放开始回调，参数为路径
    //isMustPlay是否必须播放
    playMusicNov7thFunc(url, bMustPlay, callback) {
        cc.log("===playMusicNov7thFunc====111======SoundManagerNov7th===", url);
        if (!url || bMustPlay && !lisSoundOpenNov7thFunc(true)) return;
        cc.log("====playMusicNov7thFunc===222======SoundManagerNov7th===", url);
        let self = this;
        cc.loader.loadRes(url, (err, path) => {
            self.stopMusicNov7thFunc();
            cc.log("====playMusicNov7thFunc===333======SoundManagerNov7th===", path);
            if (bMustPlay || lisSoundOpenNov7thFunc(true)) {
                cc.log("====playMusicNov7thFunc===444======SoundManagerNov7th===", path);
                self._musicPlayID = cc.audioEngine.play(path, true, self._musicVolume);
                //fix engine bug
                cc.audioEngine.setVolume(self._musicPlayID, self._musicVolume);
            }
            if (callback) callback(path);
        });
    },
    //加载并播放音效
    //url以"asset/resources/"为相对路径
    //callback在播放开始回调，参数一为路径，参数二为总时长
    //isMustPlay是否必须播放
    playEffectNov7thFunc(url, bMustPlay, callback) {
        cc.log("===playEffectNov7thFunc====111======SoundManagerNov7th===", url);
        if (!url || bMustPlay && !lisSoundOpenNov7thFunc(false)) return;
        cc.log("====playEffectNov7thFunc===222======SoundManagerNov7th===", url);
        let self = this;
        cc.loader.loadRes(url, (err, path) => {
            let durt = 0;
            cc.log("====playEffectNov7thFunc===333======SoundManagerNov7th===", path);
            if (bMustPlay || lisSoundOpenNov7thFunc(false)) {
                cc.log("====playEffectNov7thFunc===444======SoundManagerNov7th===", path, self._effectVolume);
                if (self._effectVolume > 0) {
                    let audioId = cc.audioEngine.play(path, false, self._effectVolume);
                    lplayBeginEffectNov7thFunc(audioId);
                    cc.audioEngine.setFinishCallback(audioId, function() {
                        lplayFinishEffectNov7thFunc(audioId);
                    });
                    durt = cc.audioEngine.getDuration(audioId);
                }
            }
            if (callback) callback(path, durt);
        });
    },
    //0~1.0之间
    setEffectVolumeNov7thFunc(v) {
        this._effectVolume = v;
        lsetSoundVolumnNov7thFunc(this._effectVolume);
        lsetAllEffectVolumnNov7thFunc(this._effectVolume);
    },
    getEffectVolumeNov7thFunc() {
        return this._effectVolume;
    },

    //0~1.0之间
    setMusicVolumeNov7thFunc(v) {
        this._musicVolume = v;
        lsetSoundVolumnNov7thFunc(this._musicVolume);
        if (this._musicPlayID < 0) return;
        cc.audioEngine.setVolume(this._musicPlayID, v);
    },
    getMusicVolumeNov7thFunc() {
        return this._musicVolume;
    },

    setMusicOpenNov7thFunc(isOpen) {
        if (!isOpen) this.stopMusicNov7thFunc();
        lsetSoundOpenNov7thFunc(true, isOpen);
    },
    setEffectOpenNov7thFunc(isOpen) {
        lsetSoundOpenNov7thFunc(false, isOpen);
    },
    isMusicOpenNov7thFunc() {
        return lisSoundOpenNov7thFunc(true);
    },
    isEffectOpenNov7thFunc() {
        return lisSoundOpenNov7thFunc(false);
    },
    //打断，唤醒，如用于播放语音时候
    stopAllNov7thFunc() {
        //备份状态
        exIsOpenMusicBK = lisSoundOpenNov7thFunc(true);
        exIsOpenEffectBK = lisSoundOpenNov7thFunc(false);
        cc.log("=======stopAllNov7thFunc===========", exIsOpenEffectBK, exIsOpenMusicBK);
        lsetSoundOpenNov7thFunc(false, false);
        lsetSoundOpenNov7thFunc(true, false);
        cc.audioEngine.pauseAll();
    },

    openAllNov7thFunc() {
        //恢复状态
        cc.log("=======openAllNov7thFunc===========", exIsOpenEffectBK, exIsOpenMusicBK);
        lsetSoundOpenNov7thFunc(false, exIsOpenEffectBK);
        lsetSoundOpenNov7thFunc(true, exIsOpenMusicBK);
        cc.audioEngine.resumeAll();
    },
    //清空关闭
    clearAllNov7thFunc() {
        this._musicPlayID = -1;
        cc.audioEngine.stopAll();
    },
    stopMusicNov7thFunc() {
        if (this._musicPlayID >= 0) {
            cc.audioEngine.stop(this._musicPlayID);
        }
        this._musicPlayID = -1;
    },
    preload(url, callback) {
        cc.audioEngine.preload(path, callback);
    },
    /////////////////////////////////////
};