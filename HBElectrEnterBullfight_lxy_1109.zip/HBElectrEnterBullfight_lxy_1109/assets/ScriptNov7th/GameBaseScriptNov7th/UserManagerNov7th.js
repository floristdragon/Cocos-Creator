let UserInfo = require("UserInfoNov7th");

let lAllUserIDTab = {};
module.exports = {
    m_SelfUserInfo: null,
    //isSelfInfo表示是否是客户端自己的用户信息
    newUserNov7thFunc(userid, username, isSelfInfo) {
        let userinfo = new UserInfo(userid, username);
        this._addUserNov7thFunc(userinfo);
        if (isSelfInfo) this.m_SelfUserInfo = userinfo;
        return userinfo;
    },
    //添加或者重置用户信息表
    _addUserNov7thFunc(userinfo) {
        lAllUserIDTab[userinfo.getUserIdNov7thFunc()] = userinfo;
    },
    //移除用户信息
    removeUserNov7thFunc(userid) {
        let userinfo = getUserInfoByIdNov7thFunc(userid);
        lAllUserIDTab[userinfo.getUserIdNov7thFunc()] = nil;
    },
    clearAllUserNov7thFunc() {
        lAllUserIDTab = {};
    },
    //通过用户ID获取用户信息
    getUserInfoByIdNov7thFunc(userid) {
        if (!userid || userid <= 0) return;
        return lAllUserIDTab[userid]
    },
    //获取自己的userinfo
    getSelfUserInfoNov7thFunc() {
        return this.m_SelfUserInfo;
    },
    getSelfUserIdNov7thFunc() {
        if (this.m_SelfUserInfo) return this.m_SelfUserInfo.getUserIdNov7thFunc();
    },
    //是否是自己
    IsSelfUserInfoNov7thFunc(userinfo) {
        if (!userinfo) return false;
        return this.m_SelfUserInfo.getUserIdNov7thFunc() == userinfo.getUserIdNov7thFunc();
    },
    IsSelfUserIdNov7thFunc(userid) {
        if (!userid) return false;
        return this.m_SelfUserInfo.getUserIdNov7thFunc() == userid;
    },
}