module.exports = {
    _allitemtab: {},
    updateItemNov7thFunc(itemid, count) {
        itemid = Math.floor(parseInt(itemid) / 1000);
        this._allitemtab[itemid] = count;
    },

    getItemNov7thFunc(itemid) {
        itemid = parseInt(itemid);
        return this._allitemtab[itemid];
    },
    getGoldNov7thFunc() {
        if (!this._allitemtab[1001]) return 0;
        return this._allitemtab[1001];
    },
};