//var utilbase64 = require("utilBase64Nov7th");
var globalConfig = require("globalConfig");

var exSecretkey = 'open_fwclient'; // 加密密钥
var exConfigKey = "ConfigManager_local";

var exLocalConfPath = "";
var exConfigDataTab = null;
var fwriteStorageTabNov7thFunc = function(datatab) {
    if (!datatab) return;
    let stringdata = JSON.stringify(datatab);
    //js.fileUtils().writeStringToFile(stringdata, exLocalConfPath);
    var encrypted = stringdata; //utilEncryptJS.encryptWithAES(stringdata,exSecretkey,256);
    cc.sys.localStorage.setItem(exConfigKey, encrypted);
};
var freadStorageTabNov7thFunc = function() {
    // exLocalConfPath = jsb.fileUtils().getWritablePath() + "userconfig";
    // let datastr = jsb.fileUtils().getStringFromFile(exLocalConfPath);
    let datastr = cc.sys.localStorage.getItem(exConfigKey);
    if (datastr && datastr != "") {
        //return JSON.parse(utilEncryptJS.decryptWithAES(cipherText,exSecretkey));
        return JSON.parse(datastr);
    }
    return {};
};
module.exports = {
    ////////////////////////////////////////////////////
    //用户读写本地数据
    _checkLoadConfigNov7thFunc() {
        if (!exConfigDataTab) {
            exConfigDataTab = freadStorageTabNov7thFunc();
        }
    },
    getGlobalConfigNov7thFunc(key) {
        return globalConfig[key];
    },
    getHotFixVersionNov7thFunc() {
        let cifVersion = this.getKeyNov7thFunc("CIFHotFixVersion", "0");
        let curVersion = this.getGlobalConfigNov7thFunc("HotFixVersion");
        let toVersion;
        do {
            if (!cifVersion) {
                toVersion = curVersion; //如果没有写配置，则用代码里面的配置
                break;
            }
            if (curVersion > cifVersion) {
                toVersion = curVersion; //如果代码里面配置比本地配置高，则用高版本
                break;
            }
            toVersion = cifVersion; //否则用本地配置版本
        } while (0);
        return toVersion;
    },
    setHotFixVersionNov7thFunc(version) {
        this.setKeyNov7thFunc("CIFHotFixVersion", version + "");
        this.flushNov7thFunc();
    },
    getKeyNov7thFunc(key, defaultData) {
        this._checkLoadConfigNov7thFunc();
        if (!exConfigDataTab[key]) {
            exConfigDataTab[key] = defaultData;
        }
        return exConfigDataTab[key];
    },

    setKeyNov7thFunc(key, data, autoflushNov7thFunc) {
        console.log("======g_ConfigManager==setKeyNov7thFunc===========", key, data);
        this._checkLoadConfigNov7thFunc();
        exConfigDataTab[key] = data;
        if (autoflushNov7thFunc) {
            this.flushNov7thFunc();
        }
    },

    flushNov7thFunc() {
        fwriteStorageTabNov7thFunc(exConfigDataTab);
    },
    /////////////////////////////////////////////////////////////////////////
    //登陆相关
    setLoginAccountNov7thFunc(account, pwd) {
        this.setKeyNov7thFunc("TLOGINACCOUNT", account);
        this.setKeyNov7thFunc("TLOGINPWD", pwd);
        this.flushNov7thFunc();
    },
    getLoginAccountNov7thFunc() {
        let loginAcc = this.getKeyNov7thFunc("TLOGINACCOUNT", "")
        let loginPwd = this.getKeyNov7thFunc("TLOGINPWD", "")
        return [loginAcc, loginPwd];
    },
    setIsAlreadyLoginNov7thFunc(flag) {
        this.m_bIsAlreadyLogin = flag;
    },
    getIsAlreadyLoginNov7thFunc() {
        return this.m_bIsAlreadyLogin;
    },
    checkIsCanLoginLobbyNov7thFunc(maxWait) {
        if (!this.m_iLoginLobbyFlag) {
            this.m_iLoginLobbyFlag = 0;
        }
        this.m_iLoginLobbyFlag = this.m_iLoginLobbyFlag + 1;
        return this.m_iLoginLobbyFlag == maxWait;
    },
    resetIsCanLoginLobbyNov7thFunc() {
        this.m_iLoginLobbyFlag = 0;
    },
}