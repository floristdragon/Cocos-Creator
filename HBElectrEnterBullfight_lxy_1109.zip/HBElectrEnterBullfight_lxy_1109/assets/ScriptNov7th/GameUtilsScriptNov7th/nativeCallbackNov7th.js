
module.exports = {
    savePhotoCall(){

    },
};