cc.Class({
    extends: cc.Component,

    properties: {
        _seatNo : 0,
        _handCardHandler : null,
    },
    onLoad(){
        //this.resetUiNov7thFunc();
    },
    initUiNov7thFunc(seatNo){
        this._seatNo = seatNo;

        this._handCardHandler = this.getComponent("ui-bullfightHandCardNov7th");
        this._handCardHandler.initUiNov7thFunc(this._seatNo);

        this.resetUiNov7thFunc();
        cc.log("=========player===initUiNov7thFunc===========", seatNo, g_WRDNGameData.getSelfSeatNoNov7thFunc());
    },
    resetUiNov7thFunc(){
        this.speekNothingNov7thFunc();
        this.showNiuTypeTipNov7thFunc(false);
        this.showUserInfoNov7thFunc(false);
        this.showBankerTipNov7thFunc(false);
        this.showTotalScoreNov7thFunc(false,0);
        this.showTimeWaitTipNov7thFunc(false);
        this.showTuoGuanNov7thFunc(false);
        this.showReadyTipNov7thFunc(false);
        this.showWaitStartTipNov7thFunc(false);
        this._handCardHandler.resetUiNov7thFunc();
    },
    getSeatNoNov7thFunc(){
        return this._seatNo;
    },
    getHandCardNov7thFunc(){
        return this._handCardHandler;
    },
    getHandCardPosNov7thFunc(){
        let toNode = this.node.getChildByName("handcard");
        return toNode.convertToWorldSpaceAR(cc.Vec2.ZERO);
    },
    showUserInfoNov7thFunc(isVisible, name, score, headurl){
        let nameNode = this.node.getChildByName("name");
        let scoreNode = this.node.getChildByName("score");
        let faceNode = this.node.getChildByName("playerface");
        nameNode.active = isVisible;
        scoreNode.active = isVisible;
        faceNode.active = isVisible;
        if(!isVisible) return ;
        cc.log("=======showUserInfoNov7thFunc=======", name, score, headurl);
        if(!name) name = "";
        if(!score) score = "0";
        let nametext = nameNode.getComponent(cc.RichText);
        let scoretext = scoreNode.getComponent(cc.RichText);
        nametext.string = name;
        scoretext.string = score+"";

        faceNode.scaleY = 1;
        faceNode.scaleX = 1;
        if (headurl && headurl.length > 0) {
            let toSprite = faceNode.getComponent(cc.Sprite);
            let toType = "png";
            if(headurl.indexOf(".jpg")){
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },
    showBankerTipNov7thFunc(isDiZhu){
        let tipNode = this.node.getChildByName("dizhutip");
        tipNode.active = isDiZhu;
    },
    showTotalScoreNov7thFunc(isVisible, totalscore){
        let tipNode = this.node.getChildByName("totalscore");
        tipNode.active = isVisible;
        if(!isVisible) return;
        tipNode.setLocalZOrder(100);
        let ctext = tipNode.getComponent(cc.Label);
        if(!totalscore) totalscore = "0";
        ctext.string = totalscore+"";
    },
    showWaitStartTipNov7thFunc(isVisible){
        let tipNode = this.node.getChildByName("waitstarttip");
        tipNode.active  = isVisible;
    },
    showTimeWaitTipNov7thFunc(isVisible){
        if(this._seatNo==g_WRDNGameData.getSelfSeatNoNov7thFunc()) isVisible = false;
        let tipNode = this.node.getChildByName("timewaittip");
        tipNode.active  = isVisible;
    },
    showTuoGuanNov7thFunc(istuoguan){
        let tipNode = this.node.getChildByName("tuoguantip");
        tipNode.active  = istuoguan;
    },
    showReadyTipNov7thFunc(isVisible){
        let tipNode = this.node.getChildByName("readytip");
        tipNode.active  = isVisible;
    },
    showNiuTypeTipNov7thFunc(isVisible, niutype){
        cc.log("====showNiuTypeTipNov7thFunc=====", isVisible, niutype, this._seatNo);
        let tipNode = this.node.getChildByName("niutypetip");
        tipNode.active = isVisible;
        if(!isVisible) return;
        let loadurl = "BullfightResNov7th/bullfightTipNov7th/tipBullfight_"+niutype;
        let spNode = tipNode.getComponent(cc.Sprite);
        cc.loader.loadRes(loadurl, function(err, texture){
            spNode.spriteFrame = new cc.SpriteFrame(texture);
        });
    },
    /////////////////////////////////////////////////////////
    _priSpeakThingNov7thFunc(str, beilv){
        let loadurl = "BullfightResNov7th/speakTipResNov7th/"+str;
        let tipNode = this.node.getChildByName("speaktip");
        tipNode.active = true;
        let spNode = tipNode.getComponent(cc.Sprite);
        cc.loader.loadRes(loadurl, function(err, texture){
            spNode.spriteFrame = new cc.SpriteFrame(texture);
        });
        let tipChildNode = tipNode.getChildByName("tip");
        tipChildNode.active = false;
        if(beilv){
            let totipurl = "BullfightResNov7th/rateBtnNov7th/tipRateNov7th_";
            if(beilv<=5){
                totipurl += beilv;
            }else if(beilv==10){
                totipurl += 6;
            }else if(beilv==15){
                totipurl += 7;
            }
            cc.loader.loadRes(totipurl, function(err, texture){
                tipChildNode.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
            });
            tipChildNode.active = true;
        }
    },
    speekNothingNov7thFunc(){
        let tipNode = this.node.getChildByName("speaktip");
        tipNode.active = false;
    },
    speekBuQiangNov7thFunc(){
        this._priSpeakThingNov7thFunc("speak-buqiang");
    },
    speekQiangZhuangNov7thFunc(beilv){
        this._priSpeakThingNov7thFunc("speak-qiangz", beilv);
    },
    speekDingZhuangNov7thFunc(beilv){
        this._priSpeakThingNov7thFunc("speak-dingz", beilv);
    },
    speekYouNiuNov7thFunc(){
        this._priSpeakThingNov7thFunc("speak-youniu");
    },
});
