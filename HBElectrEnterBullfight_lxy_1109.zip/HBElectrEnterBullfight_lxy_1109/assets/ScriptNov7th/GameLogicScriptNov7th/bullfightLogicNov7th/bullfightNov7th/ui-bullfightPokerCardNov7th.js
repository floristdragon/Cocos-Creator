cc.Class({
    extends: cc.Component,

    properties: {
        O_touchcard : cc.Node,

        _cardValue : 0,
        _backPosition : null,
    },

    // use this for initialization
    onLoad: function () {
        this._backPosition = new cc.Vec2(this.O_touchcard.position.x, this.O_touchcard.position.y);
    },
    setCardScaleNov7thFunc(scale){
        this.node.scale = scale;
    },
    setCardWidthNov7thFunc(width){
        this.node.width = width;
    },
    setCardHeightNov7thFunc(height){
        this.node.height = height;
    },
    setCardValueNov7thFunc(value){
        let self = this;
        cc.log("========setCardValueNov7thFunc============", value);
        if(!value) value = -1;
        this._cardValue = value;
        let toSpUrl 
        if(false){
            toSpUrl = g_WRDNGameData.getRangPokerFramePathNov7thFunc(true);
        }else{
            toSpUrl = g_WRDNGameData.getPokerFramePathNov7thFunc(true, this._cardValue, true);
        }
        var texture = cc.textureCache.addImage(toSpUrl);
        let toSprite = self.O_touchcard.getComponent(cc.Sprite);
        toSprite.spriteFrame = new cc.SpriteFrame(texture);
        // cc.loader.loadRes(toSpUrl, function(err, texture){
        //     toSprite.spriteFrame = new cc.SpriteFrame(texture);
        // });
    },
    getCardValueNov7thFunc(){
        return this._cardValue;
    },

    onChceckTouchEndNov7thFunc(touchPos){
        if(this.priIsTouchInCardNov7thFunc(touchPos)){
            
            return true;
        }
        return false;
    },
    recoverCardNov7thFunc(cardvalue){
        if(this._cardValue>0) return ;
        let self = this;
        let toRotateFunc = ()=>{
            cc.log("====toRotateFunc=========", cardvalue);
            self.setCardValueNov7thFunc(cardvalue);
        };
        this.O_touchcard.stopAllActions();
        this.O_touchcard.runAction(cc.sequence(cc.scaleTo(0.3, 0, 1), cc.callFunc(toRotateFunc, this), 
            cc.scaleTo(0.3, 1, 1)));
    },
    ////////////////////////////////////////////////////////////////////////
    priIsTouchInCardNov7thFunc(touchPos){
        let toPos = this.O_touchcard.convertToNodeSpace(touchPos);
        let toRect = new cc.Rect(0, 0, this.O_touchcard.width, this.O_touchcard.height);
        //cc.log("======priIsTouchInCardNov7thFunc====111=====", toPos, toRect);
        if(toRect.contains(toPos)){
            //cc.log("======priIsTouchInCardNov7thFunc====222=====");
            return true;
        }
        return false;
    },
});
