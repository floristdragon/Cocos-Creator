cc.Class({
    extends: cc.Component,

    properties: {
        O_jiesannode: cc.Node,
        O_leavenode: cc.Node,
        O_musicToggle: cc.Toggle,
        O_effectToggle: cc.Toggle,

        _isCheckToggleClick: true,
    },

    // use this for initialization
    onLoad() {
        let roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        let ownerUserId = roominfo.getOwnerUserIdNov7thFunc();
        let selfSeatNo = g_WRDNGameData.getSelfSeatNoNov7thFunc();
        let selfUserId = roominfo.getUserInfoNov7thFunc(selfSeatNo).userId;

        this.O_jiesannode.active = false;
        this.O_leavenode.active = false;
        if (ownerUserId == selfUserId) {
            this.O_jiesannode.active = true;
        } else {
            this.O_leavenode.active = true;
        }

        this._isCheckToggleClick = false;
        if (g_SoundManager.isMusicOpenNov7thFunc()) {
            this.O_musicToggle.check();
        } else {
            this.O_musicToggle.uncheck();
        }
        if (g_SoundManager.isEffectOpenNov7thFunc()) {
            this.O_effectToggle.check();
        } else {
            this.O_effectToggle.uncheck();
        }
        this._isCheckToggleClick = true;
    },

    onMusicToggleClickNov7thFunc(toggle) {
        cc.log("================onMusicToggleClickNov7thFunc======================", toggle, toggle.isChecked)
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setMusicOpenNov7thFunc(true);
            g_WRDNGameData.playBackgroundMusicNov7thFunc();
        } else {
            g_SoundManager.setMusicOpenNov7thFunc(false);
        }
    },

    onEffectClickNov7thFunc(toggle) {
        cc.log("==========================onEffectClickNov7thFunc===============", toggle, toggle.isChecked);
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setEffectOpenNov7thFunc(true);
        } else {
            g_SoundManager.setEffectOpenNov7thFunc(false);
        }
    },

    onCloseClickNov7thFunc() {
        this.node.destroy();
    },

    onLeaveClickNov7thFunc() {
        let toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIdNov7thFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIdNov7thFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqLeaveDesk, toProtTab);
        this.onCloseClickNov7thFunc();
    },
    onJieSanClickNov7thFunc() {
        let toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIdNov7thFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIdNov7thFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqJieSanDesk, toProtTab);
        this.onCloseClickNov7thFunc();
    },

    // called every frame, uncomment this function to activate update callback
    // update(dt) {

    // },
});