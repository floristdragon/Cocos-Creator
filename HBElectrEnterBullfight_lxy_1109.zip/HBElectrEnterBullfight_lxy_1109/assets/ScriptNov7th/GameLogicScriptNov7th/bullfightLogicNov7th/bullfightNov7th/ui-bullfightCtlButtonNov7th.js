cc.Class({
    extends: cc.Component,

    properties: {
        O_controlbtnnode : cc.Node,
        O_dingzhuangbtnnode : cc.Node,

        O_buqiangbtnnode : cc.Node,
    },

    // use this for initialization
    onLoad: function () {
    },
    hideAllButtonNov7thFunc : function(){
        this.O_controlbtnnode.active = false;
        this.O_dingzhuangbtnnode.active = false;
    },
    showControlShowBtnNov7thFunc : function(){
        this.hideAllButtonNov7thFunc();
        this.O_controlbtnnode.active = true;
    },
    showDingZhuangBtnNov7thFunc : function(){
        this.hideAllButtonNov7thFunc();
        this.O_dingzhuangbtnnode.active = true;
        
        if(!g_WRDNGameData.isQiangZhuangConfNov7thFunc()){
            this.O_buqiangbtnnode.active = false;
        }
    },
    ////////////////////////////////////////////////////
    onDingZBeiBtnNov7thFunc : function(event, detail){
        cc.log("============onDingZBeiBtnNov7thFunc=========", event, detail);
        let toProtData = {};
        toProtData.beilv = detail
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_DouNiuWuRen, g_ProtDef.ADouNiuWuRen_C2SQiangZhuang, toProtData);
    },
    onMeiNiuBtnNov7thFunc : function(event){
        let toProtData = {};
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_DouNiuWuRen, g_ProtDef.ADouNiuWuRen_C2SShowCard, toProtData);
    },
    onYouNiuBtnNov7thFunc : function(event){
        let toProtData = {};
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_DouNiuWuRen, g_ProtDef.ADouNiuWuRen_C2SShowCard, toProtData);
    },
    onQuanBuFanpaiBtnNov7thFunc : function(event){
        this.node.emit("ctlbtn-quanbufanpai");
    },
    
});
