require("include");
let gameconfig = require("gameConfigNov7th");
let GameRuleConfig = require("DouNiuRuleConfigNov7th");

//在两个数之间随机一个整数
var MathRandomNov7thFunc = function(min, max) {
    if (min > max) return min;
    let to = Math.random() * (max - min) + min;
    let toi = Math.floor(to);
    if (to < toi + 0.5) return toi;
    return toi + 1;
};
window.g_WRDNGameData = {
    _gameId: 0,
    _roomId: 0,

    _playerUIArray: [],
    _seatToUIArray: [],
    _gameplayArray: [],

    _selfSeatNo: 0,

    _handCardTab: [],
    _handTypeTab: [],
    _tuoguanTab: [],
    _bankerSeatNo: -1,
    _dingzbeilv: 0,

    _ishandcardSort: false,
    //------------------------------------
    //------------------------------------
    initNov7thFunc(gameId, roomId, selfSeatNo) {
        this._gameId = gameId;
        this._roomId = roomId;
        this._selfSeatNo = selfSeatNo;
        this.resetInitNov7thFunc();
    },
    resetInitNov7thFunc() {
        this._handCardTab = [];
        this._handTypeTab = [];
        this._tuoguanTab = [];
        this._bankerSeatNo = -1;
        this._gameplayArray = [];

        this._ishandcardSort = false;
    },
    //---------------------------------------------------------------
    isBaZhuangConfNov7thFunc() {
        let tconfig = this.getRoomInfoNov7thFunc().getRoomConfigNov7thFunc();
        return tconfig.zhuangflag == 1;
    },
    isLunZhuangConfNov7thFunc() {
        let tconfig = this.getRoomInfoNov7thFunc().getRoomConfigNov7thFunc();
        return tconfig.zhuangflag == 2;
    },
    isQiangZhuangConfNov7thFunc() {
        let tconfig = this.getRoomInfoNov7thFunc().getRoomConfigNov7thFunc();
        return tconfig.zhuangflag != 1 && tconfig.zhuangflag != 2;
    },
    setPlayerUiNov7thFunc(playerui, index, seatNo) {
        this._playerUIArray[index] = playerui;
        this._seatToUIArray[seatNo] = index;
    },
    getPlayerUiBySeatNoNov7thFunc(seatNo) {
        let index = this._seatToUIArray[seatNo];
        return this._playerUIArray[index];
    },
    getPlayerUiByUserIdNov7thFunc(userId) {
        let roominfo = this.getRoomInfoNov7thFunc();
        let seatNo = roominfo.findUserSeatNoNov7thFunc(userId);
        return this.getPlayerUiBySeatNoNov7thFunc(seatNo);
    },
    setIsGamePlayNov7thFunc(seatNo, flag) { //1表示在玩，其他表示不在玩
        this._gameplayArray[seatNo] = flag;
    },
    getIsGamePlayNov7thFunc(seatNo) {
        if (!this._gameplayArray[seatNo]) return false;
        return this._gameplayArray[seatNo] == 1;
    },
    ///////////////////////////////////////////////////
    getSelfSeatNoNov7thFunc() {
        return this._selfSeatNo;
    },
    getNextSeatNoNov7thFunc(curSeatNo) {
        if (curSeatNo == null) curSeatNo = this._selfSeatNo;
        let maxPeople = this.getMaxPlayerNov7thFunc();
        curSeatNo = curSeatNo + 1;
        if (curSeatNo >= maxPeople) curSeatNo = 0; //下标从0开始
        return curSeatNo;
    },
    getLastSeatNoNov7thFunc(curSeatNo) {
        if (curSeatNo == null) curSeatNo = this._selfSeatNo;
        let maxPeople = this.getMaxPlayerNov7thFunc();
        curSeatNo = curSeatNo - 1;
        if (curSeatNo < 0) curSeatNo = maxPeople;
        return curSeatNo;
    },
    ////////////////////////////////////////////////////
    setBankerSeatNoNov7thFunc(seatNo) {
        this._bankerSeatNo = seatNo;
    },
    getBankerSeatNoNov7thFunc() {
        return this._bankerSeatNo;
    },
    setDingZhuangBeiLvNov7thFunc(beilv) {
        this._dingzbeilv = beilv;
    },
    getDingZhuangBeiLvNov7thFunc() {
        return this._dingzbeilv;
    },
    ////////////////////////////////////////////////////
    getRoomInfoNov7thFunc() {
        return g_RoomManager.getGameRoomInfoNov7thFunc(this._gameId, this._roomId);
    },
    getGameIdNov7thFunc() {
        return this._gameId;
    },
    getRoomIdNov7thFunc() {
        return this._roomId;
    },
    //------------------------------------
    getMaxPlayerNov7thFunc() {
        if (!this._gameId) this._gameId = g_ProtDef.MID_Protocol_DouNiuWuRen;
        console.log("====getMaxPlayerNov7thFunc===========", gameconfig, this._gameId, g_ProtDef.MID_Protocol_DouNiuWuRen);
        return gameconfig[this._gameId].maxPlayer;
    },
    //------------------------------------
    setHandCardTypeNov7thFunc(seatNo, htype) {
        this._handTypeTab[seatNo] = htype;
    },
    getHandCardTypeNov7thFunc(seatNo) {
        return this._handTypeTab[seatNo];
    },
    setHandCardTabNov7thFunc(seatNo, cardtab, isCopy) {
        if (!cardtab) return;
        let toTab = cardtab;
        if (isCopy) {
            toTab = [];
            for (let i = 0; i < cardtab.length; i++) {
                toTab[i] = cardtab[i];
            }
        }
        this._handCardTab[seatNo] = toTab;
        this._setHandCardSortNov7thFunc(this._ishandcardSort);
    },
    _setHandCardSortNov7thFunc(isSort) {
        this._ishandcardSort = isSort;
        if (this._ishandcardSort) {
            let sortNov7thFunc = (a, b) => {
                if (a > b) return -1;
                return 1;
            };
            for (let i = 0; i < this.getMaxPlayerNov7thFunc(); i++) {
                if (this._handCardTab[i]) {
                    this._handCardTab[i].sort(sortNov7thFunc);
                }
            }
        }
    },
    addHandCardTabNov7thFunc(seatNo, cardtab) {
        if (!this._handCardTab[seatNo]) this._handCardTab[seatNo] = {};
        for (let i = 0; i < cardtab.length; i++) {
            this._handCardTab[seatNo].push(cardtab[i]);
        }
        this._setHandCardSortNov7thFunc(this._ishandcardSort);
    },
    getHandCardTabNov7thFunc(seatNo, isCopy) {
        let toTab = [];
        if (isCopy) {
            if (this._handCardTab[seatNo]) {
                for (let i = 0; i < this._handCardTab[seatNo].length; i++) {
                    toTab[i] = this._handCardTab[i];
                }
            }
        } else {
            toTab = this._handCardTab[seatNo];
        }
        console.log("========getHandCardTabNov7thFunc===========", seatNo, toTab);
        return toTab;
    },
    getHandCardCountNov7thFunc(seatNo) {
        if (!this._handCardTab[seatNo]) return 0;
        return this._handCardTab[seatNo].length;
    },
    removeCardTabNov7thFunc(seatNo, rmCardTab) {
        let toHandTab = this._handCardTab[seatNo];
        let removeNum = 0;
        for (let i = 0; i < rmCardTab.length; i++) {
            for (let j = 0; j < toHandTab.length; j++) {
                if (toHandTab[j] == rmCardTab[i]) {
                    toHandTab.splice(j, 1);
                    removeNum++;
                    break;
                }
            }
        }
        cc.log("=====removeCardTabNov7thFunc=======", toHandTab);
        return removeNum;
    },
    //------------------------------------
    //--托管
    setTuoGuanNov7thFunc(seatNo, bTuoGuan) {
        this._tuoguanTab[seatNo] = bTuoGuan;
    },
    isTuoGuanNov7thFunc(seatNo) {
        return this._tuoguanTab[seatNo];
    },
    //////////////////////////////////////////////
    //value为空，表示背牌
    getPokerFramePathNov7thFunc(isBigPoker, value, bRawPath) {
        let topath = "BullfightResNov7th/poker-small/small_";
        if (isBigPoker) {
            topath = "BullfightResNov7th/bigPokerResNov7th/bigPoker_";
        }
        do {
            if (!value || value <= 0) {
                topath = topath + "cardback";
                break;
            }
            let cindex = GameRuleConfig.GetCardIndex(value);
            if (cindex == GameRuleConfig.CardType.XiaoWangID) {
                topath = topath + "xiaowang";
                break;
            } else if (cindex == GameRuleConfig.CardType.DaWangID) {
                topath = topath + "dawang";
                break;
            }
            let ccolor = GameRuleConfig.GetCardColor(value);
            topath += ccolor;
            topath += "_";
            topath += cindex;
        } while (0);
        if (bRawPath) {
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },
    getRangPokerFramePathNov7thFunc(bRawPath) {
        let topath = "BullfightResNov7th/bigPokerResNov7th/bigPoker_rangpai";
        if (bRawPath) {
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },
    //////////////////////////////////////////////////////////////////
    playBackgroundMusicNov7thFunc() {
        g_SoundManager.playMusicNov7thFunc("BullfightResNov7th/soundResNov7th/musicResNov7th/bg");
    },
    _getCardIdIndexNov7thFunc(value) {
        let cindex = GameRuleConfig.GetCardIndex(value);
        if (cindex == GameRuleConfig.CardType.XiaoWangID) {
            return cindex;
        } else if (cindex == GameRuleConfig.CardType.DaWangID) {
            return cindex;
        }
        if (cindex <= GameRuleConfig.CardType.KID) {
            cindex += 2;
        } else if (cindex == GameRuleConfig.CardType.ErID) {
            cindex = 2;
        } else if (cindex == GameRuleConfig.CardType.YiID) {
            cindex = 1;
        }
        return cindex;
    },
    _getBaseEffectPathNov7thFunc(userId) {
        let userinfo = this.getRoomInfoNov7thFunc().getUserInfoByUserIdNov7thFunc(userId);
        if (!userinfo) return;
        let effectpath = "BullfightResNov7th/soundResNov7th/effectResNov7th/";
        if (userinfo.isBoy == 1) {
            effectpath += "boySoundRes/";
        } else {
            effectpath += "girlSoundRes/";
        }
        return effectpath;
    },
    playGameStartNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("BullfightResNov7th/soundResNov7th/effectResNov7th/gameStartSound");
    },
    playSendCardNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("BullfightResNov7th/soundResNov7th/effectResNov7th/sendCardSound");
    },
    playGameResultNov7thFunc(isWin) {
        if (isWin) {
            g_SoundManager.playEffectNov7thFunc("BullfightResNov7th/soundResNov7th/effectResNov7th/winSound");
        } else {
            g_SoundManager.playEffectNov7thFunc("BullfightResNov7th/soundResNov7th/effectResNov7th/failedSound");
        }
    },
    playCardTypeNov7thFunc(userId, ctype) {
        let topath = this._getBaseEffectPathNov7thFunc(userId);
        if (ctype <= GameRuleConfig.CardType.NiuNiu) {
            g_SoundManager.playEffectNov7thFunc(topath + "ctype" + ctype);
        }
    },
};