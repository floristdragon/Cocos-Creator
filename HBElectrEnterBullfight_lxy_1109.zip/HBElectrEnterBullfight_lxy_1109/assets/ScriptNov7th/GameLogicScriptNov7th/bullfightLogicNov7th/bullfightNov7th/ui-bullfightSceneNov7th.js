require("bullfightGameDataNov7th");

let STATUS_READY = 0 //准备
let STATUS_DINGZHUANG = 1 //抢庄
let STATUS_SENDCARD = 2 //发牌
let STATUS_SHOWCARD = 3 //摊牌
let STATUS_GAMEFINISH = 4 //游戏结束
cc.Class({
    extends: require("ui-roomSceneNov7th"),

    properties: {
        O_controlbtnprefab: cc.Prefab,
        O_gameresultprefab: cc.Prefab,

        O_userInfoPrefab: cc.Prefab,

        O_settingPrefab: cc.Prefab,

        //////////////////////////////////////
        _backgroundScipt: null,
        _ctlbuttonScript: null,
        _gameresultScript: null,
        _dispcardScript: null,

    },

    // use this for initialization
    onLoad: function() {
        this._super(); //调用父类的onLoad
        this.setChatRoomStateNov7thFunc(true);
        //背景音乐
        g_WRDNGameData.playBackgroundMusicNov7thFunc();

        let gameId = g_RoomManager.getCurGameIdNov7thFunc();
        let roomId = g_RoomManager.getCurRoomIdNov7thFunc();
        let selfUserId = g_UserManager.getSelfUserIdNov7thFunc();
        let roominfo = g_RoomManager.getGameRoomInfoNov7thFunc(gameId, roomId);

        let selfSeatNo = roominfo.findUserSeatNoNov7thFunc(selfUserId);
        g_WRDNGameData.initNov7thFunc(gameId, roomId, selfSeatNo);
        cc.log("=======wurendouniu==mainscene=11====", gameId, roomId, selfUserId);

        //////////////////////////////////////////////////////////
        this._cplayerArray = [];
        let maxPlayer = g_WRDNGameData.getMaxPlayerNov7thFunc();
        let toSeatNo = selfSeatNo;
        for (let i = 0; i < maxPlayer; i++) {
            let playerNo = i + 1;
            let playerNode = this.node.getChildByName("player" + playerNo);
            playerNode.setLocalZOrder(100);
            console.log("=====111111=======", toSeatNo, selfSeatNo, playerNo);
            let cplayerhandler = playerNode.getComponent("ui-bullfightPlayerNov7th");
            cplayerhandler.initUiNov7thFunc(toSeatNo, playerNode);
            g_WRDNGameData.setPlayerUiNov7thFunc(cplayerhandler, i, toSeatNo);

            toSeatNo = g_WRDNGameData.getNextSeatNoNov7thFunc(toSeatNo);
        };
        this._backgroundScipt = this.getComponent("ui-bullfightBackgroundNov7th");
        this._backgroundScipt.showBaseTipNov7thFunc();

        this._dispcardScript = this.getComponent("ui-bullfightDispcardNov7th");
        cc.log("=========wurendouniu==mainscene====22====", this._dispcardScript);
        /////////////////////////////////////////////////////////////////
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_DouNiuWuRen, null, this.onProtSocketMessageNov7thFunc, this);

        /////////////////////////////////////////////////////////////////
        //场景加载完毕，开始请求场景协议
        let toProtData = {};
        toProtData.gameId = g_WRDNGameData.getGameIdNov7thFunc();
        toProtData.roomId = g_WRDNGameData.getRoomIdNov7thFunc();
        cc.log("=========requestGameStatus===", toProtData);
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqGameStatus, toProtData);
    },
    onDestroyNov7thFunc() {
        cc.log("=============onDestroyNov7thFunc==============");
    },
    _resetAllUiNov7thFunc() {
        if (this._ctlbuttonScript) {
            this._getControlBtnNov7thFunc().hideAllButtonNov7thFunc();
        }
        if (this._gameresultScript) {
            this._getGameResultNov7thFunc().showResultNov7thFunc(false);
        }
        g_WRDNGameData.resetInitNov7thFunc();
        this._showReadyButtonNov7thFunc(false);
        this._backgroundScipt.showBaseTipNov7thFunc();
        this._backgroundScipt.showLeftClockNov7thFunc(false);
        this._backgroundScipt.showBaseBeiLvNov7thFunc(false);
        let roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        let maxPlayer = g_WRDNGameData.getMaxPlayerNov7thFunc();
        for (let i = 0; i < maxPlayer; i++) {
            let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
            playerui.resetUiNov7thFunc();

            let userinfo = roominfo.getUserInfoNov7thFunc(i);
            cc.log("======_resetAllUiNov7thFunc====111=======", i, userinfo);
            if (userinfo) {
                playerui.showUserInfoNov7thFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
            } else {
                playerui.showUserInfoNov7thFunc(false);
            }
        }
    },
    onRequestGameReadyNov7thFunc(delaytime) {
        cc.log("==========onRequestGameReadyNov7thFunc========", delaytime);
        let self = this;
        let readyNov7thFunc = function() {
            //在这里进入房间后要发协议，自己默认进入房间就准备
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_DouNiuWuRen, g_ProtDef.ADouNiuWuRen_C2SReady);
        };
        this._showReadyButtonNov7thFunc(false);
        if (typeof(delaytime) != 'number' || !delaytime || delaytime <= 0) {
            readyNov7thFunc();
        } else {
            this.scheduleOnce(readyNov7thFunc, delaytime);
        }
    },
    _showReadyButtonNov7thFunc(bVisible) {
        let readynode = this.node.getChildByName("readybtn");
        readynode.active = bVisible;
    },
    onSettingBtnNov7thFunc(event) {
        var settingPlane = cc.instantiate(this.O_settingPrefab);
        this.node.addChild(settingPlane, 1000);
    },
    onShowUserInfoPanelNov7thFunc(node, detail) {
        cc.log("========onShowUserInfoPanelNov7thFunc=========", node, detail);
        let seatNo = g_WRDNGameData.getSelfSeatNoNov7thFunc();
        if (detail == 2) {
            seatNo = g_WRDNGameData.getNextSeatNoNov7thFunc(seatNo);
        }
        let roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        if (roominfo.getUserInfoNov7thFunc(seatNo)) {
            var userInfoNode = cc.instantiate(this.O_userInfoPrefab);
            userInfoNode.parent = this.node;
            userInfoNode.setLocalZOrder(200);
            userInfoNode.getComponent("ui-bullfightUserInfoNov7th").showInfoNov7thFunc(seatNo);
        }
    },
    //////////////////////////////////////////////////////////////////////////////
    _getControlBtnNov7thFunc() {
        if (!this._ctlbuttonScript) {
            let ctrbtn = cc.instantiate(this.O_controlbtnprefab);
            ctrbtn.parent = this.node;
            ctrbtn.setLocalZOrder(150);
            this._ctlbuttonScript = ctrbtn.getComponent("ui-bullfightCtlButtonNov7th");
            ctrbtn.off("ctlbtn-quanbufanpai");
            ctrbtn.on("ctlbtn-quanbufanpai", (event) => {
                this._onShowCard_QuanBuFanPaiNov7thFunc();
            }, this);
        }
        return this._ctlbuttonScript;
    },
    _onShowCard_QuanBuFanPaiNov7thFunc() {
        cc.log("==========_onShowCard_QuanBuFanPaiNov7thFunc==============");
        let selfSeatNo = g_WRDNGameData.getSelfSeatNoNov7thFunc();
        let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(selfSeatNo);
        playerui.getHandCardNov7thFunc().recoverAllCardNov7thFunc();
    },
    _getGameResultNov7thFunc() {
        if (!this._gameresultScript) {
            let resultnode = cc.instantiate(this.O_gameresultprefab);
            resultnode.parent = this.node;
            resultnode.setLocalZOrder(200);
            this._gameresultScript = resultnode.getComponent("ui-bullfightGameResultNov7th");
        }
        return this._gameresultScript;
    },
    ////////////////////////////////////////////////////////////////////////////////
    onRecvErrcodeNov7thFunc(errcode, attachtab) {
        cc.log("=======onRecvErrcodeNov7thFunc============", errcode, attachtab);
        this.showPopupWindowNov7thFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },
    //其他玩家进入房间会调用这里, 进入房间协议比场景协议要先到来
    onRecvEnterRoomNov7thFunc(gameId, roomId, userId) {
        //let selfUserId = g_UserManager.getSelfUserIdNov7thFunc();
        let roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        let seatNo = roominfo.findUserSeatNoNov7thFunc(userId);
        let userinfo = roominfo.getUserInfoNov7thFunc(seatNo);
        let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(seatNo);
        cc.log("==============onRecvEnterRoomNov7thFunc==========", roomId, userId, typeof(userId), roominfo);
        playerui.showUserInfoNov7thFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
    },
    onRecvJieSanDeskNov7thFunc(gameId, roomId, userId, userName, isAuto) {
        cc.log("======onRecvJieSanDeskNov7thFunc==========", gameId, roomId, userId, userName, isAuto);
        if (!isAuto) {
            this.showPopupWindowNov7thFunc(true, false, "提示", "房主已经解散了房间！", (flag) => {
                this.switchLobbySceneNov7thFunc();
            }, this);
        } else {
            this.showPopupWindowNov7thFunc(true, false, "提示", "房间局数已尽！", (flag) => {
                this.switchLobbySceneNov7thFunc();
            }, this);
        }
    },
    onRecvLeaveDeskNov7thFunc(gameId, roomId, userId) {
        cc.log("======onRecvLeaveDeskNov7thFunc==========", gameId, roomId, userId);
        if (userId == g_UserManager.getSelfUserIdNov7thFunc()) {
            // this.showPopupWindowNov7thFunc(true, false, "提示", "您已经离开房间！", (flag)=>{
            //     this.switchLobbySceneNov7thFunc();
            // }, this);
            this.switchLobbySceneNov7thFunc();
        }
    },
    onRecvUpdateJuShuNov7thFunc(gameId, roomId, curJuShu) {
        cc.log("=====onRecvUpdateJuShuNov7thFunc========", gameId, roomId, curJuShu);
        let roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        if (roomId == roominfo.getRoomIdNov7thFunc() && gameId == roominfo.getGameIdNov7thFunc()) {
            this._backgroundScipt.showBaseTipNov7thFunc();
        }
    },
    ////////////////////////////////////////////////////////////////////////////////
    _startDispCardNov7thFunc(beginSeatNo) {
        let maxPlayer = g_WRDNGameData.getMaxPlayerNov7thFunc();
        let eachNumArray = [];
        let eachPosArray = [];
        for (let i = 0; i < maxPlayer; i++) {
            let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
            let numcard = g_WRDNGameData.getHandCardCountNov7thFunc(i);
            if (numcard > 0) {
                eachNumArray.push(numcard);
                eachPosArray.push(playerui.getHandCardPosNov7thFunc());
            } else {
                eachNumArray.push(null);
                eachPosArray.push(null);
            }
        }
        let self = this;
        this._dispcardScript.sendAllCardNov7thFunc(beginSeatNo, eachNumArray, eachPosArray, (seatNo, num, isEnd) => {
            if (!isEnd) {
                let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(seatNo);
                playerui.getHandCardNov7thFunc().drawHandCardNov7thFunc(num, false);
            } else {
                let maxPlayer = g_WRDNGameData.getMaxPlayerNov7thFunc();
                let selfSeatNo = g_WRDNGameData.getSelfSeatNoNov7thFunc();
                for (let i = 0; i < maxPlayer; i++) {
                    if (!g_WRDNGameData.getIsGamePlayNov7thFunc(i)) continue;
                    let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
                    playerui.showTimeWaitTipNov7thFunc(false);
                    let selfctype = g_WRDNGameData.getHandCardTypeNov7thFunc(i);
                    if (selfctype != null) {
                        playerui.getHandCardNov7thFunc().drawHandCardNov7thFunc(null, true);
                    } else {
                        playerui.getHandCardNov7thFunc().drawHandCardNov7thFunc();
                        if (i == selfSeatNo) {
                            self._getControlBtnNov7thFunc().showControlShowBtnNov7thFunc();
                        }
                    }
                }
            }
        });
    },
    ////////////////////////////////////////////////////////////////////////////////
    onRecvGameStatusNov7thFunc(protTab) {
        cc.log("==========onRecvGameStatusNov7thFunc====11=========", protTab);
        this._resetAllUiNov7thFunc();
        g_WRDNGameData.setDingZhuangBeiLvNov7thFunc(protTab.baseBeiLv);

        let maxPlayer = g_WRDNGameData.getMaxPlayerNov7thFunc();
        let roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        let selfUserId = g_UserManager.getSelfUserIdNov7thFunc();
        let selfSeatNo = roominfo.findUserSeatNoNov7thFunc(selfUserId);
        for (let i = 0; i < protTab.usertab.length; i++) {
            let toUserId = protTab.usertab[i];
            let toSeatNo = roominfo.findUserSeatNoNov7thFunc(toUserId);
            cc.log("======g_WRDNGameData.setIsGamePlayNov7thFunc====", toSeatNo, toUserId);
            g_WRDNGameData.setIsGamePlayNov7thFunc(toSeatNo, 1);
        }
        cc.log("==========onRecvGameStatusNov7thFunc====22=========", protTab.status);

        for (let i = 0; i < maxPlayer; i++) {
            let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
            playerui.showWaitStartTipNov7thFunc(false);
            if (protTab.status != STATUS_READY) {
                if (roominfo.getUserInfoNov7thFunc(i)) {
                    if (!g_WRDNGameData.getIsGamePlayNov7thFunc(i)) {
                        playerui.showWaitStartTipNov7thFunc(true);
                    }
                }
            }
        }
        if (protTab.status == STATUS_READY) {
            for (let i = 0; i < maxPlayer; i++) {
                let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
                let isReady = protTab.readyTab[i] == 1;
                playerui.showReadyTipNov7thFunc(isReady);
                if (i == selfSeatNo) {
                    this._showReadyButtonNov7thFunc(!isReady);
                }
            }
            if (protTab.ltime) {
                this._backgroundScipt.showLeftClockNov7thFunc(true, protTab.ltime);
            }
        } else if (protTab.status == STATUS_DINGZHUANG) {
            let bankerSeatNo = null;
            if (protTab.bankerUserId) {
                bankerSeatNo = roominfo.findUserSeatNoNov7thFunc(protTab.bankerUserId);
                g_WRDNGameData.setBankerSeatNoNov7thFunc(bankerSeatNo);
            }
            for (let i = 0; i < maxPlayer; i++) {
                if (!g_WRDNGameData.getIsGamePlayNov7thFunc(i)) continue;
                let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
                playerui.showTimeWaitTipNov7thFunc(false);
                playerui.showBankerTipNov7thFunc(bankerSeatNo == i);
                let dingbeilv = protTab.dingztab[i];
                if (dingbeilv != null) {
                    if (dingbeilv == 0) {
                        playerui.speekBuQiangNov7thFunc();
                    } else {
                        if (g_WRDNGameData.isQiangZhuangConfNov7thFunc()) {
                            playerui.speekQiangZhuangNov7thFunc(dingbeilv);
                        } else {
                            playerui.speekDingZhuangNov7thFunc(dingbeilv);
                        }
                    }
                } else {
                    if (g_WRDNGameData.isQiangZhuangConfNov7thFunc()) {
                        if (i == selfSeatNo) {
                            this._getControlBtnNov7thFunc().showDingZhuangBtnNov7thFunc();
                        } else {
                            playerui.showTimeWaitTipNov7thFunc(true);
                        }
                    } else if (i == bankerSeatNo) {
                        if (i == selfSeatNo) {
                            this._getControlBtnNov7thFunc().showDingZhuangBtnNov7thFunc();
                        } else {
                            playerui.showTimeWaitTipNov7thFunc(true);
                        }

                    }
                }
            }
        } else if (protTab.status == STATUS_SENDCARD) {
            let bankerSeatNo = roominfo.findUserSeatNoNov7thFunc(protTab.bankerUserId);
            g_WRDNGameData.setBankerSeatNoNov7thFunc(bankerSeatNo);
            this._backgroundScipt.showBaseBeiLvNov7thFunc(true);
            this._getControlBtnNov7thFunc().hideAllButtonNov7thFunc();
            for (let i = 0; i < maxPlayer; i++) {
                if (!g_WRDNGameData.getIsGamePlayNov7thFunc(i)) continue;
                g_WRDNGameData.setHandCardTabNov7thFunc(i, protTab.handCardTab[i], true);
                g_WRDNGameData.setHandCardTypeNov7thFunc(i, protTab.handTypeTab[i]);
                let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
                playerui.showTimeWaitTipNov7thFunc(false);
                playerui.speekNothingNov7thFunc();
                playerui.showBankerTipNov7thFunc(bankerSeatNo == i);
                //playerui.getHandCardNov7thFunc().drawHandCardNov7thFunc();
            }
            //this._startDispCardNov7thFunc(selfSeatNo);
            let selfSeatNo = g_WRDNGameData.getSelfSeatNoNov7thFunc();
            if (g_WRDNGameData.getIsGamePlayNov7thFunc(selfSeatNo)) {
                this._getControlBtnNov7thFunc().showControlShowBtnNov7thFunc();
            }
        } else if (protTab.status == STATUS_SHOWCARD) {
            let bankerSeatNo = roominfo.findUserSeatNoNov7thFunc(protTab.bankerUserId);
            g_WRDNGameData.setBankerSeatNoNov7thFunc(bankerSeatNo);
            this._backgroundScipt.showBaseBeiLvNov7thFunc(true);
            this._getControlBtnNov7thFunc().hideAllButtonNov7thFunc();
            for (let i = 0; i < maxPlayer; i++) {
                cc.log("=======STATUS_SHOWCARD===11====", i);
                if (!g_WRDNGameData.getIsGamePlayNov7thFunc(i)) continue;
                let handcardtype = protTab.handTypeTab[i];
                cc.log("=======STATUS_SHOWCARD===22====", i, handcardtype);
                g_WRDNGameData.setHandCardTabNov7thFunc(i, protTab.handCardTab[i], true);
                g_WRDNGameData.setHandCardTypeNov7thFunc(i, handcardtype);
                let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
                playerui.showBankerTipNov7thFunc(false);
                if (bankerSeatNo == i) {
                    playerui.showBankerTipNov7thFunc(true);
                }
                if (handcardtype != null) {
                    playerui.showNiuTypeTipNov7thFunc(true, handcardtype);
                    playerui.getHandCardNov7thFunc().drawHandCardNov7thFunc(null, true);
                } else {
                    playerui.getHandCardNov7thFunc().drawHandCardNov7thFunc();
                    if (i == selfSeatNo) {
                        this._getControlBtnNov7thFunc().showControlShowBtnNov7thFunc();
                    }
                }
            }
        } else if (protTab.status == STATUS_GAMEFINISH) {
            //this.onRequestGameReadyNov7thFunc(3);
            this._onShowGameResultNov7thFunc(protTab.finishdata);
        }
    },
    onProtSocketMessageNov7thFunc(mainId, assistId, protTab) {
        cc.log("==========onProtSocketMessageNov7thFunc=============", mainId, assistId, protTab);
        // prottab.ADouNiuWuRen_S2CReady  = 200     //准备
        // prottab.ADouNiuWuRen_S2CGameBegin = 201  //游戏开始
        // prottab.ADouNiuWuRen_S2CDingZhuang = 202  //抢庄
        // prottab.ADouNiuWuRen_S2CSendCard  = 203  //发牌
        // prottab.ADouNiuWuRen_S2CShowCard  = 204   //摊牌
        // prottab.ADouNiuWuRen_S2CTuoGuan = 205   //托管
        // prottab.ADouNiuWuRen_S2CGameFinish = 208    //游戏结束
        let maxPlayer = g_WRDNGameData.getMaxPlayerNov7thFunc();
        let roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        let selfUserId = g_UserManager.getSelfUserIdNov7thFunc();
        let selfSeatNo = roominfo.findUserSeatNoNov7thFunc(selfUserId);
        for (let i = 0; i < maxPlayer; i++) {
            let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
            playerui.showWaitStartTipNov7thFunc(false);
            if (assistId != g_ProtDef.ADouNiuWuRen_S2CReady) {
                playerui.showTotalScoreNov7thFunc(false);
                if (roominfo.getUserInfoNov7thFunc(i)) {
                    if (!g_WRDNGameData.getIsGamePlayNov7thFunc(i)) {
                        playerui.showWaitStartTipNov7thFunc(true);
                    }
                }
            }
        }
        this._backgroundScipt.showBaseTipNov7thFunc();
        if (assistId == g_ProtDef.ADouNiuWuRen_S2CReady) {
            if (protTab.userId == selfUserId) {
                this._resetAllUiNov7thFunc();
            }
            for (let i = 0; i < maxPlayer; i++) {
                let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
                let isReady = protTab.readyTab[i] == 1;
                playerui.showReadyTipNov7thFunc(isReady);
                if (isReady) {
                    playerui.showTotalScoreNov7thFunc(false);
                } else {
                    if (i == selfSeatNo) {
                        this._showReadyButtonNov7thFunc(!isReady);
                        this._getGameResultNov7thFunc().showResultNov7thFunc(false);
                    }
                }
            }
            if (protTab.ltime) {
                for (let i = 0; i < maxPlayer; i++) {
                    let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
                    playerui.showTotalScoreNov7thFunc(false);
                }
                this._backgroundScipt.showLeftClockNov7thFunc(true, protTab.ltime);
                this._getGameResultNov7thFunc().showResultNov7thFunc(false);
            }
        } else if (assistId == g_ProtDef.ADouNiuWuRen_S2CGameBegin) {
            this._backgroundScipt.showLeftClockNov7thFunc(false);
            let bankerSeatNo = null;
            if (protTab.bankerUserId) {
                bankerSeatNo = roominfo.findUserSeatNoNov7thFunc(protTab.bankerUserId);
                g_WRDNGameData.setBankerSeatNoNov7thFunc(bankerSeatNo);
            }
            this._getControlBtnNov7thFunc().hideAllButtonNov7thFunc();
            for (let i = 0; i < protTab.usertab.length; i++) {
                let toUserId = protTab.usertab[i];
                let toSeatNo = roominfo.findUserSeatNoNov7thFunc(toUserId);
                g_WRDNGameData.setIsGamePlayNov7thFunc(toSeatNo, 1);
                let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(toSeatNo);
                playerui.showReadyTipNov7thFunc(false);
                playerui.showTimeWaitTipNov7thFunc(false);
                playerui.showWaitStartTipNov7thFunc(false);
                playerui.showBankerTipNov7thFunc(bankerSeatNo == i);

                if (!protTab.bankerUserId) {
                    playerui.showTimeWaitTipNov7thFunc(true);
                    if (selfUserId == toUserId) {
                        this._getControlBtnNov7thFunc().showDingZhuangBtnNov7thFunc();
                    }
                } else {
                    playerui.showTimeWaitTipNov7thFunc(false);
                    if (selfUserId == toUserId && toUserId == protTab.bankerUserId) {
                        this._getControlBtnNov7thFunc().showDingZhuangBtnNov7thFunc();
                    }
                }
            }
        } else if (assistId == g_ProtDef.ADouNiuWuRen_S2CDingZhuang) {
            if (protTab.userId == selfUserId) {
                this._getControlBtnNov7thFunc().hideAllButtonNov7thFunc();
            }
            let toSeatNo = roominfo.findUserSeatNoNov7thFunc(protTab.userId);
            let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(toSeatNo);
            if (protTab.beilv > 0) {
                playerui.speekDingZhuangNov7thFunc(protTab.beilv);
            } else {
                playerui.speekBuQiangNov7thFunc();
            }
            playerui.showTimeWaitTipNov7thFunc(false);
        } else if (assistId == g_ProtDef.ADouNiuWuRen_S2CSendCard) {
            g_WRDNGameData.setDingZhuangBeiLvNov7thFunc(protTab.beilv)
            let bankerSeatNo = roominfo.findUserSeatNoNov7thFunc(protTab.bankerUserId);
            g_WRDNGameData.setBankerSeatNoNov7thFunc(bankerSeatNo);
            this._getControlBtnNov7thFunc().hideAllButtonNov7thFunc();
            this._backgroundScipt.showLeftClockNov7thFunc(false);
            this._backgroundScipt.showBaseBeiLvNov7thFunc(true);
            for (let i = 0; i < maxPlayer; i++) {
                if (!g_WRDNGameData.getIsGamePlayNov7thFunc(i)) continue;
                g_WRDNGameData.setHandCardTabNov7thFunc(i, protTab.handCardTab[i], false);
                let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
                playerui.showTimeWaitTipNov7thFunc(false);
                playerui.speekNothingNov7thFunc();
                playerui.showReadyTipNov7thFunc(false);
                playerui.showBankerTipNov7thFunc(bankerSeatNo == i);
            }
            this._startDispCardNov7thFunc(selfSeatNo);
        } else if (assistId == g_ProtDef.ADouNiuWuRen_S2CShowCard) {
            let toSeatNo = roominfo.findUserSeatNoNov7thFunc(protTab.userId);
            g_WRDNGameData.setHandCardTypeNov7thFunc(toSeatNo, protTab.cardType);
            g_WRDNGameData.playCardTypeNov7thFunc(protTab.userId, protTab.cardType);
            let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(toSeatNo);
            playerui.getHandCardNov7thFunc().recoverAllCardNov7thFunc();
            playerui.showNiuTypeTipNov7thFunc(true, protTab.cardType);
            if (protTab.userId == selfUserId) {
                this._getControlBtnNov7thFunc().hideAllButtonNov7thFunc();
            }
        } else if (assistId == g_ProtDef.ADouNiuWuRen_S2CTuoGuan) {
            let toSeatNo = roominfo.findUserSeatNoNov7thFunc(protTab.userId);
            let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(toSeatNo);
            playerui.showTuoGuanNov7thFunc(protTab.isTuoGuanNov7thFunc == 1);
        } else if (assistId == g_ProtDef.ADouNiuWuRen_S2CGameFinish) {
            this._onShowGameResultNov7thFunc(protTab);
        }
    },
    ////////////////////////////////////////////////////////////////////
    _onShowGameResultNov7thFunc(protTab) {
        this._resetAllUiNov7thFunc();
        this._backgroundScipt.showBaseBeiLvNov7thFunc(true);
        let maxPlayer = g_WRDNGameData.getMaxPlayerNov7thFunc();
        let roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        let bankerSeatNo = roominfo.findUserSeatNoNov7thFunc(protTab.bankerUserId);
        let selfSeatNo = g_WRDNGameData.getSelfSeatNoNov7thFunc();
        for (let i = 0; i < maxPlayer; i++) {
            if (!protTab.handCardTab[i]) {
                if (i == selfSeatNo) {
                    this._showReadyButtonNov7thFunc(true);
                }
                continue;
            }
            let handcardtype = protTab.handTypeTab[i];
            g_WRDNGameData.setHandCardTabNov7thFunc(i, protTab.handCardTab[i], true);
            g_WRDNGameData.setHandCardTypeNov7thFunc(i, handcardtype);
            let playerui = g_WRDNGameData.getPlayerUiBySeatNoNov7thFunc(i);
            playerui.getHandCardNov7thFunc().recoverAllCardNov7thFunc();
            playerui.showBankerTipNov7thFunc(false);
            if (bankerSeatNo == i) {
                playerui.showBankerTipNov7thFunc(true);
            }
            if (handcardtype != null) {
                playerui.showNiuTypeTipNov7thFunc(true, handcardtype);
                playerui.getHandCardNov7thFunc().drawHandCardNov7thFunc(null, true);
            } else {
                playerui.showNiuTypeTipNov7thFunc(false);
                playerui.getHandCardNov7thFunc().drawHandCardNov7thFunc();
            }
            roominfo.updateUserGoldNov7thFunc(i, protTab.winScoreTab[i]);
            playerui.showTotalScoreNov7thFunc(true, protTab.winScoreTab[i]);
        }
        if (protTab.handCardTab[selfSeatNo]) {
            let isSelfWin = protTab.winScoreTab[selfSeatNo] > 0;
            g_WRDNGameData.playGameResultNov7thFunc(isSelfWin);
            this._getGameResultNov7thFunc().showResultNov7thFunc(true, isSelfWin);
        }
    },
});