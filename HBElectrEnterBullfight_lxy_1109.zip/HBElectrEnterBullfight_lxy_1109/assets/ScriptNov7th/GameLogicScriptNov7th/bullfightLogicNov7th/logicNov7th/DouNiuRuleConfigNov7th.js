

//配置文件都在这里，所要用到的资源路径也在这里



let GameRuleConfig = {}
module.exports = GameRuleConfig;
//卡牌类型
GameRuleConfig.CardType = {
    NiuNoPoint : 0,  //无点牌
    NiuYi : 1,
    NiuEr : 2,
    NiuSan : 3, 
    NiuSi : 4,
    NiuWu : 5,
    NiuLiu : 6,
    NiuQi : 7,
    NiuBa : 8,
    NiuJiu : 9,
    NiuNiu : 10, //牛牛，三张牌数字总和为10的倍数，另两张数字总和也为10的倍数。
    NiuSiHua : 11,  //四花牛, 四张牌皆为J，Q，K中任意。第5张为10。
    NiuWuHua : 12,  //五花牛, 五张牌皆为J，Q，K中任意。
    NiuWuXiao : 13,  //五小牛, 五张牌皆小于5，总和小于等于10。
    NiuBomb : 14,   //炸弹

    //卡牌index值
    YiID : 1,  	//卡牌A的id
    ErID : 2,   //卡牌2的id
    SanID : 3,
    SiID : 4,
    WuID : 5,
    LiuID : 6,
    QiID : 7,
    BaID : 8,
    JiuID : 9,
    ShiID : 10,
    JID : 11,
    QID : 12,
    KID : 13,
    XiaoWangID : 14,	//小王，数值不要改，表示小王的卡牌index
    DaWangID : 15,	//大王，数值不要改

    NoType : 0,  //没有类型，大王小王
    RedSquare : 1, //方块
    BlackFlower : 2, //梅花
    RedHeart : 3, //红桃
    BlackHeart : 4, //黑桃
}

	//卡牌id转换成卡牌index
GameRuleConfig.GetCardIndex = function(cardId){
    return Math.floor(cardId / 10);
}
GameRuleConfig.GetCardColor = function(cardId){
	return cardId % 10;
}
