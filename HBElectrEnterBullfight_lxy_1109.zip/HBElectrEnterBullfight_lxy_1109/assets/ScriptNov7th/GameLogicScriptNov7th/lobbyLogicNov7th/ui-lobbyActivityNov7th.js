cc.Class({
    extends: cc.Component,

    properties: {
        label: cc.Label,
    },

    // use this for initialization
    onLoad: function() {

    },

    onCloseClickNov7thFunc: function() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});