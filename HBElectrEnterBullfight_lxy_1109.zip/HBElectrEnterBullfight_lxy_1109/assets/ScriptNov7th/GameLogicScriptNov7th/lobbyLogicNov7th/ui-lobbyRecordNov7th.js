cc.Class({
    extends: cc.Component,

    properties: {
        O_zhanjilineprefab: cc.Prefab,
        O_scrollviewnode: cc.Node,
        O_emptytip: cc.Node,
        //-----
        O_zjdetailnode: cc.Node,
        O_zjdetailscrollview: cc.Node,
        O_zjdetailprefab: cc.Prefab,
        ////////////////////////////////////////////////////////
        _zhanjiAllList: [],
        _zhanjiscollscript: null,
        _zjdetailscrollscript: null,
    },

    // use this for initialization
    onLoad: function() {
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_ZhanJi, null, this.onProtGameMessageNov7thFunc, this);

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ZhanJi, g_ProtDef.AZhanJi_C2SQuery);

        this._zhanjiscollscript = this.O_scrollviewnode.getComponent("ui-scrollViewNov7th");
        this._zjdetailscrollscript = this.O_zjdetailscrollview.getComponent("ui-scrollViewNov7th");
    },

    showUiNov7thFunc(bVisible) {
        this.node.active = bVisible;
        this.O_zjdetailnode.active = false;
    },

    onProtGameMessageNov7thFunc(mainId, assistId, protTab) {
        if (assistId == g_ProtDef.AZhanJi_S2CQuery) {
            cc.log("=====zhanji====AZhanJi_S2CQuery====", protTab)
            for (let i in protTab) {
                this._zhanjiAllList[i] = protTab[i];
            }
            this._updateAllListNov7thFunc();
        }
    },
    _updateAllListNov7thFunc() {
        this._zhanjiscollscript.clearAllNodeNov7thFunc();
        this.O_emptytip.active = true;
        for (let zjId in this._zhanjiAllList) {
            let tozjidtab = zjId.split("_");
            cc.log("=======_updateAllListNov7thFunc=tozjidtab=====11========", zjId, tozjidtab);
            if (!tozjidtab || !tozjidtab[0]) {
                this._zhanjiAllList[zjId] = null;
                continue;
            }
            let gameId = tozjidtab[0];
            let roomId = tozjidtab[1];
            let jushu = tozjidtab[2];
            let tozjdata = this._zhanjiAllList[zjId];

            let zhanjinode = cc.instantiate(this.O_zhanjilineprefab);
            cc.log("============_updateAllListNov7thFunc=tozjidtab=======22=====", zhanjinode, tozjdata);
            zhanjinode.getComponent("ui-lobbyRecordLineNov7th").setDataNov7thFunc(gameId, roomId, jushu, tozjdata.stime, tozjdata.userlist);
            zhanjinode.off("zhanjiline-event");
            zhanjinode.on("zhanjiline-event", (event) => {
                cc.log("=======_updateAllListNov7thFunc=tozjidtab=====33====", event, event.detail);
                this._showDetailNodeNov7thFunc(true, event.detail);
            }, this);
            this._zhanjiscollscript.addScrollNodeNov7thFunc(zhanjinode, null, tozjdata.stime);
            this.O_emptytip.active = false;
        }
        //按时间排序
        this._zhanjiscollscript.sortAllNodeListNov7thFunc((a, b) => {
            if (a > b) return -1;
            return 1;
        });
    },

    onCloseBtnNov7thFunc() {
        this.node.active = false;
    },

    _showDetailNodeNov7thFunc(bVisible, userlist) {
        cc.log("==========_showDetailNodeNov7thFunc===11=====", bVisible, userlist);
        this.O_zjdetailnode.active = bVisible;
        if (!bVisible) return;
        this._zjdetailscrollscript.clearAllNodeNov7thFunc();
        let selfUserId = g_UserManager.getSelfUserIdNov7thFunc();
        for (let i = 0; i < userlist.length; i++) {
            let udata = userlist[i];
            cc.log("==========_showDetailNodeNov7thFunc===22=====", udata);
            let detailline = cc.instantiate(this.O_zjdetailprefab);
            let dtlinescript = detailline.getComponent("ui-lobbyRecordDetailNov7th");
            dtlinescript.setDetailNov7thFunc(udata.userName, udata.userId, udata.score);
            let attdata = udata.userId;
            if (attdata == selfUserId) attdata *= 2;
            this._zjdetailscrollscript.addScrollNodeNov7thFunc(detailline, null, attdata);
        }
        this._zjdetailscrollscript.sortAllNodeListNov7thFunc((a, b) => {
            if (a > b) return -1;
            return 1;
        });
    },
    onCloseDetailBtnNov7thFunc() {
        cc.log("======onCloseDetailBtnNov7thFunc============");
        this._showDetailNodeNov7thFunc(false);
    },
});