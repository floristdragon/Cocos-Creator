cc.Class({
    extends: cc.Component,

    properties: {

        O_musicToggle: cc.Toggle,
        O_effectToggle: cc.Toggle,

        _isCheckToggleClick: true,
    },
    onLoad() {
        this._isCheckToggleClick = false;
        if (g_SoundManager.isMusicOpenNov7thFunc()) {
            cc.log("=======onLoad===11================");
            this.O_musicToggle.check();
        } else {
            cc.log("=======onLoad===22================");
            this.O_musicToggle.uncheck();
        }
        if (g_SoundManager.isEffectOpenNov7thFunc()) {
            cc.log("=======onLoad===33================");
            this.O_effectToggle.check();
        } else {
            cc.log("=======onLoad===44================");
            this.O_effectToggle.uncheck();
        }
        this._isCheckToggleClick = true;
    },

    showSettingNodeNov7thFunc: function() {
        this.node.active = true;
    },

    onMusicToggleClickNov7thFunc(toggle) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        cc.log("================onMusicToggleClickNov7thFunc======================", toggle, toggle.isChecked)
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setMusicOpenNov7thFunc(true);
            g_SoundManager.playMusicNov7thFunc("doudizhu/sound/music/bg_happy");
        } else {
            g_SoundManager.setMusicOpenNov7thFunc(false);
        }
    },

    onEffectToggleClickNov7thFunc(toggle) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        cc.log("==========================onEffectClickNov7thFunc===============", toggle, toggle.isChecked);
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setEffectOpenNov7thFunc(true);
        } else {
            g_SoundManager.setEffectOpenNov7thFunc(false);
        }
    },

    onCloseClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.node.active = false;
    },
});