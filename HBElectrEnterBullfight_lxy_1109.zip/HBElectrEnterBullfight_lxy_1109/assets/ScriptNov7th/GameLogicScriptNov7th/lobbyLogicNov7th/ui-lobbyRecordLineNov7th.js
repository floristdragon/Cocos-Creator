let gameconfig = require("gameConfigNov7th");
cc.Class({
    extends: cc.Component,

    properties: {
        O_gameidlabel: cc.Label,
        O_roomidlabel: cc.Label,
        O_timelabel: cc.Label,

        _userdatalist: null,
    },

    setDataNov7thFunc(gameid, roomid, jushu, stime, userlist) {
        this.O_gameidlabel.string = gameconfig[parseInt(gameid)].desc;
        this.O_roomidlabel.string = roomid + "-" + jushu;
        this._userdatalist = userlist;
        let date = new Date(stime * 1000);
        let extNov7thFunc = function(time) {
            if (time < 10) return "0" + time;
            return time + "";
        };
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        this.O_timelabel.string = ' ' + year + "/" + extNov7thFunc(month) + "/" +
            extNov7thFunc(date.getDate()) + "-" + extNov7thFunc(date.getHours()) + ":" + extNov7thFunc(date.getMinutes()) + ' ';
    },

    onClickBtnNov7thFunc() {
        cc.log("=======onClickBtnNov7thFunc========", this._userdatalist)
        if (this._userdatalist) {
            this.node.emit("zhanjiline-event", this._userdatalist);
        }
    },
});