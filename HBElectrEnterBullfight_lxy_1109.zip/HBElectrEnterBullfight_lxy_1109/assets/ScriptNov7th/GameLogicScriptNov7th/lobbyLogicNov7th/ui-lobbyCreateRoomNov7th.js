let gameconfig = require("gameConfigNov7th");

cc.Class({
    extends: cc.Component,

    properties: {
        //所有根节点
        // O_doudizhunode : cc.Node,
        O_douniunode: cc.Node,
        // O_sangongnode : cc.Node,

        //斗地主
        // O_erddztoggleBtn : cc.Toggle,
        // O_srddztoggleBtn : cc.Toggle,
        // O_wrdntoggleBtn : cc.Toggle,

        // O_ddz8toggleBtn : cc.Toggle,
        // O_ddz16toggleBtn : cc.Toggle,
        //斗牛
        O_dn8toggleBtn: cc.Toggle,
        O_dn16toggleBtn: cc.Toggle,
        O_dnwfQiangZhuang: cc.Toggle,
        O_dnwfLunZhuang: cc.Toggle,
        O_dnwfBaZhuang: cc.Toggle,
        //三公
        // O_sg8toggleBtn : cc.Toggle,
        // O_sg16toggleBtn : cc.Toggle,
        // O_sgwfQiangZhuang : cc.Toggle,
        // O_sgwfLunZhuang : cc.Toggle,
        // O_sgwfBaZhuang : cc.Toggle,

        //////////////////////////////////////////////////////
        _enableInput: true,
        _maxJuShu: null,
        _selectgameId: null,
        _selectDNWanFa: 0, //选择斗牛玩法
        _selectSGWanFa: 0, //选择三公玩法
    },

    // use this for initialization
    onLoad: function(data01, data02, data03) {
        cc.log("=======createroom===onload===", data01, data02, data03);
        this._enableInput = true;
        // this.onSelectDouDizhuBtnNov7thFunc(null);
        this.onSelectDouNiuBtnNov7thFunc(null);
    },
    _hideAllGameNodeNov7thFunc() {
        // this.O_doudizhunode.active = false;
        this.O_douniunode.active = false;
        // this.O_sangongnode.active = false;
    },
    ////////////////////////////////////////////////////////
    // onSelectDouDizhuBtnNov7thFunc(event){
    //     cc.log("===========onSelectDouDizhuBtnNov7thFunc========");
    //     g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
    //     this._hideAllGameNodeNov7thFunc();
    //     this.O_doudizhunode.active = true;
    //     this._checkDouDiZhuAllToggleNov7thFunc();
    // },
    onSelectDouNiuBtnNov7thFunc(event) {
        cc.log("===========onSelectDouNiuBtnNov7thFunc========");
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this._hideAllGameNodeNov7thFunc();
        this.O_douniunode.active = true;
        this._checkDouNiuAllToggleNov7thFunc();
    },
    // onSelectSanGongBtnNov7thFunc(event){
    //     cc.log("===========onSelectDouNiuBtnNov7thFunc========");
    //     g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
    //     this._hideAllGameNodeNov7thFunc();
    //     this.O_sangongnode.active = true;
    //     this._checkSanGongAllToggleNov7thFunc();
    // },
    onCreateBtnNov7thFunc(event) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        if (!this._enableInput) return;
        this._enableInput = false;
        let self = this;
        this.scheduleOnce(function() {
            self._enableInput = true;
        }, 0.5);
        if (!this._selectgameId || !gameconfig[this._selectgameId]) {
            return g_GameScene.showPopupWindowNov7thFunc(true, false, "提示",
                g_ProtDef.GetErrDiscByCode("M_LOBBY_CREATEROOM_CONFIG_ERR"));
        }
        let protTab = {};
        protTab.gameId = this._selectgameId; //游戏名称
        protTab.userId = g_UserManager.getSelfUserIdNov7thFunc();
        protTab.pwd = ""; //房间密码
        protTab.maxJuShu = this._maxJuShu;
        protTab.config = {}; //创建配置

        if (this._selectgameId == g_ProtDef.MID_Protocol_DouNiuWuRen) {
            this._checkDouNiuAllToggleNov7thFunc();
            protTab.config.zhuangflag = this._selectDNWanFa;
        } else if (this._selectgameId == g_ProtDef.MID_Protocol_SanGongWuRen) {
            this._checkSanGongAllToggleNov7thFunc();
            protTab.config.zhuangflag = this._selectSGWanFa;
        } else if (this._selectgameId == g_ProtDef.MID_Protocol_ErRenDDZ ||
            this._selectgameId == g_ProtDef.MID_Protocol_ClassicDDZ) {
            this._checkDouDiZhuAllToggleNov7thFunc();
        }

        cc.log("========onCreateBtnNov7thFunc=======", protTab, protTab.config);
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SCreatDesk, protTab)
    },
    onCloseBtnNov7thFunc(event) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.node.active = false;
    },
    ////////////////////////////////////////////////////////////////////////////////
    // _checkDouDiZhuAllToggleNov7thFunc(){
    //     this._maxJuShu = 8;
    //     this._selectgameId = null;
    //     if(this.O_ddz8toggleBtn.isChecked) {
    //         this._maxJuShu = 8;
    //     }else if(this.O_ddz16toggleBtn.isChecked) {
    //         this._maxJuShu = 16;
    //     }
    //     if(this.O_erddztoggleBtn.isChecked){
    //         this._selectgameId = g_ProtDef.MID_Protocol_ErRenDDZ;
    //     }else if(this.O_srddztoggleBtn.isChecked){
    //         this._selectgameId = g_ProtDef.MID_Protocol_ClassicDDZ;
    //     }
    // },
    _checkDouNiuAllToggleNov7thFunc() {
        this._maxJuShu = 8;
        this._selectgameId = null;
        this._selectDNWanFa = 0;
        this._selectgameId = g_ProtDef.MID_Protocol_DouNiuWuRen;

        if (this.O_dn8toggleBtn.isChecked) {
            this._maxJuShu = 8;
        } else if (this.O_dn16toggleBtn.isChecked) {
            this._maxJuShu = 16;
        }
        if (this.O_dnwfQiangZhuang.isChecked) {
            this._selectDNWanFa = 0;
        } else if (this.O_dnwfBaZhuang.isChecked) {
            this._selectDNWanFa = 1;
        } else if (this.O_dnwfLunZhuang.isChecked) {
            this._selectDNWanFa = 2;
        }
        cc.log("===_checkDouNiuAllToggleNov7thFunc========", this._selectDNWanFa);
    },
    // _checkSanGongAllToggleNov7thFunc(){
    //     this._maxJuShu = 8;
    //     this._selectgameId = null;
    //     this._selectSGWanFa = 0;
    //     this._selectgameId = g_ProtDef.MID_Protocol_SanGongWuRen;

    //     if(this.O_sg8toggleBtn.isChecked) {
    //         this._maxJuShu = 8;
    //     }else if(this.O_sg16toggleBtn.isChecked) {
    //         this._maxJuShu = 16;
    //     }
    //     if(this.O_sgwfQiangZhuang.isChecked){
    //         this._selectSGWanFa = 0;
    //     }else if(this.O_sgwfBaZhuang.isChecked){
    //         this._selectSGWanFa = 1;
    //     }else if(this.O_sgwfLunZhuang.isChecked){
    //         this._selectSGWanFa = 2;
    //     }
    //     cc.log("===_checkSanGongAllToggleNov7thFunc========", this._selectSGWanFa);
    // },
});