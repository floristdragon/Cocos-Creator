let utilIconv = require("util_iconvNov7th")
cc.Class({
    extends: cc.Component,

    properties: {
        O_mailprefab: cc.Prefab,

        O_scrollview: cc.Node,

        O_maildetailnode: cc.Node,
        O_labelcontent: cc.Label,
        O_emptytip: cc.Node,

        _scrollscript: null,
        _detailnode: null,
    },
    onLoad() {
        this.O_maildetailnode.active = false;
        this._scrollscript = this.O_scrollview.getComponent("ui-scrollViewNov7th");
        this._scrollscript.setHeightInterNov7thFunc(0);
        this._checkEmptyTipNov7thFunc();
    },

    showBoxNov7thFunc(bVisible, bClear) {
        cc.log("=========setMailBox===========");
        this.node.active = bVisible;
        if (bClear) this._scrollscript.clearAllNodeNov7thFunc();
    },
    setBoxMailNov7thFunc(maillist) {
        if (!maillist) return;
        for (let i = 0; i < maillist.length; i++) {
            let maildata = maillist[i];
            if (!maildata) continue;
            //let iconvlite = require('iconv-lite');
            //let toData = iconvlite.decode(toTempArray, 'UTF8');
            maildata.title = utilIconv.GBKToUTF8(maildata.title);
            maildata.content = utilIconv.GBKToUTF8(maildata.content);
            let mailnode = cc.instantiate(this.O_mailprefab);
            cc.log("======setBoxMailNov7thFunc===title===", maildata.title);
            mailnode.getComponent("ui-lobbyMailLineNov7th").initNov7thFunc(maildata.mailId, maildata.title, maildata.stime);
            mailnode.on("mailbox-readmail", () => {
                this.O_labelcontent.string = maildata.content;
                this.O_maildetailnode.active = true;
                this._detailnode = mailnode;
            }, this);
            this._scrollscript.addScrollNodeNov7thFunc(mailnode, null, maildata.stime);
        }
        this._scrollscript.sortAllNodeListNov7thFunc((a, b) => {
            if (a > b) return -1;
            return 1;
        });
        this._checkEmptyTipNov7thFunc();
    },

    onCloseDetailClickNov7thFunc(node) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        cc.log("========onCloseDetailClickNov7thFunc=========", node);
        this.O_maildetailnode.active = false;
        this._scrollscript.rmScrollNodeNov7thFunc(this._detailnode);
        this._checkEmptyTipNov7thFunc();
    },
    onCloseNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.showBoxNov7thFunc(false);
    },

    _checkEmptyTipNov7thFunc() {
        if (this._scrollscript.getListSizeNov7thFunc() <= 0) {
            this.O_emptytip.active = true;
        } else {
            this.O_emptytip.active = false;
        }
    },
});