cc.Class({
    extends: cc.Component,

    properties: {
        O_editBox: cc.EditBox,
        O_chatLinePrefab: cc.Prefab,
        O_toUserId: cc.Label,

        _toUserId: 0,

    },

    onCloseEventNov7thFunc: function() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.node.active = false;
    },

    initNov7thFunc: function(toUserid) {
        //
        //this._scrollScript = this.scrollViewNode.getComponent('ui-scrollViewNov7th');
        this.O_toUserId.string = toUserid;
        this._toUserId = toUserid;
    },

    onSendEventNov7thFunc: function() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        if (g_GameScene.rejectClickEventNov7thFunc(3)) return;
        var userstr = this.O_editBox.string;
        this.O_editBox.string = "";

        //发送协议
        let toChattab = {};
        toChattab.toUserId = this._toUserId;
        toChattab.ctype = 4;
        toChattab.content = userstr;
        toChattab.msgtype = 3;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SSendChatMsg, toChattab);

        cc.log("========onSendEventNov7thFunc=========toChattab==========", toChattab);
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});