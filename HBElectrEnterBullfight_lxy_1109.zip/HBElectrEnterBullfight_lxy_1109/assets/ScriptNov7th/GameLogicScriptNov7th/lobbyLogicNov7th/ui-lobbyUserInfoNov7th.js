cc.Class({
    extends: cc.Component,

    properties: {
        O_userName: cc.Label,
        O_userId: cc.Label,
        O_userIp: cc.Label,
        O_userHead: cc.Node,

    },

    onLoad() {
        let userinfo = g_UserManager.getSelfUserInfoNov7thFunc();
        this.O_userName.string = userinfo.getUserNameNov7thFunc();
        this.O_userId.string = userinfo.getUserIdNov7thFunc();
        this.O_userIp.string = userinfo.getIpAddrNov7thFunc();
        cc.log("===========userinfo=========", userinfo);
        let headurl = userinfo.getHeadUrlNov7thFunc();
        if (headurl && headurl.length > 0) {
            let toSprite = this.O_userHead.getComponent(cc.Sprite);
            let toType = "png";
            if (headurl.indexOf(".jpg")) {
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },

    onChangeUserBtnNov7thFunc: function() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        g_GameScene.switchStartSceneNov7thFunc();
        this.onCloseNov7thFunc();
    },

    onCloseNov7thFunc: function() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.node.destroy();
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});