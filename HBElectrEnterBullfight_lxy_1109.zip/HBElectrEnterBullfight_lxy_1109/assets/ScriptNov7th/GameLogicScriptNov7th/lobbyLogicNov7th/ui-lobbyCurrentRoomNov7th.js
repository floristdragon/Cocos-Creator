cc.Class({
    extends: cc.Component,

    properties: {
        O_curroomlineprefab: cc.Prefab,
        O_scrollviewnode: cc.Node,

        _scrollviewscript: null,
    },

    onLoad() {
        this._scrollviewscript = this.O_scrollviewnode.getComponent("ui-scrollViewNov7th");
    },

    // use this for initialization
    addOneRoomRecordNov7thFunc(gameId, roomId, curjushu, maxjushu) {
        cc.log("=====addOneRoomRecordNov7thFunc========", gameId, roomId, curjushu, maxjushu)
        let croomlinenode = cc.instantiate(this.O_curroomlineprefab);
        let croomlinescript = croomlinenode.getComponent("ui-lobbyCurrentRoomLineNov7th");
        croomlinescript.setDataNov7thFunc(gameId, roomId, curjushu, maxjushu);
        this._scrollviewscript.addScrollNodeNov7thFunc(croomlinenode);
    },

    onCloseEventNov7thFunc: function() {
        this.node.destroy();
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});