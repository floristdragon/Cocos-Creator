cc.Class({
    extends: cc.Component,

    properties: {
        O_namelabel : cc.Label,
        O_useridlabel : cc.Label,
        O_scorelabel : cc.Label,

    },

    // use this for initialization
    onLoad: function () {
        //this.setDetailNov7thFunc();  //不要在这里初始化，cc.instantiate会延迟调用onLoad
    },

    setDetailNov7thFunc(name, userId, score){
        cc.log("=======setDetailNov7thFunc==========", name, userId, score);
        if(!name) name = "";
        if(!userId) userId = "";
        if(score==null) score = 0;
        this.O_namelabel.string = name;
        this.O_useridlabel.string = "ID:" + userId;
        this.O_scorelabel.string = score;
    },
});
