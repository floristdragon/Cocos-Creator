let HttpRequest = require("httpRequestNov7th");
cc.Class({
    extends: require("ui-basesceneNov7th"),

    properties: {
        O_videoplayer: cc.Node,

        O_loginprefab: cc.Prefab,
        O_registerprefab: cc.Prefab,
        O_loginloadprefab: cc.Prefab,
        O_xieyiprefab: cc.Prefab,
        O_leafparticlenode: cc.Node,


        O_hotfixVersionLabel: cc.Label,
        O_hotfixnode: cc.Node,
        ////////////////////////////////////////
        _loginNode: null,
        _registerNode: null,
        _loginloadNode: null,
        _isLoadingScene: false,
    },
    // use this for initialization
    onLoad: function() {
        this._super(); //调用父类的onLoad
        this.O_videoplayer.setLocalZOrder(1000);
        //this.O_videoplayer.active = true;

        let writepath = 0; //cc.FileUtils.getInstance().getWritablePath();
        cc.log("===writepath===", cc, cc.jsb, writepath);
        this.O_leafparticlenode.setLocalZOrder(100);

        this._showHotFixNodeNov7thFunc(true);

        //md5 32位小写加密测试
        //let utilmd5 = require("util_md5Nov7th");
        //cc.log("==========md5==test====", utilmd5.md5("fanfangyou"));
        cc.log("=====ui-start===onLoad=============");
        //音频操作
        g_SoundManager.setMusicOpenNov7thFunc(true);
        g_SoundManager.setEffectOpenNov7thFunc(true);
        g_SoundManager.playMusicNov7thFunc("CommonResNov7th/bgMusicNov7th-welcome");
        /*
        g_SoundManager.pauseAll();
        g_SoundManager.playMusicNov7thFunc("doudizhu/sound/music/bg_happy");
        let self = this;
        self.intervalVolumn = 1;
        this.schedule(function(){
            if(self.intervalVolumn>=0){
                cc.log("========update===volum==========", self.intervalVolumn);
                self.intervalVolumn -= 0.02;
                g_SoundManager.setMusicVolumeNov7thFunc(self.intervalVolumn);
                g_SoundManager.setEffectVolumeNov7thFunc(self.intervalVolumn);
            }
        }, 0.1);
        this.scheduleOnce(function(){
            g_SoundManager.stopMusicNov7thFunc();
        }, 1);
        g_SoundManager.playEffectNov7thFunc("doudizhu/sound/effect/win", (path, dur)=>{
            cc.log("========playEffectNov7thFunc===========", path, dur);
        });
        */
        let curhotVersion = g_ConfigManager.getHotFixVersionNov7thFunc();
        this.O_hotfixVersionLabel.string = curhotVersion + "";
        //检测更新
        let self = this;
        let onErrorHandleNov7thFunc = () => {
            cc.log("=====hotfix====onErrorHandleNov7thFunc=========");
            self.node.runAction(cc.sequence(cc.delayTime(2), cc.callFunc(self.onAllInitNov7thFunc, self)));
        }
        let onSuccessHandleNov7thFunc = (response) => {
                let jsonData = JSON.parse(response);
                cc.log("=====hotfix====onSuccessHandleNov7thFunc=========", jsonData, response);
                if (true || !jsonData || !jsonData.version) {
                    return onErrorHandleNov7thFunc();
                }
                let jsonVersion = jsonData.version;
                if (jsonVersion == curhotVersion) {
                    return onErrorHandleNov7thFunc();
                }
                g_ConfigManager.setHotFixVersionNov7thFunc(jsonData.version);
                self.O_hotfixVersionLabel.string = jsonData.version;
                self.startHotFixUpdateNov7thFunc();
            }
            /////
        let isHaveHotfix = false;
        if (isHaveHotfix) {
            let hotfixVerUrl = g_ConfigManager.getGlobalConfigNov7thFunc("HotFixUrl");
            let httpHandler = new HttpRequest();
            httpHandler.onError = onErrorHandleNov7thFunc;
            httpHandler.onSuccess = onSuccessHandleNov7thFunc;
            httpHandler.sendGet(hotfixVerUrl);
        } else {
            onErrorHandleNov7thFunc();
        }
    },
    onPreLoadResourceNov7thFunc() {
        //预加载资源
        cc.log("========onPreLoadResourceNov7thFunc=================");
        cc.loader.loadResDir("doudizhu/poker-small", (err, arraytex) => {
            cc.log("===loadResDir==errenddz/poker-small===", arraytex);
        });
        cc.loader.loadResDir("doudizhu/poker-big", (err, arraytex) => {
            cc.log("===loadResDir==errenddz/poker-big===", arraytex);
        });
        let self = this;
        this.scheduleOnce(() => {
            self.onLoadLobbySceneNov7thFunc();
        }, 2);
    },
    onAllInitNov7thFunc() {
        //所有初始化都在这里
        this.O_videoplayer.destroy();
        this._showHotFixNodeNov7thFunc(false);
        this._showLoginNodeNov7thFunc();
        this._initNetWorkNov7thFunc();
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_S2CSignIN, this.onProtSignInNov7thFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_S2CRegAccount, this.onProtRegAccountNov7thFunc, this);
        //请求登陆大厅
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqLoginIn, this.onProtLoginLobbyNov7thFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqUserInfo, this.onProtLoginLobbyInfoNov7thFunc, this);
    },
    _initNetWorkNov7thFunc() {
        let serverIp = g_ConfigManager.getGlobalConfigNov7thFunc("ServerIP");
        let serverPort = g_ConfigManager.getGlobalConfigNov7thFunc("ServerPort");
        cc.log("=======_initNetWorkNov7thFunc=============", serverIp, serverPort);
        g_NetManager.connect(serverIp, serverPort);
        let self = this;
        self._isLoadingScene = false;
        g_NetManager.onopen = function() {
            console.log("=========g_NetManager.onopen=============");
            self.showLoadFlowerNov7thFunc(false);
            //如果在加载资源时候重连
            if (self._isLoadingScene) {
                self.onProtSignInNov7thFunc(null, null, { isSuccess: 1 });
            }
        };
    },
    onLoadLobbySceneNov7thFunc() {
        cc.log("=========onLoadLobbySceneNov7thFunc=======11========");
        //检测能否切换大厅场景，
        //1、是否服务器已经发送完所有数据过来
        //2、是否进度条已经到了最后
        //3、是否预加载资源已经加载完成了。
        if (g_ConfigManager.checkIsCanLoginLobbyNov7thFunc(3)) {
            cc.log("=========onLoadLobbySceneNov7thFunc=======22========");
            g_ConfigManager.resetIsCanLoginLobbyNov7thFunc();
            g_GameScene.switchLobbySceneNov7thFunc();
        }
    },
    startHotFixUpdateNov7thFunc() {
        let self = this;
        let finishUpdateNov7thFunc = function() {
            cc.log("=========finishUpdateNov7thFunc==========")
            self.node.runAction(cc.sequence(cc.delayTime(2), cc.callFunc(self.onAllInitNov7thFunc, self)));
        };
        this.getComponent('hotFixUpdateNov7th').initNov7thFunc(finishUpdateNov7thFunc);
    },
    /////////////////////////////////////////////////////
    onRecvErrcodeNov7thFunc(errcode, attachtab) {
        cc.log("=======onRecvErrcodeNov7thFunc============", errcode, attachtab);
        this.showPopupWindowNov7thFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },
    /////////////////////////////////////////////////////
    //协议回调
    onProtSignInNov7thFunc(mainId, assistId, protTab) {
        cc.log("======onProtSignInNov7thFunc=============", protTab);
        if (protTab.isSuccess != 1) {
            return this.showPopupWindowNov7thFunc(true, false, "提示", "登陆失败！");
        }
        this._isLoadingScene = true;
        //登陆成功
        this._showLoadingNodeNov7thFunc();
        this.onPreLoadResourceNov7thFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqLoginIn)
    },
    onProtRegAccountNov7thFunc(mainId, assistId, protTab) {
        cc.log("======onProtRegAccountNov7thFunc=============", protTab);
        if (protTab.isSuccess != 1) {
            this.showPopupWindowNov7thFunc(true, false, "提示", "注册失败！");
        } else {
            this.showPopupWindowNov7thFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_REGISTER_SUCCESS_ACC"), (flag) => {
                this._showLoginNodeNov7thFunc(true);
            }, this);
        }
    },
    onProtLoginLobbyNov7thFunc(mainId, assistId, protTab) {
        cc.log("======onProtLoginLobbyNov7thFunc=============", protTab);
        if (protTab.isSuccess == 1) {
            this.onLoadLobbySceneNov7thFunc();
        } else {
            this.showPopupWindowNov7thFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_REGISTER_LOGIN_LOBBY_FAILED"));
        }
    },
    onProtLoginLobbyInfoNov7thFunc(mainId, assistId, protTab) {
        cc.log("======onProtLoginLobbyInfoNov7thFunc=============", protTab);
        //在ALobby_S2CReqLoginIn登陆大厅成功的协议返回前，返回玩家数据
        let userinfo = g_UserManager.newUserNov7thFunc(protTab.userId, protTab.userName, true)
        userinfo.setUserInfoPackageNov7thFunc(protTab)
    },
    /////////////////////////////////////////////////////
    _showHotFixNodeNov7thFunc(isVisible) {
        this.O_hotfixnode.active = isVisible;
        if (isVisible) {
            this._showLoginRegLoadVisibleNov7thFunc(false, false, false);
        }
    },
    _showLoginRegLoadVisibleNov7thFunc(isLogin, isReg, isLoad) {
        if (this._loginNode) {
            this._loginNode.destroy();
            this._loginNode = null;
        }
        if (this._registerNode) {
            this._registerNode.destroy();
            this._registerNode = null;
        }
        if (isLogin) {
            this._loginNode = cc.instantiate(this.O_loginprefab);
            this._loginNode.parent = this.node;
        } else if (isReg) {
            this._registerNode = cc.instantiate(this.O_registerprefab);
            this._registerNode.parent = this.node;
        } else if (isLoad) {
            if (!this._loginloadNode) {
                this._loginloadNode = cc.instantiate(this.O_loginloadprefab);
                this._loginloadNode.parent = this.node;
            }
        }
        if (this._loginNode) this._loginNode.active = isLogin;
        if (this._registerNode) this._registerNode.active = isReg;
        if (this._loginloadNode) this._loginloadNode.active = isLoad;
    },
    _showLoginNodeNov7thFunc() {
        this._showLoginRegLoadVisibleNov7thFunc(true, false, false);
        //on接收事件，其事件的emit必定是在这个节点内部发射
        //移除同类型的事件监听，否则on会递增, 最好在on之前调用，不要在时间响应后调用，保持有且仅有一个同类事件
        this._loginNode.off("login-loginacc");
        this._loginNode.off("login-showregister");
        this._loginNode.off("login-xieyi-not-select");
        this._loginNode.off("login-showxieyi");

        this._loginNode.on("login-loginacc", (event) => {
            console.log("=======login-loginacc======", event.detail);
            let toAcc = String(event.detail.acc);
            let toPwd = String(event.detail.pwd);
            if (toAcc.length <= 0 || toPwd.length <= 0) {
                return this.showPopupWindowNov7thFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_LOGIN_ACC_PWD_EMPTY"));
            } else if (toAcc.length < 6 || toPwd.length < 6) {
                return this.showPopupWindowNov7thFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_REGISTER_LONGERR_ACC"));
            }
            let protTab = {};
            protTab.accName = toAcc;
            protTab.accPwd = toPwd;
            protTab.platform = 0;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_C2SSignIN, protTab);
            g_ConfigManager.setLoginAccountNov7thFunc(toAcc, toPwd);
        }, this);
        this._loginNode.on("login-showregister", (event) => {
            console.log("=======login-showregister======", event.detail);
            this._showRegisterNodeNov7thFunc();
        }, this);


        this._loginNode.on("login-xieyi-not-select", (event) => {
            console.log("=======login-xieyi-not-select======", event.detail);
            this.showPopupWindowNov7thFunc(true, false, "提示", "继续游戏需要同意用户协议");
        }, this);

        this._loginNode.on("login-showxieyi", (event) => {
            console.log("=======login-showxieyi======", event.detail);
            this._showXieYiNodeNov7thFunc();
        }, this);


        /////////////////////////////
    },
    _showRegisterNodeNov7thFunc() {
        this._showLoginRegLoadVisibleNov7thFunc(false, true, false);
        //on接收事件，其事件的emit必定是在这个节点内部发射
        //移除同类型的事件监听，否则on会递增, 最好在on之前调用，不要在时间响应后调用，保持有且仅有一个同类事件
        this._registerNode.off("register-regaccount");
        this._registerNode.off("register-hideregnode");
        this._registerNode.on("register-regaccount", (event) => {
            console.log("=======login-regaccount======", event, event.detail);
            let toAcc = String(event.detail.acc);
            let toPwd = String(event.detail.pwd);
            if (toAcc.length <= 0 || toPwd.length <= 0) {
                return this.showPopupWindowNov7thFunc(true, false, "错误", g_ProtDef.GetErrDiscByCode("M_LOGIN_ACC_PWD_EMPTY"));
            } else if (toAcc.length < 6 || toPwd.length < 6) {
                return this.showPopupWindowNov7thFunc(true, false, "错误", g_ProtDef.GetErrDiscByCode("M_REGISTER_LONGERR_ACC"));
            }
            let protTab = {};
            protTab.accName = toAcc;
            protTab.accPwd = toPwd;
            protTab.userName = toAcc;
            protTab.headUrl = ""
            protTab.isBoy = 1
            protTab.platform = 0 //普通注册
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_C2SRegAccount, protTab);
        }, this);
        this._registerNode.on("register-hideregnode", (event) => {
            console.log("=======login-hideregnode======", event, event.detail);
            this._showLoginNodeNov7thFunc();
        }, this);
    },
    _showLoadingNodeNov7thFunc() {
        this._showLoginRegLoadVisibleNov7thFunc(false, false, true);
        let toPreLoadNode = this._loginloadNode.getChildByName("proloadbar");
        let toProgressBar = toPreLoadNode.getComponent(cc.ProgressBar);
        cc.log("====_showLoadingNodeNov7thFunc=====", toPreLoadNode, toProgressBar);
        toProgressBar.progress = 0;
        let self = this;
        let loginUPloadCallBackNov7thFunc = function(dt) {
            let topercent = dt * (Math.random() * 100 + 40);
            toProgressBar.progress += topercent / 100.0;
            //cc.log("========loginUPloadCallBackNov7thFunc=========", toProgressBar.progress,  dt, topercent);
            if (toProgressBar.progress >= 1) {
                cc.log("========loginUPloadCallBackNov7thFunc====end=====");
                toProgressBar.progress = 1;
                self.unschedule(loginUPloadCallBackNov7thFunc);
                self.onLoadLobbySceneNov7thFunc();
            }
        };
        this.schedule(loginUPloadCallBackNov7thFunc, 0);
    },

    _showXieYiNodeNov7thFunc: function() {
        if (this._xieYiNode != null) {
            return;
        }
        this._xieYiNode = cc.instantiate(this.O_xieyiprefab);
        this._xieYiNode.parent = this.node;

        this._xieYiNode.on("login-hidexieyi", (event) => {
            console.log("=======login-hidexieyi======", event.detail);
            this._hideXieYiNodeNov7thFunc();
        }, this);
    },

    _hideXieYiNodeNov7thFunc: function() {
        if (this._xieYiNode != null) {
            this._xieYiNode.destroy();
            this._xieYiNode = null;
        }
    },

    onRegisterBtnNov7thFunc(event) {
        this._showRegisterNodeNov7thFunc();
    },
});