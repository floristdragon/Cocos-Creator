
let errcodetab = {};
let errfunctab = {};
module.exports = errfunctab;
//通过错误码获取错误描述字符串
errfunctab.GetErrDiscByCode = function(code){
    return errcodetab[code][2];
};
//通过参数获取错误描述码
errfunctab.GetErrNumErrcode = function(val){
    return errcodetab[val][1];
};
//如通过code=1，获得SYS_UNKNOW_ERROR
errfunctab.GetErrVarByCode = function(code){
    return errcodetab[code][0];
};
let _lRegErrcode = function(val, code, errstr){
    let tab = [val, code, errstr];
    errcodetab[val] = tab;
    errcodetab[code] = tab;
};
//-------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------
_lRegErrcode("SYS_UNKNOW_ERROR",						1,		"系统错误")  //如“协议解析失败”、“没有定义的协议ID”等等
_lRegErrcode("SYS_VERSION",               				2, 		"版本过低，请更新客户端")
_lRegErrcode("SYS_SERVER_SHUTDOWN",               		3, 		"游戏服务器未开放！")
_lRegErrcode("SYS_USER_NOT_EXIST",						4,	    "玩家不存在！")
_lRegErrcode("SYS_CONTENT_NOT_EXIST",					5,	    "内容为空！")

//登录模块

_lRegErrcode("M_LOGIN_ACC_PWD_EMPTY",				21,		"用户名或密码不能为空")
_lRegErrcode("M_LOGIN_ACC_OR_PWD_ERROR",			23,		"用户名或密码错误")
_lRegErrcode("M_LOGIN_REPLACE",						24,		"被玩家替换下线")
_lRegErrcode("M_LOGIN_REDO_LOGIN",					25,		"登陆异常，请重新登录")
_lRegErrcode("M_LOGIN_ERR_PLATFORM",				26,		"登陆配置异常！")
_lRegErrcode("M_LOGIN_WEIXIN_ERROR",				27,		"微信授权失败！")

_lRegErrcode("M_REGISTER_SUCCESS_ACC",				30,		"注册成功！")
_lRegErrcode("M_REGISTER_ALREADY_ACC",				31,		"用户名已经被注册！")
_lRegErrcode("M_REGISTER_LONGERR_ACC",				32,		"用户名或密码太短！(少于6个字符)")

_lRegErrcode("M_REGISTER_LOGIN_LOBBY_FAILED",				200,		"登陆游戏失败")

_lRegErrcode("M_LOBBY_CREATEROOM_TO_LIMITED",				1001,	"创建房间失败，游戏容纳的房间数量已经达到上限！")
_lRegErrcode("M_LOBBY_CREATEROOM_CONFIG_ERR",				1002,	"创建房间失败，配置错误！")

_lRegErrcode("M_LOBBY_DELETEROOM_PLAYING",				1101,	"解散房间失败，游戏已经开始！")
_lRegErrcode("M_LOBBY_DELETEROOM_USER_ERR",				1102,	"解散房间失败，你不是房主！")

_lRegErrcode("M_LOBBY_ENTERROOM_TO_LIMITED",			1201,	"坐下失败，房间人数已满！")
_lRegErrcode("M_LOBBY_ENTERROOM_PLAYING",				1202,	"坐下失败，游戏已经开始！")

_lRegErrcode("M_LOBBY_SPEAKROOM_NOUSER",				1300,	"你不在房间内！")
_lRegErrcode("M_LOBBY_ROOM_NOTEXIST",				1301,	"房间不存在！")

_lRegErrcode("M_ROOMGAME_OUTCARD_RULE",				    2001,	"出牌不符合规则")
_lRegErrcode("M_ROOMGAME_OPTION_SEATNO",				2002,	"还未轮到您操作，请等待！")
_lRegErrcode("M_ROOMGAME_OPTION_SEGMENT",				2003,	"当前游戏阶段已经结束！")
_lRegErrcode("M_ROOMGAME_WAIT_ZHUANG_OPT",				2004,	"正在等待庄家操作，请稍后！")

_lRegErrcode("M_BROADCAST_MSG_LIMITED",				10001,	"对方私信已满！")
_lRegErrcode("M_MAILBOX_BOX_LIMITED",				10002,	"对方邮箱已满！")
_lRegErrcode("M_MAILBOX_READ_ERRMAIL",				10003,	"读取错误的邮件！")

_lRegErrcode("M_FRIEND_YOUR_FRIEND",				11002,	"该玩家已经是你的好友！")
_lRegErrcode("M_FRIEND_NOTYOUR_FRIEND",				11003,	"该玩家不是你的好友！")
_lRegErrcode("M_FRIEND_ADD_SUCCESS",				11004,	"成功添加好友！")
_lRegErrcode("M_FRIEND_ADDTIP_WAIT",				11005,	"已经发送好友申请，请等待对方回应！")
_lRegErrcode("M_FRIEND_DELETE_SUCCESS",				11006,	"成功删除好友！")
_lRegErrcode("M_FRIEND_ACCEPT_FRIEND",				11007,	"您接收对方为好友，一起愉快游戏！")
_lRegErrcode("M_FRIEND_TARGET_LIMIT",				11008,	"对方的好友数量已经达到上限")
_lRegErrcode("M_FRIEND_LIMIT_FRIEND",				11009,	"好友数量已经达到上限")
