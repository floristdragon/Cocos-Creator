let utilIconv = require("util_iconvNov7th")
let nethandshakekey = null;
let netcheckpackflag = "WTF\n";
let checknotip = 789632145;
console.log("nethandshakekey: >>>>>>>>>>>> ", nethandshakekey);
console.log("netcheckpackflag: >>>>>>>>>>>> ", netcheckpackflag);
console.log("checknotip: >>>>>>>>>>>> ", checknotip);
let SocketPack = function(sendfunc, endfunc, checkpackfunc){
    this.m_isclient = 1;
    this.m_sendfunc = sendfunc;
    this.m_endfunc = endfunc;
    this.m_checkpackfunc = checkpackfunc;
    this.reset();
};
SocketPack.prototype = {
    constructor : SocketPack,
    start : function(){
        console.log("-----pack:start======");
        this.reset();
        this._sendhandshake(checknotip);
    },
    reset : function(){
        console.log("-----pack:reset======");
        this.m_state = 1;
        this.m_proto = ""
    },
    ishandshake : function(){
        return this.m_state != 3;
    },
    packmsg : function(msg){
        if(!msg) return ;
        return this._checkmsg(msg, null, true);
    },
    unpackmsg : function(msg, sz, fd){
        console.log("======pack:unpackmsg======", msg,sz, fd, this.m_state);
        return this._dispatch(fd, msg, sz);
    },
    //-------------------------------------------------------------
    //-------------------------------------------------------------
    _dispatch : function(fd, msg, sz){
        let tomsg = this._checkmsg(msg, sz, false) ;  
        console.log("-----pack:_dispatch---state---", tomsg, fd, this.m_state,this.m_proto);
        if(!this.ishandshake()) return tomsg;
        this._recvhandshake(tomsg);
    },
    _sendhandshake : function(proto, state){
        let nowt = new Date().getTime()/1000.0;
        let tab = {};
        tab.state = state;
        tab.proto = proto;
        tab.isclient = this.m_isclient;
        if(state==3 && this.m_isclient==0){
            tab.ckey = this.m_ckey;
        }
        tab[nowt] = nowt;
        console.log("=============pack:_sendhandshake====", proto, state);
        this.m_sendfunc(tab);
        return tab;
    },
    _recvhandshake : function(msgtab){
        msgtab.ffy = utilIconv.GBKToUTF8(msgtab.ffy);
        for(let k in (msgtab)){            
            console.log("----pack:_recvhandshake---1---", k,msgtab[k]);
        }
        
        if(this.m_state==1){
            //对方是client
            if(this._isClient(msgtab)){
                if(msgtab.proto==checknotip){
                    this.m_state = 2;
                    this._sendhandshake(checknotip, this.m_state);
                    return;
                }
            }
            else if(this._isServer(msgtab)){//对方是server
                if(msgtab.proto==checknotip){
                    this.m_state = msgtab.state;
                    this._sendhandshake(checknotip, this.m_state);
                    return;
                }
            }
        }
        else if(this.m_state==2){
            if(this._isClient(msgtab)){//对方是client
                if(msgtab.state==2 && msgtab.proto==checknotip){
                    let state = 3;
                    this._sendhandshake(this.m_proto, state);
                    this.m_state = state;
                    if (this.m_state==3 && this.m_endfunc) this.m_endfunc();
                    return;
                }
            }	
            else if(this._isServer(msgtab)){//对方是server
                this.m_state = msgtab.state;
                this.m_proto = msgtab.proto;
                this.m_ckey = msgtab.ckey;
                console.log("======handshake=success=========");
                if (this.m_state==3 && this.m_endfunc) this.m_endfunc();
                return ;
            } 
        }
        this.m_state = 1; 	//若握手不成功则重置
        this.m_proto = "";
    },
    _isServer : function(tab){
        return parseInt(tab.isclient)==0 && this.m_isclient==1;
    },
    _isClient : function(tab){
        return parseInt(tab.isclient)==1 && this.m_isclient==0;
    },
    _checkmsg : function(data, size, bsend){
        return this.m_checkpackfunc(data, size, bsend);
    },    
    
}

module.exports = SocketPack;