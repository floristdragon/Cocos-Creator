"use strict";
cc._RF.push(module, '4408dEWWAZJ/Kd7PIvE/k4X', 'ui-bullfightUserInfoNov7th');
// ScriptNov7th/GameLogicScriptNov7th/bullfightLogicNov7th/bullfightNov7th/ui-bullfightUserInfoNov7th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_userName: cc.Label,
        O_userId: cc.Label,
        O_userIp: cc.Label,
        O_userHead: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {},

    showInfoNov7thFunc: function showInfoNov7thFunc(seatNo) {
        var roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        var userinfo = roominfo.getUserInfoNov7thFunc(seatNo);
        cc.log("===========showInfoNov7thFunc=========", roominfo, userinfo);

        this.O_userName.string = userinfo.userName;
        this.O_userId.string = userinfo.userId;
        this.O_userIp.string = userinfo.addr;
        var headurl = userinfo.headurl;
        if (headurl && headurl.length > 0) {
            var toSprite = this.O_userHead.getComponent(cc.Sprite);
            var toType = "png";
            if (headurl.indexOf(".jpg")) {
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, function (err, texture) {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },
    onCloseBtnNov7thFunc: function onCloseBtnNov7thFunc() {
        this.node.destroy();
    }
});

cc._RF.pop();