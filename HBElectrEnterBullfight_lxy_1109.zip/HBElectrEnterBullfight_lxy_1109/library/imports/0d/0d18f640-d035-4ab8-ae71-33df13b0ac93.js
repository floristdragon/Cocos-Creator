"use strict";
cc._RF.push(module, '0d18fZA0DVKuK5xM98TsKyT', 'RoomInfoNov7th');
// ScriptNov7th/GameBaseScriptNov7th/RoomInfoNov7th.js

"use strict";

var gameconfig = require("gameConfigNov7th");
//如果不是按照局数来限定的游戏，则maxJuShu传入nil或-1
var RoomInfoNov7th = function RoomInfoNov7th(gameid, roomid) {
    console.log("=========gameconfig===", gameconfig, gameid, roomid);
    this._roomID = roomid; //房间id
    this._gameID = gameid; //游戏id
    this._maxJuShu = -1; //最大局数
    this._curJuShu = 0; //当前局数，游戏没开始表示第一局，第一局打完就成为第二局
    this._baseScore = 0; //基本分,当前局数变化分数加上基本分就是变化分
    this._baseBeiLv = 1; //基本倍数，依据当前倍率往上递增，如胡牌赢了2倍，基本倍率为2，则赢了2+2倍
    this._userTab = {}; //已经进入房间的用户id列表
    this._ownerUserID = 0; //创建房间的用户id(房主)
    this._maxPlayer = gameconfig[this._gameID].maxPlayer; //游戏最大人数，若无限制人数，则按其他条件开始游戏
    this._roomPwd = ""; //房间密码
    this._config = {}; //创建房间的配置选项

    this._jieSanReqTab = {}; //申请解散标记
};
RoomInfoNov7th.prototype = {
    constructor: RoomInfoNov7th,
    setPackageInfoNov7thFunc: function setPackageInfoNov7thFunc(packtab) {
        var toTab = packtab;
        this._gameID = toTab.gameId;
        this._roomID = toTab.roomId;
        this._baseScore = toTab.baseScore;
        this._baseBeiLv = toTab.baseBeiLv;
        this._curJuShu = toTab.curJuShu;
        this._maxJuShu = toTab.maxJuShu;
        this._ownerUserID = toTab.ownUserId;
        this._roomPwd = toTab.roomPwd;
        this._setRoomConfigNov7thFunc(toTab.config);
        for (var i in toTab.playertab) {
            var itab = toTab.playertab[i];
            //console.log("===setPackageInfoNov7thFunc===111====", i, itab);
            this._updateUserInfoNov7thFunc(i, itab.userId, itab.userName, itab.headurl, itab.addr, itab.isBoy, itab.gold);
        }
        //console.log("===setPackageInfoNov7thFunc=======", toTab.playertab);
    },
    getPackageInfoNov7thFunc: function getPackageInfoNov7thFunc() {
        var toTab = {};
        toTab.gameId = this._gameID;
        toTab.roomId = this._roomID;
        toTab.baseScore = this._baseScore;
        toTab.baseBeiLv = this._baseBeiLv;
        toTab.curJuShu = this._curJuShu;
        toTab.maxJuShu = this._maxJuShu;
        toTab.ownUserId = this._ownerUserID;
        toTab.roomPwd = this._roomPwd;
        toTab.playertab = this.getUserIdTabNov7thFunc();
        toTab.config = this.getRoomConfigNov7thFunc();
        return toTab;
    },
    getRoomIdNov7thFunc: function getRoomIdNov7thFunc() {
        return this._roomID;
    },
    getGameIdNov7thFunc: function getGameIdNov7thFunc() {
        return this._gameID;
    },
    getMaxJuShuNov7thFunc: function getMaxJuShuNov7thFunc() {
        return this._maxJuShu;
    },
    getCurJuShuNov7thFunc: function getCurJuShuNov7thFunc() {
        return this._curJuShu;
    },
    setCurJuShuNov7thFunc: function setCurJuShuNov7thFunc(jushu) {
        this._curJuShu = jushu;
    },
    getOwnerUserIdNov7thFunc: function getOwnerUserIdNov7thFunc() {
        return this._ownerUserID;
    },
    setOwnerUserIdNov7thFunc: function setOwnerUserIdNov7thFunc(userId) {
        this._ownerUserID = userId;
    },
    _updateUserInfoNov7thFunc: function _updateUserInfoNov7thFunc(seatNo, userId, userName, headurl, addr, isBoy, gold) {
        seatNo = parseInt(seatNo);
        if (!this._userTab[seatNo]) this._userTab[seatNo] = {};
        this._userTab[seatNo].userId = userId;
        this._userTab[seatNo].userName = userName;
        this._userTab[seatNo].addr = addr;
        this._userTab[seatNo].isBoy = isBoy;
        this._userTab[seatNo].gold = gold;
        this._userTab[seatNo].headurl = headurl;
    },
    updateUserGoldNov7thFunc: function updateUserGoldNov7thFunc(seatNo, addgold) {
        if (!addgold || seatNo == null) return;
        this._userTab[seatNo].gold = this._userTab[seatNo].gold + addgold;
    },
    rmUserInfoNov7thFunc: function rmUserInfoNov7thFunc(userId) {
        if (!userId) return;
        for (var i = 0; i < this._maxPlayer; i++) {
            if (this._userTab[i] && this._userTab[i].userId == userId) {
                this._userTab[i] = null;
                return true;
            }
        }
    },
    findUserSeatNoNov7thFunc: function findUserSeatNoNov7thFunc(userId) {
        for (var i = 0; i < this._maxPlayer; i++) {
            if (this._userTab[i] && this._userTab[i].userId == userId) {
                return i;
            }
        }
        console.log("========findUserSeatNoNov7thFunc===not=find====", userId, this._userTab);
    },
    getUserInfoNov7thFunc: function getUserInfoNov7thFunc(seatNo) {
        if (seatNo == null) return this._userTab; //记住，0和null的！都是true
        seatNo = parseInt(seatNo);
        return this._userTab[seatNo];
    },
    getUserInfoByUserIdNov7thFunc: function getUserInfoByUserIdNov7thFunc(userId) {
        if (!userId) return;
        for (var i = 0; i < this._maxPlayer; i++) {
            if (this._userTab[i] && this._userTab[i].userId == userId) {
                return this._userTab[i];
            }
        }
    },
    IsJushuFinishNov7thFunc: function IsJushuFinishNov7thFunc() {
        //是否局数已尽
        if (this._maxJuShu > 0) return this._curJuShu > this._maxJuShu;
    },
    getBaseScoreNov7thFunc: function getBaseScoreNov7thFunc() {
        return this._baseScore;
    },
    setBaseScoreNov7thFunc: function setBaseScoreNov7thFunc(score) {
        this._baseScore = score;
    },
    getBaseBeiLvNov7thFunc: function getBaseBeiLvNov7thFunc() {
        return this._baseBeiLv;
    },
    setBaseBeiLvNov7thFunc: function setBaseBeiLvNov7thFunc(beilv) {
        this._baseBeiLv = beilv;
    },
    getMaxPlayerNov7thFunc: function getMaxPlayerNov7thFunc() {
        return this._maxPlayer;
    },
    _setRoomConfigNov7thFunc: function _setRoomConfigNov7thFunc(configtab) {
        this._config = {};
        if (!configtab) return;
        for (var i in configtab) {
            this._config[i] = configtab[i];
        }
    },
    getRoomConfigNov7thFunc: function getRoomConfigNov7thFunc(bDeepCopy) {
        if (!bDeepCopy) return this._config;
        var tab = {};
        for (var i in this._config) {
            tab[i] = this._config[i];
        }
        return tab;
    },
    setRoomPwdNov7thFunc: function setRoomPwdNov7thFunc(pwd) {
        this._roomPwd = pwd;
    },
    getRoomPwdNov7thFunc: function getRoomPwdNov7thFunc() {
        return this._roomPwd;
    }
};
module.exports = RoomInfoNov7th;

cc._RF.pop();