"use strict";
cc._RF.push(module, '017b4Dl4mdHMIrHnVoWPY3D', 'ui_chatUserInfoNov7thFunc');
// ScriptNov7th/GameUiScriptNov7th/ui_chatUserInfoNov7thFunc.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_userId: cc.Label,
        O_siliaoPrefab: cc.Prefab
    },

    // use this for initialization
    initNov7thFunc: function initNov7thFunc(userId) {
        this.O_userId.string = userId;
    },

    onCloseEventNov7thFunc: function onCloseEventNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.node.active = false;
    },

    onShenQingEventNov7thFunc: function onShenQingEventNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        //发送申请好友协议
        var idtoProt = {};
        idtoProt.userId = this.O_userId.string;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SReqAddFriend, idtoProt);

        cc.log("======onShenQingEventNov7thFunc========idtoProt========", idtoProt);
    },

    onSiliaoEventNov7thFunc: function onSiliaoEventNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.node.active = false;
        var siliaoNode = cc.instantiate(this.O_siliaoPrefab);
        var canNode = cc.director.getScene();
        siliaoNode.parent = canNode.getChildByName('Canvas');
        siliaoNode.setLocalZOrder(11);
        var siliaoScript = siliaoNode.getComponent('ui-lobbyPrivateChatNov7th');
        siliaoScript.initNov7thFunc(this.O_userId.string);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();