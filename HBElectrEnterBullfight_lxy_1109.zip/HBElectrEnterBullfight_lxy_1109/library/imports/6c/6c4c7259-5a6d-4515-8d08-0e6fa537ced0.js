"use strict";
cc._RF.push(module, '6c4c7JZWm1FFY0IDm+lN87Q', 'ui-lobbyActivityNov7th');
// ScriptNov7th/GameLogicScriptNov7th/lobbyLogicNov7th/ui-lobbyActivityNov7th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        label: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {},

    onCloseClickNov7thFunc: function onCloseClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();