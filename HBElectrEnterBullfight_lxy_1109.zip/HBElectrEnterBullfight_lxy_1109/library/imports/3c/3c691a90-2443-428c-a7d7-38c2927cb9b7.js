"use strict";
cc._RF.push(module, '3c691qQJENCjKfXOMKSfLm3', 'bullfightGameDataNov7th');
// ScriptNov7th/GameLogicScriptNov7th/bullfightLogicNov7th/bullfightNov7th/bullfightGameDataNov7th.js

"use strict";

require("include");
var gameconfig = require("gameConfigNov7th");
var GameRuleConfig = require("DouNiuRuleConfigNov7th");

//在两个数之间随机一个整数
var MathRandomNov7thFunc = function MathRandomNov7thFunc(min, max) {
    if (min > max) return min;
    var to = Math.random() * (max - min) + min;
    var toi = Math.floor(to);
    if (to < toi + 0.5) return toi;
    return toi + 1;
};
window.g_WRDNGameData = {
    _gameId: 0,
    _roomId: 0,

    _playerUIArray: [],
    _seatToUIArray: [],
    _gameplayArray: [],

    _selfSeatNo: 0,

    _handCardTab: [],
    _handTypeTab: [],
    _tuoguanTab: [],
    _bankerSeatNo: -1,
    _dingzbeilv: 0,

    _ishandcardSort: false,
    //------------------------------------
    //------------------------------------
    initNov7thFunc: function initNov7thFunc(gameId, roomId, selfSeatNo) {
        this._gameId = gameId;
        this._roomId = roomId;
        this._selfSeatNo = selfSeatNo;
        this.resetInitNov7thFunc();
    },
    resetInitNov7thFunc: function resetInitNov7thFunc() {
        this._handCardTab = [];
        this._handTypeTab = [];
        this._tuoguanTab = [];
        this._bankerSeatNo = -1;
        this._gameplayArray = [];

        this._ishandcardSort = false;
    },

    //---------------------------------------------------------------
    isBaZhuangConfNov7thFunc: function isBaZhuangConfNov7thFunc() {
        var tconfig = this.getRoomInfoNov7thFunc().getRoomConfigNov7thFunc();
        return tconfig.zhuangflag == 1;
    },
    isLunZhuangConfNov7thFunc: function isLunZhuangConfNov7thFunc() {
        var tconfig = this.getRoomInfoNov7thFunc().getRoomConfigNov7thFunc();
        return tconfig.zhuangflag == 2;
    },
    isQiangZhuangConfNov7thFunc: function isQiangZhuangConfNov7thFunc() {
        var tconfig = this.getRoomInfoNov7thFunc().getRoomConfigNov7thFunc();
        return tconfig.zhuangflag != 1 && tconfig.zhuangflag != 2;
    },
    setPlayerUiNov7thFunc: function setPlayerUiNov7thFunc(playerui, index, seatNo) {
        this._playerUIArray[index] = playerui;
        this._seatToUIArray[seatNo] = index;
    },
    getPlayerUiBySeatNoNov7thFunc: function getPlayerUiBySeatNoNov7thFunc(seatNo) {
        var index = this._seatToUIArray[seatNo];
        return this._playerUIArray[index];
    },
    getPlayerUiByUserIdNov7thFunc: function getPlayerUiByUserIdNov7thFunc(userId) {
        var roominfo = this.getRoomInfoNov7thFunc();
        var seatNo = roominfo.findUserSeatNoNov7thFunc(userId);
        return this.getPlayerUiBySeatNoNov7thFunc(seatNo);
    },
    setIsGamePlayNov7thFunc: function setIsGamePlayNov7thFunc(seatNo, flag) {
        //1表示在玩，其他表示不在玩
        this._gameplayArray[seatNo] = flag;
    },
    getIsGamePlayNov7thFunc: function getIsGamePlayNov7thFunc(seatNo) {
        if (!this._gameplayArray[seatNo]) return false;
        return this._gameplayArray[seatNo] == 1;
    },

    ///////////////////////////////////////////////////
    getSelfSeatNoNov7thFunc: function getSelfSeatNoNov7thFunc() {
        return this._selfSeatNo;
    },
    getNextSeatNoNov7thFunc: function getNextSeatNoNov7thFunc(curSeatNo) {
        if (curSeatNo == null) curSeatNo = this._selfSeatNo;
        var maxPeople = this.getMaxPlayerNov7thFunc();
        curSeatNo = curSeatNo + 1;
        if (curSeatNo >= maxPeople) curSeatNo = 0; //下标从0开始
        return curSeatNo;
    },
    getLastSeatNoNov7thFunc: function getLastSeatNoNov7thFunc(curSeatNo) {
        if (curSeatNo == null) curSeatNo = this._selfSeatNo;
        var maxPeople = this.getMaxPlayerNov7thFunc();
        curSeatNo = curSeatNo - 1;
        if (curSeatNo < 0) curSeatNo = maxPeople;
        return curSeatNo;
    },

    ////////////////////////////////////////////////////
    setBankerSeatNoNov7thFunc: function setBankerSeatNoNov7thFunc(seatNo) {
        this._bankerSeatNo = seatNo;
    },
    getBankerSeatNoNov7thFunc: function getBankerSeatNoNov7thFunc() {
        return this._bankerSeatNo;
    },
    setDingZhuangBeiLvNov7thFunc: function setDingZhuangBeiLvNov7thFunc(beilv) {
        this._dingzbeilv = beilv;
    },
    getDingZhuangBeiLvNov7thFunc: function getDingZhuangBeiLvNov7thFunc() {
        return this._dingzbeilv;
    },

    ////////////////////////////////////////////////////
    getRoomInfoNov7thFunc: function getRoomInfoNov7thFunc() {
        return g_RoomManager.getGameRoomInfoNov7thFunc(this._gameId, this._roomId);
    },
    getGameIdNov7thFunc: function getGameIdNov7thFunc() {
        return this._gameId;
    },
    getRoomIdNov7thFunc: function getRoomIdNov7thFunc() {
        return this._roomId;
    },

    //------------------------------------
    getMaxPlayerNov7thFunc: function getMaxPlayerNov7thFunc() {
        if (!this._gameId) this._gameId = g_ProtDef.MID_Protocol_DouNiuWuRen;
        console.log("====getMaxPlayerNov7thFunc===========", gameconfig, this._gameId, g_ProtDef.MID_Protocol_DouNiuWuRen);
        return gameconfig[this._gameId].maxPlayer;
    },

    //------------------------------------
    setHandCardTypeNov7thFunc: function setHandCardTypeNov7thFunc(seatNo, htype) {
        this._handTypeTab[seatNo] = htype;
    },
    getHandCardTypeNov7thFunc: function getHandCardTypeNov7thFunc(seatNo) {
        return this._handTypeTab[seatNo];
    },
    setHandCardTabNov7thFunc: function setHandCardTabNov7thFunc(seatNo, cardtab, isCopy) {
        if (!cardtab) return;
        var toTab = cardtab;
        if (isCopy) {
            toTab = [];
            for (var i = 0; i < cardtab.length; i++) {
                toTab[i] = cardtab[i];
            }
        }
        this._handCardTab[seatNo] = toTab;
        this._setHandCardSortNov7thFunc(this._ishandcardSort);
    },
    _setHandCardSortNov7thFunc: function _setHandCardSortNov7thFunc(isSort) {
        this._ishandcardSort = isSort;
        if (this._ishandcardSort) {
            var sortNov7thFunc = function sortNov7thFunc(a, b) {
                if (a > b) return -1;
                return 1;
            };
            for (var i = 0; i < this.getMaxPlayerNov7thFunc(); i++) {
                if (this._handCardTab[i]) {
                    this._handCardTab[i].sort(sortNov7thFunc);
                }
            }
        }
    },
    addHandCardTabNov7thFunc: function addHandCardTabNov7thFunc(seatNo, cardtab) {
        if (!this._handCardTab[seatNo]) this._handCardTab[seatNo] = {};
        for (var i = 0; i < cardtab.length; i++) {
            this._handCardTab[seatNo].push(cardtab[i]);
        }
        this._setHandCardSortNov7thFunc(this._ishandcardSort);
    },
    getHandCardTabNov7thFunc: function getHandCardTabNov7thFunc(seatNo, isCopy) {
        var toTab = [];
        if (isCopy) {
            if (this._handCardTab[seatNo]) {
                for (var i = 0; i < this._handCardTab[seatNo].length; i++) {
                    toTab[i] = this._handCardTab[i];
                }
            }
        } else {
            toTab = this._handCardTab[seatNo];
        }
        console.log("========getHandCardTabNov7thFunc===========", seatNo, toTab);
        return toTab;
    },
    getHandCardCountNov7thFunc: function getHandCardCountNov7thFunc(seatNo) {
        if (!this._handCardTab[seatNo]) return 0;
        return this._handCardTab[seatNo].length;
    },
    removeCardTabNov7thFunc: function removeCardTabNov7thFunc(seatNo, rmCardTab) {
        var toHandTab = this._handCardTab[seatNo];
        var removeNum = 0;
        for (var i = 0; i < rmCardTab.length; i++) {
            for (var j = 0; j < toHandTab.length; j++) {
                if (toHandTab[j] == rmCardTab[i]) {
                    toHandTab.splice(j, 1);
                    removeNum++;
                    break;
                }
            }
        }
        cc.log("=====removeCardTabNov7thFunc=======", toHandTab);
        return removeNum;
    },

    //------------------------------------
    //--托管
    setTuoGuanNov7thFunc: function setTuoGuanNov7thFunc(seatNo, bTuoGuan) {
        this._tuoguanTab[seatNo] = bTuoGuan;
    },
    isTuoGuanNov7thFunc: function isTuoGuanNov7thFunc(seatNo) {
        return this._tuoguanTab[seatNo];
    },

    //////////////////////////////////////////////
    //value为空，表示背牌
    getPokerFramePathNov7thFunc: function getPokerFramePathNov7thFunc(isBigPoker, value, bRawPath) {
        var topath = "BullfightResNov7th/poker-small/small_";
        if (isBigPoker) {
            topath = "BullfightResNov7th/bigPokerResNov7th/bigPoker_";
        }
        do {
            if (!value || value <= 0) {
                topath = topath + "cardback";
                break;
            }
            var cindex = GameRuleConfig.GetCardIndex(value);
            if (cindex == GameRuleConfig.CardType.XiaoWangID) {
                topath = topath + "xiaowang";
                break;
            } else if (cindex == GameRuleConfig.CardType.DaWangID) {
                topath = topath + "dawang";
                break;
            }
            var ccolor = GameRuleConfig.GetCardColor(value);
            topath += ccolor;
            topath += "_";
            topath += cindex;
        } while (0);
        if (bRawPath) {
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },
    getRangPokerFramePathNov7thFunc: function getRangPokerFramePathNov7thFunc(bRawPath) {
        var topath = "BullfightResNov7th/bigPokerResNov7th/bigPoker_rangpai";
        if (bRawPath) {
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },

    //////////////////////////////////////////////////////////////////
    playBackgroundMusicNov7thFunc: function playBackgroundMusicNov7thFunc() {
        g_SoundManager.playMusicNov7thFunc("BullfightResNov7th/soundResNov7th/musicResNov7th/bg");
    },
    _getCardIdIndexNov7thFunc: function _getCardIdIndexNov7thFunc(value) {
        var cindex = GameRuleConfig.GetCardIndex(value);
        if (cindex == GameRuleConfig.CardType.XiaoWangID) {
            return cindex;
        } else if (cindex == GameRuleConfig.CardType.DaWangID) {
            return cindex;
        }
        if (cindex <= GameRuleConfig.CardType.KID) {
            cindex += 2;
        } else if (cindex == GameRuleConfig.CardType.ErID) {
            cindex = 2;
        } else if (cindex == GameRuleConfig.CardType.YiID) {
            cindex = 1;
        }
        return cindex;
    },
    _getBaseEffectPathNov7thFunc: function _getBaseEffectPathNov7thFunc(userId) {
        var userinfo = this.getRoomInfoNov7thFunc().getUserInfoByUserIdNov7thFunc(userId);
        if (!userinfo) return;
        var effectpath = "BullfightResNov7th/soundResNov7th/effectResNov7th/";
        if (userinfo.isBoy == 1) {
            effectpath += "boySoundRes/";
        } else {
            effectpath += "girlSoundRes/";
        }
        return effectpath;
    },
    playGameStartNov7thFunc: function playGameStartNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("BullfightResNov7th/soundResNov7th/effectResNov7th/gameStartSound");
    },
    playSendCardNov7thFunc: function playSendCardNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("BullfightResNov7th/soundResNov7th/effectResNov7th/sendCardSound");
    },
    playGameResultNov7thFunc: function playGameResultNov7thFunc(isWin) {
        if (isWin) {
            g_SoundManager.playEffectNov7thFunc("BullfightResNov7th/soundResNov7th/effectResNov7th/winSound");
        } else {
            g_SoundManager.playEffectNov7thFunc("BullfightResNov7th/soundResNov7th/effectResNov7th/failedSound");
        }
    },
    playCardTypeNov7thFunc: function playCardTypeNov7thFunc(userId, ctype) {
        var topath = this._getBaseEffectPathNov7thFunc(userId);
        if (ctype <= GameRuleConfig.CardType.NiuNiu) {
            g_SoundManager.playEffectNov7thFunc(topath + "ctype" + ctype);
        }
    }
};

cc._RF.pop();