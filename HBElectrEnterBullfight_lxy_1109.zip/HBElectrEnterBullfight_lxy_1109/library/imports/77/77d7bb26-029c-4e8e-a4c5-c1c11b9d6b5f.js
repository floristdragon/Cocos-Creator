"use strict";
cc._RF.push(module, '77d7bsmApxOjqTFwcEbnWtf', 'ui-bullfightDispcardNov7th');
// ScriptNov7th/GameLogicScriptNov7th/bullfightLogicNov7th/bullfightNov7th/ui-bullfightDispcardNov7th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_dispcardprefab: cc.Prefab,
        O_dispcardNode: cc.Node,

        _dispcardSize: null,
        _dispcardArray: null,

        _dispEachNumArray: [],
        _dispEachPosArray: [],
        _dispUpFunc: null,
        _dispCurSeatNo: 0,
        _dispCurNumArray: []
    },

    // use this for initialization
    onLoad: function onLoad() {
        var dispcardsp = this.O_dispcardNode.getComponent(cc.Sprite);
        dispcardsp.enabled = false;
        this._dispcardSize = new cc.Size(this.O_dispcardNode.width, this.O_dispcardNode.height);
        this._dispcardArray = [];
    },
    _clearTurnCardNov7thFunc: function _clearTurnCardNov7thFunc() {
        this.O_dispcardNode.removeAllChildren();
        this._dispcardArray = [];
    },
    drawTurnCardNov7thFunc: function drawTurnCardNov7thFunc(numCard, pIndex) {
        this._clearTurnCardNov7thFunc();
        cc.log("========drawTurnCardNov7thFunc=========", numCard, pIndex, this._dispcardSize);
        var beginPosX = 0;
        var beginPosY = 0;
        var toInterval = 10; //this._dispcardSize.width/2.5;
        for (var i = 0; i < numCard; i++) {
            var topNode = cc.instantiate(this.O_dispcardprefab);
            topNode.parent = this.O_dispcardNode;

            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            topNode.setLocalZOrder(i);
            beginPosX += toInterval;
            this._dispcardArray.push(topNode);

            var toCardScript = topNode.getComponent("ui-bullfightPokerCardNov7th"); //不能用var
            toCardScript.setCardWidthNov7thFunc(this._dispcardSize.width);
            toCardScript.setCardHeightNov7thFunc(this._dispcardSize.height);
            toCardScript.setCardValueNov7thFunc(0);

            toCardScript.showPointTipNov7thFunc(false);
            if (pIndex == i) {
                toCardScript.showPointTipNov7thFunc(true);
            }
        }
    },
    sendAllCardNov7thFunc: function sendAllCardNov7thFunc(beginSeatNo, eachNumArray, eachPosArray, sendupfunc) {
        var maxPlayer = g_WRDNGameData.getMaxPlayerNov7thFunc();
        for (var i = 0; i < maxPlayer; i++) {
            if (!eachNumArray[i]) eachNumArray[i] = 0;
            this._dispEachNumArray[i] = eachNumArray[i];
            if (eachPosArray[i]) {
                this._dispEachPosArray[i] = this.O_dispcardNode.convertToNodeSpaceAR(eachPosArray[i]);
            }
        }
        this._dispUpFunc = sendupfunc;
        this._dispCurSeatNo = beginSeatNo;
        this._dispCurNumArray = [];
        var self = this;
        cc.director.getScheduler().unschedule(this._updateSendNov7thFunc, this);
        cc.director.getScheduler().schedule(this._updateSendNov7thFunc, this, 0.05, false);
    },
    _updateSendNov7thFunc: function _updateSendNov7thFunc(dt) {
        // if(this._dispcardArray.length<=0) {
        //     return this._dispAndCallNov7thFunc(null, null, true);
        // }
        var maxPlayer = g_WRDNGameData.getMaxPlayerNov7thFunc();
        var numReachMax = 0;
        var toAllPlayNum = 0;
        for (var i = 0; i < maxPlayer; i++) {
            if (this._dispEachPosArray[i]) {
                if (!this._dispCurNumArray[i]) this._dispCurNumArray[i] = 0;
                if (this._dispCurNumArray[i] >= this._dispEachNumArray[i]) {
                    numReachMax++;
                }
                toAllPlayNum += 1;
            }
        }
        if (numReachMax == toAllPlayNum) {
            cc.director.getScheduler().unschedule(this._updateSendNov7thFunc, this);
            return this._dispAndCallNov7thFunc(null, null, true);
        }
        var seatNo = this._dispCurSeatNo;
        if (this._dispEachPosArray[seatNo]) {
            if (this._dispCurNumArray[seatNo] >= this._dispEachNumArray[seatNo]) {
                return;
            }
            this._dispCurNumArray[seatNo]++;

            var cardsp = this._dispcardArray.pop();
            if (cardsp) {
                cardsp.runAction(cc.sequence(cc.moveTo(0.2, this._dispEachPosArray[seatNo]), cc.removeSelf()));
            }
            if (this._dispCurSeatNo == 0) g_WRDNGameData.playSendCardNov7thFunc();
            this._dispAndCallNov7thFunc(seatNo, this._dispCurNumArray[seatNo], false);
        }

        this._dispCurSeatNo++;
        this._dispCurSeatNo = this._dispCurSeatNo % maxPlayer;
    },
    _dispAndCallNov7thFunc: function _dispAndCallNov7thFunc(seatNo, num, isEnd) {
        cc.log("======_dispAndCallNov7thFunc==========", seatNo, num, isEnd);
        if (this._dispUpFunc) this._dispUpFunc(seatNo, num, isEnd);
        if (isEnd) {
            this._dispUpFunc = null;
            cc.director.getScheduler().unschedule(this._updateSendNov7thFunc, this);
        }
    }
});

cc._RF.pop();