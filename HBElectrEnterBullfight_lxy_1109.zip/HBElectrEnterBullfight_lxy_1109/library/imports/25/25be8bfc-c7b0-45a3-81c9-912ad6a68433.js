"use strict";
cc._RF.push(module, '25be8v8x7BFo4HJkSrWpoQz', 'ui-roomSceneNov7th');
// ScriptNov7th/GameUiScriptNov7th/ui-roomSceneNov7th.js

"use strict";

//用户进入房间
function lonProtEnterRoomNov7thFunc(mainId, assistId, protTab) {
    //进入房间
    cc.log("==============lonProtEnterRoomNov7thFunc==================", protTab, g_GameScene.onRecvEnterRoomNov7thFunc);
    var gameId = protTab.info.gameId;
    var roomId = protTab.info.roomId;
    var roominfo = g_RoomManager.newRoomInfoNov7thFunc(gameId, roomId);
    roominfo.setPackageInfoNov7thFunc(protTab.info);
    if (g_GameScene.onRecvEnterRoomNov7thFunc) {
        g_GameScene.onRecvEnterRoomNov7thFunc(gameId, roomId, protTab.userId);
    }
}

function lonProtGameStatusNov7thFunc(mainId, assistId, protTab) {
    //场景协议
    if (g_GameScene.onRecvGameStatusNov7thFunc) {
        g_GameScene.onRecvGameStatusNov7thFunc(protTab);
    }
}

function lonProtJieSanDeskNov7thFunc(mainId, assistId, protTab) {
    //解散
    cc.log("======lonProtJieSanDeskNov7thFunc==========", mainId, assistId, protTab);
    if (g_GameScene.onRecvJieSanDeskNov7thFunc) {
        g_GameScene.onRecvJieSanDeskNov7thFunc(protTab.gameId, protTab.roomId, protTab.userId, protTab.userName, protTab.isauto);
    }
}

function lonProtLeaveDeskNov7thFunc(mainId, assistId, protTab) {
    //离开房间
    cc.log("======lonProtLeaveDeskNov7thFunc==========", mainId, assistId, protTab);
    if (g_GameScene.onRecvLeaveDeskNov7thFunc) g_GameScene.onRecvLeaveDeskNov7thFunc(protTab.gameId, protTab.roomId, protTab.userId);
}

function lonProtCheckSignInNov7thFunc(mainId, assistId, protTab) {
    //短线检测登陆
    cc.log("========lonProtCheckSignInNov7thFunc=========");
    g_NetManager.clearSendPack(true);
}
//提示有信息操作
function lonProtUpdateJuShuNov7thFunc(mainId, assistId, protTab) {
    cc.log("========lonProtUpdateJuShuNov7thFunc=========", protTab);
    var roominfo = g_RoomManager.getGameRoomInfoNov7thFunc(protTab.gameId, protTab.roomId);
    //let toJuShu = roominfo.getCurJuShuNov7thFunc();
    if (roominfo) roominfo.setCurJuShuNov7thFunc(protTab.curJuShu);
    if (g_GameScene.onRecvUpdateJuShuNov7thFunc) {
        g_GameScene.onRecvUpdateJuShuNov7thFunc(protTab.gameId, protTab.roomId, protTab.curJuShu);
    }
}

cc.Class({
    extends: require("ui-basesceneNov7th"),

    properties: {
        _mmgamechatscript: null,
        _mmisInRoomChat: false,

        _mmChatMsgList: [],
        O_chatPrefab: cc.Prefab,

        //////////////////////////////////////////////////////Tips
        O_chatTipsNode: cc.Node,
        O_friendsTipsNode: cc.Node,
        O_mailsTipsNode: cc.Node,
        O_zhanjiTipsNode: cc.Node,
        _chatTips: null,
        _friendsTis: null,
        _mailsTips: null,
        _zhanjiTips: null
    },

    // use this for initialization
    onLoad: function onLoad() {
        var _this = this;

        this._super(); //调用父类的onLoad
        console.log("=========roomscene=onLoad=============");
        var self = this;
        g_NetManager.onopen = function () {
            console.log("======roomscene===g_NetManager.onopen=============");
            self.showLoadFlowerNov7thFunc(false);
            //test
            // 检测登陆信息, 短线重连
            var logintab = g_ConfigManager.getLoginAccountNov7thFunc();
            var accName = logintab[0];
            var accPwd = logintab[1];
            if (!accName || !accPwd) {
                self.showPopupWindowNov7thFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_LOGIN_REDO_LOGIN"), function (flag) {
                    self.switchStartSceneNov7thFunc();
                });
            } else {
                var protTab = {};
                protTab.accName = accName;
                protTab.accPwd = accPwd;
                protTab.platform = 0;
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_C2SCheckSignIN, protTab);
            }
        };
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_S2CCheckSignIN, lonProtCheckSignInNov7thFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqEnterDesk, lonProtEnterRoomNov7thFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CGameStatus, lonProtGameStatusNov7thFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqJieSanDesk, lonProtJieSanDeskNov7thFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqLeaveDesk, lonProtLeaveDeskNov7thFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CUpdateJuShu, lonProtUpdateJuShuNov7thFunc);

        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2CSendChatMsg, function (mid, pid, protTab) {
            if (_this._mmgamechatscript) {
                _this._mmgamechatscript.addChatMsgNov7thFunc(protTab);
                _this._mmChatMsgList = [];
            } else {
                _this._mmChatMsgList.push(protTab);
            }
        }, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2CNoticePoint, this.onProtNoticePointNov7thFunc, this);
    },

    //////////////////////////////////////////////////////////////////
    onRecvUpdateJuShuNov7thFunc: function onRecvUpdateJuShuNov7thFunc(gameId, roomId, curJuShu) {
        cc.log("=====onRecvUpdateJuShuNov7thFunc========", gameId, roomId, curJuShu);
    },

    //提示有信息操作
    onProtNoticePointNov7thFunc: function onProtNoticePointNov7thFunc(mainId, assistId, protTab) {
        cc.log("=====onProtNoticePointNov7thFunc========protTab======", protTab);
        var tipsNode = this.node.getChildByName('nodeTips');
        tipsNode.setLocalZOrder(9);
        this._chatTips = protTab[g_ProtDef.MID_Protocol_Broadcast];
        this._friendsTis = protTab[g_ProtDef.MID_Protocol_Friend];
        this._mailsTips = protTab[g_ProtDef.MID_Protocol_MailBox];
        this._zhanjiTips = protTab[g_ProtDef.MID_Protocol_ZhanJi];

        if (this._chatTips) {
            this.O_chatTipsNode.active = true;
        } else {
            this.O_chatTipsNode.active = false;
        }

        if (this._friendsTis) {
            this.O_friendsTipsNode.active = true;
        } else {
            this.O_friendsTipsNode.active = false;
        }

        if (this._mailsTips) {
            this.O_mailsTipsNode.active = true;
        } else {
            this.O_mailsTipsNode.active = false;
        }

        if (this._zhanjiTips) {
            this.O_zhanjiTipsNode.active = true;
        } else {
            this.O_zhanjiTipsNode.active = false;
        }
    },
    onChatPanelBtnNov7thFunc: function onChatPanelBtnNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.O_chatTipsNode.active = false;
        //聊天协议
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SReqChatMsg);

        var isfirstinit = false;
        if (!this._mmgamechatscript) {
            var talkNode = cc.instantiate(this.O_chatPrefab);

            talkNode.parent = this.node;
            if (this._mmisInRoomChat) {
                talkNode.setLocalZOrder(150);
            } else {
                talkNode.setLocalZOrder(10);
            }

            this._mmgamechatscript = talkNode.getComponent('ui-gameChatNov7th');
            isfirstinit = true;
        }
        this.setChatRoomStateNov7thFunc(this._mmisInRoomChat);
        this._mmgamechatscript.showSiliaoTipsNov7thFunc(this._chatTips);
        if (this._mmisInRoomChat) {
            this._mmgamechatscript.hideSiliaoTipsNov7thFunc(false);
        }
        this._mmgamechatscript.openChatViewNov7thFunc();

        if (isfirstinit) {
            for (var i = 0; i < this._mmChatMsgList.length; i++) {
                this._mmgamechatscript.addChatMsgNov7thFunc(this._mmChatMsgList[i]);
            }
        }
    },
    setChatRoomStateNov7thFunc: function setChatRoomStateNov7thFunc(isRoom) {
        this._mmisInRoomChat = isRoom;
        if (this._mmgamechatscript) this._mmgamechatscript.setRoomChatStateNov7thFunc(isRoom);
    }
});

cc._RF.pop();