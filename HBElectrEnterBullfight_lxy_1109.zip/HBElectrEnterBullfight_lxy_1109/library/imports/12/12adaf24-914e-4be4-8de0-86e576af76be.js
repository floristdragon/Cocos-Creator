"use strict";
cc._RF.push(module, '12ada8kkU5L5I3ghuV2r3a+', 'ItemManagerNov7th');
// ScriptNov7th/GameBaseScriptNov7th/ItemManagerNov7th.js

"use strict";

module.exports = {
    _allitemtab: {},
    updateItemNov7thFunc: function updateItemNov7thFunc(itemid, count) {
        itemid = Math.floor(parseInt(itemid) / 1000);
        this._allitemtab[itemid] = count;
    },
    getItemNov7thFunc: function getItemNov7thFunc(itemid) {
        itemid = parseInt(itemid);
        return this._allitemtab[itemid];
    },
    getGoldNov7thFunc: function getGoldNov7thFunc() {
        if (!this._allitemtab[1001]) return 0;
        return this._allitemtab[1001];
    }
};

cc._RF.pop();