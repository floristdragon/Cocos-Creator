"use strict";
cc._RF.push(module, '466eeYDTvxBrLd8MY9X98Hh', 'UserInfoNov7th');
// ScriptNov7th/GameBaseScriptNov7th/UserInfoNov7th.js

"use strict";

var UserInfo = function UserInfo(userid, username) {
    //私有变量定义在构造函数中，每次new时候都会新建
    this._userId = userid;
    this._userName = username;
    this._gold = 0;
    this._diamond = 0;
    this._ipaddr = ""; //ip
    this._isBoy = 1;
    this._headurl = "";
    this._platform = 0;
};
//静态函数, 只能通过类名访问，不能用new的对象访问,最好定义函数来访问
//UserInfo.staticParam = "111111"; 
UserInfo.prototype = {
    //共享变量或者共享函数定义在prototype中，所有new对象公用
    constructor: UserInfo,
    /*
    示例: 
    showStatic(){
        console.log("=====showStatic=======", UserInfo.staticParam, this._stparam);
    },
    setStaticValue(val){
        UserInfo.staticParam = val;
        this._stparam = val; //若构造函数未明确定义的变量，则新建一个变量
    },
    */
    setUserInfoPackageNov7thFunc: function setUserInfoPackageNov7thFunc(infotab) {
        this._userId = infotab.userId;
        this._userName = infotab.userName;
        this._diamond = infotab.diamond;
        this._gold = infotab.gold;
        this._ipaddr = infotab.addr;
        this._headurl = infotab.headurl;
        this._platform = infotab.platform;
        this._isBoy = infotab.isBoy;
    },
    getUserIdNov7thFunc: function getUserIdNov7thFunc() {
        return this._userId;
    },
    getUserNameNov7thFunc: function getUserNameNov7thFunc() {
        return this._userName;
    },
    setUserNameNov7thFunc: function setUserNameNov7thFunc(name) {
        if (!name) name = "";
        this._userName = name;
    },
    setGoldNov7thFunc: function setGoldNov7thFunc(num) {
        if (!num) num = 0;
        this._gold = num;
    },
    getGoldNov7thFunc: function getGoldNov7thFunc() {
        return this._gold;
    },
    setDiamondNov7thFunc: function setDiamondNov7thFunc(num) {
        if (!num) num = 0;
        this._diamond = num;
    },
    getDiamondNov7thFunc: function getDiamondNov7thFunc() {
        return this._diamond;
    },
    getIpAddrNov7thFunc: function getIpAddrNov7thFunc() {
        return this._ipaddr;
    },
    setIpAddrNov7thFunc: function setIpAddrNov7thFunc(addr) {
        this._ipaddr = addr;
    },
    getHeadUrlNov7thFunc: function getHeadUrlNov7thFunc() {
        return this._headurl;
    },
    setHeadUrlNov7thFunc: function setHeadUrlNov7thFunc(headurl) {
        this._headurl = headurl;
    },
    getIsBoyNov7thFunc: function getIsBoyNov7thFunc() {
        return this._isBoy;
    },
    setIsBoyNov7thFunc: function setIsBoyNov7thFunc(isboy) {
        this._isBoy = isboy;
    },
    getLoginPlatformNov7thFunc: function getLoginPlatformNov7thFunc() {
        return this._platform;
    }
};

module.exports = UserInfo;

cc._RF.pop();