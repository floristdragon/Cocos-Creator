"use strict";
cc._RF.push(module, '334189/3Z5DA5QpGUfzNrdQ', 'ui-lobbyPrivateChatNov7th');
// ScriptNov7th/GameLogicScriptNov7th/lobbyLogicNov7th/ui-lobbyPrivateChatNov7th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_editBox: cc.EditBox,
        O_chatLinePrefab: cc.Prefab,
        O_toUserId: cc.Label,

        _toUserId: 0

    },

    onCloseEventNov7thFunc: function onCloseEventNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.node.active = false;
    },

    initNov7thFunc: function initNov7thFunc(toUserid) {
        //
        //this._scrollScript = this.scrollViewNode.getComponent('ui-scrollViewNov7th');
        this.O_toUserId.string = toUserid;
        this._toUserId = toUserid;
    },

    onSendEventNov7thFunc: function onSendEventNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        if (g_GameScene.rejectClickEventNov7thFunc(3)) return;
        var userstr = this.O_editBox.string;
        this.O_editBox.string = "";

        //发送协议
        var toChattab = {};
        toChattab.toUserId = this._toUserId;
        toChattab.ctype = 4;
        toChattab.content = userstr;
        toChattab.msgtype = 3;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SSendChatMsg, toChattab);

        cc.log("========onSendEventNov7thFunc=========toChattab==========", toChattab);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();