"use strict";
cc._RF.push(module, '3e94aHmc5dEHJhXeBQUYvYy', 'nativeCallbackNov7th');
// ScriptNov7th/GameUtilsScriptNov7th/nativeCallbackNov7th.js

"use strict";

module.exports = {
    savePhotoCall: function savePhotoCall() {}
};

cc._RF.pop();