"use strict";
cc._RF.push(module, '1573azIgOxFfq5yhRePZ3wV', 'ui-bullfightCtlButtonNov7th');
// ScriptNov7th/GameLogicScriptNov7th/bullfightLogicNov7th/bullfightNov7th/ui-bullfightCtlButtonNov7th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_controlbtnnode: cc.Node,
        O_dingzhuangbtnnode: cc.Node,

        O_buqiangbtnnode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {},
    hideAllButtonNov7thFunc: function hideAllButtonNov7thFunc() {
        this.O_controlbtnnode.active = false;
        this.O_dingzhuangbtnnode.active = false;
    },
    showControlShowBtnNov7thFunc: function showControlShowBtnNov7thFunc() {
        this.hideAllButtonNov7thFunc();
        this.O_controlbtnnode.active = true;
    },
    showDingZhuangBtnNov7thFunc: function showDingZhuangBtnNov7thFunc() {
        this.hideAllButtonNov7thFunc();
        this.O_dingzhuangbtnnode.active = true;

        if (!g_WRDNGameData.isQiangZhuangConfNov7thFunc()) {
            this.O_buqiangbtnnode.active = false;
        }
    },
    ////////////////////////////////////////////////////
    onDingZBeiBtnNov7thFunc: function onDingZBeiBtnNov7thFunc(event, detail) {
        cc.log("============onDingZBeiBtnNov7thFunc=========", event, detail);
        var toProtData = {};
        toProtData.beilv = detail;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_DouNiuWuRen, g_ProtDef.ADouNiuWuRen_C2SQiangZhuang, toProtData);
    },
    onMeiNiuBtnNov7thFunc: function onMeiNiuBtnNov7thFunc(event) {
        var toProtData = {};
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_DouNiuWuRen, g_ProtDef.ADouNiuWuRen_C2SShowCard, toProtData);
    },
    onYouNiuBtnNov7thFunc: function onYouNiuBtnNov7thFunc(event) {
        var toProtData = {};
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_DouNiuWuRen, g_ProtDef.ADouNiuWuRen_C2SShowCard, toProtData);
    },
    onQuanBuFanpaiBtnNov7thFunc: function onQuanBuFanpaiBtnNov7thFunc(event) {
        this.node.emit("ctlbtn-quanbufanpai");
    }

});

cc._RF.pop();