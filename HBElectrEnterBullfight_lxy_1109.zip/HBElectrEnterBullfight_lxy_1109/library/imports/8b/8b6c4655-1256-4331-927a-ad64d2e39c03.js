"use strict";
cc._RF.push(module, '8b6c4ZVElZDMZJ6rWTS45wD', 'ui-bullfightBackgroundNov7th');
// ScriptNov7th/GameLogicScriptNov7th/bullfightLogicNov7th/bullfightNov7th/ui-bullfightBackgroundNov7th.js

"use strict";

var exFangHaoNodePos = null;
var exJuShuNodePos = null;
cc.Class({
    extends: cc.Component,

    properties: {
        O_fanghaonode: cc.Node,
        O_jushunode: cc.Node,
        O_timetext: cc.Label,
        O_clocknode: cc.Node,

        O_wanfatip: cc.Node,
        O_wanfabeilv: cc.Node,

        _backcardparent: null,
        _clockfunc: null,
        _bclocking: false,
        _clocktime: -1
    },

    // use this for initialization
    onLoad: function onLoad() {
        this._setBaseNumNov7thFunc(this.O_fanghaonode, 0);

        var self = this;
        var uptimerNov7thFunc = function uptimerNov7thFunc(dt) {
            var date = new Date();
            var tostr = "";
            if (date.getHours() < 10) {
                tostr += "0";
            }
            tostr += date.getHours();
            tostr += ":";
            if (date.getMinutes() < 10) {
                tostr += "0";
            }
            tostr += date.getMinutes();
            self.O_timetext.string = tostr;
        };
        uptimerNov7thFunc();
        this.schedule(uptimerNov7thFunc, 1);
        this.showLeftClockNov7thFunc(false);

        if (g_WRDNGameData.isBaZhuangConfNov7thFunc()) {
            this.O_wanfatip.getComponent(cc.Label).string = "霸王庄";
        } else if (g_WRDNGameData.isLunZhuangConfNov7thFunc()) {
            this.O_wanfatip.getComponent(cc.Label).string = "轮庄";
        } else if (g_WRDNGameData.isQiangZhuangConfNov7thFunc()) {
            this.O_wanfatip.getComponent(cc.Label).string = "抢庄";
        }
    },

    showBaseTipNov7thFunc: function showBaseTipNov7thFunc() {
        var roominfo = g_WRDNGameData.getRoomInfoNov7thFunc();
        if (roominfo) {
            this._setBaseNumNov7thFunc(this.O_fanghaonode, roominfo.getRoomIdNov7thFunc());

            if (!exFangHaoNodePos) {
                exFangHaoNodePos = new cc.Vec2(this.O_fanghaonode.position.x, this.O_fanghaonode.position.y);
            }
            if (!exJuShuNodePos) {
                exJuShuNodePos = new cc.Vec2(this.O_jushunode.position.x, this.O_jushunode.position.y);
            }
            var curjushu = roominfo.getCurJuShuNov7thFunc();
            var maxjushu = roominfo.getMaxJuShuNov7thFunc();
            if (maxjushu > 0) {
                this._setBaseNumNov7thFunc(this.O_jushunode, curjushu + "/" + maxjushu);
            } else {
                this.O_jushunode.active = false;
                this.O_fanghaonode.position = exJuShuNodePos;
            }
        }
        cc.log("======ScoreTip===resetTip=============", roominfo);
    },
    showBaseBeiLvNov7thFunc: function showBaseBeiLvNov7thFunc(bVisible) {
        this.O_wanfabeilv.active = bVisible;
        if (!bVisible) return;
        var beilv = g_WRDNGameData.getDingZhuangBeiLvNov7thFunc();
        this.O_wanfabeilv.getComponent(cc.Label).string = beilv + "倍";
    },
    showLeftClockNov7thFunc: function showLeftClockNov7thFunc(bVisible, ltime, func) {
        this.O_clocknode.active = bVisible;
        this._clockfunc = func;
        this._bclocking = false;
        this._clocktime = ltime;
        if (!bVisible) {
            return;
        }
        this._setBaseNumNov7thFunc(this.O_clocknode, Math.floor(this._clocktime));
        this._bclocking = true;
    },
    update: function update(dt) {
        if (!this._clocktime || this._clocktime <= 0) return;
        this._clocktime -= dt;
        this._setBaseNumNov7thFunc(this.O_clocknode, Math.floor(this._clocktime));
        if (this._clocktime <= 0) {
            if (this._clockfunc) this._clockfunc();
            this._clockfunc = null;
            this.showLeftClockNov7thFunc(false);
        }
    },

    /////////////////////////////////////////////////////////////////////////////
    _setBaseNumNov7thFunc: function _setBaseNumNov7thFunc(node, str) {
        node.getChildByName("num").getComponent(cc.Label).string = str;
    }
});

cc._RF.pop();