"use strict";
cc._RF.push(module, '3db43RDcmFDLr2LdHnXDHkp', 'ui-lobbyMessageNov7th');
// ScriptNov7th/GameLogicScriptNov7th/lobbyLogicNov7th/ui-lobbyMessageNov7th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        messageLabel: cc.Label
    },

    // use this for initialization
    initNov7thFunc: function initNov7thFunc(message) {
        if (message) {
            this.messageLabel.string = message;
        }
    },

    onCloseClickNov7thFunc: function onCloseClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();