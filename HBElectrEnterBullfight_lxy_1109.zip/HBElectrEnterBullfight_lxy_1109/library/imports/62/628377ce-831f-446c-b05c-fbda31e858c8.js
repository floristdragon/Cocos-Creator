"use strict";
cc._RF.push(module, '62837fOgx9EbLBc+9ox6FjI', 'ui-lobbyRecordLineNov7th');
// ScriptNov7th/GameLogicScriptNov7th/lobbyLogicNov7th/ui-lobbyRecordLineNov7th.js

"use strict";

var gameconfig = require("gameConfigNov7th");
cc.Class({
    extends: cc.Component,

    properties: {
        O_gameidlabel: cc.Label,
        O_roomidlabel: cc.Label,
        O_timelabel: cc.Label,

        _userdatalist: null
    },

    setDataNov7thFunc: function setDataNov7thFunc(gameid, roomid, jushu, stime, userlist) {
        this.O_gameidlabel.string = gameconfig[parseInt(gameid)].desc;
        this.O_roomidlabel.string = roomid + "-" + jushu;
        this._userdatalist = userlist;
        var date = new Date(stime * 1000);
        var extNov7thFunc = function extNov7thFunc(time) {
            if (time < 10) return "0" + time;
            return time + "";
        };
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        this.O_timelabel.string = ' ' + year + "/" + extNov7thFunc(month) + "/" + extNov7thFunc(date.getDate()) + "-" + extNov7thFunc(date.getHours()) + ":" + extNov7thFunc(date.getMinutes()) + ' ';
    },
    onClickBtnNov7thFunc: function onClickBtnNov7thFunc() {
        cc.log("=======onClickBtnNov7thFunc========", this._userdatalist);
        if (this._userdatalist) {
            this.node.emit("zhanjiline-event", this._userdatalist);
        }
    }
});

cc._RF.pop();