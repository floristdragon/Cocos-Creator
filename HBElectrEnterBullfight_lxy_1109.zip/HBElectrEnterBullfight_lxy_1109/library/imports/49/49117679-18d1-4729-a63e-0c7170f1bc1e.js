"use strict";
cc._RF.push(module, '49117Z5GNFHKaY+DHFw8bwe', 'ui-lobbyMailBoxNov7th');
// ScriptNov7th/GameLogicScriptNov7th/lobbyLogicNov7th/ui-lobbyMailBoxNov7th.js

"use strict";

var utilIconv = require("util_iconvNov7th");
cc.Class({
    extends: cc.Component,

    properties: {
        O_mailprefab: cc.Prefab,

        O_scrollview: cc.Node,

        O_maildetailnode: cc.Node,
        O_labelcontent: cc.Label,
        O_emptytip: cc.Node,

        _scrollscript: null,
        _detailnode: null
    },
    onLoad: function onLoad() {
        this.O_maildetailnode.active = false;
        this._scrollscript = this.O_scrollview.getComponent("ui-scrollViewNov7th");
        this._scrollscript.setHeightInterNov7thFunc(0);
        this._checkEmptyTipNov7thFunc();
    },
    showBoxNov7thFunc: function showBoxNov7thFunc(bVisible, bClear) {
        cc.log("=========setMailBox===========");
        this.node.active = bVisible;
        if (bClear) this._scrollscript.clearAllNodeNov7thFunc();
    },
    setBoxMailNov7thFunc: function setBoxMailNov7thFunc(maillist) {
        var _this = this;

        if (!maillist) return;

        var _loop = function _loop(i) {
            var maildata = maillist[i];
            if (!maildata) return "continue";
            //let iconvlite = require('iconv-lite');
            //let toData = iconvlite.decode(toTempArray, 'UTF8');
            maildata.title = utilIconv.GBKToUTF8(maildata.title);
            maildata.content = utilIconv.GBKToUTF8(maildata.content);
            var mailnode = cc.instantiate(_this.O_mailprefab);
            cc.log("======setBoxMailNov7thFunc===title===", maildata.title);
            mailnode.getComponent("ui-lobbyMailLineNov7th").initNov7thFunc(maildata.mailId, maildata.title, maildata.stime);
            mailnode.on("mailbox-readmail", function () {
                _this.O_labelcontent.string = maildata.content;
                _this.O_maildetailnode.active = true;
                _this._detailnode = mailnode;
            }, _this);
            _this._scrollscript.addScrollNodeNov7thFunc(mailnode, null, maildata.stime);
        };

        for (var i = 0; i < maillist.length; i++) {
            var _ret = _loop(i);

            if (_ret === "continue") continue;
        }
        this._scrollscript.sortAllNodeListNov7thFunc(function (a, b) {
            if (a > b) return -1;
            return 1;
        });
        this._checkEmptyTipNov7thFunc();
    },
    onCloseDetailClickNov7thFunc: function onCloseDetailClickNov7thFunc(node) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        cc.log("========onCloseDetailClickNov7thFunc=========", node);
        this.O_maildetailnode.active = false;
        this._scrollscript.rmScrollNodeNov7thFunc(this._detailnode);
        this._checkEmptyTipNov7thFunc();
    },
    onCloseNov7thFunc: function onCloseNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.showBoxNov7thFunc(false);
    },
    _checkEmptyTipNov7thFunc: function _checkEmptyTipNov7thFunc() {
        if (this._scrollscript.getListSizeNov7thFunc() <= 0) {
            this.O_emptytip.active = true;
        } else {
            this.O_emptytip.active = false;
        }
    }
});

cc._RF.pop();