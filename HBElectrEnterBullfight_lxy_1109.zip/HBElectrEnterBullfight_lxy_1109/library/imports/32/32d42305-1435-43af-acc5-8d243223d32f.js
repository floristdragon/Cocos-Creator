"use strict";
cc._RF.push(module, '32d42MFFDVDr6zFjSQyI9Mv', 'ui-bullfightHandCardNov7th');
// ScriptNov7th/GameLogicScriptNov7th/bullfightLogicNov7th/bullfightNov7th/ui-bullfightHandCardNov7th.js

"use strict";

var GameRuleConfig = require("DouNiuRuleConfigNov7th");
cc.Class({
    extends: cc.Component,
    properties: {
        O_handcardprefab: cc.Prefab,
        O_handCardSp: cc.Node,
        O_handCardNode: cc.Node,
        ///////////////////////////////////////////
        _seatNo: 0,
        _handCardSize: null,
        _allCardArray: [],

        _tishiEatCardTab: [],
        _touchPreMoveUpNum: 0
    },
    // 尽量在onLoad来初始化界面，在initUI初始化和数据无关的变量
    onLoad: function onLoad() {
        cc.log("========handcard=========onLoad======================", this.O_handCardSp);
        this._handCardSize = new cc.Size(this.O_handCardSp.width, this.O_handCardSp.height);
        this.O_handCardSp.active = false;

        var self = this;
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_START, function (event) {
            //console.log("TOUCH_START");
            var touchPos = event.getLocation();
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            //console.log("TOUCH_MOVE");
            var touchPos = event.getLocation();
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_END, function (event) {
            //console.log("TOUCH_END");
            var touchPos = event.getLocation();
            self.priCheckCardTouchEndNov7thFunc(touchPos, false);
        });
    },

    //属于该句柄的seatNo，cardpos为手牌中心位置，cardWidth一张手牌的宽度
    initUiNov7thFunc: function initUiNov7thFunc(seatNo) {
        this._seatNo = seatNo;
    },
    resetUiNov7thFunc: function resetUiNov7thFunc() {
        this._clearHandCardNov7thFunc();
    },
    _clearHandCardNov7thFunc: function _clearHandCardNov7thFunc() {
        this.O_handCardNode.removeAllChildren(true);
        this._allCardArray = [];
        this.O_handCardNode.active = false;
    },
    drawHandCardNov7thFunc: function drawHandCardNov7thFunc(numCard, isAllShow) {
        this._clearHandCardNov7thFunc();
        var handCardTab = g_WRDNGameData.getHandCardTabNov7thFunc(this._seatNo);
        if (!handCardTab || handCardTab.length <= 0) return;
        if (!numCard || numCard > handCardTab.length) numCard = handCardTab.length;
        var beginPosX = 0;
        var beginPosY = 0;
        var toInterZOrder = 1;
        var toInterval = this._handCardSize.width + 10;
        var selfSeatNo = g_WRDNGameData.getSelfSeatNoNov7thFunc();
        if (selfSeatNo != this._seatNo) {
            toInterval = this._handCardSize.width / 3.5;
        }
        var isNextTwoSeatNo = false;
        var isLastTwoSeatNo = false;
        if (true) {
            var toTSeatNo = g_WRDNGameData.getNextSeatNoNov7thFunc(selfSeatNo);
            if (toTSeatNo == this._seatNo) isNextTwoSeatNo = true;
            toTSeatNo = g_WRDNGameData.getNextSeatNoNov7thFunc(toTSeatNo);
            if (toTSeatNo == this._seatNo) isNextTwoSeatNo = true;
        }
        if (!isNextTwoSeatNo) {
            var _toTSeatNo = g_WRDNGameData.getLastSeatNoNov7thFunc(selfSeatNo);
            if (_toTSeatNo == this._seatNo) isLastTwoSeatNo = true;
            _toTSeatNo = g_WRDNGameData.getLastSeatNoNov7thFunc(_toTSeatNo);
            if (_toTSeatNo == this._seatNo) isLastTwoSeatNo = true;
        }

        if (isLastTwoSeatNo) {
            beginPosX = 0;
        } else if (isNextTwoSeatNo) {
            beginPosX = 0;
            toInterval *= -1;
            toInterZOrder *= -1;
        } else {
            beginPosX -= (numCard - 1) * toInterval / 2;
        }
        var rangpaiNum = 0; //g_WRDNGameData.getQiangRangNum();
        if (this._seatNo == g_WRDNGameData.getBankerSeatNoNov7thFunc()) {
            rangpaiNum = -1;
        }
        cc.log("========drawHandCardNov7thFunc=========", handCardTab, numCard, rangpaiNum);
        for (var i = 0; i < numCard; i++) {
            var topNode = cc.instantiate(this.O_handcardprefab);
            var toCardScript = topNode.getComponent("ui-bullfightPokerCardNov7th"); //不能用var

            if (isAllShow) {
                toCardScript.setCardValueNov7thFunc(handCardTab[i]);
            } else {
                var israngpai = false;
                if (i < rangpaiNum) {
                    israngpai = true;
                }
                toCardScript.setCardValueNov7thFunc(0, israngpai);
            }
            if (selfSeatNo != this._seatNo) {
                toCardScript.setCardScaleNov7thFunc(0.75);
            }
            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            console.log("======drawHandCardNov7thFunc============", beginPosX, beginPosY);
            topNode.setLocalZOrder(i * toInterZOrder);
            beginPosX += toInterval;
            this._allCardArray.push(topNode);

            topNode.parent = this.O_handCardNode;
        }
        //按照zorder来从大到小排列，用于触摸
        this._allCardArray.reverse();
        if (numCard > 0) {
            this.O_handCardNode.active = true;
        }
        console.log("===drawHandCardNov7thFunc====end==", this.O_handCardNode);
    },
    recoverAllCardNov7thFunc: function recoverAllCardNov7thFunc() {
        this.priCheckCardTouchEndNov7thFunc(cc.Vec2.ZERO, true);
    },


    //////////////////////////////////////////////////////////////////////////////////////////////
    priCheckCardTouchEndNov7thFunc: function priCheckCardTouchEndNov7thFunc(touchPos, isAllShow) {
        var cardtab = g_WRDNGameData.getHandCardTabNov7thFunc(this._seatNo);
        cc.log("-----recoverAllCardNov7thFunc----priCheckCardTouchEndNov7thFunc----", isAllShow, cardtab);
        for (var i = 0; i < this._allCardArray.length; i++) {
            var cardScript = this._allCardArray[i].getComponent("ui-bullfightPokerCardNov7th");
            if (!cardScript) return;
            if (isAllShow || cardScript.onChceckTouchEndNov7thFunc(touchPos)) {
                cardScript.recoverCardNov7thFunc(cardtab[i]);
                if (!isAllShow) break;
            }
        }
    }
});

cc._RF.pop();