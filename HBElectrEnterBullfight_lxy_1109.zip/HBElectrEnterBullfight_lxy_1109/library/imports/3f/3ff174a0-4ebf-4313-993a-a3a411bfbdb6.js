"use strict";
cc._RF.push(module, '3ff17SgTr9DE5k6o6QRv722', 'ui-bullfightGameResultNov7th');
// ScriptNov7th/GameLogicScriptNov7th/bullfightLogicNov7th/bullfightNov7th/ui-bullfightGameResultNov7th.js

"use strict";

var nativeExtend = require("nativeExtendNov7th");
cc.Class({
    extends: cc.Component,

    properties: {
        O_winnode: cc.Node,
        O_lossnode: cc.Node,

        O_winAniNode: cc.Node,
        O_lossAniNode: cc.Node,
        O_jiesuannode: cc.Node

    },

    // use this for initialization
    onLoad: function onLoad() {
        this.showResultNov7thFunc(false);
    },
    showResultNov7thFunc: function showResultNov7thFunc(isVisible, isGameWin) {
        this.node.active = isVisible;
        if (!isVisible) {
            return;
        }
        var selfUserId = g_UserManager.getSelfUserIdNov7thFunc();
        this.O_winnode.active = isGameWin;
        this.O_lossnode.active = !isGameWin;

        this.O_lossAniNode.active = false;
        this.O_winAniNode.active = false;
        if (!isGameWin) {
            this.O_lossAniNode.active = true;
            this.O_lossAniNode.getComponent(cc.Animation).play();
        } else {
            this.O_winAniNode.active = true;
            this.O_winAniNode.getComponent(cc.Animation).play();
        }
        this.O_jiesuannode.active = true;
        this.O_jiesuannode.opacity = 0;
        this.O_jiesuannode.runAction(cc.sequence(cc.delayTime(1.0), cc.fadeIn(0.5)));
    },

    onExitGameBtnNov7thFunc: function onExitGameBtnNov7thFunc(event) {
        this.showResultNov7thFunc(false);
        var toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIdNov7thFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIdNov7thFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqLeaveDesk, toProtTab);
    },
    onShareBtnNov7thFunc: function onShareBtnNov7thFunc(event) {
        nativeExtend.screenShoot(function (path, w, h) {
            nativeExtend.shareImageNative("image", path, "");
        });
    },
    onContinueBtnNov7thFunc: function onContinueBtnNov7thFunc(event) {
        this.showResultNov7thFunc(false);

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_DouNiuWuRen, g_ProtDef.ADouNiuWuRen_C2SReady);
    }
});

cc._RF.pop();