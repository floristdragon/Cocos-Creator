"use strict";
cc._RF.push(module, '38404zVajNJVZjPM/WWmaAT', 'ui-xieYiNodeNov7th');
// ScriptNov7th/GameLogicScriptNov7th/startLogicNov7th/ui-xieYiNodeNov7th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    onCloseBtnNov7thFunc: function onCloseBtnNov7thFunc(event) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.node.emit("login-hidexieyi");
    }

});

cc._RF.pop();