"use strict";
cc._RF.push(module, '9beb5NsTnNKpY+uqn1KJANh', 'ui-lobbyMailLineNov7th');
// ScriptNov7th/GameLogicScriptNov7th/lobbyLogicNov7th/ui-lobbyMailLineNov7th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {

        title: cc.Label,
        time: cc.Label,
        bgFrame: cc.SpriteFrame,
        bg: cc.Sprite,

        _mailId: null,
        _node: null,

        _renew: null
    },

    // use this for initialization
    initNov7thFunc: function initNov7thFunc(mid, title, stime) {
        this.title.string = title;
        var date = new Date(stime * 1000);
        var extNov7thFunc = function extNov7thFunc(time) {
            if (time < 10) return "0" + time;
            return time + "";
        };
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        this.time.string = year + "/" + extNov7thFunc(month) + "/" + extNov7thFunc(date.getDate()) + " " + extNov7thFunc(date.getHours()) + ":" + extNov7thFunc(date.getMinutes());
        this._mailId = mid;
    },

    onClickNov7thFunc: function onClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");

        this.bg.spriteFrame = this.bgFrame;
        var mailtoProtab = {};
        mailtoProtab.mailId = this._mailId;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_MailBox, g_ProtDef.AMailBox_C2SReqReadMail, mailtoProtab);

        this.node.emit("mailbox-readmail");
        cc.log("==============ui-mailContent.parent================", this._mailId);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();