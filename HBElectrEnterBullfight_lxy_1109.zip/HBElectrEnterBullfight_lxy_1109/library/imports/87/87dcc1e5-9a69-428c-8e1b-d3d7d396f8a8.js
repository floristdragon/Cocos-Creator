"use strict";
cc._RF.push(module, '87dccHlmmlCjI4b09fTlvio', 'ui-lobbySceneNov7th');
// ScriptNov7th/GameLogicScriptNov7th/lobbyLogicNov7th/ui-lobbySceneNov7th.js

"use strict";

var utilIconv = require("util_iconvNov7th");
cc.Class({
    extends: require("ui-roomSceneNov7th"),

    properties: {

        O_bottmBtns: cc.Node,

        O_isRoomExitPrefab: cc.Prefab,
        O_createRoomprefab: cc.Prefab,
        O_joinRoomprefab: cc.Prefab,
        O_userinfoprefab: cc.Prefab,

        //bottomButtons Prefab
        O_friendsPrefab: cc.Prefab,
        O_kefuPrefab: cc.Prefab,
        O_zhanjiPrefab: cc.Prefab,
        O_mailPrefab: cc.Prefab,
        O_messagePrefab: cc.Prefab,
        O_activityPrefab: cc.Prefab,

        //topButtons Prefab
        O_settingPrefab: cc.Prefab,
        O_rulePrefab: cc.Prefab,

        O_noticeMaskNode: cc.Node,
        O_namelabel: cc.Label,
        O_useridlabel: cc.Label,

        O_paihangbangPrefab: cc.Prefab,
        O_showChat: cc.Node,
        ///////////////////////////////////////////////////////
        _createroomNode: null,
        _joinroomNode: null,
        _mailBoxScript: null,
        _friendNode: null,
        _friendnodeScript: null,
        _ctrCreateOrJoinRoomFlag: null,

        _paihangbangNode: null,
        _zhanjiNodeScript: null
    },

    // use this for initialization
    onLoad: function onLoad() {
        this._super(); //调用父类的
        this.O_bottmBtns.setLocalZOrder(5);
        this.O_showChat.setLocalZOrder(5);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CQueryMyDesk, this.onProtCurrentRoomExitNov7thFunc, this);
        //注册回调函数
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CCreatDesk, this.onProtCreateRoomNov7thFunc, this);
        //排行榜协议
        // g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Rank, g_ProtDef.ARank_S2CReqRankList, this.onProtReqRankListNov7thFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_MailBox, g_ProtDef.AMailBox_S2CQueryAllMail, this.onProtMailListNov7thFunc, this);
        //大厅公告
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2ClobbyNotice, this.onProtLobbyNoticeNov7thFunc, this);

        //初始化数据
        var userinfo = g_UserManager.getSelfUserInfoNov7thFunc();
        this.O_namelabel.string = userinfo.getUserNameNov7thFunc();
        this.O_useridlabel.string = "ID:" + userinfo.getUserIdNov7thFunc();
        cc.log("=====lobbbyscene===onLoad=======", this.O_namelabel.string);
        // this._showRankNodeNov7thFunc();

        g_SoundManager.playMusicNov7thFunc("CommonResNov7th/bgMusicNov7th-lobby");
        //请求一些信息
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Rank, g_ProtDef.ARank_C2SReqRankList);
        //
        var toBcProtTab = {};
        toBcProtTab.AppGameID = g_ConfigManager.getGlobalConfigNov7thFunc("AppGameID");
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SlobbyNotice, toBcProtTab);
    },
    _runNoticeLabelActionNov7thFunc: function _runNoticeLabelActionNov7thFunc(str, repeatnum) {
        var noticelabel = this.O_noticeMaskNode.getChildByName("label");
        noticelabel.getComponent(cc.Label).string = str;
        noticelabel.stopAllActions();
        var maskWidth = this.O_noticeMaskNode.width;
        if (maskWidth < noticelabel.width) maskWidth = noticelabel.width;
        var toPosY = noticelabel.position.y;
        var toPosX = 0;
        var toRightPos = new cc.Vec2(toPosX - maskWidth - 5, toPosY);
        var toLeftPos = new cc.Vec2(toPosX + maskWidth + 5, toPosY);
        var toAction = cc.sequence(cc.moveTo(15, toRightPos), cc.moveTo(0, toLeftPos));
        if (!repeatnum || repeatnum <= 0) {
            noticelabel.runAction(cc.repeatForever(toAction));
        } else {
            noticelabel.runAction(cc.repeat(toAction, repeatnum));
        }
    },

    ///////////////////////////////////////////////////////////////
    //协议回调 
    //玩家查询属于自己创建的桌子房间状态
    onProtCurrentRoomExitNov7thFunc: function onProtCurrentRoomExitNov7thFunc(mainId, assistId, protTab) {
        cc.log("=====onProtCurrentRoomExitNov7thFunc===================", mainId, assistId, protTab);
        this.showLoadFlowerNov7thFunc(false);
        if (protTab && protTab.length > 0) {
            var curroomnode = cc.instantiate(this.O_isRoomExitPrefab);
            curroomnode.parent = this.node;
            curroomnode.setLocalZOrder(10);
            curroomnode.active = true;
            var croomexitScript = curroomnode.getComponent('ui-lobbyCurrentRoomNov7th');
            for (var i = 0; i < protTab.length; i++) {
                var toroomdata = protTab[i];
                croomexitScript.addOneRoomRecordNov7thFunc(toroomdata.gameId, toroomdata.roomId, toroomdata.curjushu, toroomdata.maxjushu);
            }
        } else {
            if (this._ctrCreateOrJoinRoomFlag == 1) {
                this._showCreateRoomNodeNov7thFunc(true);
            } else if (this._ctrCreateOrJoinRoomFlag == 2) {
                this._showJoinRoomNodeNov7thFunc(true);
            }
        }
    },

    //用户创建房间
    onProtCreateRoomNov7thFunc: function onProtCreateRoomNov7thFunc(mainId, assistId, protTab) {
        cc.log("=====onProtCreateRoomNov7thFunc===================", mainId, assistId, protTab);
        var roominfo = g_RoomManager.newRoomInfoNov7thFunc(protTab.gameId, protTab.roomId);
        roominfo.setPackageInfoNov7thFunc(protTab);

        var toProtTab = {};
        toProtTab.gameId = roominfo.getGameIdNov7thFunc(); //游戏id
        toProtTab.roomId = roominfo.getRoomIdNov7thFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqEnterDesk, toProtTab);
    },

    //请求大厅公告
    onProtLobbyNoticeNov7thFunc: function onProtLobbyNoticeNov7thFunc(mainId, assistId, protTab) {
        cc.log("======lobbyScene=======onProtLobbyNoticeNov7thFunc========", protTab);
        if (protTab.itype == 0) {
            var toContent = utilIconv.GBKToUTF8(protTab.content);
            this._runNoticeLabelActionNov7thFunc(toContent, protTab.repeatnum);
        }
    },

    //排行榜
    // onProtReqRankListNov7thFunc(mainId, assistId, protTab) {
    //     cc.log("=========ui-lobbySceneNov7th=========onRankInit=========", protTab);
    //     if (!this._paihangbangNode) {
    //         this._paihangbangNode = cc.instantiate(this.O_paihangbangPrefab);
    //         this._paihangbangNode.parent = this.node;
    //         this._paihangbangNode.setLocalZOrder(2);
    //     }
    //     let phbscript = this._paihangbangNode.getComponent('ui-lobbyrank');
    //     phbscript.setPaiHangBangNov7thFunc(protTab.rank, protTab.winNum, protTab.list);
    // },

    onProtMailListNov7thFunc: function onProtMailListNov7thFunc(mainId, assistId, protTab) {
        cc.log("=========ui-lobbySceneNov7th=============onProtMailListNov7thFunc========", protTab);
        if (this._mailBoxScript) this._mailBoxScript.setBoxMailNov7thFunc(protTab.mailtab);
    },

    ///////////////////////////////////////////////////////////////
    onRecvErrcodeNov7thFunc: function onRecvErrcodeNov7thFunc(errcode, attachtab) {
        cc.log("=======onRecvErrcodeNov7thFunc============", errcode, attachtab);
        this.showPopupWindowNov7thFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },
    onRecvEnterRoomNov7thFunc: function onRecvEnterRoomNov7thFunc(gameId, roomId, userId) {
        cc.log("==========lobbyscene====onRecvEnterRoomNov7thFunc=====", gameId, roomId, userId);
        g_RoomManager.setCurGameRoomNov7thFunc(null, null);
        var selfUserId = g_UserManager.getSelfUserIdNov7thFunc();
        if (selfUserId == userId) {
            g_RoomManager.setCurGameRoomNov7thFunc(gameId, roomId);
            if (gameId == g_ProtDef.MID_Protocol_ErRenDDZ) {
                // this.switchErRenDdzSceneNov7thFunc();
            } else if (gameId == g_ProtDef.MID_Protocol_ClassicDDZ) {
                // this.switchClassicDdzSceneNov7thFunc()
            } else if (gameId == g_ProtDef.MID_Protocol_DouNiuWuRen) {
                this.switchBullfightSceneNov7thFunc();
            } else if (gameId == g_ProtDef.MID_Protocol_SanGongWuRen) {
                // this.switchWuRenSanGongSceneNov7thFunc();
            }
        }
    },
    _showCreateRoomNodeNov7thFunc: function _showCreateRoomNodeNov7thFunc(isVisible) {
        if (!this._createroomNode) {
            this._createroomNode = cc.instantiate(this.O_createRoomprefab);
            this._createroomNode.parent = this.node;
            this._createroomNode.setLocalZOrder(10);
        }
        this._createroomNode.active = isVisible;
    },
    _showJoinRoomNodeNov7thFunc: function _showJoinRoomNodeNov7thFunc(isVisible) {
        if (!this._joinroomNode) {
            this._joinroomNode = cc.instantiate(this.O_joinRoomprefab);
            cc.log("======= this._joinroomNode ========", this._joinroomNode);
            this._joinroomNode.parent = this.node;
            this._joinroomNode.setLocalZOrder(10);
        }
        this._joinroomNode.active = isVisible;
    },
    onExitGameBtnNov7thFunc: function onExitGameBtnNov7thFunc(event) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        var self = this;
        self.showPopupWindowNov7thFunc(true, true, "提示", "是否退出游戏？", function (okflag) {
            cc.log("===========showPopupWindowNov7thFunc=============", okflag);
            if (okflag == 1) {
                cc.game.end();
            }
        });
    },

    // _showRankNodeNov7thFunc(){
    //     //
    //     this._paihangbangNode = cc.instantiate(this.O_paihangbangPrefab);
    //     this._paihangbangNode.parent = this.node;
    //     this._paihangbangNode.setLocalZOrder(2);
    // },
    onCreateRoomBtnNov7thFunc: function onCreateRoomBtnNov7thFunc(event) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.showLoadFlowerNov7thFunc(true);
        this._ctrCreateOrJoinRoomFlag = 1;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SQueryMyDesk);
    },
    onJoinRoomBtnNov7thFunc: function onJoinRoomBtnNov7thFunc(event) {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.showLoadFlowerNov7thFunc(true);
        this._ctrCreateOrJoinRoomFlag = 2;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SQueryMyDesk);
    },
    onUserInfoBtnNov7thFunc: function onUserInfoBtnNov7thFunc(event) {},


    //分享点击事件
    onFriendsClickNov7thFunc: function onFriendsClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.O_friendsTipsNode.active = false;
        if (!this._friendNode) {
            var friendNode = cc.instantiate(this.O_friendsPrefab);
            friendNode.parent = this.node;
            friendNode.setLocalZOrder(10);
            this._friendNode = friendNode;
        }
        this._friendnodeScript = this._friendNode.getComponent('ui-lobbyFriendsNov7th');
        if (this._friendsTis == 1) {
            this._friendnodeScript.showApplyTipsNov7thFunc(this._friendsTis);
            this._friendsTis = 0;
        }
        this._friendnodeScript.openFriendsViewNov7thFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SQueryFriend);
    },
    onSettingClickNov7thFunc: function onSettingClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        var settingNode = cc.instantiate(this.O_settingPrefab);
        settingNode.parent = this.node;
        settingNode.setLocalZOrder(10);
    },
    onKeFuClickNov7thFunc: function onKeFuClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        var kefuNode = cc.instantiate(this.O_kefuPrefab);
        kefuNode.parent = this.node;
        kefuNode.setLocalZOrder(10);
    },
    onMessageClickNov7thFunc: function onMessageClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        var messageNode = cc.instantiate(this.O_messagePrefab);
        messageNode.parent = this.node;
        messageNode.setLocalZOrder(10);
    },
    onActivityClickNov7thFunc: function onActivityClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        var activityNode = cc.instantiate(this.O_activityPrefab);
        activityNode.parent = this.node;
        activityNode.setLocalZOrder(10);
    },
    onMailClickNov7thFunc: function onMailClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        cc.log("========ui-lobbySceneNov7th=====onMailClickNov7thFunc===============");

        //邮箱协议
        var toProtTab = {};
        toProtTab.AppGameID = g_ConfigManager.getGlobalConfigNov7thFunc("AppGameID");
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_MailBox, g_ProtDef.AMailBox_C2SQueryAllMail, toProtTab);

        if (!this._mailBoxScript) {
            var mailBoxNode = cc.instantiate(this.O_mailPrefab);
            mailBoxNode.parent = this.node;
            mailBoxNode.setLocalZOrder(10);
            this._mailBoxScript = mailBoxNode.getComponent('ui-lobbyMailBoxNov7th');
        }
        this._mailBoxScript.showBoxNov7thFunc(true, true);
    },
    onRuleClickNov7thFunc: function onRuleClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        var ruleNode = cc.instantiate(this.O_rulePrefab);
        ruleNode.setLocalZOrder(10);
        ruleNode.parent = this.node;
        var close = ruleNode.getChildByName('close');
        close.off("touchstart");
        close.on('touchstart', function (event) {
            g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
            ruleNode.active = false;
        });
    },
    onZhanJiClickNov7thFunc: function onZhanJiClickNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        this.O_zhanjiTipsNode.active = false;
        if (!this._zhanjiNodeScript) {
            var zhanjiNode = cc.instantiate(this.O_zhanjiPrefab);
            zhanjiNode.parent = this.node;
            zhanjiNode.setLocalZOrder(10);

            this._zhanjiNodeScript = zhanjiNode.getComponent("ui-lobbyRecordNov7th");
        }
        cc.log("==============onZhanJiClickNov7thFunc============", this._zhanjiNodeScript);
        this._zhanjiNodeScript.showUiNov7thFunc(true);
    },
    onShowUserInfoPanelNov7thFunc: function onShowUserInfoPanelNov7thFunc() {
        g_SoundManager.playEffectNov7thFunc("CommonResNov7th/btnMusicNov7th");
        var userInfoNode = cc.instantiate(this.O_userinfoprefab);
        userInfoNode.setLocalZOrder(100);
        userInfoNode.parent = this.node;
    }
});

cc._RF.pop();