
module.exports = {
    HotFixVersion : "1.2.0",    //热更新版本
    HotFixUrl : "http://39.108.141.178:8080/hotfix/creator/version.manifest", //热更新生成的version文件

    VERSION : "1.0", //游戏版本
    ServerIP : "39.108.232.240",
    ServerPort : 11010,
};  