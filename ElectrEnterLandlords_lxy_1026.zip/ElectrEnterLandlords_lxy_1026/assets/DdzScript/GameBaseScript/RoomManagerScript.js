let RoomInfo = require("RoomInfoScript");
let lAllGameRoomTab = {};
module.exports = {
    _curGameId : null,
    _curRoomId : null,
    ///////////////////////////////////////////////////////
    newRoomInfoFunc(gameId, roomId){
        let rinfo = new RoomInfo(gameId, roomId);
        if(gameId && roomId){
            return this._addRoomInfoFunc(rinfo);
        }
    },
    _addRoomInfoFunc(roominfo){
        let gameId = roominfo.getGameIDFunc();
        let roomId = roominfo.getRoomIDFunc();
        if(!lAllGameRoomTab[gameId])lAllGameRoomTab[gameId] = {};
        lAllGameRoomTab[gameId][roomId] = roominfo;
        return roominfo;
    },
    getGameRoomInfoFunc(gameId, roomId){
        if(!roomId) return lAllGameRoomTab[gameId];
        return lAllGameRoomTab[gameId][roomId];
    },
    setCurGameRoomFunc(gameId, roomId){
        this._curGameId = gameId;
        this._curRoomId = roomId;
    },
    getCurGameIDFunc(){
        return this._curGameId;
    },
    getCurRoomIDFunc(){
        return this._curRoomId;
    },
}
