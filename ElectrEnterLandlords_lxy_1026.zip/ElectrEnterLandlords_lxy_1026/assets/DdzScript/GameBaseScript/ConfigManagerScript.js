//var utilbase64 = require("util-base64Script");
var globalConfig = require("globalConfig");

var exSecretkey= 'open_fwclient'; // 加密密钥
var exConfigKey = "ConfigManager_local";

var exLocalConfPath = "";
var exConfigDataTab = null;
var fwriteStorageTabFunc = function(datatab){
    if(!datatab) return ;
    let stringdata = JSON.stringify(datatab);
    //js.fileUtils().writeStringToFile(stringdata, exLocalConfPath);
    var encrypted = stringdata;//utilEncryptJS.encryptWithAES(stringdata,exSecretkey,256);
    cc.sys.localStorage.setItem(exConfigKey, encrypted);
};
var freadStorageTabFunc = function(){
    // exLocalConfPath = jsb.fileUtils().getWritablePath() + "userconfig";
    // let datastr = jsb.fileUtils().getStringFromFile(exLocalConfPath);
    let datastr = cc.sys.localStorage.getItem(exConfigKey);
    if(datastr && datastr!=""){
        //return JSON.parse(utilEncryptJS.decryptWithAES(cipherText,exSecretkey));
        return JSON.parse(datastr);
    }
    return {};
};
module.exports = {
    ////////////////////////////////////////////////////
    //用户读写本地数据
    _checkLoadConfigFunc(){
        if(!exConfigDataTab){
            exConfigDataTab = freadStorageTabFunc();
        }
    },
    getGlobalConfigFunc(key) {
        return globalConfig[key];
    },
    getHotfixVersionFunc(){
        let cifVersion = this.getKeyFunc("CIFHotFixVersion", "0");
        let curVersion = this.getGlobalConfigFunc("HotFixVersion");
        let toVersion;
        do{
            if(!cifVersion) {
                toVersion = curVersion; //如果没有写配置，则用代码里面的配置
                break;
            }
            if(curVersion>cifVersion) {
                toVersion = curVersion; //如果代码里面配置比本地配置高，则用高版本
                break;
            }
            toVersion = cifVersion; //否则用本地配置版本
        }while(0);
        return toVersion;
    },
    setHotfixVersionFunc(version){
        this.setKeyFunc("CIFHotFixVersion", version+"");
        this.flushFunc();
    },
    getKeyFunc(key, defaultData){
        this._checkLoadConfigFunc();
        if(!exConfigDataTab[key]){
            exConfigDataTab[key] = defaultData;
        }
        return exConfigDataTab[key];
    },
    
    setKeyFunc(key, data, autoflush){
        console.log("======g_ConfigManager==setKeyFunc===========", key, data);
        this._checkLoadConfigFunc();
        exConfigDataTab[key] = data;
        if(autoflush){
            this.flushFunc();
        }
    },
    
    flushFunc(){
        fwriteStorageTabFunc(exConfigDataTab);
    },
    /////////////////////////////////////////////////////////////////////////
    //登陆相关
    setLoginAccountFunc(account, pwd){
        this.setKeyFunc("TLOGINACCOUNT", account);
        this.setKeyFunc("TLOGINPWD", pwd);
        this.flushFunc();
    },
    getLoginAccountFunc(){
        let loginAcc = this.getKeyFunc("TLOGINACCOUNT", "")
        let loginPwd = this.getKeyFunc("TLOGINPWD", "")
        return [loginAcc, loginPwd];
    },
    setIsAlreadyLoginFunc(flag){
        this.m_bIsAlreadyLogin = flag;
    },
    getIsAlreadyLoginFunc(){
        return this.m_bIsAlreadyLogin;
    },
    checkIsCanLoginLobbyFunc(maxWait) {
        if(!this.m_iLoginLobbyFlag){
            this.m_iLoginLobbyFlag = 0;
        }
        this.m_iLoginLobbyFlag = this.m_iLoginLobbyFlag + 1;
        return this.m_iLoginLobbyFlag==maxWait;
    },
    resetIsCanLoginLobbyFunc(){
        this.m_iLoginLobbyFlag = 0;
    },
}
