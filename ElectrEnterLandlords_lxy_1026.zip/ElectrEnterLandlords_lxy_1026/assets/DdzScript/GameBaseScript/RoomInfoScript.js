let gameconfig = require("GameConfigScript");
//如果不是按照局数来限定的游戏，则maxJuShu传入nil或-1
let RoomInfoFunc = function(gameid, roomid){
    console.log("=========gameconfig===", gameconfig, gameid, roomid);
    this._roomID = roomid; 	//房间id
    this._gameID = gameid; 	//游戏id
    this._maxJuShu = -1; 	 //最大局数
    this._curJuShu = 0;		//当前局数，游戏没开始表示第一局，第一局打完就成为第二局
    this._baseScore = 0;		//基本分,当前局数变化分数加上基本分就是变化分
    this._baseBeiLv = 1;		//基本倍数，依据当前倍率往上递增，如胡牌赢了2倍，基本倍率为2，则赢了2+2倍
    this._userTab = {};	//已经进入房间的用户id列表
    this._ownerUserID = 0; //创建房间的用户id(房主)
    this._maxPlayer = gameconfig[this._gameID].maxPlayer;  //游戏最大人数，若无限制人数，则按其他条件开始游戏
    this._roomPwd = "";		//房间密码
    this._config = {};	//创建房间的配置选项

    this._jieSanReqTab = {}; //申请解散标记
};
RoomInfoFunc.prototype = {
    constructor : RoomInfoFunc,
    setPackageInfoFunc(packtab){
        let toTab = packtab;
        this._gameID = toTab.gameId;
        this._roomID = toTab.roomId;
        this._baseScore = toTab.baseScore;
        this._baseBeiLv = toTab.baseBeiLv;
        this._curJuShu = toTab.curJuShu;
        this._maxJuShu = toTab.maxJuShu;
        this._ownerUserID = toTab.ownUserId;
        this._roomPwd = toTab.roomPwd;
        this._setRoomConfigFunc(toTab.config);
        for(let i in toTab.playertab){
            let itab = toTab.playertab[i];
            //console.log("===setPackageInfoFunc===111====", i, itab);
            this._updateUserInfoFunc(i, itab.userId, itab.userName, itab.headurl, itab.addr, itab.isBoy, itab.gold);
        }
        //console.log("===setPackageInfoFunc=======", toTab.playertab);
    },
    getPackageInfoFunc(){
        let toTab = {};
        toTab.gameId = this._gameID;
        toTab.roomId = this._roomID;
        toTab.baseScore = this._baseScore;
        toTab.baseBeiLv = this._baseBeiLv;
        toTab.curJuShu =  this._curJuShu;
        toTab.maxJuShu = this._maxJuShu;
        toTab.ownUserId = this._ownerUserID;
        toTab.roomPwd = this._roomPwd;
        toTab.playertab = this.getUserIdTab();
        toTab.config = this._getRoomConfigFunc();
        return toTab;
    },
    getRoomIDFunc(){
        return this._roomID;
    },
    getGameIDFunc(){
        return this._gameID;
    },
    getMaxJuShuFunc(){
        return this._maxJuShu;
    },
    getCurJuShuFunc(){
        return this._curJuShu;
    },
    setCurJuShuFunc(jushu){
        this._curJuShu = jushu;
    },
    getOwnerUserIDFunc(){
        return this._ownerUserID;
    },
    setOwnerUserIDFunc(userId){
        this._ownerUserID = userId;
    },
    _updateUserInfoFunc(seatNo, userId, userName, headurl, addr, isBoy, gold){
        seatNo = parseInt(seatNo);
        if(!this._userTab[seatNo]) this._userTab[seatNo] = {};
        this._userTab[seatNo].userId = userId;
        this._userTab[seatNo].userName = userName;
        this._userTab[seatNo].addr = addr;
        this._userTab[seatNo].isBoy = isBoy;
        this._userTab[seatNo].gold = gold;
        this._userTab[seatNo].headurl = headurl;
    },
    updateUserGoldFunc(seatNo, addgold){
        if(!addgold || seatNo==null) return ;
        this._userTab[seatNo].gold = this._userTab[seatNo].gold + addgold
    },
    rmUserInfoFunc(userId){
        if(!userId) return ;
        for(let i=0; i<this._maxPlayer; i++){
            if(this._userTab[i] && this._userTab[i].userId == userId){
                this._userTab[i] = null;
                return true;
            }
        }
    },
    findUserSeatNoFunc(userId){
        for(let i=0; i<this._maxPlayer; i++){
            if(this._userTab[i] && this._userTab[i].userId == userId){
                return i;
            }
        }
        console.log("========findUserSeatNoFunc===not=find====", userId, this._userTab);
    },
    getUserInfoFunc(seatNo){
        if(seatNo==null)return this._userTab; //记住，0和null的！都是true
        seatNo = parseInt(seatNo);
        return this._userTab[seatNo];
    },
    getUserInfoByUserIdFunc(userId){
        if(!userId) return ;
        for(let i=0; i<this._maxPlayer; i++){
            if(this._userTab[i] && this._userTab[i].userId == userId){
                return this._userTab[i];
            }
        }
    },
    IsJushuFinishFunc() {//是否局数已尽
        if(this._maxJuShu>0)return this._curJuShu>this._maxJuShu;
    },
    getBaseScoreFunc(){
        return this._baseScore;
    },
    setBaseScoreFunc(score){
        this._baseScore = score;
    },
    getBaseBeiLvFunc(){
        return this._baseBeiLv;
    },
    setBaseBeiLvFunc(beilv){
        this._baseBeiLv = beilv;
    },
    getMaxPlayerFunc(){
        return this._maxPlayer;
    },
    _setRoomConfigFunc(configtab){
        this._config = {};
        if(!configtab) return ;
        for(let i in configtab){
            this._config[i] = configtab[i];
        }
    },
    _getRoomConfigFunc(){
        let tab = {};
        for(let i in this._config){
            tab[i] = this._config[i];
        }
        return tab;
    },
    _setRoomPwdFunc(pwd){
        this._roomPwd = pwd;
    },
    _getRoomPwdFunc(){
        return this._roomPwd;
    },
    
}
module.exports = RoomInfoFunc;