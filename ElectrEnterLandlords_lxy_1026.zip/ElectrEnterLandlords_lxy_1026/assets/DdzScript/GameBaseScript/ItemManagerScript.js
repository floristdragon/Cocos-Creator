
module.exports = {
    _allitemtab : {},
    updateItemFunc(itemid, count) {
        itemid = parseInt(itemid);
        this._allitemtab[itemid] = count;
    },

    getItemFunc(itemid){
        itemid = parseInt(itemid);
        return this._allitemtab[itemid];
    },
    getGoldFunc(){
        return this._allitemtab[1001];
    },
};