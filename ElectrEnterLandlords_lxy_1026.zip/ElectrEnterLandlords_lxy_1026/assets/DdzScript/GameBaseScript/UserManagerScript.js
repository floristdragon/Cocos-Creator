

let UserInfo = require("UserInfoScript");

let lAllUserIDTab = {};
module.exports = {    
    m_SelfUserInfo : null,
    //isSelfInfo表示是否是客户端自己的用户信息
    newUserFunc(userid, username, isSelfInfo){
        let userinfo = new UserInfo(userid, username);
        this._addUserFunc(userinfo);
        if(isSelfInfo)this.m_SelfUserInfo = userinfo;
        return userinfo;
    },
    //添加或者重置用户信息表
    _addUserFunc(userinfo){
        lAllUserIDTab[userinfo.getUserIDFunc()] = userinfo;
    },
    //移除用户信息
    removeUserFunc(userid){
        let userinfo = getUserInfoByIDFunc(userid);
        lAllUserIDTab[userinfo.getUserIDFunc()] = nil;
    },
    clearAllUserFunc(){
        lAllUserIDTab = {};
    },
    //通过用户ID获取用户信息
    getUserInfoByIDFunc(userid){
        if(!userid || userid<=0) return ;
        return lAllUserIDTab[userid]
    },
     //获取自己的userinfo
    getSelfUserInfoFunc(){
        return this.m_SelfUserInfo;
    },
    getSelfUserIDFunc(){
        if(this.m_SelfUserInfo) return this.m_SelfUserInfo.getUserIDFunc();
    },
    //是否是自己
    IsSelfUserInfoFunc(userinfo){
        if(!userinfo) return false;
        return this.m_SelfUserInfo.getUserIDFunc()==userinfo.getUserIDFunc();
    },
    IsSelfUserIDFunc(userid) {
        if(!userid) return false;
        return this.m_SelfUserInfo.getUserIDFunc()==userid;
    },
}