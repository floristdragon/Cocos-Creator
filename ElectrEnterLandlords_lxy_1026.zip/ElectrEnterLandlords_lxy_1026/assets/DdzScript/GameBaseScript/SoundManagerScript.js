
var configManager = require("ConfigManagerScript");
var nativeVoice = require("native-voiceScript");

var CIFMusicKEY = "Music_PLAY";
var CIFEffectKEY = "Effect_PLAY";
var CIFMusicVolKEY = "Music_Volumn";
var CIFEffectVolKEY = "Music_Volumn";
var mAllEffectTab = {};
var lisSoundOpenFunc = function(isMusic){
    if(isMusic){
        return configManager.getKeyFunc(CIFMusicKEY, "1")=="1";
    }else{
        return configManager.getKeyFunc(CIFEffectKEY, "1")=="1";
    }
};
var lsetSoundOpenFunc = function(isMusic, isOpen){
    let openflag = "0";
    if(isOpen) openflag = "1";
    if(isMusic){
        configManager.setKeyFunc(CIFMusicKEY, openflag);
    }else{
        configManager.setKeyFunc(CIFEffectKEY, openflag);
    }
    configManager.flushFunc();
};
var lgetSoundVolumnFunc = function(isMusic){
    let toVolumn;
    if(isMusic){
        toVolumn = configManager.getKeyFunc(CIFMusicVolKEY, "1");
    }else{
        toVolumn = configManager.getKeyFunc(CIFEffectVolKEY, "1");
    }
    return parseFloat(toVolumn);
};
var lsetSoundVolumnFunc = function(isMusic, volumn){
    if(volumn<0) volumn = 0;
    if(volumn>1.0) volumn = 1.0;
    let toVolumn = ""+volumn;
    if(isMusic){
        configManager.setKeyFunc(CIFMusicVolKEY, toVolumn);
    }else{
        configManager.setKeyFunc(CIFEffectVolKEY, toVolumn);
    }
    configManager.flushFunc();
};
///////////////////////////////////////////////////////////////////////////
//用于操控音效的声音大小
var lsetAllEffectVolumnFunc = function(volumn){
    for(let id in mAllEffectTab){
        cc.audioEngine.setVolume(id, volumn);
    }
};
var lplayBeginEffectFunc = function(voiceid){
    mAllEffectTab[voiceid] = 0;
};
var lplayFinishEffectFunc = function(voiceid){
    mAllEffectTab[voiceid] = null;
};
var exIsOpenMusicBK = true;
var exIsOpenEffectBK = true;
///////////////////////////////////////////////////////////////////////////
module.exports = {
    _musicVolume : 1.0,
    _effectVolume : 1.0,

    _musicPlayID : -1,
    _musicPath : null,


    _voiceRecord : null,
    /////////////////////////////////////////////////////////////////////////
    getVoiceRecordFunc(){
        if (!this._voiceRecord){
            this._voiceRecord = nativeVoice;
            this._voiceRecord.initFunc(this);
        }
        return this._voiceRecord;
    },
    //加载并播放音乐
    //url以"asset/resources/"为相对路径
    //callback在播放开始回调，参数为路径
    //isMustPlay是否必须播放
    playMusicFunc(url, bMustPlay, callback) {
        cc.log("===playMusicFunc====111======SoundManager===", url);
        if(bMustPlay && !lisSoundOpenFunc(true)) return;
        cc.log("====playMusicFunc===222======SoundManager===", url);
        let self = this;
        cc.loader.loadRes(url, (err, path)=>{
            self.stopMusicFunc();
            cc.log("====playMusicFunc===333======SoundManager===", path);
            if(bMustPlay || lisSoundOpenFunc(true)){
                cc.log("====playMusicFunc===444======SoundManager===", path);
                self._musicPlayID = cc.audioEngine.play(path, true, self._musicVolume);
                //fix engine bug
                cc.audioEngine.setVolume(self._musicPlayID, self._musicVolume);
            }
            if(callback) callback(path);
        });
    },
    //加载并播放音效
    //url以"asset/resources/"为相对路径
    //callback在播放开始回调，参数一为路径，参数二为总时长
    //isMustPlay是否必须播放
    playEffectFunc(url, bMustPlay, callback) {
        cc.log("===playEffectFunc====111======SoundManager===", url);
        if(bMustPlay && !lisSoundOpenFunc(false)) return ;
        cc.log("====playEffectFunc===222======SoundManager===", url);
        let self = this;
        cc.loader.loadRes(url, (err, path)=>{
            let durt = 0;
            cc.log("====playEffectFunc===333======SoundManager===", path);
            if(bMustPlay || lisSoundOpenFunc(false)) {
                cc.log("====playEffectFunc===444======SoundManager===", path, self._effectVolume);
                if (self._effectVolume > 0) {
                    let audioId = cc.audioEngine.play(path, false, self._effectVolume);
                    lplayBeginEffectFunc(audioId);
                    cc.audioEngine.setFinishCallback(audioId, function(){
                        lplayFinishEffectFunc(audioId);
                    });
                    durt = cc.audioEngine.getDuration(audioId);
                }
            }
            if(callback) callback(path, durt);
        });
    },
    //0~1.0之间
    setEffectVolumeFunc(v) {
        this._effectVolume = v;
        lsetSoundVolumnFunc(this._effectVolume);
        lsetAllEffectVolumnFunc(this._effectVolume);
    },
    getEffectVolumeFunc(){
        return this._effectVolume;
    },

    //0~1.0之间
    setMusicVolumeFunc(v) {
        this._musicVolume = v;
        lsetSoundVolumnFunc(this._musicVolume);
        if(this._musicPlayID<0) return ;
        cc.audioEngine.setVolume(this._musicPlayID, v);
    },
    getMusicVolumeFunc(){
        return this._musicVolume;
    },

    setMusicOpenFunc(isOpen){
        if(!isOpen) this.stopMusicFunc();
        lsetSoundOpenFunc(true, isOpen);
    },
    setEffectOpenFunc(isOpen){
        lsetSoundOpenFunc(false, isOpen);
    },
    isMusicOpenFunc(){
        return lisSoundOpenFunc(true);
    },
    isEffectOpenFunc(){
        return lisSoundOpenFunc(false);
    },
    //打断，唤醒，如用于播放语音时候
    stopAllFunc() {
        //备份状态
        exIsOpenMusicBK = lisSoundOpenFunc(true);
        exIsOpenEffectBK = lisSoundOpenFunc(false);
        cc.log("=======stopAllFunc===========", exIsOpenEffectBK, exIsOpenMusicBK);
        lsetSoundOpenFunc(false, false);
        lsetSoundOpenFunc(true, false);
        cc.audioEngine.pauseAll();
    },

    openAllFunc() {
        //恢复状态
        cc.log("=======openAllFunc===========", exIsOpenEffectBK, exIsOpenMusicBK);
        lsetSoundOpenFunc(false, exIsOpenEffectBK);
        lsetSoundOpenFunc(true, exIsOpenMusicBK);
        cc.audioEngine.resumeAll();
    },
    //清空关闭
    clearAll() {
        this._musicPlayID = -1;
        cc.audioEngine.stopAll();
    },
    stopMusicFunc(){
        if(this._musicPlayID>=0){
            cc.audioEngine.stop(this._musicPlayID);
        }
        this._musicPlayID = -1;
    },
    preloadFunc(url, callback){
        cc.audioEngine.preload(path, callback);
    },
    /////////////////////////////////////
};