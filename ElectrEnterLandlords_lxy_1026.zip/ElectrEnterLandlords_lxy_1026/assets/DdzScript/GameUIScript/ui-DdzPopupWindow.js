cc.Class({
    extends: cc.Component,

    properties: {

        _popupcallback: null,
        _popuptarget: null,
    },

    // use this for initialization
    onLoad: function() {
        this._popupcallback = null;
    },
    showWindowFunc: function(isOk, isCancel, isRetry, text1, text2, callback, target) {
        let panelNode = this.node.getChildByName("panel");
        // if (text1) panelNode.getChildByName("text1").getComponent(cc.RichText).string = text1 + "";
        if (text2) panelNode.getChildByName("text2").getComponent(cc.RichText).string = text2 + "";

        let pokbtn = panelNode.getChildByName("okbtn");
        let pcancelbtn = panelNode.getChildByName("cancelbtn");
        let retrybtn = panelNode.getChildByName("retrybtn");
        pokbtn.active = isOk;
        pcancelbtn.active = isCancel;
        retrybtn.active = isRetry;
        if (isOk != isCancel) {
            let toCenterPos = new cc.Vec2(pokbtn.position.x + pcancelbtn.position.x, pokbtn.position.y + pcancelbtn.position.y);
            toCenterPos.divSelf(2);
            console.log("====showPopupWindowFunc==11=====", toCenterPos);
            if (isOk) {
                pokbtn.position = new cc.Vec2(toCenterPos.x, toCenterPos.y);
            } else if (isCancel) {
                pcancelbtn.position = new cc.Vec2(toCenterPos.x, toCenterPos.y);
            }
            retrybtn.active = false;
        }
        panelNode.setScale(0);
        panelNode.runAction(cc.scaleTo(0.2, 1));

        this._popupcallback = callback;
        this._popuptarget = target;
    },
    onDdzPopupOkBtn: function(event) {
        //this.node.emit("loadflower-popup-ok");
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        if (this._popuptarget) {
            if (this._popupcallback) this._popupcallback.call(this._popuptarget, 1);
        } else {
            if (this._popupcallback) this._popupcallback(1);
        }

        this.node.destroy();
    },
    onDdzPopupCancelBtn: function(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        if (this._popuptarget) {
            if (this._popupcallback) this._popupcallback.call(this._popuptarget, 0);
        } else {
            if (this._popupcallback) this._popupcallback(0);
        }
        this.node.destroy();
    },
    onDdzPopupRetryBtn: function(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        if (this._popuptarget) {
            if (this._popupcallback) this._popupcallback.call(this._popuptarget, 2);
        } else {
            if (this._popupcallback) this._popupcallback(2);
        }
        this.node.destroy();
    },
});