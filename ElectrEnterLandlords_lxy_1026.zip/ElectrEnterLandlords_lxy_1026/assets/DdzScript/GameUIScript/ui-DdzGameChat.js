cc.Class({
    extends: cc.Component,

    properties: {
        O_editNode: cc.EditBox,
        O_ShuruNode: cc.Node,
        O_chatUserInfo: cc.Prefab,

        O_worldLayer: cc.Node,
        O_roomLayer: cc.Node,
        O_siliaoLayer: cc.Node,

        O_worldToggleNode: cc.Node,
        O_roomToggleNode: cc.Node,
        O_siliaoToggleNode: cc.Node,

        O_siliaoTips: cc.Node,

        _chattype: 1,
        _scrollViewNode: null,
        _isInRoomChat: false,
        _curPos: null,
    },

    onLoad: function() {
        this._curPos = this.O_worldToggleNode.position;

    },

    openChatViewFunc() {
        this.node.active = true;
        if (this._isInRoomChat) {
            this.onDdzRoomToggleBtn();
            this.O_roomToggleNode.active = true;
            this.node.setLocalZOrder(151);
        } else {
            var toggleWorld = this.O_worldToggleNode.getComponent(cc.Toggle);
            var toggleSiliao = this.O_siliaoToggleNode.getComponent(cc.Toggle);
            if (toggleWorld.isChecked) {
                this.onDdzWorldToggleBtn();
            } else if (toggleSiliao.isChecked) {
                this.onDdzSiLiaoToggleBtn();
            }

        }
    },

    onDdzSendBtn: function() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        if (g_GameScene.rejectClickEventFunc(3)) return;

        let sendstr = this.O_editNode.string;
        this.O_editNode.string = "";

        if (!sendstr) return;

        let talkProtab = {};
        talkProtab.ctype = 4;
        talkProtab.content = sendstr;
        talkProtab.msgtype = this._chattype;
        if (talkProtab.msgtype == 2) {
            talkProtab.gameId = g_RoomManager.getCurGameIDFunc();
            talkProtab.roomId = g_RoomManager.getCurRoomIDFunc();
        }
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SSendChatMsg, talkProtab);

        cc.log("=============onDdzSendBtn========this._chattype======", this._chattype);
    },

    onDdzWorldToggleBtn: function(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.O_worldLayer.active = true;
        this.O_siliaoLayer.active = false;
        this.O_roomLayer.active = false;
        this._chattype = 1;
        this.O_ShuruNode.active = true;
        cc.log("=============onDdzWorldToggleBtn========this._chattype======", this._chattype);
    },

    onDdzSiLiaoToggleBtn: function(event) {
        this.O_siliaoTips.active = false;
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SReqChatMsg);
        this.O_worldLayer.active = false;
        this.O_siliaoLayer.active = true;
        this.O_roomLayer.active = false;
        this._chattype = 3;
        this.O_ShuruNode.active = false;
        cc.log("=============onDdzSiLiaoToggleBtn========this._chattype======", this._chattype);
    },

    onDdzRoomToggleBtn: function(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.O_worldLayer.active = false;
        this.O_siliaoLayer.active = false;
        this.O_roomLayer.active = true;
        this._chattype = 2;
        this.O_ShuruNode.active = true;

        if (this._isInRoomChat) {
            this.O_worldToggleNode.active = false;
            var worldtoggle = this.O_worldToggleNode.getComponent(cc.Toggle);
            worldtoggle.isChecked = false;

            this.O_siliaoToggleNode.active = false;
            var siliaotoggle = this.O_siliaoToggleNode.getComponent(cc.Toggle);
            siliaotoggle.isChecked = false;

            this.O_roomToggleNode.position = this._curPos;
        }
        cc.log("=============onDdzRoomToggleBtn========this._chattype======", this._chattype);
    },
    addChatMsgFunc(msgtab) {
        if (msgtab.msgtype == 1) {
            this._scrollViewNode = this.node.getChildByName('worldLayer').getComponent('ui-DdzScrollView');
            this._scrollViewNode.setMoveAddNodeFunc(true);
            this._scrollViewNode.setLimitNodeMaxFunc(30);
        } else if (msgtab.msgtype == 2) {
            this._scrollViewNode = this.node.getChildByName('roomLayer').getComponent('ui-DdzScrollView');
            this._scrollViewNode.setMoveAddNodeFunc(true);
            this._scrollViewNode.setLimitNodeMaxFunc(30);
        } else if (msgtab.msgtype == 3) {
            this._scrollViewNode = this.node.getChildByName('siliaoLayer').getComponent('ui-DdzScrollView');
            this._scrollViewNode.setMoveAddNodeFunc(true);
            this._scrollViewNode.setLimitNodeMaxFunc(30);
        }

        let infoNode = cc.instantiate(this.O_chatUserInfo);
        let infoscript = infoNode.getComponent('ui-DdzGameChatInfo');
        infoscript.setTalkInfoFunc(msgtab);

        this._scrollViewNode.addScrollNodeFunc(infoNode, 0);
        cc.log("=======onProtAddTalks==========msgtab=========", msgtab);
    },

    onDdzHideChatPanelBtn: function() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.node.active = false;
    },

    showSiLiaoTipsFunc: function(flag) {
        cc.log("========siliaoFlag==================", flag);
        if (flag) {
            this.O_siliaoTips.active = true;
        }
    },
    hideSiLiaoTipsFunc: function() {
        this.O_siliaoTips.active = false;
    },

    setRoomChatStateFunc(isRoom) {
        this._isInRoomChat = isRoom;
    },
});