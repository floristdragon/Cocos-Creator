//场景切换函数
function _switchSceneFunc(sceneName) {
    g_GameScene.showLoadFlowerFunc(true);
    cc.game.off(cc.game.EVENT_HIDE);
    cc.game.off(cc.game.EVENT_SHOW);
    cc.log("=========cc.director.preloadScene======begin===============");
    cc.director.preloadScene(sceneName, function() {
        cc.log("=========cc.director.preloadScene======End===============");
        g_GameScene.showLoadFlowerFunc(false);
        g_NetManager.removeAllListener();
        g_SoundManager.clearAll();
        cc.director.loadScene(sceneName);
    });
}
///////////////////////////////////////////////////////////////////////////
//协议回调
function _lonProtRecvErrcodeFunc(mainId, assitId, attachtab) {
    cc.log("======onProtRecvErrcode=====11=======", mainId, assitId, attachtab);
    let errcode = assitId;
    let errvar = g_ProtDef.GetErrVarByCode(errcode);
    cc.log("======onProtRecvErrcode=====22=======", errvar, errcode);
    if (errvar == "SYS_SERVER_SHUTDOWN" || errvar == "M_LOGIN_REDO_LOGIN") {
        g_UserManager.clearAllUserFunc();
        g_GameScene.showPopupWindowFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode), function(flag) {
            cc.log("===========redo=login============");
            g_GameScene.runStartSceneFunc();
        });
    } else if (errvar == "M_LOGIN_REPLACE") {
        g_UserManager.clearAllUserFunc();
        let totip = g_ProtDef.GetErrDiscByCode(errcode) + attachtab.addr;
        g_GameScene.showPopupWindowFunc(true, false, "提示", totip, function(flag) {
            cc.log("===========redo=login============");
            g_GameScene.runStartSceneFunc();
        });
    } else {
        if (g_GameScene.onRecvErrcodeFunc) g_GameScene.onRecvErrcodeFunc(assitId, attachtab);
    }
}

function _lonProtRecvUpdateItemFunc(mainId, assitId, protTab) {
    cc.log("======onProtRecvUpdateItem=========", protTab);
    if (assitId == g_ProtDef.AItem_S2CUpdate) {
        for (let id in protTab.itemtab) {
            g_ItemManager.updateItemFunc(id, protTab.itemtab[id]);
        }
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////
module.exports = cc.Class({
    extends: cc.Component,

    properties: {
        mO_loadflowerprefab: cc.Prefab,
        mO_popupprefab: cc.Prefab,

        //////////////////////////////////////////
        _mmloadflowerNode: null,
        _mmOnceEnterBack: false,
        _mmOnceEnterForce: false,

        _mmRejectEventMap: null,
    },
    /*
    //在编译时候就会调用ctor, 即在cocos库还没加入时候
    ctor: function () {
        cc.log("=====ui-loadflower=======ctor======");
    },*/
    // use this for initialization
    //在加载时候调用，但父节点不会主动调用,需要调用this._super();来调用
    //已经不用onload去调用了，因为onLoad是在当前脚本加载完毕后调用的，其他后面的脚本都未加载
    //切换场景初始化统一用init
    onLoad: function() {

        cc.view.setDesignResolutionSize(this.node.width, this.node.height, cc.ResolutionPolicy.EXACT_FIT);

        g_GameScene = this;
        this._mmRejectEventMap = {};
        //每切换一个场景都会调用这里，覆盖掉原有的注册协议回调
        cc.log("=====ui-loadflower=======onLoad======");
        let self = this;
        //网络回调注册
        g_NetManager.onbegin = function() {
            console.log("=========g_NetManager.onbegin=============");
            self.showLoadFlowerFunc(true);
        };
        g_NetManager.onopen = function() {
            console.log("=========g_NetManager.onopen=============");
            self.showLoadFlowerFunc(false);
        };
        g_NetManager.onclose = function(linkcount) {
            console.log("=========g_NetManager.onclose=============", linkcount);
            self.showLoadFlowerFunc(false);
            self._showPopupRetryWindowFunc("提示", "网络连接异常", function(okflag) {
                cc.log("===========_showPopupRetryWindowFunc=============", okflag);
                g_NetManager.connect();
            });
        };
        //注册进入后台，进入前台时候回调
        self._mmOnceEnterForce = false;
        self._mmOnceEnterBack = false;
        let enterbackfunc = function() {
            cc.log("========cc.game.on(cc.game.EVENT_HIDE==========");
            if (self._mmOnceEnterBack) {
                self._mmOnceEnterBack = false;
                return;
            }
            self._mmOnceEnterBack = true;
            g_SoundManager.stopAllFunc();
            if (self._onEnterBackgroundFunc) self._onEnterBackgroundFunc();
        };
        let enterforcefunc = function() {
            cc.log("========cc.game.on(cc.game.EVENT_SHOW==========");
            if (self._mmOnceEnterForce) {
                self._mmOnceEnterForce = false;
                return;
            }
            self._mmOnceEnterForce = true;
            g_SoundManager.openAllFunc();
            if (self._onEnterForegroundFunc) self._onEnterForegroundFunc();
        };
        cc.game.off(cc.game.EVENT_HIDE);
        cc.game.off(cc.game.EVENT_SHOW);
        cc.game.on(cc.game.EVENT_HIDE, enterbackfunc);
        cc.game.on(cc.game.EVENT_SHOW, enterforcefunc);

        //错误码、创建房间、加入房间、解散房间等等，只要需要跨场景通知的协议，或者要上层看不见的协议都在这里
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Errcode, null, _lonProtRecvErrcodeFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Item, null, _lonProtRecvUpdateItemFunc);
    },
    //进入后台回调, 可以继承重写
    _onEnterBackgroundFunc() {

    },
    //进入前台回调, 可以继承重写
    _onEnterForegroundFunc() {

    },
    onRecvErrcodeFunc(errcode, attachtab) {
        cc.log("====onRecvErrcodeFunc==========", errcode, attachtab)
    },
    ////////////////////////////////////////////////////
    showLoadFlowerFunc(isVisible) {
        if (!this._mmloadflowerNode) {
            this._mmloadflowerNode = cc.instantiate(this.mO_loadflowerprefab);
            this._mmloadflowerNode.parent = this.node;
            this._mmloadflowerNode.setLocalZOrder(10000);
        }
        this._mmloadflowerNode.getComponent("ui-DdzNetFlower").showFlowerFunc(isVisible);
    },
    //callback 参数1位确定，否则为取消
    showPopupWindowFunc(isOk, isCancel, text1, text2, callback, target) {
        let popupnode = cc.instantiate(this.mO_popupprefab);
        popupnode.parent = this.node;
        popupnode.setLocalZOrder(10000);
        popupnode.getComponent("ui-DdzPopupWindow").showWindowFunc(isOk, isCancel, false, text1, text2, callback, target);
    },

    _showPopupRetryWindowFunc(text1, text2, callback, target) {
        let popupnode = cc.instantiate(this.mO_popupprefab);
        popupnode.parent = this.node;
        popupnode.setLocalZOrder(10000);
        popupnode.getComponent("ui-DdzPopupWindow").showWindowFunc(false, false, true, text1, text2, callback, target);
    },

    rejectClickEventFunc(delay) {
        if (!delay || delay <= 0) return false;
        let self = this;
        let rejkey = "reject-default-key";
        let rejfunc = function() {
            self._mmRejectEventMap[rejkey] = null;
        };
        cc.log("=======rejectClickEventFunc=========", delay, this._mmRejectEventMap);
        if (!this._mmRejectEventMap[rejkey]) {
            this._mmRejectEventMap[rejkey] = 1;
            this.scheduleOnce(rejfunc, delay);
            return false;
        }
        this.showPopupWindowFunc(true, false, "提示", "操作过于频繁，请稍候！");
        return true;
    },
    ////////////////////////////////////////////////////////////////
    runErRenDouDiZhuSceneFunc() {
        _switchSceneFunc("ErRenDdzScene");
    },
    runLobbySceneFunc() {
        _switchSceneFunc("LobbyScene");
    },
    runStartSceneFunc() {
        g_NetManager.closeNet();
        _switchSceneFunc("StartScene");
    },
});