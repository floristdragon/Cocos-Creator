cc.Class({
    extends: cc.Component,

    properties: {
        O_contentnode: cc.Node,
        O_scrollbar: cc.Node,
        //O_scrollprefab : cc.Prefab,  //用于测试的预制
        //////////////////////////////////////
        _curList: [],
        _alignInter: 0,
        _isAddAndMove: false, //是否增加一个就往上移，必须把最新的显示出来
        _limitNodeMax: -1, //限制大小 -1表示无限制，否则如果超过，则会默认删掉最早的
    },

    // use this for initialization
    onLoad: function() {
        if (this.O_scrollbar) {
            this.O_scrollbar.setLocalZOrder(1000);
        }
        this.setHeightInterFunc(5); //默认间隔
        this.O_contentnode.anchorX = 0.5;
        //test code
        // this.setMoveAddNodeFunc(true);
        // for(let i=0; i<10; i++){
        //     let snode = cc.instantiate(this.O_scrollprefab);

        //     // let lab = "fanfangyou"+i + Math.floor(Math.random() * 20000);
        //     // cc.log("===============", lab);
        //     // snode.getComponent(cc.Label).string = lab
        //     let toAlignHor = 0;
        //     if(i>=3) toAlignHor = 1;
        //     if(i>=7) toAlignHor = 2;
        //     this.addScrollNodeFunc(snode, toAlignHor);
        // }
    },
    getListSizeFunc() {
        return this._curList.length;
    },
    //每个节点之间的间隔大小
    setHeightInterFunc(inter) {
        if (this._alignInter != inter) {
            this._alignInter = inter;
        }
    },
    setMoveAddNodeFunc(flag) {
        this._isAddAndMove = flag;
    },
    setLimitNodeMaxFunc(limit) {
        if (!limit) limit = -1;
        this._limitNodeMax = limit;
    },
    /*
        如邮件的排序: 
        sortAllNodeListFunc((a, b)=>{
            if(a.stime>b.stime) return -1; //表示要交换
            return 1; //不用交换
        });
    */
    sortAllNodeListFunc(sortfunc) {
        if (!sortfunc || this._curList.length <= 0) return;
        let toNodeList = [];
        for (let i = 0; i < this._curList.length; i++) {
            toNodeList.push(this._curList[i]);
        }
        cc.log("=====sortAllNodeListFunc===11========", toNodeList.length);
        this._curList = [];
        toNodeList.sort((a, b) => {
            let ret = sortfunc(a.adata, b.adata);
            if (ret < 0) {
                let temp = new cc.Vec2(a.snode.position.x, a.snode.position.y);
                a.snode.position = b.snode.position;
                b.snode.position = temp;
            }
            return ret;
        });
        for (let i = 0; i < toNodeList.length; i++) {
            let toNodeData = toNodeList[i];
            cc.log("=====sortAllNodeListFunc===22========", toNodeData);
            this._addNodeFunc(toNodeData.snode, toNodeData.align, toNodeData.adata, false);
        }
    },
    clearAllNodeFunc() {
        this.O_contentnode.removeAllChildren(true);
        this._curList = [];
        cc.log("=========clearAllNodeFunc===========", this.O_contentnode);
    },
    //alignHor这个节点的对齐方式，0居中对齐，1表示左对齐，2右边对齐
    //adata表示附加数据，用于排序使用，不排序则不需要传入
    addScrollNodeFunc(snode, alignHor, adata) {
        this._addNodeFunc(snode, alignHor, adata, true);
    },
    /*
        函数返回1表示删掉，返回其他不删掉: 
        rmScrollNodeByFunc((a)=>{
            return 1
        });
    */
    rmScrollNodeByFunc(rmfunc) {
        if (!rmfunc) return;
        let toNodeList = [];
        let isRmNode = false;
        for (let i = 0; i < this._curList.length; i++) {
            if (rmfunc(this._curList[i].adata) == 1) {
                isRmNode = true;
                this._curList[i].snode.destroy();
            } else {
                toNodeList.push(this._curList[i]);
            }
        }
        this._curList = [];
        for (let i = 0; i < toNodeList.length; i++) {
            let toNodeData = toNodeList[i];
            cc.log("=====sortAllNodeListFunc===22========", toNodeData);
            this._addNodeFunc(toNodeData.snode, toNodeData.align, toNodeData.adata, false);
        }
    },
    rmScrollNodeFunc(snode) {
        cc.log("========rmScrollNodeFunc===========", snode);
        if (!snode) return;
        let tobklist = [];
        let tonodelist = [];
        for (let i = 0; i < this._curList.length; i++) {
            if (this._curList[i].snode == snode) {
                snode.destroy();
                this._curList[i] = null;
                for (let k = i + 1; k < this._curList.length; k++) {
                    tonodelist.push(this._curList[k]);
                }
                break;
            } else {
                tobklist.push(this._curList[i]);
            }
        }
        this._curList = tobklist;
        for (let i = 0; i < tonodelist.length; i++) {
            this._addNodeFunc(tonodelist[i].snode, tonodelist[i].align, tonodelist[i].adata, false);
        }
    },
    _addNodeFunc(snode, alignHor, adata, bAddChild) {
        let toAlignHor = 0;
        if (!alignHor) alignHor = 0;
        if (alignHor == 0) {
            toAlignHor = 0;
        } else if (alignHor == 1) {
            toAlignHor = -0.5;
        } else if (alignHor == 2) {
            toAlignHor = 0.5;
        }
        if (bAddChild) snode.parent = this.O_contentnode;
        let toNodeTab = {};
        toNodeTab.snode = snode;
        toNodeTab.align = alignHor;
        toNodeTab.adata = adata;
        this._curList.push(toNodeTab);

        let curNodeIndex = this._curList.length - 1;
        let toPosY = 0;
        let toPosX = 0;
        let toInterPosX = (this.O_contentnode.width - snode.width - 6);
        toPosX = toInterPosX * toAlignHor;
        if (this.O_scrollbar) toPosX -= this.O_scrollbar.width; //是否有滚动条，有的话就往左移动
        let toLeftPos = toInterPosX * -0.5;
        if (toPosX < toLeftPos) { //当往左移动后，超出范围，则调整
            toPosX = toLeftPos;
        }
        if (curNodeIndex == 0) {
            toPosY = toPosY - snode.height * 0.5 - 3;
        } else {
            toPosY = this._curList[curNodeIndex - 1].snode.position.y;
            toPosY -= (snode.height * 1 + this._alignInter);
        }
        snode.position = new cc.Vec2(toPosX, toPosY);

        this.O_contentnode.height = Math.abs(toPosY) + snode.height * 0.5 + this._alignInter;

        if (this._isAddAndMove && this.O_contentnode.height > this.node.height) {
            this.O_contentnode.position = new cc.Vec2(this.O_contentnode.position.x, this.O_contentnode.height - this.node.height / 2);
        }
        //内容的父节点宽高必须大于等于SrollView的宽高,才有滚动条显示
        // if(this.O_contentnode.height<this.node.height){
        //     this.O_contentnode.height = this.node.height;
        // }
        cc.log("========addScrollNodeFunc===========", this.node.height, this.O_contentnode.height);
        if (this._limitNodeMax && this._limitNodeMax > 0 && this._curList.length > this._limitNodeMax) {
            this.rmScrollNodeFunc(this._curList[0].snode);
        }
    },
});