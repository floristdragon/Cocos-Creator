cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        agreeMentToggle: cc.Toggle,
    },

    // use this for initialization
    onLoad: function () {
        this.node.setScale(0);
        this.node.runAction(cc.scaleTo(0.2, 1));
    },

    onDdzLoginBtn : function(event){
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        if(this.agreeMentToggle.isChecked == false){
            console.log("请勾选提示框");
            let eventparam = {};
            this.node.emit("login-xieyi-not-select", eventparam);
            return;
        }

        let accText = this.node.getChildByName("enteracc").getComponent(cc.EditBox).string;
        let pwdText = this.node.getChildByName("enterpwd").getComponent(cc.EditBox).string;
        let eventparam = {acc : accText, pwd : pwdText};
        console.log("====onDdzLoginBtn=======", eventparam);
        //有两种发射方式，emit比较方便，区别不大，详细看官方文档
        //传参可以用任何类型变量，数组、对象、字符串等等，这里传入什么参数，on接受到的detail就是什么。
        this.node.emit("login-loginacc", eventparam);
        // let eventcon = new cc.Event.EventCustom('login-loginacc', true);
        // eventcon.detail = eventparam;
        // this.node.dispatchEvent(eventcon);
    },
    onDdzRegisterBtn : function(event){
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        
        console.log("====onDdzRegisterBtn=======");
        this.node.emit("login-showregister");
    },

    onAgreementBtn:function (event) {
    	g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        console.log("====onAgreementBtn=======");
        this.node.emit("login-showxieyi");
    },
});
