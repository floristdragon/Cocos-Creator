cc.Class({
    extends: cc.Component,

    properties: {
        O_jiesannode: cc.Node,
        O_leavenode: cc.Node,
        O_musicToggle: cc.Toggle,
        O_effectToggle: cc.Toggle,

        _isCheckToggleClick: true,
    },

    // use this for initialization
    onLoad() {
        let roominfo = g_ERDDZGameData.getRoomInfoFunc();
        let ownerUserId = roominfo.getOwnerUserIDFunc();
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        let selfUserId = roominfo.getUserInfoFunc(selfSeatNo).userId;

        this.O_jiesannode.active = false;
        this.O_leavenode.active = false;
        if (ownerUserId == selfUserId) {
            this.O_jiesannode.active = true;
        } else {
            this.O_leavenode.active = true;
        }

        this._isCheckToggleClick = false;
        if (g_SoundManager.isMusicOpenFunc()) {
            this.O_musicToggle.check();
        } else {
            this.O_musicToggle.uncheck();
        }
        if (g_SoundManager.isEffectOpenFunc()) {
            this.O_effectToggle.check();
        } else {
            this.O_effectToggle.uncheck();
        }
        this._isCheckToggleClick = true;
    },

    onDdzMusicToggleClickBtn(toggle) {
        cc.log("================onDdzMusicToggleClickBtn======================", toggle, toggle.isChecked)
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setMusicOpenFunc(true);
            g_ERDDZGameData.playBackgroundMusicFunc();
        } else {
            g_SoundManager.setMusicOpenFunc(false);
        }
    },

    onDdzEffectClickBtn(toggle) {
        cc.log("==========================onDdzEffectClickBtn===============", toggle, toggle.isChecked);
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setEffectOpenFunc(true);
        } else {
            g_SoundManager.setEffectOpenFunc(false);
        }
    },

    onDdzCloseClickBtn() {
        this.node.destroy();
    },

    onDdzLeaveClickBtn() {
        let toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIDFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIDFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqLeaveDesk, toProtTab);
        this.onDdzCloseClickBtn();
    },
    onDdzJieSanClickBtn() {
        let toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIDFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIDFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqJieSanDesk, toProtTab);
        this.onDdzCloseClickBtn();
    },

    // called every frame, uncomment this function to activate update callback
    // update(dt) {

    // },
});