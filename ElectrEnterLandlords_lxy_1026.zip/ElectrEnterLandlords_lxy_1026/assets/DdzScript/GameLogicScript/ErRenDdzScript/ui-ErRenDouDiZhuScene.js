require("ErRenDdzGameData");

let GameRuleLogic = require("ErRenDdzRuleLogic");
let STATUS_READY = 0; //准备
let STATUS_SENDCARD = 1; //发牌
let STATUS_QIANGDIZHU = 2; //抢地主
let STATUS_OUTCARD = 3; //出牌
let STATUS_GAMEFINISH = 4; //游戏结束
cc.Class({
    extends: require("ui-DdzRoomScene"),

    properties: {
        O_controlbtnprefab: cc.Prefab,
        O_gameresultprefab: cc.Prefab,

        O_userInfoPrefab: cc.Prefab,

        O_settingPrefab: cc.Prefab,

        //////////////////////////////////////
        _backgroundScipt: null,
        _ctlbuttonScript: null,
        _rangtipScript: null,
        _gameresultScript: null,
        _dispcardScript: null,

    },

    // use this for initialization
    onLoad: function() {
        this._super(); //调用父类的onLoad
        this.setChatRoomStateFunc(true);
        //背景音乐
        g_ERDDZGameData.playBackgroundMusicFunc();

        let gameId = g_RoomManager.getCurGameIDFunc();
        let roomId = g_RoomManager.getCurRoomIDFunc();
        let selfUserId = g_UserManager.getSelfUserIDFunc();
        let roominfo = g_RoomManager.getGameRoomInfoFunc(gameId, roomId);

        let selfSeatNo = roominfo.findUserSeatNoFunc(selfUserId);
        g_ERDDZGameData.initFunc(gameId, roomId, selfSeatNo);
        cc.log("=======errenddz==mainscene=11====", gameId, roomId, selfUserId);

        //////////////////////////////////////////////////////////
        this._cplayerArray = [];
        let maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        let toSeatNo = selfSeatNo;
        for (let i = 0; i < maxPlayer; i++) {
            let playerNo = i + 1;
            let playerNode = this.node.getChildByName("player" + playerNo);
            playerNode.setLocalZOrder(100);
            console.log("=====111111=======", toSeatNo, selfSeatNo, playerNo);
            let cplayerhandler = playerNode.getComponent("ui-ErRenDouDiZhuPlayer");
            cplayerhandler.initUIFunc(toSeatNo, playerNode);
            g_ERDDZGameData.setPlayerUiFunc(cplayerhandler, i, toSeatNo);

            toSeatNo = g_ERDDZGameData.getNextSeatNoFunc(toSeatNo);
        };
        this._backgroundScipt = this.getComponent("ui-ErRenDouDiZhuBackground");
        this._backgroundScipt.showBaseTipFunc();

        this._rangtipScript = this.getComponent("ui-ErRenDouDiZhuRangTip");
        this._rangtipScript.showQiangDiZhuTipFunc(false);

        this._dispcardScript = this.getComponent("ui-ErRenDouDiZhuDispCard");
        cc.log("=========errenddz==mainscene====22====", this._dispcardScript);
        /////////////////////////////////////////////////////////////////
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_ErRenDDZ, null, this._onProtSocketMessageFunc, this);

        /////////////////////////////////////////////////////////////////
        //场景加载完毕，开始请求场景协议
        let toProtData = {};
        toProtData.gameId = g_ERDDZGameData.getGameIDFunc();
        toProtData.roomId = g_ERDDZGameData.getRoomIDFunc();
        cc.log("=========requestGameStatus===", toProtData);
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqGameStatus, toProtData);
    },
    onDestroyFunc() {
        cc.log("=============onDestroyFunc==============");
    },
    _resetAllUiFunc() {
        if (this._ctlbuttonScript) {
            this._getDdzControlBtn().hideDdzAllBtn();
        }
        if (this._gameresultScript) {
            this._getGameResultFunc()._showResultFunc(false);
        }
        g_ERDDZGameData.resetInitFunc();
        this._rangtipScript.hideAllTipFunc();
        this._backgroundScipt._showThreeBackCardFunc(false);
        this._backgroundScipt._showSmallBackCardFunc(false);
        this._backgroundScipt.showBaseTipFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoFunc();
        let maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        for (let i = 0; i < maxPlayer; i++) {
            let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
            playerui.resetUIFunc();

            let userinfo = roominfo.getUserInfoFunc(i);
            cc.log("======_resetAllUiFunc====111=======", i, userinfo);
            if (userinfo) {
                playerui.showUserInfoFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
            } else {
                playerui.showUserInfoFunc(false);
            }
        }
    },
    _requestGameReadyFunc(delaytime) {
        let self = this;
        let _readyDdzFunc = function() {
            //在这里进入房间后要发协议，自己默认进入房间就准备
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SReady);
        };
        if (!delaytime || delaytime <= 0) {
            _readyDdzFunc();
        } else {
            this.scheduleOnce(_readyDdzFunc, delaytime);
        }
    },
    onDdzSettingBtn(event) {
        var settingPlane = cc.instantiate(this.O_settingPrefab);
        this.node.addChild(settingPlane, 1000);
    },
    onDdzShowUserInfoPanel(node, detail) {
        cc.log("========onDdzShowUserInfoPanel=========", node, detail);
        let seatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        if (detail == 2) {
            seatNo = g_ERDDZGameData.getNextSeatNoFunc(seatNo);
        }
        let roominfo = g_ERDDZGameData.getRoomInfoFunc();
        if (roominfo.getUserInfoFunc(seatNo)) {
            var userInfoNode = cc.instantiate(this.O_userInfoPrefab);
            userInfoNode.parent = this.node;
            userInfoNode.setLocalZOrder(200);
            userInfoNode.getComponent("ui-ErRenDdzUserInfo").showInfoFunc(seatNo);
        }
    },
    //////////////////////////////////////////////////////////////////////////////
    _getDdzControlBtn() {
        if (!this._ctlbuttonScript) {
            let ctrbtn = cc.instantiate(this.O_controlbtnprefab);
            ctrbtn.parent = this.node;
            ctrbtn.setLocalZOrder(150);
            this._ctlbuttonScript = ctrbtn.getComponent("ui-ErRenDdzCtlButton");
            ctrbtn.off("outbtn-buchu");
            ctrbtn.off("outbtn-tishi");
            ctrbtn.off("outbtn-chupai");
            ctrbtn.on("outbtn-buchu", (event) => {
                this._outCardBuChuFunc();
            }, this);
            ctrbtn.on("outbtn-tishi", (event) => {
                this._outCardTiShiFunc();
            }, this);
            ctrbtn.on("outbtn-chupai", (event) => {
                this._outCardChuPaiFunc();
            }, this);
        }
        return this._ctlbuttonScript;
    },
    _getGameResultFunc() {
        if (!this._gameresultScript) {
            let resultnode = cc.instantiate(this.O_gameresultprefab);
            resultnode.parent = this.node;
            resultnode.setLocalZOrder(200);
            this._gameresultScript = resultnode.getComponent("ui-ErRenDouDiZhuGameResult");
        }
        return this._gameresultScript;
    },
    _outCardBuChuFunc() {
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(selfSeatNo);
        playerui.getHandCardFunc().clearTiShiHandCardFunc();

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SBuChu);
    },
    _outCardTiShiFunc() {
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        let outCardTab = g_ERDDZGameData.getCurOutCardTabFunc(true);
        let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(selfSeatNo);
        playerui.getHandCardFunc().moveTiShiHandCardFunc(outCardTab);
    },
    _outCardChuPaiFunc() {
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(selfSeatNo);
        playerui.getHandCardFunc().clearTiShiHandCardFunc();
        let outCardTab = g_ERDDZGameData.getCurOutCardTabFunc(true);
        let outTab = playerui.getHandCardFunc().getMoveUpCardTabFunc(outCardTab);
        if (outTab && outTab.length > 0) {
            let toProtTab = {};
            toProtTab.cardTab = outTab;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SOutCard, toProtTab);
        } else {
            this.showPopupWindowFunc(true, false, "提示", "出牌不符合规则！");
        }
    },
    ////////////////////////////////////////////////////////////////////////////////
    onRecvErrcodeFunc(errcode, attachtab) {
        cc.log("=======onRecvErrcodeFunc============", errcode, attachtab);
        this.showPopupWindowFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },
    //其他玩家进入房间会调用这里, 进入房间协议比场景协议要先到来
    onRecvEnterRoomFunc(gameId, roomId, userId) {
        //let selfUserId = g_UserManager.getSelfUserIDFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoFunc();
        let seatNo = roominfo.findUserSeatNoFunc(userId);
        let userinfo = roominfo.getUserInfoFunc(seatNo);
        let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(seatNo);
        cc.log("==============onRecvEnterRoomFunc==========", roomId, userId, typeof(userId), roominfo);
        playerui.showUserInfoFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
    },
    onRecvJieSanDeskFunc(gameId, roomId, userId, userName, isAuto) {
        cc.log("======onRecvJieSanDeskFunc==========", gameId, roomId, userId, userName, isAuto);
        if (!isAuto) {
            this.showPopupWindowFunc(true, false, "提示", "房主已经解散了房间！", (flag) => {
                this.runLobbySceneFunc();
            }, this);
        } else {
            this.showPopupWindowFunc(true, false, "提示", "房间局数已尽！", (flag) => {
                this.runLobbySceneFunc();
            }, this);
        }
    },
    onRecvLeaveDeskFunc(gameId, roomId, userId) {
        cc.log("======onRecvLeaveDeskFunc==========", gameId, roomId, userId);
        if (userId == g_UserManager.getSelfUserIDFunc()) {
            // this.showPopupWindowFunc(true, false, "提示", "您已经离开房间！", (flag)=>{
            //     this.runLobbySceneFunc();
            // }, this);
            this.runLobbySceneFunc();
        }
    },
    ////////////////////////////////////////////////////////////////////////////////
    _startDispCardFunc(beginSeatNo) {
        let maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        let eachNumArray = [];
        let eachPosArray = [];
        for (let i = 0; i < maxPlayer; i++) {
            let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
            eachNumArray.push(17);
            eachPosArray.push(playerui.getHandCardPosFunc());
        }
        let self = this;
        this._dispcardScript.sendAllCardFunc(beginSeatNo, eachNumArray, eachPosArray, (seatNo, num, isEnd) => {
            if (!isEnd) {
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(seatNo);
                playerui.getHandCardFunc().drawHandCardFunc(num);
            } else {
                g_ERDDZGameData.setHandCardSortFunc(true);
                self._backgroundScipt._showThreeBackCardFunc(true);
                self._backgroundScipt._showSmallBackCardFunc(false);
                let maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
                for (let i = 0; i < maxPlayer; i++) {
                    let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                    playerui.getHandCardFunc().drawHandCardFunc();
                }
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SSendCardFinish);
            }
        });
    },
    ////////////////////////////////////////////////////////////////////////////////
    onRecvGameStatusFunc(protTab) {
        cc.log("==========onRecvGameStatusFunc====11=========", protTab);
        let maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoFunc();
        let selfUserId = g_UserManager.getSelfUserIDFunc();
        let selfSeatNo = roominfo.findUserSeatNoFunc(selfUserId);
        this._resetAllUiFunc();
        cc.log("==========onRecvGameStatusFunc====22=========");
        if (protTab.status == STATUS_READY) {
            for (let i = 0; i < maxPlayer; i++) {
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                let isReady = protTab.readyTab[i];
                if (i == selfSeatNo) isReady = true;
                playerui.showReadyTipFunc(isReady);
            }
            this._requestGameReadyFunc();
        } else if (protTab.status == STATUS_SENDCARD) {
            for (let i = 0; i < maxPlayer; i++) {
                g_ERDDZGameData.setHandCardTabFunc(i, protTab.handCardTab[i], true);
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                let leftnum = g_ERDDZGameData.getHandCardCountFunc(i);
                playerui.showUserLeftCardFunc(true, leftnum);
                playerui.getHandCardFunc().drawHandCardFunc();
            }
            this._startDispCardFunc(selfSeatNo);
        } else if (protTab.status == STATUS_QIANGDIZHU) {
            let turnSeatNo = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortFunc(true);
            if (protTab.bankerUserId) {
                let bankSeatNo = roominfo.findUserSeatNoFunc(protTab.bankerUserId);
                g_ERDDZGameData.setDiZhuSeatNoFunc(bankSeatNo);
            }
            for (let i = 0; i < maxPlayer; i++) {
                g_ERDDZGameData.setHandCardTabFunc(i, protTab.handCardTab[i], true);
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                let leftnum = g_ERDDZGameData.getHandCardCountFunc(i);
                playerui.showUserLeftCardFunc(true, leftnum);
                playerui.getHandCardFunc().drawHandCardFunc();
                if (turnSeatNo == i && turnSeatNo != selfSeatNo) {
                    playerui.showTimeWaitTipFunc(true);
                } else {
                    playerui.showTimeWaitTipFunc(false);
                }
            }
            this._rangtipScript.showQiangDiZhuTipFunc(false);
            this._rangtipScript.showRangTipFunc();
            this._backgroundScipt._showThreeBackCardFunc(true);
            this._backgroundScipt._showSmallBackCardFunc(false);
            if (protTab.turnUserId == selfUserId) {
                if (protTab.isTurnJiaoDZ == 1) {
                    this._getDdzControlBtn().showDdzJiaoDiZhuBtn();
                } else {
                    this._getDdzControlBtn().showDdzQiangDiZhuBtn();
                    this._rangtipScript.showQiangDiZhuTipFunc(true);
                }
            }
            if (protTab.lastUserId != null) {
                let playerui = g_ERDDZGameData.getPlayerUIByUserIdFunc(protTab.lastUserId);
                if (protTab.isJiaoDZ == 1) {
                    playerui.speekJiaoDiZhuFunc(true);
                } else {
                    playerui.speekQiangDiZhuFunc(true);
                }
            }
        } else if (protTab.status == STATUS_OUTCARD) {
            g_ERDDZGameData.setBackCardFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            let bankerSeatNo = roominfo.findUserSeatNoFunc(protTab.bankerUserId);
            let outSeatNo = roominfo.findUserSeatNoFunc(protTab.outUserId);
            let turnSeatNo = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            g_ERDDZGameData.setDiZhuSeatNoFunc(bankerSeatNo);
            g_ERDDZGameData.setCurOutCardTabFunc(protTab.outTab);
            g_ERDDZGameData.setQiangRangNumFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortFunc(true);
            for (let i = 0; i < maxPlayer; i++) {
                g_ERDDZGameData.setHandCardTabFunc(i, protTab.handCardTab[i], true);
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                playerui.getHandCardFunc().drawHandCardFunc();
                playerui.showDiZhuTipFunc(false);
                if (bankerSeatNo == i) {
                    playerui.showDiZhuTipFunc(true);
                }
                if (i == outSeatNo) {
                    playerui.getHandCardFunc().drawOutCardFunc(protTab.outTab);
                    playerui.getHandCardFunc().drawHandCardFunc();
                } else {
                    playerui.getHandCardFunc().clearOutCardFunc();
                }
                if (turnSeatNo == i && turnSeatNo != selfSeatNo) {
                    playerui.showTimeWaitTipFunc(true);
                } else {
                    playerui.showTimeWaitTipFunc(false);
                }
                let leftnum = g_ERDDZGameData.getHandCardCountFunc(i);
                playerui.showUserLeftCardFunc(true, leftnum);
                if (leftnum <= 3) {
                    playerui.showBaoJingTipFunc(true)
                }
            }
            this._backgroundScipt._showSmallBackCardFunc(false);
            this._rangtipScript.showQiangDiZhuTipFunc(false);
            this._rangtipScript.showRangTipFunc();
            if (protTab.turnUserId == selfUserId) {
                this._getDdzControlBtn().showDdzOutCardBtn(protTab.mustOut == 1);
            }
        } else if (protTab.status == STATUS_GAMEFINISH) {
            //this._requestGameReadyFunc(3);
            this._onShowGameResultFunc(protTab.finishdata);
        }
    },
    _onProtSocketMessageFunc(mainId, assistId, protTab) {
        cc.log("==========_onProtSocketMessageFunc=============", mainId, assistId, protTab);
        // AErRenDDZ_S2CBeginOut = 201;   //开始出牌
        // AErRenDDZ_S2CCallLandlord = 202;  //叫地主
        // AErRenDDZ_S2COutCard    = 203;    //出牌
        // AErRenDDZ_S2CBuChu  = 204;   //不出
        // AErRenDDZ_S2CSendCard  = 205;  //发牌
        // AErRenDDZ_S2CTuoGuan = 207;   //托管
        // AErRenDDZ_S2CGameFinish = 208;    //游戏结束
        let maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoFunc();
        let selfUserId = g_UserManager.getSelfUserIDFunc();
        let selfSeatNo = roominfo.findUserSeatNoFunc(selfUserId);
        for (let i = 0; i < maxPlayer; i++) {
            let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
            playerui.showReadyTipFunc(false);
            playerui.showTimeWaitTipFunc(false);
            playerui.speekNothingFunc();
        }
        this._backgroundScipt.showBaseTipFunc();
        if (assistId == g_ProtDef.AErRenDDZ_S2CReady) {
            if (protTab.userId == selfUserId) {
                this._resetAllUiFunc();
            }
            let playerui = g_ERDDZGameData.getPlayerUIByUserIdFunc(protTab.userId);
            playerui.showReadyTipFunc(true);
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CSendCard) {
            let jiaoSeatNo = roominfo.findUserSeatNoFunc(protTab.jiaoUserId);
            for (let i = 0; i < maxPlayer; i++) {
                g_ERDDZGameData.setHandCardTabFunc(i, protTab.handCardTab[i], false);
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                playerui.getHandCardFunc().drawHandCardFunc();
                if (i == jiaoSeatNo && jiaoSeatNo != selfSeatNo) {
                    playerui.showTimeWaitTipFunc(true);
                }
            }
            this._startDispCardFunc(selfSeatNo);
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CCallLandlord) {
            let turnSeatNo = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortFunc(true);
            this._getDdzControlBtn().hideDdzAllBtn();
            this._backgroundScipt._showThreeBackCardFunc(true);
            this._backgroundScipt._showSmallBackCardFunc(false);

            let jiaoSeatNo = -1;
            if (protTab.userId) {
                //当发牌完成后，会发送一个userId为空的首次叫地主的协议过来，通知开始叫地主
                jiaoSeatNo = roominfo.findUserSeatNoFunc(protTab.userId);
                this._rangtipScript.showQiangDiZhuTipFunc(true);
            }
            if (turnSeatNo == selfSeatNo && !protTab.isEnd) {
                if (protTab.isTurnJiaoDZ == 1) {
                    this._getDdzControlBtn().showDdzJiaoDiZhuBtn();
                } else {
                    this._getDdzControlBtn().showDdzQiangDiZhuBtn();
                }
            }
            for (let i = 0; i < maxPlayer; i++) {
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);

                let leftnum = g_ERDDZGameData.getHandCardCountFunc(i);
                playerui.showUserLeftCardFunc(true, leftnum);
                if (i == turnSeatNo && turnSeatNo != selfSeatNo) {
                    playerui.showTimeWaitTipFunc(true);
                }
                playerui.speekNothingFunc();
                if (i == jiaoSeatNo && protTab.isJiaoDZ != null) {
                    if (protTab.isJiaoDZ == 1) {
                        playerui.speekJiaoDiZhuFunc(protTab.isCall == 1);
                        g_ERDDZGameData.playJiaoDiZhuFunc(protTab.userId, protTab.isCall == 1);
                    } else {
                        playerui.speekQiangDiZhuFunc(protTab.isCall == 1);
                        g_ERDDZGameData.playQiangDiZhuFunc(protTab.userId, protTab.isCall == 1);
                    }
                }
            }
            this._rangtipScript.showRangTipFunc();
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CBeginOut) {
            g_ERDDZGameData.setBackCardFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            let bankSeatNo = roominfo.findUserSeatNoFunc(protTab.bankerUserId);
            g_ERDDZGameData.setHandCardSortFunc(true);
            g_ERDDZGameData.setDiZhuSeatNoFunc(bankSeatNo);
            g_ERDDZGameData.addHandCardTabFunc(bankSeatNo, protTab.backCardTab);
            g_ERDDZGameData.playGameStartFunc();
            this._rangtipScript.showQiangDiZhuTipFunc(false);
            this._rangtipScript.showRangTipFunc();
            this._backgroundScipt._showThreeBackCardFunc(true);
            this._backgroundScipt._recoverBackCardFunc();
            if (selfSeatNo == bankSeatNo) {
                this._getDdzControlBtn().showDdzOutCardBtn(true);
            }

            for (let i = 0; i < maxPlayer; i++) {
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                playerui.showDiZhuTipFunc(false);
                playerui.getHandCardFunc().drawHandCardFunc();
                if (i == bankSeatNo) {
                    playerui.showDiZhuTipFunc(true);
                    playerui.getHandCardFunc().moveAddActionCardFunc(protTab.backCardTab);
                    if (i == selfSeatNo) {
                        playerui.showTimeWaitTipFunc(false);
                    } else {
                        playerui.showTimeWaitTipFunc(true);
                    }
                }
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2COutCard) {
            let outSeatNo = roominfo.findUserSeatNoFunc(protTab.userId);
            let turnSeatNo = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            let outtype = GameRuleLogic.getCardTabCardTypeFunc(protTab.cardTab);
            if (protTab.newTurn == 1 || Math.random() * 100 < 50) {
                g_ERDDZGameData.playOutCardFunc(protTab.userId, protTab.cardTab[0], outtype);
            } else {
                g_ERDDZGameData.playEatCardDaNiFunc(protTab.userId);
            }
            g_ERDDZGameData.playOutTypeFunc(outtype);

            g_ERDDZGameData.setCurOutCardTabFunc(protTab.cardTab);
            g_ERDDZGameData.removeCardTabFunc(outSeatNo, protTab.cardTab);
            g_ERDDZGameData.setHandCardSortFunc(true);
            this._backgroundScipt._showThreeBackCardFunc(false);
            this._rangtipScript.showQiangDiZhuTipFunc(false);
            this._getDdzControlBtn().hideDdzAllBtn();
            for (let i = 0; i < maxPlayer; i++) {
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                if (i == outSeatNo) {
                    playerui.getHandCardFunc().drawOutCardFunc(protTab.cardTab);
                    playerui.getHandCardFunc().drawHandCardFunc();
                } else {
                    playerui.getHandCardFunc().clearOutCardFunc();
                }
                if (i == turnSeatNo && turnSeatNo == selfSeatNo || i == outSeatNo) {
                    playerui.showTimeWaitTipFunc(false);
                } else {
                    playerui.showTimeWaitTipFunc(true);
                }
                let leftnum = g_ERDDZGameData.getHandCardCountFunc(i);
                playerui.showUserLeftCardFunc(true, leftnum);
                if (leftnum <= 3) {
                    playerui.showBaoJingTipFunc(true)
                }
            }
            if (turnSeatNo == selfSeatNo) {
                this._getDdzControlBtn().showDdzOutCardBtn(false);
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CBuChu) {
            let theSeatNo = roominfo.findUserSeatNoFunc(protTab.userId);
            let turnSeatNo = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            g_ERDDZGameData.setCurOutCardTabFunc(null);
            g_ERDDZGameData.playNotOutFunc(protTab.userId);
            this._getDdzControlBtn().hideDdzAllBtn();
            for (let i = 0; i < maxPlayer; i++) {
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                if (i == theSeatNo) {
                    playerui.speekBuChuFunc();
                }
                playerui.getHandCardFunc().clearOutCardFunc();
            }
            if (turnSeatNo == selfSeatNo) {
                this._getDdzControlBtn().showDdzOutCardBtn(true);
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CTuoGuan) {} else if (assistId == g_ProtDef.AErRenDDZ_S2CGameFinish) {
            g_ERDDZGameData.playGameResultFunc(protTab.winUserId == selfUserId);
            this._onShowGameResultFunc(protTab);
            //游戏正常结束，调用基类函数
            let gameId = roominfo.getGameIDFunc();
            let roomId = roominfo.getRoomIDFunc();
            this.onBaseGameFinishFunc(gameId, roomId);
        }
    },
    ////////////////////////////////////////////////////////////////////
    _onShowGameResultFunc(protTab) {
        this._resetAllUiFunc();
        g_ERDDZGameData.setHandCardSortFunc(true);
        let maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoFunc();
        let bankerSeatNo = roominfo.findUserSeatNoFunc(protTab.bankerUserId);
        let winSeatNo = roominfo.findUserSeatNoFunc(protTab.winUserId);
        for (let i = 0; i < maxPlayer; i++) {
            g_ERDDZGameData.setHandCardTabFunc(i, protTab.handCardTab[i], true);
            let playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
            playerui.getHandCardFunc().drawHandCardFunc(null, true);
            playerui.showDiZhuTipFunc(false);
            if (bankerSeatNo == i) {
                playerui.showDiZhuTipFunc(true);
            }
            if (i == winSeatNo) {
                playerui.getHandCardFunc().drawOutCardFunc(protTab.lastOutTab);
            }
            roominfo.updateUserGoldFunc(i, protTab.winScore[i]);
            playerui.showTotalScoreFunc(true, protTab.winScore[i]);
        }
        this._getGameResultFunc()._showResultFunc(true, protTab);
    },
});