cc.Class({
    extends: cc.Component,

    properties: {
        O_ifrangxiantip: cc.Node,
        O_ninbeirangtip: cc.Node,
        O_ninrangtip: cc.Node,
        O_qiangdizhutip: cc.Node,
    },

    // use this for initialization
    onLoad: function() {
        this.hideAllTipFunc();
    },
    hideAllTipFunc() {
        this.O_ifrangxiantip.active = false;
        this.O_ninbeirangtip.active = false;
        this.O_ninrangtip.active = false;
        this.O_qiangdizhutip.active = false;
    },
    showQiangDiZhuTipFunc(bVisible) {
        let qiangNum = g_ERDDZGameData.getQiangRangNumFunc();
        cc.log("==========showQiangDiZhuTipFunc=========", qiangNum);
        if (!qiangNum) qiangNum = "0";
        this.O_qiangdizhutip.active = bVisible;
        if (bVisible) {
            let numlabel = this.O_qiangdizhutip.getChildByName("num").getComponent(cc.Label);
            numlabel.string = qiangNum;
        }
    },
    showRangTipFunc() {
        this.O_ifrangxiantip.active = false;
        this.O_ninbeirangtip.active = false;
        this.O_ninrangtip.active = false;

        let qiangNum = g_ERDDZGameData.getQiangRangNumFunc();
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        let isDiZhu = (g_ERDDZGameData.getDiZhuSeatNoFunc() == selfSeatNo);

        let nodzleftnum = 0;
        if (isDiZhu) {
            let duijiaSeatNo = g_ERDDZGameData.getNextSeatNoFunc(selfSeatNo);
            nodzleftnum = g_ERDDZGameData.getHandCardCountFunc(duijiaSeatNo);
        } else {
            nodzleftnum = g_ERDDZGameData.getHandCardCountFunc(selfSeatNo);
        }
        let toleftnum = nodzleftnum - qiangNum;
        cc.log("=========showRangTipFunc================", nodzleftnum, qiangNum, isDiZhu);
        if (toleftnum < 0) toleftnum = 0;
        if (isDiZhu) {
            this.O_ninrangtip.active = true;
            let numlabel1 = this.O_ninrangtip.getChildByName("num1").getComponent(cc.Label);
            let numlabel2 = this.O_ninrangtip.getChildByName("num2").getComponent(cc.Label);
            numlabel1.string = qiangNum + "";
            numlabel2.string = toleftnum + "";
        } else {
            this.O_ninbeirangtip.active = true;
            let numlabel1 = this.O_ninbeirangtip.getChildByName("num1").getComponent(cc.Label);
            let numlabel2 = this.O_ninbeirangtip.getChildByName("num2").getComponent(cc.Label);
            numlabel1.string = qiangNum + "";
            numlabel2.string = toleftnum + "";
        }

    },
});