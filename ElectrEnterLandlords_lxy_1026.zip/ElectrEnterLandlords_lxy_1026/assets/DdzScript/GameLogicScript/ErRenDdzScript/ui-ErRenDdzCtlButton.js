cc.Class({
    extends: cc.Component,

    properties: {
        O_outcardbtnnode: cc.Node,
        O_qiangdzbtnnode: cc.Node,
        O_jiaodzbtnnode: cc.Node,

        O_buchubtn: cc.Button,
    },

    // use this for initializatio n
    onLoad: function() {
        this.hideDdzAllBtn();
    },
    hideDdzAllBtn: function() {
        this.O_outcardbtnnode.active = false;
        this.O_qiangdzbtnnode.active = false;
        this.O_jiaodzbtnnode.active = false;
    },
    showDdzOutCardBtn: function(bMustOut) {
        this.hideDdzAllBtn();
        this.O_outcardbtnnode.active = true;
        this.O_buchubtn.interactable = !bMustOut;
    },
    showDdzQiangDiZhuBtn: function() {
        this.hideDdzAllBtn();
        this.O_qiangdzbtnnode.active = true;
    },
    showDdzJiaoDiZhuBtn: function() {
        this.hideDdzAllBtn();
        this.O_jiaodzbtnnode.active = true;
    },
    ////////////////////////////////////////////////////
    onDdzBuChuBtn: function(event) {
        this.node.emit("outbtn-buchu");
    },
    onDdzLastHandBtn: function(event) {
        //this.node.emit("outbtn-lasthand");
    },
    onDdzTiShiBtn: function(event) {
        this.node.emit("outbtn-tishi");
    },
    onDdzChuPaiBtn: function(event) {
        this.node.emit("outbtn-chupai");
    },
    /////////////////////////////////////////////////
    _priCallProtocolDzFunc: function(isCall) {
        this.hideDdzAllBtn();
        let toProtData = {};
        toProtData.isCall = isCall,
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SCallLandlord, toProtData);
    },
    onDdzBuQiangBtn: function(event) {
        cc.log("=========onDdzBuQiangBtn===");
        this._priCallProtocolDzFunc(0);
    },
    onDdzQiangDiZhuBtn: function(event) {
        cc.log("=========onDdzQiangDiZhuBtn===");
        this._priCallProtocolDzFunc(1);
    },
    /////////////////////////////////////////////////
    onDdzBuJiaoBtn: function(event) {
        cc.log("=========onDdzBuJiaoBtn===");
        this._priCallProtocolDzFunc(0);
    },
    onDdzJiaoDiZhuBtn: function(event) {
        cc.log("=========onDdzJiaoDiZhuBtn===");
        this._priCallProtocolDzFunc(1);
    },
});