var GameRuleLogic = require("ErRenDdzRuleLogic");
var GameRuleConfig = require("ErRenDdzRuleConfig");
cc.Class({
    extends: cc.Component,
    properties: {
        O_handcardprefab: cc.Prefab,
        O_outcardprefab: cc.Prefab,
        O_handCardSp: cc.Node,
        O_outCardSp: cc.Node,
        O_handCardNode: cc.Node,
        ///////////////////////////////////////////
        _seatNo: 0,
        _handCardSize: null,
        _outCardSize: null,
        _allCardArray: [],

        _tishiEatCardTab: [],
        _touchPreMoveUpNum: 0,
    },
    // 尽量在onLoad来初始化界面，在initUI初始化和数据无关的变量
    onLoad() {
        cc.log("========handcard=========onLoad======================", this.O_handCardSp);
        this._handCardSize = new cc.Size(this.O_handCardSp.width, this.O_handCardSp.height);
        this.O_handCardSp.active = false;

        this._outCardSize = new cc.Size(this.O_outCardSp.width, this.O_outCardSp.height);
        this.O_outCardSp.getComponent(cc.Sprite).enabled = false;

        let self = this;
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_START, function(event) {
            //console.log("TOUCH_START");
            let touchPos = event.getLocation();
            self._priCheckTouchHandCardFunc(touchPos, 1);
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_MOVE, function(event) {
            //console.log("TOUCH_MOVE");
            let touchPos = event.getLocation();
            self._priCheckTouchHandCardFunc(touchPos, 2);
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_END, function(event) {
            //console.log("TOUCH_END");
            let touchPos = event.getLocation();
            self._priCheckTouchHandCardFunc(touchPos, 3);
        });
        // this.scheduleOnce(function(){
        //     let toCardTab = [22,140,150,24,23,21, 42,43, 44,41,63,61,62,34,73,82,83];
        //     toCardTab.sort((a, b)=>{
        //         if(a>b) return -1;
        //         return 1;
        //     })
        //     g_ERDDZGameData.setHandCardTabFunc(this._seatNo, toCardTab);
        //     ///g_ERDDZGameData.setCurOutCardTabFunc([31, 32, 33, 52, 53]);
        //     g_ERDDZGameData.removeCardTabFunc(this._seatNo, [63,61,62]);
        //     self.drawHandCardFunc(17);
        // }, 2);

        //let ret = GameRuleLogic.getCardTabCardTypeFunc([11,13,21,31,43,44,52,54]);
        //cc.log("=======GameRuleLogic.IsCardTab1CanEatCardTab2Func=========", ret);
    },
    //属于该句柄的seatNo，cardpos为手牌中心位置，cardWidth一张手牌的宽度
    initUIFunc(seatNo) {
        this._seatNo = seatNo;
    },
    resetUIFunc() {
        this._clearHandCardFunc();
        this.clearOutCardFunc();
    },
    _clearHandCardFunc() {
        this.O_handCardNode.removeAllChildren(true);
        this._allCardArray = [];
    },
    clearOutCardFunc() {
        this.O_outCardSp.removeAllChildren(true);
    },
    drawHandCardFunc(numCard, isAllShow) {
        this._clearHandCardFunc();
        let handCardTab = g_ERDDZGameData.getHandCardTabFunc(this._seatNo);
        if (!handCardTab || handCardTab.length <= 0) return;
        if (!numCard || numCard > handCardTab.length) numCard = handCardTab.length;
        let beginPosX = 0;
        let beginPosY = 0;
        let toInterval = this._handCardSize.width / 2.5;
        beginPosX -= (numCard - 1) * toInterval / 2;
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        if (selfSeatNo != this._seatNo) {
            toInterval = this._handCardSize.width / 3.5;
        }
        let rangpaiNum = g_ERDDZGameData.getQiangRangNumFunc();
        if (this._seatNo == g_ERDDZGameData.getDiZhuSeatNoFunc()) {
            rangpaiNum = -1;
        }
        cc.log("========drawHandCardFunc=========", handCardTab, numCard, rangpaiNum);
        for (let i = 0; i < numCard; i++) {
            let topNode = cc.instantiate(this.O_handcardprefab);
            let toCardScript = topNode.getComponent("ui-ErRenDouDiZhuPokerCard"); //不能用var

            if (selfSeatNo == this._seatNo || isAllShow) {
                toCardScript.setCardValueFunc(handCardTab[i]);
            } else {
                let israngpai = false;
                if (i < rangpaiNum) {
                    israngpai = true;
                }
                toCardScript.setCardValueFunc(0, israngpai);
            }
            if (selfSeatNo != this._seatNo) {
                toCardScript.setCardScaleFunc(0.75);
            }
            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            //console.log("======drawHandCardFunc============", beginPosX, beginPosY);
            topNode.setLocalZOrder(i);
            beginPosX += toInterval;
            this._allCardArray.push(topNode);

            topNode.parent = this.O_handCardNode;
        }
        //按照zorder来从大到小排列，用于触摸
        this._allCardArray.reverse();
        console.log("===drawHandCardFunc====end==", this.O_handCardNode);
    },
    drawOutCardFunc(outCardTab) {
        this.clearOutCardFunc();
        let numCard = outCardTab.length;
        cc.log("========drawOutCardFunc=========", outCardTab, numCard);
        let beginPosX = 0;
        let beginPosY = 0;
        let toInterval = this._outCardSize.width / 2.5;
        beginPosX -= (numCard - 1) * toInterval / 2;
        for (let i = 0; i < numCard; i++) {
            let topNode = cc.instantiate(this.O_outcardprefab);
            let toCardScript = topNode.getComponent("ui-ErRenDouDiZhuPokerCard"); //不能用var
            //cc.log("====drawOutCardFunc=======", this._seatNo, toCardScript);
            toCardScript.setCardValueFunc(outCardTab[i]);
            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            //console.log("======drawHandCardFunc============", beginPosX, beginPosY);
            topNode.setLocalZOrder(i);
            beginPosX += toInterval;

            topNode.parent = this.O_outCardSp;
        }
    },
    moveAddActionCardFunc(actCardTab) {
        for (let j = 0; j < actCardTab.length; j++) {
            for (let i = 0; i < this._allCardArray.length; i++) {
                let cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
                if (!cardScript) return;
                if (!cardScript.isCardMoveUpFunc() && actCardTab[j] == cardScript.getCardValueFunc()) {
                    cardScript.moveUpCardFunc();
                    cardScript.moveDownCardFunc(1);
                    cardScript.showPointTipFunc(true);
                    break;
                }
            }
        }
    },
    moveTiShiHandCardFunc(outCardTab) {
        cc.log("======moveTiShiHandCardFunc====11====", outCardTab);
        let handCardTab = g_ERDDZGameData.getHandCardTabFunc(this._seatNo);
        if (!handCardTab || handCardTab.length <= 0) return;
        let preTiShiLength = this._tishiEatCardTab.length;
        let isEat = GameRuleLogic.IsCardTab1CanEatCardTab2Func(this._tishiEatCardTab, outCardTab);
        if (!isEat) {
            cc.log("======moveTiShiHandCardFunc====22====");
            this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabFunc(handCardTab, outCardTab);
        } else {
            cc.log("======moveTiShiHandCardFunc====33====");
            this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabFunc(handCardTab, this._tishiEatCardTab);
            if (preTiShiLength > 0 && this._tishiEatCardTab.length <= 0) {
                this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabFunc(handCardTab, outCardTab);
            }
        }
        cc.log("======moveTiShiHandCardFunc====44====", isEat, preTiShiLength, this._tishiEatCardTab);
        this._priMoveUpCardTabFunc(this._tishiEatCardTab);
    },
    clearTiShiHandCardFunc() {
        this._tishiEatCardTab = [];
    },
    getMoveUpCardTabFunc(outCardTab) {
        let tab = [];
        for (let i = 0; i < this._allCardArray.length; i++) {
            let cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
            if (!cardScript) return;
            if (cardScript.isCardMoveUpFunc()) {
                tab.push(cardScript.getCardValueFunc());
            }
        }
        let ctype = GameRuleLogic.getCardTabCardTypeFunc(tab);
        if (ctype == GameRuleConfig.CardType.ErrorType) return;
        let isEat = GameRuleLogic.IsCardTab1CanEatCardTab2Func(tab, outCardTab);
        if (isEat) return tab;
    },

    //////////////////////////////////////////////////////////////////////////////////////////////
    _priMoveUpCardTabFunc(cardTab) {
        for (let i = 0; i < this._allCardArray.length; i++) {
            let cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
            if (!cardScript) return;
            cardScript.moveDownCardFunc();
        }
        for (let j = 0; j < cardTab.length; j++) {
            for (let i = 0; i < this._allCardArray.length; i++) {
                let cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
                if (!cardScript) return;
                if (!cardScript.isCardMoveUpFunc() && cardTab[j] == cardScript.getCardValueFunc()) {
                    cardScript.moveUpCardFunc();
                    break;
                }
            }
        }
    },
    _priCheckTouchHandCardFunc(touchPos, touchType) {
        if (touchType == 1) this._touchPreMoveUpNum = 0;
        let touchindex = -1;
        for (let i = 0; i < this._allCardArray.length; i++) {
            let cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
            if (!cardScript) return;
            if (cardScript.onChceckTouchFunc(touchPos, touchType)) {
                touchindex = i;
                break;
            }
        }
        let moveUpTab = [];
        for (let i = 0; i < this._allCardArray.length; i++) {
            let cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
            if (!cardScript) return;
            if (i != touchindex) {
                cardScript.onUnTouchCardFunc();
            }
            if (cardScript.isCardMoveUpFunc()) {
                moveUpTab.push(cardScript.getCardValueFunc());
            }
        }
    }
});