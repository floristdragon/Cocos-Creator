cc.Class({
    extends: cc.Component,

    properties: {
        _seatNo: 0,
        _handCardHandler: null,
    },
    onLoad() {
        //this.resetUIFunc();
    },
    initUIFunc(seatNo) {
        this._seatNo = seatNo;

        this._handCardHandler = this.getComponent("ui-ErRenDouDiZhuHandCard");
        this._handCardHandler.initUIFunc(this._seatNo);

        this.resetUIFunc();
        cc.log("=========player===initUIFunc===========", seatNo, g_ERDDZGameData.getSelfSeatNoFunc());
    },
    resetUIFunc() {
        this.speekNothingFunc();
        this.showUserInfoFunc(false);
        this.showDiZhuTipFunc(false);
        this.showUserLeftCardFunc(false, 0);
        this.showBaoJingTipFunc(false);
        this.showTotalScoreFunc(false, 0);
        this.showTimeWaitTipFunc(false);
        this._showTuoGuanFunc(false);
        this.showReadyTipFunc(false);
        this._handCardHandler.resetUIFunc();
    },
    _getSeatNoFunc() {
        return this._seatNo;
    },
    getHandCardFunc() {
        return this._handCardHandler;
    },
    getHandCardPosFunc() {
        let toNode = this.node.getChildByName("handcard");
        return toNode.convertToWorldSpaceAR(cc.Vec2.ZERO);
    },
    showUserInfoFunc(isVisible, name, score, headurl) {
        let nameNode = this.node.getChildByName("name");
        let scoreNode = this.node.getChildByName("score");
        let faceNode = this.node.getChildByName("playerface");
        nameNode.active = isVisible;
        scoreNode.active = isVisible;
        faceNode.active = isVisible;
        if (!isVisible) return;
        cc.log("=======showUserInfoFunc=======", name, score, headurl);
        if (!name) name = "";
        if (!score) score = "0";
        let nametext = nameNode.getComponent(cc.RichText);
        let scoretext = scoreNode.getComponent(cc.RichText);
        nametext.string = name;
        scoretext.string = score + "";

        faceNode.scaleY = 1;
        faceNode.scaleX = 1;
        if (headurl && headurl.length > 0) {
            let toSprite = faceNode.getComponent(cc.Sprite);
            let toType = "png";
            if (headurl.indexOf(".jpg")) {
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },
    showDiZhuTipFunc(isDiZhu) {
        let tipNode = this.node.getChildByName("dizhutip");
        tipNode.active = isDiZhu;
    },
    showUserLeftCardFunc(isVisible, leftnum) {
        let tipNode = this.node.getChildByName("leftnum");
        tipNode.active = isVisible;
        let ctext = tipNode.getComponent(cc.RichText);
        if (!leftnum) leftnum = "0";
        ctext.string = leftnum + "";
    },
    showBaoJingTipFunc(isVisible) {
        let tipNode = this.node.getChildByName("baojingtip");
        tipNode.active = isVisible;
    },
    showTotalScoreFunc(isVisible, totalscore) {
        let tipNode = this.node.getChildByName("totalscore");
        tipNode.active = isVisible;
        let ctext = tipNode.getComponent(cc.Label);
        if (!totalscore) totalscore = "0";
        ctext.string = totalscore + "";
    },
    showTimeWaitTipFunc(isVisible) {
        let tipNode = this.node.getChildByName("timewaittip");
        tipNode.active = isVisible;
    },
    _showTuoGuanFunc(istuoguan) {
        let tipNode = this.node.getChildByName("tuoguantip");
        tipNode.active = istuoguan;
    },
    showReadyTipFunc(isVisible) {
        let tipNode = this.node.getChildByName("readytip");
        tipNode.active = isVisible;
    },
    /////////////////////////////////////////////////////////
    _priSpeakThingFunc(flag) {
        let loadurl = "erRenDouDiZhuRes/speakTipRes/text_speak_" + flag;
        let tipNode = this.node.getChildByName("speaktip");
        tipNode.active = true;
        let spNode = tipNode.getComponent(cc.Sprite);
        cc.loader.loadRes(loadurl, function(err, texture) {
            spNode.spriteFrame = new cc.SpriteFrame(texture);
        });
    },
    speekNothingFunc() {
        let tipNode = this.node.getChildByName("speaktip");
        tipNode.active = false;
    },
    speekBuChuFunc() {
        this._priSpeakThingFunc(1);
    },
    speekJiaoDiZhuFunc(isCall) {
        if (isCall) {
            this._priSpeakThingFunc(5);
        } else {
            this._priSpeakThingFunc(2);
        }
    },
    speekQiangDiZhuFunc(isCall) {
        if (isCall) {
            this._priSpeakThingFunc(6);
        } else {
            this._priSpeakThingFunc(3);
        }
    },
    speekRangPaiFunc(isRang) {
        if (isRang) {
            this._priSpeakThingFunc(7);
        } else {
            this._priSpeakThingFunc(4);
        }
    },
});