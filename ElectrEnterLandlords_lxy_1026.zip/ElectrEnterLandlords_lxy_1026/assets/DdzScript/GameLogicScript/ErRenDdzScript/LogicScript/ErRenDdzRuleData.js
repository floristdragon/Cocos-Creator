//配置文件
//1、牌组、或者牌组之间的关系
//2、自动选择最优可吃牌组
let GameRuleConfig = require("ErRenDdzRuleConfig");

let IS_DUIZI_CANBECOME_TWODANPAI = true; //对子能否变成两个单牌来用
let GameRuleDataFunc = function(cardTab){
	console.log("=======GameRuleDataFunc===function==11====", cardTab);
	this._allCardTab = [];

	this._cardIdCountTab = {};	//卡牌index对应其数量 "[cardId]=count"
	this._countCardIdTab = {};	//卡牌数量对应该数量的index，"[count] = {cardId1, cardId2}表示index1和index2数量相同为count"
	this._countLimitTab = {};	//卡牌数量对应数量的index的最大最小值，"[count] = {MinCardId=cardId1, MaxCardId=cardId2}"

	this._minCardId = 999;  	//所有手牌最小值
	this._maxCardId = 0;		//所有手牌最大值 

	for(let i=0; i<cardTab.length; i++){
		let cardId = GameRuleConfig.GetCardIndexFunc(parseInt(cardTab[i])); //卡牌id转换成卡牌index
		this._allCardTab.push(cardId);
		let cardIdCount = this._cardIdCountTab[cardId];
		if(!cardIdCount) cardIdCount = 0;
		this._cardIdCountTab[cardId] = parseInt(cardIdCount + 1);
		if(cardId < this._minCardId) this._minCardId = cardId;
		if(cardId > this._maxCardId) this._maxCardId = cardId;
	}
	for(let cardId in this._cardIdCountTab){
		cardId = parseInt(cardId);
		let count = this._cardIdCountTab[cardId];
		if(!this._countCardIdTab[count]) this._countCardIdTab[count] = [];
		this._countCardIdTab[count].push(cardId);
		if(!this._countLimitTab[count]){
			this._countLimitTab[count] = {};
			this._countLimitTab[count].MinCardId = cardId;
			this._countLimitTab[count].MaxCardId = cardId;		
		}
		if(this._countLimitTab[count].MinCardId > cardId){
			this._countLimitTab[count].MinCardId = cardId;
		}
		if(this._countLimitTab[count].MaxCardId < cardId){
			this._countLimitTab[count].MaxCardId = cardId;
		}
	}
	console.log("=======GameRuleDataFunc===function==22====", this._cardIdCountTab, this._countCardIdTab, this._countLimitTab);
}
module.exports = GameRuleDataFunc;
GameRuleDataFunc.prototype = {
	getCopyAllCardTabFunc : function(){
		let tab = [];
		for(let i=0; i<this._allCardTab.length; i++){
			tab[i] = this._allCardTab[i];
		}
		return tab;
	},
	getCopyCardIdCountTabFunc : function(){
		let tab = [];
		for(let i in this._cardIdCountTab){
			tab[i] = this._cardIdCountTab[i];
		}
		return tab;
	},
	_getCardCountFunc : function(cardId){
		if(cardId){
			if(!this._cardIdCountTab[cardId])return 0;
			return this._cardIdCountTab[cardId];
		}
		return this._allCardTab.length;
	},
	_getCountCardCountFunc : function(count){
		if(!this._countCardIdTab[count]) return 0;
		return this._countCardIdTab[count].length;
	},
	getMinOrMaxCardIdFunc : function(){
		return [this._minCardId,this._maxCardId];
	},
	_getCountCardMinOrMaxCardIdFunc : function(minCount){
		let minCardId = null;
		let maxCardId = null;
		if(this._countLimitTab[minCount]){
			minCardId = this._countLimitTab[minCount].MinCardId;
			maxCardId = this._countLimitTab[minCount].MaxCardId;
		}
		// for(let count=minCount; i<=4; i++){
		// 	if(this._countLimitTab[count]){
		// 		if(!minCardId || minCardId>this._countLimitTab[count].MinCardId){
		// 			minCardId = this._countLimitTab[count].MinCardId;
		// 		}
		// 		if(!maxCardId || maxCardId<this._countLimitTab[count].MaxCardId){
		// 			maxCardId = this._countLimitTab[count].MaxCardId;
		// 		}
		// 	}
		// }
		if(minCardId && maxCardId){
			return [minCardId, maxCardId];
		}
	},
	_getCountCardMinAndMaxInterFunc : function(count){
		let cardtab = this._getCountCardMinOrMaxCardIdFunc(count);
		if(!cardtab) return ;
		return cardtab[1] - cardtab[0] + 1;
	},
	////////////////////////////////////////////////////////////////
	//本卡组是一种卡牌类型，返回可以被吃掉的最小卡牌值和连接数量
	getCardTypeMinEatIdOrLinkCountFunc : function(cardtype){
		let toMinCardId = null;
		let toLinkCount = null;
		if(cardtype==GameRuleConfig.CardType.DanPai){
			toMinCardId = this._minCardId;
			toLinkCount = 1;
		}else if(cardtype==GameRuleConfig.CardType.DuiZi){
			toMinCardId = this._minCardId;
			toLinkCount = 1;
		}else if(cardtype==GameRuleConfig.CardType.SanTiao ||	//三条
			cardtype==GameRuleConfig.CardType.SanDaiYi ||	//三带一
			cardtype==GameRuleConfig.CardType.SanDaiYiDui){
			let toMinOrMaxTab = this._getCountCardMinOrMaxCardIdFunc(3);
			if(!toMinOrMaxTab) return ;
			toMinCardId = toMinOrMaxTab[0];
			toLinkCount = 1;
		}else if(cardtype==GameRuleConfig.CardType.ShunZi){
			let tointer = this._getCountCardMinAndMaxInterFunc(1);
			toMinCardId = this._minCardId;
			toLinkCount = tointer;
		}else if(cardtype==GameRuleConfig.CardType.ZhaDan  ||	//炸弹
				cardtype==GameRuleConfig.CardType.SiDaiDanPai  ||	//四代二
				cardtype==GameRuleConfig.CardType.SiDaiErDui){ //四带两对
			let toMinOrMaxTab = this._getCountCardMinOrMaxCardIdFunc(4);
			if(!toMinOrMaxTab) return ;
			toMinCardId = toMinOrMaxTab[0];
			toLinkCount = 1;
		}else if(cardtype==GameRuleConfig.CardType.WangZha){
			toMinCardId = this._minCardId;
			toLinkCount = 1;
		}else if(cardtype==GameRuleConfig.CardType.FeiJiNoPai  ||   //飞机不带牌
				cardtype==GameRuleConfig.CardType.FeiJiDanPai  || 	//飞机带单牌
				cardtype==GameRuleConfig.CardType.FeiJiDuiPai){
			let toMinOrMaxTab = this._getCountCardMinOrMaxCardIdFunc(3);
			let tointer = this._getCountCardMinAndMaxInterFunc(3);
			if(!toMinOrMaxTab || !tointer) return ;
			toMinCardId = toMinOrMaxTab[0];
			toLinkCount = tointer;
		}else if(cardtype==GameRuleConfig.CardType.LianDui){
			let toMinOrMaxTab = this._getCountCardMinOrMaxCardIdFunc(2);
			let tointer = this._getCountCardMinAndMaxInterFunc(2);
			if(!toMinOrMaxTab || !tointer) return ;
			toMinCardId = toMinOrMaxTab[0];
			toLinkCount = tointer;
		}
		if(toMinCardId && toLinkCount){
			return [toMinCardId+1, toLinkCount];
		}
	},
	_IsLegalCardTypeFunc : function(cardtype){
		let cardCount = this._allCardTab.length;
		if(cardtype==GameRuleConfig.CardType.DanPai){
			return cardCount==1;
		}else if(cardtype==GameRuleConfig.CardType.DuiZi){
			return cardCount==2 && this._getCountCardCountFunc(2)==1;
		}else if(cardtype==GameRuleConfig.CardType.SanTiao){
			return cardCount==3 && this._getCountCardCountFunc(3)==1;
		}else if(cardtype==GameRuleConfig.CardType.SanDaiYi){
			return cardCount==4 && this._getCountCardCountFunc(3)==1 && this._getCountCardCountFunc(1)==1;
		}else if(cardtype==GameRuleConfig.CardType.SanDaiYiDui){
			return cardCount==5 && this._getCountCardCountFunc(3)==1 && this._getCountCardCountFunc(2)==1;
		}else if(cardtype==GameRuleConfig.CardType.ShunZi){
			let toMinOrMaxTab = this._getCountCardMinOrMaxCardIdFunc(1);
			if(!toMinOrMaxTab) return ;
			if(toMinOrMaxTab[0]<=GameRuleConfig.CardType.YiID && cardCount>=5 && 
				this._getCountCardCountFunc(1)==cardCount && this._getCountCardMinAndMaxInterFunc(1)==cardCount){
				return true;
			}
		}else if(cardtype==GameRuleConfig.CardType.ZhaDan){
			return cardCount==4 && this._getCountCardCountFunc(4)==1;
		}else if(cardtype==GameRuleConfig.CardType.SiDaiDanPai){
			if(cardCount==6 && this._getCountCardCountFunc(4)==1){
				if(IS_DUIZI_CANBECOME_TWODANPAI){
					return true;
				}else{
					return this._getCountCardCountFunc(1)==2;
				}
			}
		}else if(cardtype==GameRuleConfig.CardType.SiDaiErDui){
			return cardCount==8 && this._getCountCardCountFunc(4)==1 && this._getCountCardCountFunc(2)==2;
		}else if(cardtype==GameRuleConfig.CardType.WangZha){
			if(cardCount==2 && this._getCardCountFunc(GameRuleConfig.CardType.XiaoWangID)==1 && 
			this._getCardCountFunc(GameRuleConfig.CardType.DaWangID)==1){
				return true;
			}
		}else if(cardtype==GameRuleConfig.CardType.FeiJiNoPai){
			let threeCount = this._getCountCardCountFunc(3);
			if(cardCount>=6 && threeCount>=2 && threeCount*3==cardCount && 
					this._getCountCardMinAndMaxInterFunc(3)==threeCount){
				return true;
			}
		}else if(cardtype==GameRuleConfig.CardType.FeiJiDanPai){
			let threeCount = this._getCountCardCountFunc(3);
			let chibangCount = 0;
			if(IS_DUIZI_CANBECOME_TWODANPAI){
				chibangCount = this._getCountCardCountFunc(1) + this._getCountCardCountFunc(2)*2;
			}else{
				chibangCount = this._getCountCardCountFunc(1);
			}
			if(cardCount>=8 && threeCount>=2 && chibangCount>=2 && threeCount*3+chibangCount==cardCount && 
				threeCount==chibangCount && this._getCountCardMinAndMaxInterFunc(3)==threeCount){
				return true;
			}
		}else if(cardtype==GameRuleConfig.CardType.FeiJiDuiPai){
			let threeCount = this._getCountCardCountFunc(3);
			let twoCount = this._getCountCardCountFunc(2);
			if(cardCount>=10 && threeCount>=2 && twoCount>=2 && threeCount*3+twoCount*2==cardCount && 
				threeCount==twoCount && this._getCountCardMinAndMaxInterFunc(3)==threeCount){
				return true;
			}
		}else if(cardtype==GameRuleConfig.CardType.LianDui){
			let twoCount = this._getCountCardCountFunc(2);
			let cardtab = this._getCountCardMinOrMaxCardIdFunc(2);
			console.log("====_IsLegalCardTypeFunc===FeiJiDanPai=====", twoCount, cardCount, cardtab);
			if(!cardtab) return ;
			let minCardId = cardtab[0];
			let maxCardId = cardtab[1];
			if(maxCardId<=GameRuleConfig.CardType.YiID && 
				cardCount>=6 && twoCount*2==cardCount){
					for(let i=minCardId; i<=maxCardId; i++){
						if(this._getCardCountFunc(i)<2){
							return false;
						}
					}
					return true;
			}
		}
	},
	//获取本卡组类型
	getSelfCardTypeFunc : function(){
		let minType = GameRuleConfig.CardType.DanPai;
		let maxType = GameRuleConfig.CardType.LianDui;
		for(let i=minType; i<=maxType; i++){
			if(this._IsLegalCardTypeFunc(i)){
				return i;
			}
		}
		return GameRuleConfig.CardType.ErrorType;	
	},
	getMaxLengthCardTypeTabFunc : function(){
		console.log("======getMaxLengthCardTypeTabFunc==11===", this._allCardTab);
		if(this._allCardTab.length<=0)return [];
		let checkCardTab = [];		
		checkCardTab[0] = this._getFitnessLengthFeiJiFunc(); //最大飞机
		checkCardTab[1] = this._getFitnessLengthLianDuiFunc(); //最大连队
		checkCardTab[2] = this._getFitnessLengthShunZiFunc(); //最大顺子
		checkCardTab[3] = this._getFitnessSiTiaoFunc(); //最大四带
		checkCardTab[4] = this._getFitnessSanTiaoFunc(); //最大三带
		checkCardTab[5] = this._getFitnessDuiZiFunc(); //最小对子
		checkCardTab[6] = this._getFitnessDanPaiFunc(); //最小单牌
		console.log("======getMaxLengthCardTypeTabFunc==22===", checkCardTab);
		let toIndex = null;
		let toMaxNum = 0;
		for(let i in checkCardTab){
			if(toMaxNum < checkCardTab[i].length){
				toMaxNum = checkCardTab[i].length;
				toIndex = i;
			}
		}
		return checkCardTab[toIndex];
	},
	//传入被吃牌组的类型和被吃牌组最小值、被吃牌组顺长,返回能够吃掉牌组的牌组
	getEatCardTypeCardTabFunc : function(eatCardType, eatMinCardId, eatCardlink){
		let toEatTypeTab = GameRuleConfig.FindTypeTableCanEatTypeFunc(eatCardType);
		console.log("========getEatCardTypeCardTabFunc======11======", eatCardType, eatMinCardId, eatCardlink, toEatTypeTab);
		let isZhaDanType = GameRuleConfig.IsCardTypeZhaDanFunc(eatCardType);
		let eatMinCardIdBk = eatMinCardId;
		let eatCardlinkBk = eatCardlink;
		for(let i=0; i<toEatTypeTab.length; i++){
			let ctype = toEatTypeTab[i];
			let toEatTab = null;
			let oneChiBangNum = 0;
			let numChiBang = 0;
			if(ctype != eatCardType && GameRuleConfig.IsType1CanEatType2Func(ctype, eatCardType)){
				eatMinCardId = 0;
			}else{
				eatMinCardId = eatMinCardIdBk;
			}
			console.log("========getEatCardTypeCardTabFunc======22======", ctype, eatMinCardId, eatMinCardIdBk);
			if(ctype==GameRuleConfig.CardType.DanPai){ 
				toEatTab = this._getFitnessDanPaiFunc(eatMinCardId); //最小单牌
			}else if(ctype==GameRuleConfig.CardType.DuiZi){
				toEatTab = this._getFitnessDuiZiFunc(eatMinCardId); //最小对子
			}else if(ctype==GameRuleConfig.CardType.SanTiao){ 
				toEatTab = this._getFitnessSanTiaoFunc(eatMinCardId); //三条
			}else if(ctype==GameRuleConfig.CardType.SanDaiYi){ 
				toEatTab = this._getFitnessSanTiaoFunc(eatMinCardId); //三带一
				oneChiBangNum = 1;
				numChiBang = 1;
			}else if(ctype==GameRuleConfig.CardType.SanDaiYiDui ){	//三带二
				toEatTab = this._getFitnessSanTiaoFunc(eatMinCardId); //最小对子
				oneChiBangNum = 2;
				numChiBang = 1;
			}else if(ctype==GameRuleConfig.CardType.ShunZi ){	//顺子	
				toEatTab = this._getFitnessLengthShunZiFunc(eatMinCardId, eatCardlink); //最小对子
			}else if(ctype==GameRuleConfig.CardType.ZhaDan){ 
				toEatTab = this._getFitnessSiTiaoFunc(eatMinCardId); 
			}else if(ctype==GameRuleConfig.CardType.SiDaiDanPai){
				toEatTab = this._getFitnessSiTiaoFunc(eatMinCardId); 
				oneChiBangNum = 1;
				numChiBang = 2;
			}else if(ctype==GameRuleConfig.CardType.SiDaiErDui){	//四带二
				toEatTab = this._getFitnessSiTiaoFunc(eatMinCardId);
				oneChiBangNum = 2;
				numChiBang = 2;
			}else if(ctype==GameRuleConfig.CardType.WangZha){	//王炸
				if(this._getCardCountFunc(GameRuleConfig.CardType.XiaoWangID)>0 &&
					this._getCardCountFunc(GameRuleConfig.CardType.DaWangID)>0){
					toEatTab = [GameRuleConfig.CardType.XiaoWangID, GameRuleConfig.CardType.DaWangID];
				}
			}else if(ctype==GameRuleConfig.CardType.FeiJiNoPai){ 
				toEatTab = this._getFitnessLengthFeiJiFunc(eatMinCardId, eatCardlink) //飞机不带牌
			}else if(ctype==GameRuleConfig.CardType.FeiJiDanPai){
				toEatTab = this._getFitnessLengthFeiJiFunc(eatMinCardId, eatCardlink); //飞机带单牌
				oneChiBangNum = 1;
				numChiBang = eatCardlink;
			}else if(ctype==GameRuleConfig.CardType.FeiJiDuiPai ){   //飞机不带对牌
				toEatTab = this._getFitnessLengthFeiJiFunc(eatMinCardId, eatCardlink); //最大飞机
				oneChiBangNum = 2;
				numChiBang = eatCardlink;
			}else if(ctype==GameRuleConfig.CardType.LianDui ){	//连对
				toEatTab = this._getFitnessLengthLianDuiFunc(eatMinCardId, eatCardlink); //最大连队
			}
			if(toEatTab && toEatTab.length>0){
				let chibangtab = this.getChiBangNumCardTabFunc(oneChiBangNum, numChiBang, toEatTab);
				if(oneChiBangNum<=0 || numChiBang<=0 || chibangtab.length >0){
					for(let k=0; k<chibangtab.length; k++){
						toEatTab.push(chibangtab[k]);
					}
					return toEatTab;
				}
			}
		}
		return [];
	},
	//////////////////////////////////////////////////////////////////////////////////////////////-
	//////////////////////////////////////////////////////////////////////////////////////////////-
	//获取翅膀的数量，如三带一的一，飞机带翅膀的翅膀，
	//单一个翅膀oneChiBangCard张卡牌
	//需要numChiBang个翅膀
	getChiBangNumCardTabFunc : function(oneChiBangCard, numChiBang, notCardTab){
		if(oneChiBangCard==0 || numChiBang==0 || this._allCardTab.length<numChiBang*oneChiBangCard){ return []; }
		let tab = [];
		let toCount = 0;
		console.log("======getChiBangNumCardTabFunc==11====", oneChiBangCard, numChiBang, notCardTab);
		for(let count=oneChiBangCard; count<=4; count++){
			//console.log("======getChiBangNumCardTabFunc==22====", this._countCardIdTab, count);
			if(!this._countCardIdTab[count]) continue;
			for(let i in this._countCardIdTab[count]){
				let cardId = this._countCardIdTab[count][i];
				if(cardId==GameRuleConfig.CardType.DaWangID || 
					cardId==GameRuleConfig.CardType.XiaoWangID) continue;
				let isInNotTab = false;
				if(notCardTab){
					for(let k=0; k<notCardTab.length; k++){
						if(notCardTab[k]==cardId){
							isInNotTab = true;
							break;
						}
					}
				}
				//console.log("======getChiBangNumCardTabFunc==33====", cardId, isInNotTab);
				if(!isInNotTab){
					let tobegin = 0;
					let toend = 1;
					if(oneChiBangCard==1){ toend = count; }
					for(let j=tobegin;j<toend; j++){
						for(let p=0; p<oneChiBangCard; p++){
							tab.push(cardId);
						}
						toCount = toCount + 1;
						if(toCount>=numChiBang){ return tab; }
					}
				}
			}
		}
		//最后才去拿大小王当翅膀
		if(oneChiBangCard==1 && numChiBang-tab.length<=2){
			if(this._getCardCountFunc(GameRuleConfig.CardType.XiaoWangID)>0){
				tab.push(GameRuleConfig.CardType.XiaoWangID);
			}
			if(numChiBang>1 && this._getCardCountFunc(GameRuleConfig.CardType.DaWangID)>0){
				tab.push(GameRuleConfig.CardType.DaWangID);
			}
			if(tab.length<numChiBang){
				tab = [];
			}
		}
		return [];
	},
	//Fitness合适
	_getFitnessLengthFeiJiFunc : function(minId, limitlink){
		let cardtab = this._getCountCardMinOrMaxCardIdFunc(3);
		if(!cardtab) return [];
		let minCardId = cardtab[0];
		let maxCardId = cardtab[1];
		if(minId) minCardId = minId;
		if((limitlink && maxCardId-minCardId<limitlink) || maxCardId-minCardId<2) return [];
		let toMinLength = 2;
		if(limitlink && limitlink>toMinLength) toMinLength = limitlink;
		return this._priGetLinkCountMinOrMaxCardTabFunc(maxCardId, minCardId, toMinLength, 3, limitlink)
	},
	_getFitnessLengthShunZiFunc : function(minId, limitlink){
		let cardtab = this._getCountCardMinOrMaxCardIdFunc(1);
		if(!cardtab) return [];
		let minCardId = cardtab[0];
		let maxCardId = cardtab[1];
		console.log("=======_getFitnessLengthShunZiFunc=======", minCardId, maxCardId, minId, limitlink);
		if(minId) minCardId = minId;
		if((limitlink && maxCardId-minCardId<limitlink) || maxCardId-minCardId<5) return [];
		let toMinLength = 5;
		if(limitlink && limitlink>toMinLength) toMinLength = limitlink;
		return this._priGetLinkCountMinOrMaxCardTabFunc(maxCardId, minCardId, toMinLength, 1, limitlink)
	},
	_getFitnessSiTiaoFunc : function(minId){
		return this._priGetNumSameCardTabFunc(4, minId);
	},
	_getFitnessLengthLianDuiFunc : function(minId, limitlink){
		let cardtab = this._getCountCardMinOrMaxCardIdFunc(2);
		if(!cardtab) return [];
		let minCardId = cardtab[0];
		let maxCardId = cardtab[1];
		if(minId) minCardId = minId;
		if((limitlink && maxCardId-minCardId<limitlink) || maxCardId-minCardId<3) return [];
		let toMinLength = 3;
		if(limitlink && limitlink>toMinLength) toMinLength = limitlink;
		return this._priGetLinkCountMinOrMaxCardTabFunc(maxCardId, minCardId, toMinLength, 2, limitlink)
	},
	_getFitnessSanTiaoFunc : function(minId){
		return this._priGetNumSameCardTabFunc(3, minId)
	},
	_getFitnessDuiZiFunc : function(minId){
		return this._priGetNumSameCardTabFunc(2, minId)
	},
	_getFitnessDanPaiFunc : function(minId){
		return this._priGetNumSameCardTabFunc(1, minId)
	},
	_priGetNumSameCardTabFunc : function(numCount, minId){
		let toMinId = this._minCardId;
		if(minId && minId>toMinId) toMinId = minId;
		//console.log("======_priGetNumSameCardTabFunc===11=====", numCount, minId, toMinId, this._maxCardId);
		for(let id=toMinId; id<=this._maxCardId; id++){
			if(this._getCardCountFunc(id)<numCount) continue;
			//console.log("======_priGetNumSameCardTabFunc===22=====", id, numCount);
			let tab = [];
			for(let j=0; j<numCount; j++){
				tab.push(id);
			}
			return tab;
		}
		return [];
	},
	_priGetLinkCountMinOrMaxCardTabFunc : function(maxCardId, minCardId, minlinklength, oneLinkCount, limitlink){
		if(maxCardId && maxCardId>GameRuleConfig.CardType.YiID){
			maxCardId = GameRuleConfig.CardType.YiID;
		}
		let toMinCardId = null;
		let toMaxCardId = null;
		for(let i=minCardId; i<=maxCardId; i++){
			let beginId = i;
			let endId = i;
			for(let j=i; j<=maxCardId; j++){
				if(this._getCardCountFunc(j)>=oneLinkCount){ 
					endId = j;
				}else{
					break;
				}
			}
			let tolen = toMaxCardId-toMinCardId + 1;
			if(!toMinCardId || endId-beginId+1 > tolen){
				toMinCardId = beginId;
				toMaxCardId = endId;
				if(limitlink && tolen >= limitlink){
					break;
				}
			}
		}
		console.log("=======_priGetLinkCountMinOrMaxCardTabFunc====11===", toMinCardId, toMaxCardId, minlinklength, limitlink);
		if(!toMinCardId || toMaxCardId-toMinCardId+1 < minlinklength){ return []; }
		let tab = [];
		let toCount = 0;
		for(let kk=toMinCardId; kk<=toMaxCardId; kk++){
			for(let tt=0; tt<oneLinkCount; tt++){
				tab.push(kk);
			}
			toCount = toCount+1;
			if(limitlink && toCount>=limitlink){ break; }
		}
		console.log("=======_priGetLinkCountMinOrMaxCardTabFunc====222===", tab);
		// return {
		// 	[0] : toMinCardId,
		// 	[1] : toMaxCardId,
		// 	[2] : tab,
		// };
		return tab;
	}
};

