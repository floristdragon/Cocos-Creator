
//[[
// 配置文件都在这里，所要用到的资源路径也在这里
//]]

module.exports = {
	//卡牌类型
	CardType : {
		ErrorType : 20, //错误类型
		DanPai : 21,	//单牌
		DuiZi : 22,	//对子
		SanTiao : 23,	//三条
		SanDaiYi : 24,	//三带一
		SanDaiYiDui : 25,//三带一对
		ShunZi : 26,	//顺子	
		ZhaDan : 27,	//炸弹
		SiDaiDanPai : 28,	//四代二
		SiDaiErDui : 29, //四带两对
		WangZha : 30,	//王炸
		FeiJiNoPai : 31,   //飞机不带牌
		FeiJiDanPai : 32, 	//飞机带单牌
		FeiJiDuiPai : 33,   //飞机带对子
		LianDui : 34, 	//连对
		RuanZhaBomb : 35,  //软炸弹，仅在癞子斗地主有
		ChunLaiZiBomb : 36, //纯赖子炸弹，仅在赖子斗地主有


		//卡牌index值
		SanID : 1,
		SiID : 2,
		WuID : 3,
		LiuID : 4,
		QiID : 5,
		BaID : 6,
		JiuID : 7,
		ShiID : 8,
		JID : 9,
		QID : 10,
		KID : 11,
		YiID : 12,  	//卡牌A的id
		ErID : 13,   //卡牌2的id
		XiaoWangID : 14,	//小王，数值不要改，表示小王的卡牌index
		DaWangID : 15,	//大王，数值不要改
	
		NoType : 0,  //没有类型，大王小王
		BlackHeart : 1, //黑心
		RedHeart : 2, //红心
		BlackFlower : 3, //黑花
		RedSquare : 4, //红方块
	},
	//卡牌id转换成卡牌index
	GetCardIndexFunc : function(cardId){
		return Math.floor(cardId / 10);
	},
	GetCardColorFunc : function(cardId){
		return cardId % 10;
	},
	//通过卡牌index和卡牌颜色 生成卡牌id
	generateCardIdFunc : function(cardtype, cardcolor){
		if(cardtype == this.CardType.XiaoWangID ||
			cardtype == this.CardType.DaWangID)
			return cardtype * 10;
		return cardtype * 10 + cardcolor;
	},
	 //比较两种类型可否能吃，itype1是否能吃掉itype2
	IsType1CanEatType2Func : function(itype1, itype2){
		if(itype1 == this.CardType.ErrorType) return false;
		if(itype1==itype2 || itype2==this.CardType.ErrorType ||
			itype1==this.CardType.WangZha){
				return true;
			}
			
		if(itype1==this.CardType.ErrorType) return false;

		if(itype2==this.CardType.ZhaDan){
			if(itype1==this.CardType.WangZha || 
				itype1==this.CardType.ChunLaiZiBomb){
					return true;
				}
		}else if(itype2==this.CardType.RuanZhaBomb){
			if(itype1==this.CardType.WangZha || 
				itype1==this.CardType.ChunLaiZiBomb ||
				itype1==this.CardType.ZhaDan){
					return true;
				}
				
		}else if(itype2==this.CardType.ChunLaiZiBomb){
			return itype1==this.CardType.WangZha;
		}else{
			if(itype1==this.CardType.WangZha || 
				itype1==this.CardType.ChunLaiZiBomb ||
				itype1==this.CardType.RuanZhaBomb ||
				itype1==this.CardType.ZhaDan)
				return true;
		}
		return false;
	},
	//获取可以吃掉itype类型的类型组
	FindTypeTableCanEatTypeFunc : function(itype){
		let eatTab = [];
		if(itype==this.CardType.ErrorType || itype==this.CardType.WangZha){
			return eatTab;
		}
		eatTab.push(itype);
		if(itype==this.CardType.ZhaDan){
			eatTab.push(this.CardType.WangZha);
			/*
			eatTab.push(this.CardType.ChunLaiZiBomb);
		}else if(itype==this.CardType.RuanZhaBomb){
			eatTab.push(this.CardType.WangZha);
			eatTab.push(this.CardType.ChunLaiZiBomb);
			eatTab.push(this.CardType.ZhaDan);
		}else if(itype==this.CardType.ChunLaiZiBomb){
			eatTab.push(this.CardType.WangZha);
			*/
		}
		else{
			//eatTab.push(this.CardType.ChunLaiZiBomb);
			eatTab.push(this.CardType.ZhaDan);
			//eatTab.push(this.CardType.RuanZhaBomb);
			eatTab.push(this.CardType.WangZha);
		}
		return eatTab;
	},
	//是否是炸弹
	IsCardTypeZhaDanFunc : function(itype){
		return itype==this.CardType.ZhaDan || itype==this.CardType.WangZha;
	},
	
	exchangeIndexToCardIdFunc : function(cardIdTab, cardIndexTab) {
		if(!cardIndexTab) return [];
		let totab = [];
		let toindextab = [];
		for(let k in cardIndexTab){
			toindextab[k]=cardIndexTab[k];
		}
		console.log("======exchangeIndexToCardIdFunc=====11===", cardIdTab, toindextab);
		for(let j=0; j<cardIdTab.length; j++){
			let cardid = cardIdTab[j];
			let cardindex=this.GetCardIndexFunc(cardid);
			//console.log("======exchangeIndexToCardIdFunc=====22===", cardid,cardindex, toindextab);
			for(let i=0; i<toindextab.length; i++){
				if(cardindex==toindextab[i]){
					totab.push(cardid);
					toindextab[i] = -1;
					break;
				}
			}
		}
		console.log("======exchangeIndexToCardIdFunc=====33===", totab);
		return totab;
	},
};

