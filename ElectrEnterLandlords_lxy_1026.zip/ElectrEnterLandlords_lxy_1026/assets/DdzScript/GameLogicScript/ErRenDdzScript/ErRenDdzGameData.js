
require("include");
let gameconfig = require("GameConfigScript");
let GameRuleConfig =  require("ErRenDdzRuleConfig");

//在两个数之间随机一个整数
var MathRandomFunc = function(min, max){
    if(min>max) return min;
    let to = Math.random() * (max-min) + min;
    let toi = Math.floor(to);
    if(to < toi + 0.5) return toi;
    return toi + 1;
};  
window.g_ERDDZGameData = {
    _gameId : 0,
    _roomId : 0,

    _playerUIArray : [],
    _seatToUIArray : [],

    _selfSeatNo : 0,

    _handCardTab : [],
    _outCardTab : [],
    _tuoguanTab : [],
    _curOutCardTab : [],
    _backCardTab : [],
    _dizhuSeatNo : -1,

    _mingpaiCardId : 0,
    _qiangRangNum : 0,
    _ishandcardSort : false,
    _isrequestStatus : false,
    //------------------------------------
    //------------------------------------
    initFunc(gameId, roomId, selfSeatNo){
        this._gameId = gameId;
        this._roomId = roomId;
        this._selfSeatNo = selfSeatNo;
        this.resetInitFunc();
    },
    resetInitFunc(){
        this._handCardTab = [];
        this._outCardTab = [];
        this._tuoguanTab = [];
        this._curOutCardTab = [];
        this._backCardTab = [];
        this._dizhuSeatNo = -1;

        this._mingpaiCardId = 0;
        this._qiangRangNum = 0;
        this._ishandcardSort = false;
        this._isrequestStatus = false;
    },
    setPlayerUiFunc(playerui, index, seatNo){
        this._playerUIArray[index] = playerui;
        this._seatToUIArray[seatNo] = index;
    },
    getPlayerUIBySeatNoFunc(seatNo){
        let index = this._seatToUIArray[seatNo];
        return this._playerUIArray[index];
    },
    getPlayerUIByUserIdFunc(userId){
        let roominfo = this.getRoomInfoFunc();
        let seatNo = roominfo.findUserSeatNoFunc(userId);
        return this.getPlayerUIBySeatNoFunc(seatNo);
    },
    ///////////////////////////////////////////////////
    getSelfSeatNoFunc(){
        return this._selfSeatNo;
    },
    getNextSeatNoFunc(curSeatNo){
        if(!curSeatNo) curSeatNo = this._selfSeatNo;
        let maxPeople = this.getMaxPlayerFunc();
        curSeatNo = curSeatNo + 1;
        if(curSeatNo>=maxPeople)curSeatNo = 0; //下标从0开始
        return curSeatNo;
    },
    getLastSeatNoFunc(curSeatNo){
        if(!curSeatNo) curSeatNo = this._selfSeatNo;
        let maxPeople = this.getMaxPlayerFunc();
        curSeatNo = curSeatNo - 1;
        if(curSeatNo<0)curSeatNo = maxPeople;
        return curSeatNo;
    },
    setDiZhuSeatNoFunc(seatNo){
        this._dizhuSeatNo = seatNo;
    },
    getDiZhuSeatNoFunc(){
        return this._dizhuSeatNo;
    },
    ////////////////////////////////////////////////////
    getRoomInfoFunc(){
        return g_RoomManager.getGameRoomInfoFunc(this._gameId, this._roomId);
    },
    getGameIDFunc(){
        return this._gameId;
    },
    getRoomIDFunc(){
        return this._roomId;
    },
    //------------------------------------
    getMaxPlayerFunc(){
        if(!this._gameId) this._gameId = g_ProtDef.MID_Protocol_ErRenDDZ;
        console.log("====getMaxPlayerFunc===========", gameconfig, this._gameId, g_ProtDef.MID_Protocol_ErRenDDZ);
        return gameconfig[this._gameId].maxPlayer;
    },
    //------------------------------------
    setHandCardTabFunc(seatNo, cardtab, isCopy){
        let toTab = cardtab;
        if(isCopy){
            toTab = [];
            for(let i=0; i<cardtab.length; i++){
                toTab[i] = cardtab[i];
            }
        }
        this._handCardTab[seatNo] = toTab;
        this.setHandCardSortFunc(this._ishandcardSort);
    },
    setHandCardSortFunc(isSort){
        this._ishandcardSort = isSort;
        if(this._ishandcardSort){
            let sortfunc = (a, b)=>{
                if(a>b) return -1;
                return 1;
            };
            for(let i=0; i<this.getMaxPlayerFunc();i++){
                if(this._handCardTab[i]){
                    this._handCardTab[i].sort(sortfunc);
                }
            }
        }
    },
    addHandCardTabFunc(seatNo, cardtab){
        if(!this._handCardTab[seatNo])this._handCardTab[seatNo] = {};
        for(let i=0; i<cardtab.length; i++){
            this._handCardTab[seatNo].push(cardtab[i]);
        }
        this.setHandCardSortFunc(this._ishandcardSort);
    },
    getHandCardTabFunc(seatNo, isCopy){
        let toTab = [];
        if(isCopy){
            if(this._handCardTab[seatNo]){
                for(let i=0; i<this._handCardTab[seatNo].length; i++){
                    toTab[i] = this._handCardTab[i];
                }
            }
        }else{
            toTab = this._handCardTab[seatNo];
        }
        console.log("========getHandCardTabFunc===========", seatNo, toTab);
        return toTab;
    },
    getHandCardCountFunc(seatNo){
        if(!this._handCardTab[seatNo]) return 0;
        return this._handCardTab[seatNo].length;
    },
    removeCardTabFunc(seatNo, rmCardTab) {
        let toHandTab = this._handCardTab[seatNo];
        let removeNum = 0;
        for(let i=0; i<rmCardTab.length; i++){
            for(let j=0; j<toHandTab.length; j++){
                if(toHandTab[j]==rmCardTab[i]){
                    toHandTab.splice(j, 1);
                    removeNum++;
                    break;
                }
            }
        }
        cc.log("=====removeCardTabFunc=======", toHandTab);
        return removeNum;
    },
    //------------------------------------
    addOutCardTabFunc(seatNo, outTab){
        if(!this._outCardTab[seatNo]) this._outCardTab[seatNo] = [];
        this._outCardTab[seatNo].push(outTab);
    },
    getAllOutCardTabFunc(seatNo){
        if(!seatNo) return this._outCardTab;
        return this._outCardTab[seatNo];
    },
    setCurOutCardTabFunc(outTab){
        this._curOutCardTab = [];
        if(outTab){
            for(let i in outTab){
                this._curOutCardTab[i] = outTab[i];
            }
        }
    },
    getCurOutCardTabFunc(isCopy){
        if(!isCopy) this._curOutCardTab;
        let totab = [];
        for(let i=0; i<this._curOutCardTab.length; i++){
            totab[i] = this._curOutCardTab[i];
        }
        return totab;
    },
    //------------------------------------
    //三张底牌
    setBackCardFunc(card1, card2, card3){
        this._backCardTab = [];
        this._backCardTab.push(card1);
        this._backCardTab.push(card2);
        this._backCardTab.push(card3);
    },
    getBackCardFunc(){
        return this._backCardTab;
    },
    //------------------------------------
    //明牌id
    setMingPaiIdFunc(cardId){
        this._mingpaiCardId = cardId;
    },
    getMingPaiIdFunc(){
        return this._mingpaiCardId;
    },
    //抢地主数量
    setQiangRangNumFunc(num){
        this._qiangRangNum = num;
    },
    getQiangRangNumFunc(){
        return this._qiangRangNum;
    },
    //------------------------------------
    //--托管
    setTuoGuanFunc(seatNo, bTuoGuan){
        this._tuoguanTab[seatNo] = bTuoGuan;
    },
    isTuoGuanFunc(seatNo){
        return this._tuoguanTab[seatNo];
    },
    //////////////////////////////////////////////
    //value为空，表示背牌
    getPokerFramePathFunc(isBigPoker, value, bRawPath){
        let topath = "erRenDouDiZhuRes/smallPokerPicture/ddz_small_";
        if(isBigPoker){
            topath = "erRenDouDiZhuRes/bigPokerPicture/ddz_big_";
        }
        do{
            if(!value || value<=0){
                // topath = topath + "cardback";
                // topath = topath + "pokerBack";
                topath = topath + "back";
                break;
            }
            let cindex = GameRuleConfig.GetCardIndexFunc(value);
            if(cindex==GameRuleConfig.CardType.XiaoWangID){
                // topath = topath + "xiaowang";
                topath = topath + "joker2";
                break;
            }else if(cindex==GameRuleConfig.CardType.DaWangID){
                // topath = topath + "dawang";
                topath = topath + "joker";
                break;
            }
            if(cindex <= GameRuleConfig.CardType.KID){
                cindex += 2;
            }else if(cindex==GameRuleConfig.CardType.ErID){
                cindex = 2;
            }else if(cindex==GameRuleConfig.CardType.YiID){
                cindex = 1;
            }
            let ccolor = GameRuleConfig.GetCardColorFunc(value);
            topath += ccolor;
            topath += "_";
            topath += cindex;
        }while(0);
        if(bRawPath){
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },
    getRangPokerFramePathFunc(bRawPath){
        // let topath = "erRenDouDiZhuRes/bigPokerPicture/ddz_big_rangpai";
        let topath = "erRenDouDiZhuRes/bigPokerPicture/ddz_big_pokerBack";
        if(bRawPath){
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },
    //////////////////////////////////////////////////////////////////
    playBackgroundMusicFunc(){
        g_SoundManager.playMusicFunc("erRenDouDiZhuRes/sound/music/bg_happy");
    },
    _getCardIdIndexFunc(value){
        let cindex = GameRuleConfig.GetCardIndexFunc(value);
        if(cindex==GameRuleConfig.CardType.XiaoWangID){
            return cindex;
        }else if(cindex==GameRuleConfig.CardType.DaWangID){
            return cindex;
        }
        if(cindex <= GameRuleConfig.CardType.KID){
            cindex += 2;
        }else if(cindex==GameRuleConfig.CardType.ErID){
            cindex = 2;
        }else if(cindex==GameRuleConfig.CardType.YiID){
            cindex = 1;
        }
        return cindex;
    },
    _getBaseEffectPathFunc(userId){
        let userinfo = this.getRoomInfoFunc().getUserInfoByUserIdFunc(userId);
        if(!userinfo) return ;
        let effectpath = "erRenDouDiZhuRes/sound/effect/";
        if(userinfo.isBoy==1){
            effectpath += "boy/";
        }else{
            effectpath += "girl/";            
        }
        return effectpath;
    },
    playGameStartFunc(){
        g_SoundManager.playEffectFunc("erRenDouDiZhuRes/sound/effect/bg-gameMusic");
    },
    playSendCardFunc(){
        g_SoundManager.playEffectFunc("erRenDouDiZhuRes/sound/effect/sendcard");
    },
    playGameResultFunc(isWin){
        if(isWin){
            g_SoundManager.playEffectFunc("erRenDouDiZhuRes/sound/effect/win");
        }else{
            g_SoundManager.playEffectFunc("erRenDouDiZhuRes/sound/effect/failed");
        }
    },
    playJiaoDiZhuFunc(userId, isJiao){
        let effectpath = this._getBaseEffectPathFunc(userId);
        if(isJiao){
            effectpath += "jiaodizhu";
        }else{
            effectpath += "bujiao" + MathRandomFunc(1, 2);
        }
        g_SoundManager.playEffectFunc(effectpath);
    },
    playQiangDiZhuFunc(userId, isQiang){
        let effectpath = this._getBaseEffectPathFunc(userId);
        if(isQiang){
            if(MathRandomFunc(1, 100)<50){
                effectpath += "qiangdizhu";
            }else{
                effectpath += "woqiang";                
            }
        }else{
            effectpath += "buqiang";
        }
        g_SoundManager.playEffectFunc(effectpath);
    },
    playNotOutFunc(userId){
        let effectpath = this._getBaseEffectPathFunc(userId);
        effectpath += "buyao" + MathRandomFunc(1, 4);
        g_SoundManager.playEffectFunc(effectpath);
    },
    playEatCardDaNiFunc(userId){
        let effectpath = this._getBaseEffectPathFunc(userId);
        effectpath += "dani" + MathRandomFunc(1, 3);
        g_SoundManager.playEffectFunc(effectpath);
    },
    playOutTypeFunc(cardtype){
        if(cardtype==GameRuleConfig.CardType.FeiJiNoPai ||
            cardtype==GameRuleConfig.CardType.FeiJiDanPai ||
            cardtype==GameRuleConfig.CardType.FeiJiDuiPai){
                g_SoundManager.playEffectFunc("erRenDouDiZhuRes/sound/effect/feijisound");
        }else if(cardtype==GameRuleConfig.CardType.WangZha){
            g_SoundManager.playEffectFunc("erRenDouDiZhuRes/sound/effect/rocket");
        }
    },
    playOutCardFunc(userId, cardId, cardtype){
        g_SoundManager.playEffectFunc("erRenDouDiZhuRes/sound/effect/outcard");
        let effectpath = this._getBaseEffectPathFunc(userId);
        let cindex = this._getCardIdIndexFunc(cardId);
        if(cardtype==GameRuleConfig.CardType.DanPai){
            effectpath += cindex;
        }else if(cardtype==GameRuleConfig.CardType.DuiZi){
            effectpath += "dui" + this._getCardIdIndexFunc(cardId);
        }else if(cardtype==GameRuleConfig.CardType.SanTiao){
            if(MathRandomFunc(1, 100)<50){
                effectpath += "sange";
            }else{
                effectpath += "sanzhang";
            }
        }else if(cardtype==GameRuleConfig.CardType.SanDaiYi){
            effectpath += "sandaiyi";
        }else if(cardtype==GameRuleConfig.CardType.SanDaiYiDui){
            effectpath += "sandaiyidui";
        }else if(cardtype==GameRuleConfig.CardType.ShunZi){
            if(MathRandomFunc(1, 100)<50){
                effectpath += "shunzi";
            }else{
                effectpath += "danshun";
            }
        }else if(cardtype==GameRuleConfig.CardType.ZhaDan){
            effectpath += "zhadan";
        }else if(cardtype==GameRuleConfig.CardType.SiDaiDanPai){
            effectpath += "sidaier";
        }else if(cardtype==GameRuleConfig.CardType.SiDaiErDui){
            effectpath += "sidailiangdui";
        }else if(cardtype==GameRuleConfig.CardType.WangZha){
            effectpath += "wangzha";
        }else if(cardtype==GameRuleConfig.CardType.FeiJiNoPai){
            effectpath += "feiji";
        }else if(cardtype==GameRuleConfig.CardType.FeiJiDanPai){
            effectpath += "feijichibang";
        }else if(cardtype==GameRuleConfig.CardType.FeiJiDuiPai){
            effectpath += "feijichibang";
        }else if(cardtype==GameRuleConfig.CardType.LianDui){
            effectpath += "liandui";
        }else{
            effectpath = null;
        }
        if(effectpath){
            g_SoundManager.playEffectFunc(effectpath);
        }
    },
};