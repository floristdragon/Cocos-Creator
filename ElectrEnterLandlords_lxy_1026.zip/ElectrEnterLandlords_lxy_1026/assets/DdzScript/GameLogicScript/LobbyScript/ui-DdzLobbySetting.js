cc.Class({
    extends: cc.Component,

    properties: {

        O_musicToggle: cc.Toggle,
        O_effectToggle: cc.Toggle,

        _isCheckToggleClick: true,
    },
    onLoad() {
        this._isCheckToggleClick = false;
        if (g_SoundManager.isMusicOpenFunc()) {
            cc.log("=======onLoad===11================");
            this.O_musicToggle.check();
        } else {
            cc.log("=======onLoad===22================");
            this.O_musicToggle.uncheck();
        }
        if (g_SoundManager.isEffectOpenFunc()) {
            cc.log("=======onLoad===33================");
            this.O_effectToggle.check();
        } else {
            cc.log("=======onLoad===44================");
            this.O_effectToggle.uncheck();
        }
        this._isCheckToggleClick = true;
    },

    showSettingNodeFunc: function() {
        this.node.active = true;
    },

    onDdzMusicToggleClickBtn(toggle) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        cc.log("================onDdzMusicToggleClickBtn======================", toggle, toggle.isChecked)
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setMusicOpenFunc(true);
            g_SoundManager.playMusicFunc("erRenDouDiZhuRes/sound/music/bg_happy");
        } else {
            g_SoundManager.setMusicOpenFunc(false);
        }
    },

    onDdzEffectToggleClickBtn(toggle) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        cc.log("==========================onDdzEffectClickBtn===============", toggle, toggle.isChecked);
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setEffectOpenFunc(true);
        } else {
            g_SoundManager.setEffectOpenFunc(false);
        }
    },

    onDdzCloseClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.node.active = false;
    },
});