let gameconfig = require("GameConfigScript");

cc.Class({
    extends: cc.Component,

    properties: {
        _enableInput: true,
        _maxJuShu: null,

        O_8toggleBtn: cc.Toggle,
        O_16toggleBtn: cc.Toggle,

        O_rulePrefab: cc.Prefab,
        O_settingPrefab: cc.Prefab,
    },

    // use this for initialization
    onLoad: function(data01, data02, data03) {
        cc.log("=======createroom===onload===", data01, data02, data03);
        this._enableInput = true;
        if (this.O_8toggleBtn.isChecked) {
            this._maxJuShu = 8;

        }
        if (this.O_16toggleBtn.isChecked) {
            this._maxJuShu = 16;

        }
    },

    onDdzToggleClickBtn: function(event, detail) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        if (this.O_8toggleBtn.isChecked) {
            this._maxJuShu = parseInt(detail);
            //this._maxJuShu = gameconfig[g_ProtDef.MID_Protocol_ErRenDDZ].jushuLimit[8];
            cc.log("==============this.O_8toggleBtn.isChecked====================", gameconfig[g_ProtDef.MID_Protocol_ErRenDDZ].jushuLimit[8]);
        }
        if (this.O_16toggleBtn.isChecked) {
            this._maxJuShu = parseInt(detail);
            //this._maxJuShu = gameconfig[g_ProtDef.MID_Protocol_ErRenDDZ].jushuLimit[16];

        }
    },


    onDdzCreateBtn(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        if (!this._enableInput) return;
        this._enableInput = false;
        let self = this;
        this.scheduleOnce(function() {
            self._enableInput = true;
        }, 0.5);

        let protTab = {};
        protTab.gameId = g_ProtDef.MID_Protocol_ErRenDDZ; //游戏名称
        protTab.userId = g_UserManager.getSelfUserIDFunc();
        protTab.pwd = ""; //房间密码
        protTab.maxJuShu = this._maxJuShu;
        protTab.config = {}; //创建配置
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SCreatDesk, protTab)
    },

    onDdzRuleClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        let ruleNode = cc.instantiate(this.O_rulePrefab);
        ruleNode.setLocalZOrder(10);
        ruleNode.parent = this.node;
        let close = ruleNode.getChildByName('close');
        close.off("touchstart");
        close.on('touchstart', function(event) {
            g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
            ruleNode.active = false;
        });
    },

    onDdzSettingClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        let settingNode = cc.instantiate(this.O_settingPrefab);
        settingNode.parent = this.node;
        settingNode.setLocalZOrder(10);
    },

    onDdzCloseBtn(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.node.active = false;
    },
});