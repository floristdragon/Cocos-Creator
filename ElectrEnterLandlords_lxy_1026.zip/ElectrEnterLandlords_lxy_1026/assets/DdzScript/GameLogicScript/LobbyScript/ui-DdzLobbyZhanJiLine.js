let gameconfig = require("GameConfigScript");
cc.Class({
    extends: cc.Component,

    properties: {
        O_gameidlabel: cc.Label,
        O_roomidlabel: cc.Label,
        O_timelabel: cc.Label,

        _userdatalist: null,
    },

    setDataFunc(gameid, roomid, jushu, stime, userlist) {
        // this.O_gameidlabel.string = gameconfig[parseInt(gameid)].desc;
        this.O_gameidlabel.string = "二人斗地主";
        this.O_roomidlabel.string = roomid + "-" + jushu;
        this._userdatalist = userlist;
        let date = new Date(stime * 1000);
        let extTimeFunc = function(time) {
            if (time < 10) return "0" + time;
            return time + "";
        };
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        this.O_timelabel.string = ' ' + year + "/" + extTimeFunc(month) + "/" +
            extTimeFunc(date.getDate()) + "-" + extTimeFunc(date.getHours()) + ":" + extTimeFunc(date.getMinutes()) + ' ';
    },

    onDdzClickBtn() {
        cc.log("=======onDdzClickBtn========", this._userdatalist)
        if (this._userdatalist) {
            this.node.emit("zhanjiline-event", this._userdatalist);
        }
    },
});