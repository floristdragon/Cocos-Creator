cc.Class({
    extends: cc.Component,

    properties: {
        label : cc.Label,
    },

    // use this for initialization
    onLoad: function () {

    },

    onDdzCloseClickBtn : function () {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        
        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
