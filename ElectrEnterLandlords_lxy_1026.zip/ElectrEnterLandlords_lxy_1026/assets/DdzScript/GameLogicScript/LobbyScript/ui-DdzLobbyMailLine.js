cc.Class({
    extends: cc.Component,

    properties: {

        title: cc.Label,
        time: cc.Label,
        bgFrame: cc.SpriteFrame,
        bg: cc.Sprite,

        _mailId: null,
        _node: null,

        _renew: null,
    },

    // use this for initialization
    initFunc: function(mid, title, stime) {
        this.title.string = title;
        let date = new Date(stime * 1000);
        let extTimeFunc = function(time) {
            if (time < 10) return "0" + time;
            return time + "";
        };
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        this.time.string = year + "/" + extTimeFunc(month) + "/" +
            extTimeFunc(date.getDate()) + " " + extTimeFunc(date.getHours()) + ":" + extTimeFunc(date.getMinutes());
        this._mailId = mid;
    },

    onDdzMainBoxClick: function() {
            g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

            this.bg.spriteFrame = this.bgFrame;
            let mailtoProtab = {};
            mailtoProtab.mailId = this._mailId;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_MailBox, g_ProtDef.AMailBox_C2SReqReadMail, mailtoProtab);

            this.node.emit("mailbox-readmail");
            cc.log("==============ui-mailContent.parent================", this._mailId);
        }
        // called every frame, uncomment this function to activate update callback
        // update: function (dt) {

    // },
});