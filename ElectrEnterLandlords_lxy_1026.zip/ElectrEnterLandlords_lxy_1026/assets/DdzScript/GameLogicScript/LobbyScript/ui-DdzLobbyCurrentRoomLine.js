cc.Class({
    extends: cc.Component,

    properties: {
        O_roomidlabel: cc.Label,
        O_jushulabel: cc.Label,

        _roomId: null,
        _gameId: null,
    },

    setDataFunc(gameId, roomId, curjushu, maxjushu) {
        cc.log("===ui-DdzLobbyCurrentRoomLine==setDataFunc========", gameId, roomId, curjushu, maxjushu)
        this._gameId = gameId;
        this._roomId = roomId;
        this.O_roomidlabel.string = roomId + "";
        this.O_jushulabel.string = curjushu + "/" + maxjushu;
    },

    onDdzJoinRoomBtn() {
        if (!this._gameId || !this._roomId) return;
        let toProtTab = {};
        toProtTab.gameId = this._gameId;
        toProtTab.roomId = this._roomId;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqEnterDesk, toProtTab)
    },
});