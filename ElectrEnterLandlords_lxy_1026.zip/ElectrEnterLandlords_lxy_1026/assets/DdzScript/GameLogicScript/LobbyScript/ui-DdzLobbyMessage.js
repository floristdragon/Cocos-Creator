cc.Class({
    extends: cc.Component,

    properties: {
        messageLabel : cc.Label,
    },

    // use this for initialization
    initFunc: function (message) {
        if(message){
            this.messageLabel.string = message;
        }
    },

    onDdzCloseClickBtn : function () {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        
        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
