let utilIconv = require("util-iconvScript")
cc.Class({
    extends: cc.Component,

    properties: {
        O_mailprefab: cc.Prefab,

        O_scrollview: cc.Node,

        O_maildetailnode: cc.Node,
        O_labelcontent: cc.Label,
        O_emptytip: cc.Node,

        _scrollscript: null,
        _detailnode: null,
    },
    onLoad() {
        this.O_maildetailnode.active = false;
        this._scrollscript = this.O_scrollview.getComponent("ui-DdzScrollView");
        this._scrollscript.setHeightInterFunc(0);
        this._checkEmptyTipFunc();
    },

    showBoxFunc(bVisible, bClear) {
        cc.log("=========setMailBox===========");
        this.node.active = bVisible;
        if (bClear) this._scrollscript.clearAllNodeFunc();
    },
    setBoxMailFunc(maillist) {
        if (!maillist) return;
        for (let i = 0; i < maillist.length; i++) {
            let maildata = maillist[i];
            //let iconvlite = require('iconv-lite');
            //let toData = iconvlite.decode(toTempArray, 'UTF8');
            maildata.title = utilIconv.GBKToUTF8(maildata.title);
            maildata.content = utilIconv.GBKToUTF8(maildata.content);
            let mailnode = cc.instantiate(this.O_mailprefab);
            cc.log("======setBoxMailFunc===title===", maildata.title);
            mailnode.getComponent("ui-DdzLobbyMailLine").initFunc(maildata.mailId, maildata.title, maildata.stime);
            mailnode.on("mailbox-readmail", () => {
                this.O_labelcontent.string = maildata.content;
                this.O_maildetailnode.active = true;
                this._detailnode = mailnode;
            }, this);
            this._scrollscript.addScrollNodeFunc(mailnode, null, maildata.stime);
        }
        this._scrollscript.sortAllNodeListFunc((a, b) => {
            if (a > b) return -1;
            return 1;
        });
        this._checkEmptyTipFunc();
    },

    onDdzCloseDetailClick(node) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        cc.log("========onDdzCloseDetailClick=========", node);
        this.O_maildetailnode.active = false;
        this._scrollscript.rmScrollNodeFunc(this._detailnode);
        this._checkEmptyTipFunc();
    },
    onDdzClose() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.showBoxFunc(false);
    },

    _checkEmptyTipFunc() {
        if (this._scrollscript.getListSizeFunc() <= 0) {
            this.O_emptytip.active = true;
        } else {
            this.O_emptytip.active = false;
        }
    },
});