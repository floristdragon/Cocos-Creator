cc.Class({
    extends: cc.Component,

    properties: {
        O_userName: cc.Label,
        O_userId: cc.Label,
        O_userIp: cc.Label,
        O_userHead: cc.Node,

    },

    onLoad() {
        let userinfo = g_UserManager.getSelfUserInfoFunc();
        this.O_userName.string = userinfo.getUserNameFunc();
        this.O_userId.string = userinfo.getUserIDFunc();
        this.O_userIp.string = userinfo.getIpAddrFunc();
        cc.log("===========userinfo=========", userinfo);
        let headurl = userinfo.getHeadUrlFunc();
        if (headurl && headurl.length > 0) {
            let toSprite = this.O_userHead.getComponent(cc.Sprite);
            let toType = "png";
            if (headurl.indexOf(".jpg")) {
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },

    onDdzChangeUserBtn: function() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        g_GameScene.runStartSceneFunc();
        this.onDdzCloseBtn();
    },

    onDdzCloseBtn: function() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.node.destroy();
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});