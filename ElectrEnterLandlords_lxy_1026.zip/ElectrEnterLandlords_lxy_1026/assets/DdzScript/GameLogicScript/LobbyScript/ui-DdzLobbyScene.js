let utilIconv = require("util-iconvScript")
cc.Class({
    extends: require("ui-DdzRoomScene"),

    properties: {

        O_bottmBtns: cc.Node,

        O_isRoomExitPrefab: cc.Prefab,
        O_createRoomprefab: cc.Prefab,
        O_joinRoomprefab: cc.Prefab,
        O_userinfoprefab: cc.Prefab,

        //bottomButtons Prefab
        O_friendsPrefab: cc.Prefab,
        O_kefuPrefab: cc.Prefab,
        O_zhanjiPrefab: cc.Prefab,
        O_mailPrefab: cc.Prefab,
        O_messagePrefab: cc.Prefab,
        O_activityPrefab: cc.Prefab,

        //topButtons Prefab
        O_settingPrefab: cc.Prefab,
        O_rulePrefab: cc.Prefab,

        O_noticeMaskNode: cc.Node,
        O_namelabel: cc.Label,
        O_useridlabel: cc.Label,

        O_paihangbangPrefab: cc.Prefab,
        O_showChat: cc.Node,
        ///////////////////////////////////////////////////////
        _createroomNode: null,
        _joinroomNode: null,
        _mailBoxScript: null,
        _friendNode: null,
        _friendnodeScript: null,
        _ctrCreateOrJoinRoomFlag: null,


        _paihangbangNode: null,
        _zhanjiNodeScript: null,
    },

    // use this for initialization
    onLoad() {
        this._super(); //调用父类的
        this.O_bottmBtns.setLocalZOrder(5);
        this.O_showChat.setLocalZOrder(5);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CQueryMyDesk, this._onProtCurrentRoomExitFunc, this);
        //注册回调函数
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CCreatDesk, this._onProtCreateRoomFunc, this);
        //排行榜协议
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Rank, g_ProtDef.ARank_S2CReqRankList, this._onProtReqRankListFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_MailBox, g_ProtDef.AMailBox_S2CQueryAllMail, this._onProtMailListFunc, this);
        //大厅公告
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2ClobbyNotice, this._onProtLobbyNoticeFunc, this);

        //初始化数据
        let userinfo = g_UserManager.getSelfUserInfoFunc();
        this.O_namelabel.string = userinfo.getUserNameFunc();
        this.O_useridlabel.string = "ID:" + userinfo.getUserIDFunc();
        cc.log("=====lobbbyscene===onLoad=======", this.O_namelabel.string);
        this._showRankNodeFunc();

        g_SoundManager.playMusicFunc("DdzCommonMusic/bg-lobbyMusic");
        //请求一些信息
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Rank, g_ProtDef.ARank_C2SReqRankList);
        //
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SlobbyNotice);
    },
    _runNoticeLabelActionFunc(str, repeatnum) {
        let noticelabel = this.O_noticeMaskNode.getChildByName("label");
        // noticelabel.getComponent(cc.Label).string = str;
        noticelabel.stopAllActions();
        let maskWidth = this.O_noticeMaskNode.width;
        if (maskWidth < noticelabel.width) maskWidth = noticelabel.width;
        let toPosY = noticelabel.position.y;
        let toPosX = 0;
        let toRightPos = new cc.Vec2(toPosX - maskWidth - 5, toPosY);
        let toLeftPos = new cc.Vec2(toPosX + maskWidth + 5, toPosY);
        let toAction = cc.sequence(cc.moveTo(15, toRightPos), cc.moveTo(0, toLeftPos));
        if (!repeatnum || repeatnum <= 0) {
            noticelabel.runAction(cc.repeatForever(toAction));
        } else {
            noticelabel.runAction(cc.repeat(toAction, repeatnum));
        }
    },
    ///////////////////////////////////////////////////////////////
    //协议回调 
    //玩家查询属于自己创建的桌子房间状态
    _onProtCurrentRoomExitFunc(mainId, assistId, protTab) {
        cc.log("=====_onProtCurrentRoomExitFunc===================", mainId, assistId, protTab);
        this.showLoadFlowerFunc(false);
        if (protTab && protTab.length > 0) {
            let curroomnode = cc.instantiate(this.O_isRoomExitPrefab);
            curroomnode.parent = this.node;
            curroomnode.setLocalZOrder(10);
            curroomnode.active = true;
            var croomexitScript = curroomnode.getComponent('ui-DdzLobbyCurrentRoom');
            for (let i = 0; i < protTab.length; i++) {
                let toroomdata = protTab[i];
                croomexitScript.addOneRoomRecordFunc(toroomdata.gameId, toroomdata.roomId, toroomdata.curjushu, toroomdata.maxjushu);
            }
        } else {
            if (this._ctrCreateOrJoinRoomFlag == 1) {
                this._showCreateRoomNodeFunc(true);
            } else if (this._ctrCreateOrJoinRoomFlag == 2) {
                this._showJoinRoomNodeFunc(true);
            }
        }

    },
    //用户创建房间
    _onProtCreateRoomFunc(mainId, assistId, protTab) {
        cc.log("=====_onProtCreateRoomFunc===================", mainId, assistId, protTab);
        let roominfo = g_RoomManager.newRoomInfoFunc(protTab.gameId, protTab.roomId);
        roominfo.setPackageInfoFunc(protTab);

        if (roominfo.getGameIDFunc() == g_ProtDef.MID_Protocol_ErRenDDZ) {
            let toProtTab = {};
            toProtTab.gameId = roominfo.getGameIDFunc(); //游戏id
            toProtTab.roomId = roominfo.getRoomIDFunc();
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqEnterDesk, toProtTab);
        }
    },
    //请求大厅公告
    _onProtLobbyNoticeFunc(mainId, assistId, protTab) {
        cc.log("======lobbyScene=======_onProtLobbyNoticeFunc========", protTab);
        if (protTab.itype == 0) {
            let toContent = utilIconv.GBKToUTF8(protTab.content);
            this._runNoticeLabelActionFunc(toContent, protTab.repeatnum);
        }
    },
    //排行榜
    _onProtReqRankListFunc(mainId, assistId, protTab) {
        cc.log("=========ui-DdzLobbyScene=========onRankInit=========", protTab);
        if (!this._paihangbangNode) {
            this._paihangbangNode = cc.instantiate(this.O_paihangbangPrefab);
            this._paihangbangNode.parent = this.node;
            this._paihangbangNode.setLocalZOrder(2);
        }
        let phbscript = this._paihangbangNode.getComponent('ui-DdzLobbyRank');
        phbscript.setPaiHangBangFunc(protTab.rank, protTab.winNum, protTab.list);
    },

    _onProtMailListFunc(mainId, assistId, protTab) {
        cc.log("=========ui-DdzLobbyScene=============_onProtMailListFunc========", protTab);
        if (this._mailBoxScript) this._mailBoxScript.setBoxMailFunc(protTab.mailtab);
    },
    ///////////////////////////////////////////////////////////////
    onRecvErrcodeFunc(errcode, attachtab) {
        cc.log("=======onRecvErrcodeFunc============", errcode, attachtab);
        this.showPopupWindowFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },
    onRecvEnterRoomFunc(gameId, roomId, userId) {
        cc.log("==========lobbyscene====onRecvEnterRoomFunc=====", gameId, roomId, userId);
        g_RoomManager.setCurGameRoomFunc(null, null);
        let selfUserId = g_UserManager.getSelfUserIDFunc();
        if (selfUserId == userId) {
            g_RoomManager.setCurGameRoomFunc(gameId, roomId);
            this.runErRenDouDiZhuSceneFunc();
        }
    },
    _showCreateRoomNodeFunc(isVisible) {
        if (!this._createroomNode) {
            this._createroomNode = cc.instantiate(this.O_createRoomprefab);
            this._createroomNode.parent = this.node;
            this._createroomNode.setLocalZOrder(10);
        }
        this._createroomNode.active = isVisible;
    },
    _showJoinRoomNodeFunc(isVisible) {
        if (!this._joinroomNode) {
            this._joinroomNode = cc.instantiate(this.O_joinRoomprefab);
            cc.log("======= this._joinroomNode ========", this._joinroomNode);
            this._joinroomNode.parent = this.node;
            this._joinroomNode.setLocalZOrder(10);
        }
        this._joinroomNode.active = isVisible;
    },
    onDdzExitGameBtn(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        let self = this;
        self.showPopupWindowFunc(true, true, "提示", "是否退出游戏？", function(okflag) {
            cc.log("===========showPopupWindowFunc=============", okflag);
            if (okflag == 1) {
                cc.game.end();
            }
        });
    },
    _showRankNodeFunc() {
        //
        this._paihangbangNode = cc.instantiate(this.O_paihangbangPrefab);
        this._paihangbangNode.parent = this.node;
        this._paihangbangNode.setLocalZOrder(2);
    },
    onDdzCreateRoomBtn(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.showLoadFlowerFunc(true);
        this._ctrCreateOrJoinRoomFlag = 1;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SQueryMyDesk);
    },
    onDdzJoinRoomBtn(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.showLoadFlowerFunc(true);
        this._ctrCreateOrJoinRoomFlag = 2;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SQueryMyDesk);
    },
    onDdzUserInfoBtn(event) {

    },

    //分享点击事件
    onDdzFriendsClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.O_friendsTipsNode.active = false;
        if (!this._friendNode) {
            let friendNode = cc.instantiate(this.O_friendsPrefab);
            friendNode.parent = this.node;
            friendNode.setLocalZOrder(10);
            this._friendNode = friendNode;
        }
        this._friendnodeScript = this._friendNode.getComponent('ui-DdzLobbyFriends');
        if (this._friendsTis == 1) {
            this._friendnodeScript.showApplyTipsFunc(this._friendsTis);
            this._friendsTis = 0;
        }
        this._friendnodeScript.openFriendsViewFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SQueryFriend);


    },

    onDdzSettingClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        let settingNode = cc.instantiate(this.O_settingPrefab);
        settingNode.parent = this.node;
        settingNode.setLocalZOrder(10);
    },

    onDdzKeFuClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        let kefuNode = cc.instantiate(this.O_kefuPrefab);
        kefuNode.parent = this.node;
        kefuNode.setLocalZOrder(10);
    },

    onDdzMessageClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        let messageNode = cc.instantiate(this.O_messagePrefab);
        messageNode.parent = this.node;
        messageNode.setLocalZOrder(10);
    },

    onDdzActivityClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        let messageNode = cc.instantiate(this.O_activityPrefab);
        messageNode.parent = this.node;
        messageNode.setLocalZOrder(10);
    },

    onDdzMailClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.O_mailsTipsNode.active = false;
        cc.log("========ui-DdzLobbyScene=====onDdzMailClickBtn===============");

        //邮箱协议
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_MailBox, g_ProtDef.AMailBox_C2SQueryAllMail);

        if (!this._mailBoxScript) {
            let mailBoxNode = cc.instantiate(this.O_mailPrefab);
            mailBoxNode.parent = this.node;
            mailBoxNode.setLocalZOrder(10);
            this._mailBoxScript = mailBoxNode.getComponent('ui-DdzLobbyMails');
        }
        this._mailBoxScript.showBoxFunc(true, true);
    },

    onDdzRuleClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        let ruleNode = cc.instantiate(this.O_rulePrefab);
        ruleNode.setLocalZOrder(10);
        ruleNode.parent = this.node;
        let close = ruleNode.getChildByName('close');
        close.off("touchstart");
        close.on('touchstart', function(event) {
            g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
            ruleNode.active = false;
        });
    },


    onDdzZhanjiClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.O_zhanjiTipsNode.active = false;
        if (!this._zhanjiNodeScript) {
            let zhanjiNode = cc.instantiate(this.O_zhanjiPrefab);
            zhanjiNode.parent = this.node;
            zhanjiNode.setLocalZOrder(10);

            this._zhanjiNodeScript = zhanjiNode.getComponent("ui-DdzLobbyZhanJi");
        }
        cc.log("==============onDdzZhanjiClickBtn============", this._zhanjiNodeScript);
        this._zhanjiNodeScript.showUIFunc(true);
    },

    onDdzShowUserInfoPanel() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        let userInfoNode = cc.instantiate(this.O_userinfoprefab);
        userInfoNode.setLocalZOrder(100);
        userInfoNode.parent = this.node;
    },



});