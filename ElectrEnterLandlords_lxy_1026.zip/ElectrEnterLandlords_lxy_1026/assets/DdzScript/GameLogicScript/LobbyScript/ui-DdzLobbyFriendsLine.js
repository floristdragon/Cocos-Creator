cc.Class({
    extends: cc.Component,

    properties: {
        O_headImg: cc.Sprite,
        O_id: cc.Label,
        O_onORout: cc.Sprite,
        O_onORoutGround: cc.Sprite,
        O_onORoutImg: [cc.SpriteFrame],
        O_onORoutGroundImg: [cc.SpriteFrame],

        O_applyButton: cc.Node,

        O_siliaoPrefab: cc.Prefab,
        _userID: null,
    },

    // use this for initialization
    initFunc: function(headImgUrl, name, id, onORoutLine) {
        cc.log("====ui-DdzFriendsLine.js=========initFunc==========", headImgUrl, name, id, onORoutLine);

        this._userID = id;
        //搜索自己的id时不显示申请好友按钮
        if (this._userID == g_UserManager.getSelfUserIDFunc()) {
            this.O_applyButton.active = false;
        }
        //获取好友头像
        let headImg = this.O_headImg.spriteFrame;
        if (headImgUrl && headImgUrl.length > 0) {
            let imgType = "png";
            if (headImgUrl.indexOf(".jpg")) {
                imgType = "jpg";
            }

            cc.loader.load({ type: imgType, url: headImgUrl }, (err, texture) => {
                if (!err) {
                    headImg = new cc.SpriteFrame(texture);
                }
            });
        }
        //获取好友用户名
        let userName = this.node.getChildByName('username');
        let namestr = userName.getComponent(cc.Label);
        namestr.string = name;
        //获取好友ID
        this.O_id.string = id;
        //玩家是否在线
        let onORout = this.O_onORout.spriteFrame;
        let onORoutGround = this.O_onORoutGround.spriteFrame;

        if (onORoutLine == 1) {
            this.O_onORout.spriteFrame = this.O_onORoutImg[0];
            this.O_onORoutGround.spriteFrame = this.O_onORoutGroundImg[0];
        } else if (onORoutLine == 0) {
            this.O_onORout.spriteFrame = this.O_onORoutImg[1];
            this.O_onORoutGround.spriteFrame = this.O_onORoutGroundImg[1];
        }

    },

    onDdzSiLiaoBtn: function(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        var siliaoNode = cc.instantiate(this.O_siliaoPrefab);
        var canNode = cc.director.getScene();
        siliaoNode.parent = canNode.getChildByName('Canvas');
        siliaoNode.setLocalZOrder(11);
        var siliaoScript = siliaoNode.getComponent('ui-DdzSiLiao');
        siliaoScript.initFunc(this._userID);
    },

    onDdzDuanJiaoBtn: function(event) {
        //断交按钮响应事件
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        let idtoProt = {};
        idtoProt.userId = this.O_id.string;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SDeleteFriend, idtoProt);

    },

    onDdzShenQingBtn: function(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        //发送申请好友协议
        let idtoProt = {};
        idtoProt.userId = this.O_id.string;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SReqAddFriend, idtoProt);

        cc.log("======onDdzShenQingBtn========idtoProt========", idtoProt);

    },

    onDdzAcceptFriendBtn: function() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        let idtoProt = {};
        idtoProt.userId = this.O_id.string;
        idtoProt.accept = 1;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SAcceptFriend, idtoProt);

        cc.log("==========onDdzAcceptFriendBtn========idtoProt=======", idtoProt);

        let todetail = {};
        todetail.flag = 1;
        todetail.node = this.node;
        todetail.userId = this.O_id.string;
        this.node.emit("friend-button", todetail);
    },

    onDdzRefuseFriendBtn: function() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        let idtoProt = {};
        idtoProt.userId = this.O_id.string;
        idtoProt.accept = 0;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SAcceptFriend, idtoProt);

        cc.log("==========onDdzRefuseFriendBtn========idtoProt=======", idtoProt);
        let todetail = {};
        todetail.flag = 2;
        todetail.node = this.node;
        todetail.userId = this.O_id.string;
        this.node.emit("friend-button", todetail);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});