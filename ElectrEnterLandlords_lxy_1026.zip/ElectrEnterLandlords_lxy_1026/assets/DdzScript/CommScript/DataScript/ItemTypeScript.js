

let itemtypetab = {};
module.exports = itemtypetab;

itemtypetab[1001] = {"desc" :"金币",};
itemtypetab[1002] = {"desc" :"钻石",};
itemtypetab[1003] = {"desc" :"房卡",};
