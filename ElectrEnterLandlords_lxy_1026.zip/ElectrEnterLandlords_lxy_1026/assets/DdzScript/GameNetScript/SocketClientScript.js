

let SocketPack = require("SocketPackScript");
let lCreateDataBuffer = function(mainId, assistid, datatab){
    let toProt = {};
    toProt.M = mainId;
    toProt.A = assistid;
    if(datatab){
        if(typeof(datatab)=="object")
            toProt.D = datatab;
        else
            toProt.D = {datatab};
    }
    return toProt;
};
let lAnalysisDataBuffer = function(protDataTab){
    return [protDataTab.M, protDataTab.A, protDataTab.D];
};
let CONNECT_MACNUM = 3; //最多多少次连接不上就断开
let regCmdListenerTab = {};
module.exports = cc.Class({
    extends: cc.Node,
    
    properties: {
        _socketip : null,
        _socketport : null,
        _wshandler : null,
        _datalist : null,
        _packObj : null,
        _connCount : 0,
        _sendpack : null,
        _isHandShaked : false, //是否已经握手
        _connDoing : false,
        _isReconnect : false, //屏蔽回调函数时候有发送协议断线重连的动作
        ///////////////////////////////////////////////////
        onbegin : null, //开始链接
        onopen : null,  //连接成功，打开网络了
        //onerror : null, //连接失败，断开网络
        onclose : null, //连接关闭，一般处理了onclose就可以了
    },
    /////////////////////////////////////////////////////
    //发送命令数据包
    sendCommand(mainId, assistId, datatab, isReconn){
        let todata = lCreateDataBuffer(mainId, assistId, datatab);
        this.priSendData(todata, true);
    },
    regCommandListener(mainId, assistId, callback, target){
        if(assistId){
            if(!regCmdListenerTab[mainId]){
                regCmdListenerTab[mainId] = {};
            }
            regCmdListenerTab[mainId][assistId] = {callback, target};
        }else{
            regCmdListenerTab[mainId] = {callback, target};
        }
    },
    removeAllListener(){
        regCmdListenerTab = {};
    },
    //////////////////////////////////////////////////////////////////////////
    //清空发送缓存
    clearSendPack(bSend){
        if(this._sendpack && bSend){
            this.priSendData(this._sendpack, false);
        }
        this._sendpack = null;
    },

    getSocketIp(){
        return this._socketip;
    },
    getSocketPort(){
        return this._socketport;
    },
    setSocketIpPort(socketip, socketport){
        this._socketip = socketip;
        this._socketport = socketport;
    },
    getWebSocketUrl(){
        return "ws://" + this._socketip + ":" + this._socketport;
    },
    updateMessage(dt){
        //console.log("===========update===123========", dt);
        if(this._datalist && this._datalist.length>0){
            let ldata = this._datalist.shift();
            let anlytab = lAnalysisDataBuffer(ldata);
            let mainId = anlytab[0];
            let assistId = anlytab[1];
            let atachdata = anlytab[2];
            let tagetMTab = regCmdListenerTab[mainId];
            console.log("=====update==ldata======", ldata, anlytab, tagetMTab);
            if(tagetMTab){
                if(tagetMTab.callback){                    
                    tagetMTab.callback.call(tagetMTab.target, mainId, assistId, atachdata);
                        
                }else{
                    let targeATab = tagetMTab[assistId];
                    if(targeATab){
                        targeATab.callback.call(targeATab.target, mainId, assistId, atachdata);
                    }
                }
            }
            //if(this.onmessage) this.onmessage(data);
        }
    },
    initPack(){
        let self = this;
        if(this._packObj){
            return this._packObj.reset();
        }
        let sendfunc = function(data){
            let tpackmsg = self._packObj.packmsg(data);
            self._wshandler.send(tpackmsg);
        };
        let endfunc = function(){
            console.log("===========handshake=success==========", self._sendpack);
            self._isHandShaked = true;
            self._connCount = 0;
            if(self.onopen)self.onopen();
        };
        let checkpackfunc = function(data, size, bsend){
            console.log("=======checkpackfunc=========", data, size, bsend);
            if(bsend){
                return JSON.stringify(data);
            }else{
                return JSON.parse(data);
            }
        };
        this._packObj = new SocketPack(sendfunc, endfunc, checkpackfunc);
        this._connCount = 0;
        cc.director.getScheduler().unschedule(this.updateMessage, this);
        cc.director.getScheduler().schedule(this.updateMessage, this, 0);
    },
    closeNet(){
        if(this._wshandler){
            this._wshandler.onclose = null;
            this._wshandler.onmessage = null;
            this._wshandler.onerror = null;
            this._wshandler.onopen = null;
            this._wshandler.close();
        }
        if(!this._datalist) this._datalist = [];
        this._isHandShaked = false;
    },
    connect(socketip, socketport){
        if(socketip && socketport){
            this.setSocketIpPort(socketip, socketport);
        }
        console.log("=========connect========", this._socketip, this._socketport);
        
        cc.director.getScheduler().unschedule(this.priConnect, this);
        cc.director.getScheduler().schedule(this.priConnect, this, 0.1);
    },
    priConnect(){
        cc.log("===========priConnect====11=========");
        cc.director.getScheduler().unschedule(this.priConnect, this);
        this.initPack();
        this.closeNet();
        this._connCount += 1;
        ///////////////////////////////////////////////
        if(this._connCount<=1){ //第一次才开始，三次连接补上则结束
            if(this.onbegin) this.onbegin();
        }
        let self = this;
        let url = this.getWebSocketUrl();
        this._wshandler = new WebSocket(url);
        this._wshandler.binaryType = "arraybuffer";
        this._wshandler.onopen=function(evt){
            self._packObj.start();
        };
        cc.log("===========priConnect====22=========", url, this._wshandler);
        this._wshandler.onmessage = function(evt){
            console.log("====11==onmessage===", evt, evt.data);
            let toData = String.fromCharCode.apply(null, new Uint8Array(evt.data));
            
            //let toData = new TextDecoder('utf8').decode(toTempArray);//这种只能在web用
            //let toData = toTempArray.toString();
            //console.log("====22==onmessage===", toData);
            let tolistdata = self._packObj.unpackmsg(toData, 0, 0);
            console.log("=====unpack=========", tolistdata);
            if(tolistdata){
                self._datalist.push(tolistdata);
            }
        };
        this._wshandler.onerror = function(evt){
            console.log("===_wshandler===onerror===", evt, self._connCount);
            
        };
        this._wshandler.onclose = function(evt){
            console.log("======onclose===", evt);
            if(self._connCount>=CONNECT_MACNUM){
                if(self.onclose)self.onclose(self._connCount);
                self._connCount = 0;
            }else{
                self.connect();
            }
        };
    },
    //发送数据包
    priSendData(datatab, isPack){
        if(isPack){
            this._sendpack = this._packObj.packmsg(datatab);
        }else{
            this._sendpack = datatab;
        }       
        console.log("======priSendData===11===", this._sendpack, this._isHandShaked, this._wshandler.readyState);
        if(this._wshandler.readyState == WebSocket.CONNECTING) return ;
        if(this._wshandler.readyState != WebSocket.OPEN){
            this.connect();
            return ;
        }
        let ret = this._wshandler.send(this._sendpack);
        console.log("======priSendData===22===", ret);
        this._sendpack = null;
    },
});

