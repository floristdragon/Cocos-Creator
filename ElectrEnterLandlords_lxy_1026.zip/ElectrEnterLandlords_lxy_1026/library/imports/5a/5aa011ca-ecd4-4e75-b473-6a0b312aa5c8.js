"use strict";
cc._RF.push(module, '5aa01HK7NROdbRzagsxKqXI', 'ui-ErRenDouDiZhuGameResult');
// DdzScript/GameLogicScript/ErRenDdzScript/ui-ErRenDouDiZhuGameResult.js

"use strict";

var nativeExtend = require("native-extendScript");
cc.Class({
    extends: cc.Component,

    properties: {
        O_giveuptip: cc.Node,
        O_winnode: cc.Node,
        O_lossnode: cc.Node,

        O_winAniNode: cc.Node,
        O_lossAniNode: cc.Node,
        O_springAniNode: cc.Node,
        O_jiesuannode: cc.Node,

        O_zongbeishulabel: cc.Label,
        O_qiangdzlabel: cc.Label,
        O_dipailabel: cc.Label,
        O_zhadanlabel: cc.Label,
        O_chuntianlabel: cc.Label,
        O_rangxianlabel: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        this._showResultFunc(false);
    },
    _showResultFunc: function _showResultFunc(isVisible, resultdata) {
        this.node.active = isVisible;
        if (!isVisible) {
            return;
        }
        var selfUserId = g_UserManager.getSelfUserIDFunc();
        var isGameWin = resultdata.winUserId == selfUserId;
        var isGiveUp = false;
        if (resultdata.giveupUserId && resultdata.giveupUserId != selfUserId) {
            isGiveUp = true; //对方主动认输
        }
        this.O_giveuptip.active = isGiveUp;
        this.O_winnode.active = isGameWin;
        this.O_lossnode.active = !isGameWin;

        this.O_lossAniNode.active = false;
        this.O_springAniNode.active = false;
        this.O_winAniNode.active = false;
        if (!isGameWin) {
            this.O_lossAniNode.active = true;
            this.O_lossAniNode.getComponent(cc.Animation).play();
        } else {
            if (resultdata.springBeiShu > 0) {
                this.O_springAniNode.active = true;
                this.O_springAniNode.getComponent(cc.Animation).play();
            } else {
                this.O_winAniNode.active = true;
                this.O_winAniNode.getComponent(cc.Animation).play();
            }
        }

        this.O_zongbeishulabel.string = "X" + resultdata.totalBeiShu;
        this.O_qiangdzlabel.string = "X" + resultdata.qiangdzBeiShu;
        this.O_dipailabel.string = "X" + resultdata.dipaiBeiShu;
        this.O_zhadanlabel.string = "X" + resultdata.zhadanBeiShu;
        this.O_chuntianlabel.string = "X" + resultdata.springBeiShu;
        this.O_rangxianlabel.string = "X0";

        this.O_jiesuannode.active = true;
        this.O_jiesuannode.opacity = 0;
        this.O_jiesuannode.runAction(cc.sequence(cc.delayTime(1.0), cc.fadeIn(0.5)));
    },

    onDdzExitGameBtn: function onDdzExitGameBtn(event) {
        this._showResultFunc(false);
        var toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIDFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIDFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqLeaveDesk, toProtTab);
    },
    onDdzShareBtn: function onDdzShareBtn(event) {
        nativeExtend.screenShoot(function (path, w, h) {
            nativeExtend.shareImageNative("image", path, "");
        });
    },
    onDdzContinueBtn: function onDdzContinueBtn(event) {
        this._showResultFunc(false);

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SReady);
    }
});

cc._RF.pop();