"use strict";
cc._RF.push(module, '2c314GD1DhGiJCMDUSZrvge', 'ui-DdzLobbyRankLine');
// DdzScript/GameLogicScript/LobbyScript/ui-DdzLobbyRankLine.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        starsFrame: [cc.SpriteFrame],
        star: cc.Sprite,
        numFrame: [cc.SpriteFrame],
        num: cc.Label,
        headImg: cc.Sprite,
        playerName: cc.Label,
        winCount: cc.Label,

        _headImg: null
    },

    // use this for initialization
    initFunc: function initFunc(list) {

        this.star.node.active = false;
        cc.log("============ui-PHBcontent======initFunc======", list);

        this._headImg = list.headurl;
        var self = this;

        if (this._headImg && this._headImg.length > 0) {
            cc.loader.load({ type: 'png', url: this._headImg }, function (err, texture) {
                if (!err) {
                    self.headImg.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
        if (list.rank && list.rank < 4) {
            this.star.node.active = true;
            this.star.spriteFrame = this.starsFrame[list.rank - 1];
            this.num.spriteFrame = this.numFrame[list.rank - 1];
            // this.num.getComponent(cc.Label).string = "";
        }
        //this.headImg.spriteFrame = playerInfo.headImg;
        if (list.weekWin == null) list.weekWin = 0;
        this.winCount.string = list.weekWin;
        this.playerName.string = list.userName;
        this.num.string = list.rank;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();