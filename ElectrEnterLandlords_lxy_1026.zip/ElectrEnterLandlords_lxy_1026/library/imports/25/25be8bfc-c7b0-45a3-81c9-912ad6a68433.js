"use strict";
cc._RF.push(module, '25be8v8x7BFo4HJkSrWpoQz', 'ui-DdzRoomScene');
// DdzScript/GameUIScript/ui-DdzRoomScene.js

"use strict";

//用户进入房间
function _lonProtEnterRoomFunc(mainId, assistId, protTab) {
    //进入房间
    cc.log("==============_lonProtEnterRoomFunc==================", protTab, g_GameScene.onRecvEnterRoomFunc);
    var gameId = protTab.info.gameId;
    var roomId = protTab.info.roomId;
    var roominfo = g_RoomManager.newRoomInfoFunc(gameId, roomId);
    roominfo.setPackageInfoFunc(protTab.info);
    if (g_GameScene.onRecvEnterRoomFunc) {
        g_GameScene.onRecvEnterRoomFunc(gameId, roomId, protTab.userId);
    }
}

function _lonProtGameStatusFunc(mainId, assistId, protTab) {
    //场景协议
    if (g_GameScene.onRecvGameStatusFunc) {
        g_GameScene.onRecvGameStatusFunc(protTab);
    }
}

function _lonProtJieSanDeskFunc(mainId, assistId, protTab) {
    //解散
    cc.log("======_lonProtJieSanDeskFunc==========", mainId, assistId, protTab);
    if (g_GameScene.onRecvJieSanDeskFunc) {
        g_GameScene.onRecvJieSanDeskFunc(protTab.gameId, protTab.roomId, protTab.userId, protTab.userName, protTab.isauto);
    }
}

function _lonProtLeaveDeskFunc(mainId, assistId, protTab) {
    //离开房间
    cc.log("======_lonProtLeaveDeskFunc==========", mainId, assistId, protTab);
    if (g_GameScene.onRecvLeaveDeskFunc) g_GameScene.onRecvLeaveDeskFunc(protTab.gameId, protTab.roomId, protTab.userId);
}

function _lonProtCheckSignInFunc(mainId, assistId, protTab) {
    //短线检测登陆
    cc.log("========_lonProtCheckSignInFunc=========");
    g_NetManager.clearSendPack(true);
}
//提示有信息操作


cc.Class({
    extends: require("ui-DdzBaseScene"),

    properties: {
        _mmgamechatscript: null,
        _mmisInRoomChat: false,

        _mmChatMsgList: [],
        O_chatPrefab: cc.Prefab,

        //////////////////////////////////////////////////////Tips
        O_chatTipsNode: cc.Node,
        O_friendsTipsNode: cc.Node,
        O_mailsTipsNode: cc.Node,
        O_zhanjiTipsNode: cc.Node,
        _chatTips: null,
        _friendsTis: null,
        _mailsTips: null,
        _zhanjiTips: null
    },

    // use this for initialization
    onLoad: function onLoad() {
        var _this = this;

        this._super(); //调用父类的onLoad
        console.log("=========roomscene=onLoad=============");
        var self = this;
        g_NetManager.onopen = function () {
            console.log("======roomscene===g_NetManager.onopen=============");
            self.showLoadFlowerFunc(false);
            //test
            // 检测登陆信息, 短线重连
            var logintab = g_ConfigManager.getLoginAccountFunc();
            var accName = logintab[0];
            var accPwd = logintab[1];
            if (!accName || !accPwd) {
                self.showPopupWindowFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_LOGIN_REDO_LOGIN"), function (flag) {
                    self.runStartSceneFunc();
                });
            } else {
                var protTab = {};
                protTab.accName = accName;
                protTab.accPwd = accPwd;
                protTab.platform = 0;
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_C2SCheckSignIN, protTab);
            }
        };
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqEnterDesk, _lonProtEnterRoomFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CGameStatus, _lonProtGameStatusFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqJieSanDesk, _lonProtJieSanDeskFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqLeaveDesk, _lonProtLeaveDeskFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_S2CCheckSignIN, _lonProtCheckSignInFunc);

        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2CSendChatMsg, function (mid, pid, protTab) {
            if (_this._mmgamechatscript) {
                _this._mmgamechatscript.addChatMsgFunc(protTab);
                _this._mmChatMsgList = [];
            } else {
                _this._mmChatMsgList.push(protTab);
            }
        }, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2CNoticePoint, this._onProtNoticePointFunc, this);
    },

    //////////////////////////////////////////////////////////////////
    onBaseGameFinishFunc: function onBaseGameFinishFunc(gameId, roomId) {
        var roominfo = g_RoomManager.getGameRoomInfoFunc(gameId, roomId);
        var toJuShu = roominfo.getCurJuShuFunc();
        if (toJuShu > 0) {
            roominfo.setCurJuShuFunc(toJuShu + 1);
        }
    },

    //提示有信息操作
    _onProtNoticePointFunc: function _onProtNoticePointFunc(mainId, assistId, protTab) {
        cc.log("=====_onProtNoticePointFunc========protTab======", protTab);
        var tipsNode = this.node.getChildByName('nodeTips');
        tipsNode.setLocalZOrder(9);
        this._chatTips = protTab[g_ProtDef.MID_Protocol_Broadcast];
        this._friendsTis = protTab[g_ProtDef.MID_Protocol_Friend];
        this._mailsTips = protTab[g_ProtDef.MID_Protocol_MailBox];
        this._zhanjiTips = protTab[g_ProtDef.MID_Protocol_ZhanJi];

        if (this._chatTips) {
            this.O_chatTipsNode.active = true;
        } else {
            this.O_chatTipsNode.active = false;
        }

        if (this._friendsTis) {
            this.O_friendsTipsNode.active = true;
        } else {
            this.O_friendsTipsNode.active = false;
        }

        if (this._mailsTips) {
            this.O_mailsTipsNode.active = true;
        } else {
            this.O_mailsTipsNode.active = false;
        }

        if (this._zhanjiTips) {
            this.O_zhanjiTipsNode.active = true;
        } else {
            this.O_zhanjiTipsNode.active = false;
        }
    },
    onDdzChatPanelBtn: function onDdzChatPanelBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.O_chatTipsNode.active = false;
        //聊天协议
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SReqChatMsg);

        var isfirstinit = false;
        if (!this._mmgamechatscript) {
            var talkNode = cc.instantiate(this.O_chatPrefab);

            talkNode.parent = this.node;
            if (this._mmisInRoomChat) {
                talkNode.setLocalZOrder(150);
            } else {
                talkNode.setLocalZOrder(10);
            }

            this._mmgamechatscript = talkNode.getComponent('ui-DdzGameChat');
            isfirstinit = true;
        }
        this.setChatRoomStateFunc(this._mmisInRoomChat);
        this._mmgamechatscript.showSiLiaoTipsFunc(this._chatTips);
        if (this._mmisInRoomChat) {
            this._mmgamechatscript.hideSiLiaoTipsFunc(false);
        }
        this._mmgamechatscript.openChatViewFunc();

        if (isfirstinit) {
            for (var i = 0; i < this._mmChatMsgList.length; i++) {
                this._mmgamechatscript.addChatMsgFunc(this._mmChatMsgList[i]);
            }
        }
    },
    setChatRoomStateFunc: function setChatRoomStateFunc(isRoom) {
        this._mmisInRoomChat = isRoom;
        if (this._mmgamechatscript) this._mmgamechatscript.setRoomChatStateFunc(isRoom);
    }
});

cc._RF.pop();