"use strict";
cc._RF.push(module, '334189/3Z5DA5QpGUfzNrdQ', 'ui-DdzSiLiao');
// DdzScript/GameLogicScript/LobbyScript/ui-DdzSiLiao.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_editBox: cc.EditBox,
        O_chatLinePrefab: cc.Prefab,
        O_toUserId: cc.Label,

        _toUserId: 0

    },

    onDdzCloseBtn: function onDdzCloseBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.node.active = false;
    },

    initFunc: function initFunc(toUserid) {
        //
        //this._scrollScript = this.scrollViewNode.getComponent("ui-DdzScrollView');
        this.O_toUserId.string = toUserid;
        this._toUserId = toUserid;
    },

    onDdzSendBtn: function onDdzSendBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        if (g_GameScene.rejectClickEventFunc(3)) return;
        var userstr = this.O_editBox.string;
        this.O_editBox.string = "";

        //发送协议
        var toChattab = {};
        toChattab.toUserId = this._toUserId;
        toChattab.ctype = 4;
        toChattab.content = userstr;
        toChattab.msgtype = 3;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SSendChatMsg, toChattab);

        cc.log("========onDdzSendBtn=========toChattab==========", toChattab);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();