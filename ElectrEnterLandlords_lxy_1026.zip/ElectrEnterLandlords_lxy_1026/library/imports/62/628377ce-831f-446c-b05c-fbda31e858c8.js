"use strict";
cc._RF.push(module, '62837fOgx9EbLBc+9ox6FjI', 'ui-DdzLobbyZhanJiLine');
// DdzScript/GameLogicScript/LobbyScript/ui-DdzLobbyZhanJiLine.js

"use strict";

var gameconfig = require("GameConfigScript");
cc.Class({
    extends: cc.Component,

    properties: {
        O_gameidlabel: cc.Label,
        O_roomidlabel: cc.Label,
        O_timelabel: cc.Label,

        _userdatalist: null
    },

    setDataFunc: function setDataFunc(gameid, roomid, jushu, stime, userlist) {
        // this.O_gameidlabel.string = gameconfig[parseInt(gameid)].desc;
        this.O_gameidlabel.string = "二人斗地主";
        this.O_roomidlabel.string = roomid + "-" + jushu;
        this._userdatalist = userlist;
        var date = new Date(stime * 1000);
        var extTimeFunc = function extTimeFunc(time) {
            if (time < 10) return "0" + time;
            return time + "";
        };
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        this.O_timelabel.string = ' ' + year + "/" + extTimeFunc(month) + "/" + extTimeFunc(date.getDate()) + "-" + extTimeFunc(date.getHours()) + ":" + extTimeFunc(date.getMinutes()) + ' ';
    },
    onDdzClickBtn: function onDdzClickBtn() {
        cc.log("=======onDdzClickBtn========", this._userdatalist);
        if (this._userdatalist) {
            this.node.emit("zhanjiline-event", this._userdatalist);
        }
    }
});

cc._RF.pop();