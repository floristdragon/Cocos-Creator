"use strict";
cc._RF.push(module, '46650cWzOBMD40gZwhwz7SP', 'ui-DdzLobbyCurrentRoom');
// DdzScript/GameLogicScript/LobbyScript/ui-DdzLobbyCurrentRoom.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_curroomlineprefab: cc.Prefab,
        O_scrollviewnode: cc.Node,

        _scrollviewscript: null,

        O_rulePrefab: cc.Prefab,
        O_settingPrefab: cc.Prefab
    },

    onLoad: function onLoad() {
        this._scrollviewscript = this.O_scrollviewnode.getComponent("ui-DdzScrollView");
    },


    // use this for initialization
    addOneRoomRecordFunc: function addOneRoomRecordFunc(gameId, roomId, curjushu, maxjushu) {
        cc.log("=====addOneRoomRecordFunc========", gameId, roomId, curjushu, maxjushu);
        var croomlinenode = cc.instantiate(this.O_curroomlineprefab);
        var croomlinescript = croomlinenode.getComponent("ui-DdzLobbyCurrentRoomLine");
        croomlinescript.setDataFunc(gameId, roomId, curjushu, maxjushu);
        this._scrollviewscript.addScrollNodeFunc(croomlinenode);
    },
    onDdzRuleClickBtn: function onDdzRuleClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        var ruleNode = cc.instantiate(this.O_rulePrefab);
        ruleNode.setLocalZOrder(10);
        ruleNode.parent = this.node;
        var close = ruleNode.getChildByName('close');
        close.off("touchstart");
        close.on('touchstart', function (event) {
            g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
            ruleNode.active = false;
        });
    },
    onDdzSettingClickBtn: function onDdzSettingClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        var settingNode = cc.instantiate(this.O_settingPrefab);
        settingNode.parent = this.node;
        settingNode.setLocalZOrder(10);
    },


    onDdzCloseBtn: function onDdzCloseBtn() {
        this.node.destroy();
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();