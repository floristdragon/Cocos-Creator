"use strict";
cc._RF.push(module, '466eeYDTvxBrLd8MY9X98Hh', 'UserInfoScript');
// DdzScript/GameBaseScript/UserInfoScript.js

"use strict";

var UserInfoFunc = function UserInfoFunc(userid, username) {
    //私有变量定义在构造函数中，每次new时候都会新建
    this._userId = userid;
    this._userName = username;
    this._gold = 0;
    this._diamond = 0;
    this._ipaddr = ""; //ip
    this._isBoy = 1;
    this._headurl = "";
    this._platform = 0;
};
//静态函数, 只能通过类名访问，不能用new的对象访问,最好定义函数来访问
//UserInfoFunc.staticParam = "111111"; 
UserInfoFunc.prototype = {
    //共享变量或者共享函数定义在prototype中，所有new对象公用
    constructor: UserInfoFunc,
    /*
    示例: 
    showStatic(){
        console.log("=====showStatic=======", UserInfoFunc.staticParam, this._stparam);
    },
    setStaticValue(val){
        UserInfoFunc.staticParam = val;
        this._stparam = val; //若构造函数未明确定义的变量，则新建一个变量
    },
    */
    setUserInfoPackageFunc: function setUserInfoPackageFunc(infotab) {
        this._userId = infotab.userId;
        this._userName = infotab.userName;
        this._diamond = infotab.diamond;
        this._gold = infotab.gold;
        this._ipaddr = infotab.addr;
        this._headurl = infotab.headurl;
        this._platform = infotab.platform;
        this._isBoy = infotab.isBoy;
    },
    getUserIDFunc: function getUserIDFunc() {
        return this._userId;
    },
    getUserNameFunc: function getUserNameFunc() {
        return this._userName;
    },
    setUserNameFunc: function setUserNameFunc(name) {
        if (!name) name = "";
        this._userName = name;
    },
    setGoldFunc: function setGoldFunc(num) {
        if (!num) num = 0;
        this._gold = num;
    },
    getGoldFunc: function getGoldFunc() {
        return this._gold;
    },
    setDiamondFunc: function setDiamondFunc(num) {
        if (!num) num = 0;
        this._diamond = num;
    },
    getDiamondFunc: function getDiamondFunc() {
        return this._diamond;
    },
    getIpAddrFunc: function getIpAddrFunc() {
        return this._ipaddr;
    },
    setIpAddrFunc: function setIpAddrFunc(addr) {
        this._ipaddr = addr;
    },
    getHeadUrlFunc: function getHeadUrlFunc() {
        return this._headurl;
    },
    setHeadUrlFunc: function setHeadUrlFunc(headurl) {
        this._headurl = headurl;
    },
    getIsBoyFunc: function getIsBoyFunc() {
        return this._isBoy;
    },
    setIsBoyFunc: function setIsBoyFunc(isboy) {
        this._isBoy = isboy;
    },
    getLoginPlatformFunc: function getLoginPlatformFunc() {
        return this._platform;
    }
};

module.exports = UserInfoFunc;

cc._RF.pop();