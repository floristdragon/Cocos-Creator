"use strict";
cc._RF.push(module, '12ada8kkU5L5I3ghuV2r3a+', 'ItemManagerScript');
// DdzScript/GameBaseScript/ItemManagerScript.js

"use strict";

module.exports = {
    _allitemtab: {},
    updateItemFunc: function updateItemFunc(itemid, count) {
        itemid = parseInt(itemid);
        this._allitemtab[itemid] = count;
    },
    getItemFunc: function getItemFunc(itemid) {
        itemid = parseInt(itemid);
        return this._allitemtab[itemid];
    },
    getGoldFunc: function getGoldFunc() {
        return this._allitemtab[1001];
    }
};

cc._RF.pop();