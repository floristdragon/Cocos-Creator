"use strict";
cc._RF.push(module, '006a8/XbPVADoMF/owxvMan', 'ErRenDdzRuleLogic');
// DdzScript/GameLogicScript/ErRenDdzScript/LogicScript/ErRenDdzRuleLogic.js

"use strict";

var GameRuleData = require("ErRenDdzRuleData");
var GameRuleConfig = require("ErRenDdzRuleConfig");

module.exports = {
	//卡组1能否吃掉卡组2
	IsCardTab1CanEatCardTab2Func: function IsCardTab1CanEatCardTab2Func(cardTab1, cardTab2) {
		console.log("=====IsCardTab1CanEatCardTab2Func===11=======", cardTab1, cardTab2);
		if (!cardTab1 || cardTab1.length <= 0) return false;
		if (!cardTab2 || cardTab2.length <= 0) return true;
		var gamedata1 = new GameRuleData(cardTab1);
		var ctype1 = gamedata1.getSelfCardTypeFunc();
		if (ctype1 == GameRuleConfig.CardType.ErrorType) return false;
		var gamedata2 = new GameRuleData(cardTab2);
		var ctype2 = gamedata2.getSelfCardTypeFunc();
		console.log("=====IsCardTab1CanEatCardTab2Func===22=======", ctype1, ctype2);
		if (ctype1 != ctype2) {
			if (GameRuleConfig.IsType1CanEatType2Func(ctype1, ctype2)) return true;
			return false;
		}
		var eatcardtab1 = gamedata1.getCardTypeMinEatIdOrLinkCountFunc(ctype1);
		var eatcardtab2 = gamedata2.getCardTypeMinEatIdOrLinkCountFunc(ctype2);
		console.log("=====IsCardTab1CanEatCardTab2Func===33=======", eatcardtab1, eatcardtab2);
		if (!eatcardtab2) return true;
		if (!eatcardtab1) return false;

		return eatcardtab1[0] > eatcardtab2[0] && eatcardtab1[1] == eatcardtab2[1];
	},

	//获取卡组的类型
	getCardTabCardTypeFunc: function getCardTabCardTypeFunc(cardTab) {
		var gamedata = new GameRuleData(cardTab);
		return gamedata.getSelfCardTypeFunc();
	},

	//从手牌中获取能吃掉eatCardTab的卡组
	getOutTipCardTabFunc: function getOutTipCardTabFunc(handCardTab, eatCardTab) {
		console.log("=====getOutTipCardTabFunc===11=======", handCardTab, eatCardTab);
		var handdata = new GameRuleData(handCardTab);
		if (!eatCardTab || eatCardTab.length <= 0) {
			var tishitab = handdata.getMaxLengthCardTypeTabFunc();
			return GameRuleConfig.exchangeIndexToCardIdFunc(handCardTab, tishitab);
		}
		var eatdata = new GameRuleData(eatCardTab);
		var eattype = eatdata.getSelfCardTypeFunc();
		console.log("=====getOutTipCardTabFunc===22=======", eattype);
		var eatcardtab = eatdata.getCardTypeMinEatIdOrLinkCountFunc(eattype);
		console.log("=====getOutTipCardTabFunc===33=======", eatcardtab);
		if (!eatcardtab) return [];
		var tishiTab = handdata.getEatCardTypeCardTabFunc(eattype, eatcardtab[0], eatcardtab[1]);
		console.log("=====getOutTipCardTabFunc===44=======", tishiTab);
		return GameRuleConfig.exchangeIndexToCardIdFunc(handCardTab, tishiTab);
	}
};

cc._RF.pop();