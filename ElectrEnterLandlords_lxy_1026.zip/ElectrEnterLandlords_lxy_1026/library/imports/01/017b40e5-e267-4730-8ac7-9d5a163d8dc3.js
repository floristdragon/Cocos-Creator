"use strict";
cc._RF.push(module, '017b4Dl4mdHMIrHnVoWPY3D', 'ui_DdzChat_UserInfo');
// DdzScript/GameUIScript/ui_DdzChat_UserInfo.js

"use strict";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

cc.Class(_defineProperty({
    extends: cc.Component,

    properties: {
        O_userId: cc.Label,
        O_siliaoPrefab: cc.Prefab
    },

    // use this for initialization
    initFunc: function initFunc(userId) {
        this.O_userId.string = userId;
    },

    onDdzCloseBtn: function onDdzCloseBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.node.active = false;
    },

    onDdzShenQingBtn: function onDdzShenQingBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        //发送申请好友协议
        var idtoProt = {};
        idtoProt.userId = this.O_userId.string;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SReqAddFriend, idtoProt);

        cc.log("======onDdzShenQingBtn========idtoProt========", idtoProt);
    },

    onDdzSiLiaoBtn: function onDdzSiLiaoBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.node.active = false;
        var siliaoNode = cc.instantiate(this.O_siliaoPrefab);
        var canNode = cc.director.getScene();
        siliaoNode.parent = canNode.getChildByName('Canvas');
        siliaoNode.setLocalZOrder(11);
        var siliaoScript = siliaoNode.getComponent('ui-DdzSiLiao');
        siliaoScript.initFunc(this.O_userId.string);
    }

}, "onDdzCloseBtn", function onDdzCloseBtn() {
    this.node.destroy();
}));

cc._RF.pop();