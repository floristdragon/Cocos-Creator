"use strict";
cc._RF.push(module, '3db43RDcmFDLr2LdHnXDHkp', 'ui-DdzLobbyMessage');
// DdzScript/GameLogicScript/LobbyScript/ui-DdzLobbyMessage.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        messageLabel: cc.Label
    },

    // use this for initialization
    initFunc: function initFunc(message) {
        if (message) {
            this.messageLabel.string = message;
        }
    },

    onDdzCloseClickBtn: function onDdzCloseClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();