"use strict";
cc._RF.push(module, '6c4c7JZWm1FFY0IDm+lN87Q', 'ui-DdzLobbyActivity');
// DdzScript/GameLogicScript/LobbyScript/ui-DdzLobbyActivity.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        label: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {},

    onDdzCloseClickBtn: function onDdzCloseClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();