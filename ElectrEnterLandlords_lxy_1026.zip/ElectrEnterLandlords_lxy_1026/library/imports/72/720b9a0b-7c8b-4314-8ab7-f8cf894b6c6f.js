"use strict";
cc._RF.push(module, '720b9oLfItDFIq3+M+JS2xv', 'ui-DdzLobbyFriends');
// DdzScript/GameLogicScript/LobbyScript/ui-DdzLobbyFriends.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {

        O_friendsLayer: cc.Node,
        O_addFriendsLayer: cc.Node,
        O_applyLayer: cc.Node,
        O_addFriendContent: cc.Node,
        O_manLayer: cc.Node,
        O_shenqingTipsNode: cc.Node,

        //玩家本人信息
        O_headImg: cc.Sprite,
        O_userName: cc.Label,
        O_userID: cc.Label,

        O_searchEditbox: cc.EditBox,

        O_curFriendsCount: cc.Label,
        O_curApplyNum: cc.Label,
        O_limitFriendNum: cc.Label,

        O_friendsLinePrefab: cc.Prefab,
        O_addFriendsLinePrefab: cc.Prefab,
        O_otherApplyFriendPrefab: cc.Prefab,

        O_roomToggle: cc.Toggle,

        _isOnline: null,

        _friendLayerScorllScript: null,
        _applyLayerScorllScript: null,

        _ftabList: [],
        _reqtabList: []
    },

    // use this for initialization
    onLoad: function onLoad() {
        //接收协议显示好友人数
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_S2CQueryFriend, this._onProtQueryAllFriendEventFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_S2CQueryUser, this._onProtQueryUserEventFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_S2CDeleteFriend, this.onProtDeleteFriendFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_S2CLoginStatus, this._onProtLoginStatusFunc, this);

        this.O_curFriendsCount.string = 0;
        this.O_curApplyNum.string = 0;
        this.O_limitFriendNum.string = 0;

        var userInfo = g_UserManager.getSelfUserInfoFunc();
        this.O_userID.string = userInfo.getUserIDFunc();
        this.O_userName.string = userInfo.getUserNameFunc();
        var headImgUrl = userInfo.getHeadUrlFunc();

        var headImg = this.O_headImg.spriteFrame;
        if (headImgUrl && headImgUrl.length > 0) {
            var imgType = "png";
            if (headImgUrl.indexOf(".jpg")) {
                imgType = "jpg";
            }

            cc.loader.load({ type: imgType, url: headImgUrl }, function (err, texture) {
                if (!err) {
                    headImg = new cc.SpriteFrame(texture);
                }
            });
        }

        this._friendLayerScorllScript = this.O_friendsLayer.getChildByName('scrollView').getComponent('ui-DdzScrollView');
        cc.log("==========this._friendLayerScorllScript========", this._friendLayerScorllScript);
        this._friendLayerScorllScript.setHeightInterFunc(10);
        this._applyLayerScorllScript = this.O_applyLayer.getChildByName('scrollView').getComponent('ui-DdzScrollView');
        this._applyLayerScorllScript.setHeightInterFunc(10);
    },

    openFriendsViewFunc: function openFriendsViewFunc() {
        this.node.active = true;
        if (this.O_roomToggle.isChecked) {
            this.O_shenqingTipsNode.active = false;
        }
    },


    onDdzToggleFriendsBtn: function onDdzToggleFriendsBtn(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.O_friendsLayer.active = true;
        this.O_addFriendsLayer.active = false;
        this.O_applyLayer.active = false;

        this.O_addFriendContent.removeAllChildren();
    },

    onDdzToggleAddFriendBtn: function onDdzToggleAddFriendBtn(event) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.O_friendsLayer.active = false;
        this.O_addFriendsLayer.active = true;
        this.O_applyLayer.active = false;

        this.O_addFriendContent.removeAllChildren();
    },

    onDdzToggleApplyBtn: function onDdzToggleApplyBtn(event) {
        this.O_shenqingTipsNode.active = false;
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        //别人申请成为玩家本人的好友

        this.O_friendsLayer.active = false;
        this.O_addFriendsLayer.active = false;
        this.O_applyLayer.active = true;

        this.O_addFriendContent.removeAllChildren();
        if (this.O_curApplyNum.string == 0) {
            this.O_manLayer.active = true;
            this._applyLayerScorllScript.clearAllNodeFunc();
        }
    },
    onDdzFriendBtnEvent: function onDdzFriendBtnEvent(detail) {
        cc.log("====onDdzFriendBtnEvent======", detail);
        this._applyLayerScorllScript.rmScrollNodeFunc(detail.node);
        this.O_curApplyNum.string = this._applyLayerScorllScript.getListSizeFunc();

        var toReqList = [];
        if (detail.flag == 2) {
            for (var i = 0; i < this._reqtabList.length; i++) {

                if (detail.userId != this._reqtabList[i].userId) {
                    toReqList.push(this._reqtabList[i]);
                }
            }
            this._reqtabList = toReqList;
        }
    },

    ///////////////////////////////////////////////////////////////////////
    _onProtLoginStatusFunc: function _onProtLoginStatusFunc(mainId, assistId, protTab) {

        //this._isOnline = protTab.online;
    },

    _onProtQueryAllFriendEventFunc: function _onProtQueryAllFriendEventFunc(mainId, assistId, protTab) {
        var _this = this;

        if (protTab.limit) {
            this.O_limitFriendNum.string = protTab.limit;
        }

        //this.O_content.removeAllChildren();
        cc.log("====ui-DdzLobbyFriends.js=======_onProtQueryAllFriendEventFunc======protTab======", protTab);
        //获取玩家好友数量
        //初始化好友列表
        if (protTab.ftab && protTab.ftab.length > 0) {
            for (var i = 0; i < protTab.ftab.length; i++) {
                var isalreadyin = false;
                for (var j = 0; j < this._ftabList.length; j++) {
                    if (protTab.ftab[i].userId == this._ftabList[j].userId) {
                        isalreadyin = true;
                        break;
                    }
                }
                if (!isalreadyin) this._ftabList.push(protTab.ftab[i]);
            }
        }
        //初始化申请列表
        //this._reqtabList = [];
        if (protTab.reqtab && protTab.reqtab.length > 0) {
            for (var _i = 0; _i < protTab.reqtab.length; _i++) {
                var _isalreadyin = false;
                for (var _j = 0; _j < this._reqtabList.length; _j++) {
                    if (protTab.reqtab[_i].userId == this._reqtabList[_j].userId) {
                        _isalreadyin = true;
                        break;
                    }
                }

                if (!_isalreadyin) this._reqtabList.push(protTab.reqtab[_i]);
            }
        }
        //删掉在好友列表里面存在得好友
        var toReqList = [];
        for (var _i2 = 0; _i2 < this._reqtabList.length; _i2++) {
            var _isalreadyin2 = false;
            for (var _j2 = 0; _j2 < this._ftabList.length; _j2++) {
                if (this._ftabList[_j2].userId == this._reqtabList[_i2].userId) {
                    _isalreadyin2 = true;
                    break;
                }
            }
            if (!_isalreadyin2) toReqList.push(this._reqtabList[_i2]);
        }
        this._reqtabList = toReqList;
        cc.log("=========this is friendList=========", this._ftabList, this._reqtabList);
        //初始化UI
        this._friendLayerScorllScript.clearAllNodeFunc();
        for (var _i3 = 0; _i3 < this._ftabList.length; _i3++) {
            var fdata = this._ftabList[_i3];

            var headUrl = fdata.headurl;
            var name = fdata.userName;
            var id = fdata.userId;
            var onORoutline = fdata.online;

            var newFriend = cc.instantiate(this.O_friendsLinePrefab);
            newFriend.off("friend-button");
            newFriend.on("friend-button", function (event) {
                _this.onDdzFriendBtnEvent(event.detail);
            }, this);
            var newFriendScript = newFriend.getComponent('ui-DdzLobbyFriendsLine');

            newFriendScript.initFunc(headUrl, name, id, onORoutline);
            var nodedata = {};
            nodedata.userId = fdata.userId;
            nodedata.online = fdata.online;
            if (!nodedata.online) nodedata.online = 0;
            this._friendLayerScorllScript.addScrollNodeFunc(newFriend, null, nodedata);
        }
        this._friendLayerScorllScript.sortAllNodeListFunc(function (a, b) {
            if (a.online > b.online) return -1; //表示要交换
            return 1; //不用交换
        });
        this._applyLayerScorllScript.setMoveAddNodeFunc(true);
        this._applyLayerScorllScript.clearAllNodeFunc();
        for (var _i4 = 0; _i4 < this._reqtabList.length; _i4++) {
            var toReqData = this._reqtabList[_i4];

            var _headUrl = toReqData.headurl;
            var _name = toReqData.userName;
            var _id = toReqData.userId;
            var _onORoutline = toReqData.online;

            var _newFriend = cc.instantiate(this.O_otherApplyFriendPrefab);
            _newFriend.off("friend-button");
            _newFriend.on("friend-button", function (event) {
                _this.onDdzFriendBtnEvent(event.detail);
            }, this);
            var _newFriendScript = _newFriend.getComponent('ui-DdzLobbyFriendsLine');

            _newFriendScript.initFunc(_headUrl, _name, _id, _onORoutline);
            this._applyLayerScorllScript.addScrollNodeFunc(_newFriend, null, _onORoutline);
        }
        cc.log("======_onProtQueryAllFriendEventFunc==O_curApplyNum==========", this.O_curApplyNum);
        this.O_manLayer.active = false;
        this.O_curFriendsCount.string = this._friendLayerScorllScript.getListSizeFunc();
        this.O_curApplyNum.string = this._applyLayerScorllScript.getListSizeFunc();
        if (this.O_curApplyNum.string == 0) {
            this.O_manLayer.active = true;
        }
    },
    _onProtQueryUserEventFunc: function _onProtQueryUserEventFunc(mainId, assistId, protTab) {
        cc.log("====ui-DdzLobbyFriends.js=======_onProtQueryUserEventFunc======protTab======", protTab);
        //获取好友信息
        var friends = protTab.info;

        var headUrl = friends.headurl;
        var name = friends.userName;
        var id = friends.userId;
        var onORoutline = friends.online;

        var newFriend = cc.instantiate(this.O_addFriendsLinePrefab);
        newFriend.setPositionX(0);
        newFriend.parent = this.O_addFriendContent;
        var newFriendScript = newFriend.getComponent('ui-DdzLobbyFriendsLine');

        newFriendScript.initFunc(headUrl, name, id, onORoutline);
    },

    onProtDeleteFriendFunc: function onProtDeleteFriendFunc(mainId, assistId, protTab) {

        var userid = protTab.userId;

        this._friendLayerScorllScript.rmScrollNodeByFunc(function (object) {
            if (object.userId == userid) {
                return 1;
            } else return 0;
        });
        var toflist = [];
        for (var i = 0; i < this._ftabList.length; i++) {
            if (this._ftabList[i].userId != userid) {
                toflist.push(this._ftabList[i]);
            }
        }
        this._ftabList = toflist;

        this.O_curFriendsCount.string -= 1;
    },

    onDdzSearchBtn: function onDdzSearchBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        //点击搜索时发送协议
        var searchId = this.O_searchEditbox.string;
        if (!searchId) return;
        var idtoProt = {};
        idtoProt.userId = searchId;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SQueryUser, idtoProt);
        cc.log("========onDdzSearchBtn=======idtoProt======", idtoProt);
        this.O_searchEditbox.string = "";

        this.O_addFriendContent.removeAllChildren();
    },

    showApplyTipsFunc: function showApplyTipsFunc(flag) {
        if (flag == 1) {
            this.O_shenqingTipsNode.active = true;
        }
    },

    onDdzCloseClickBtn: function onDdzCloseClickBtn() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        this.node.active = false;
        this.O_addFriendContent.removeAllChildren();

        this._applyLayerScorllScript.clearAllNodeFunc();
        this._friendLayerScorllScript.clearAllNodeFunc();

        this._ftabList = [];
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();