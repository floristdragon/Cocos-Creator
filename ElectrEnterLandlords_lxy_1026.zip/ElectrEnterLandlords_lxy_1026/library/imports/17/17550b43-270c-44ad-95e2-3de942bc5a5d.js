"use strict";
cc._RF.push(module, '17550tDJwxErZXiPelCvFpd', 'ui-ErRenDouDiZhuPokerCard');
// DdzScript/GameLogicScript/ErRenDdzScript/ui-ErRenDouDiZhuPokerCard.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_touchcard: cc.Node,
        O_pointnode: cc.Node,

        _cardValue: 0,
        _backPosition: null,
        _isMoveUp: false,
        _isMoveUpBack: false
    },

    // use this for initialization
    onLoad: function onLoad() {
        this._backPosition = new cc.Vec2(this.O_touchcard.position.x, this.O_touchcard.position.y);
        this._isMoveUp = false;
        this.showPointTipFunc(false);
    },
    setCardScaleFunc: function setCardScaleFunc(scale) {
        this.node.scale = scale;
    },
    setCardWidthFunc: function setCardWidthFunc(width) {
        this.node.width = width;
    },
    setCardHeightFunc: function setCardHeightFunc(height) {
        this.node.height = height;
    },
    showPointTipFunc: function showPointTipFunc(isVisible) {
        this.O_pointnode.active = isVisible;
    },
    setCardValueFunc: function setCardValueFunc(value, isRangpai) {
        var self = this;
        cc.log("========setCardValueFunc============", value, isRangpai);
        if (!value) value = -1;
        this._cardValue = value;
        var toSpUrl = void 0;
        if (isRangpai) {
            toSpUrl = g_ERDDZGameData.getRangPokerFramePathFunc(true);
        } else {
            toSpUrl = g_ERDDZGameData.getPokerFramePathFunc(true, this._cardValue, true);
        }
        var texture = cc.textureCache.addImage(toSpUrl);
        var toSprite = self.O_touchcard.getComponent(cc.Sprite);
        toSprite.spriteFrame = new cc.SpriteFrame(texture);
        // cc.loader.loadRes(toSpUrl, function(err, texture){
        //     toSprite.spriteFrame = new cc.SpriteFrame(texture);
        // });
    },
    getCardValueFunc: function getCardValueFunc() {
        return this._cardValue;
    },
    onUnTouchCardFunc: function onUnTouchCardFunc() {
        this._isMoveUpBack = this._isMoveUp;
        this._isTouchCard = false;
    },
    onChceckTouchFunc: function onChceckTouchFunc(touchPos, touchType) {
        if (touchType == 1) {
            return this._priTouchBeginFunc(touchPos);
        } else if (touchType == 2) {
            return this._priTouchMoveFunc(touchPos);
        } else if (touchType == 3) {
            return this._priTouchEndFunc(touchPos);
        }
    },
    isCardMoveUpFunc: function isCardMoveUpFunc() {
        return this._isMoveUp;
    },
    moveUpCardFunc: function moveUpCardFunc() {
        this._isMoveUp = true;
        this.O_touchcard.position = new cc.Vec2(this._backPosition.x, this._backPosition.y + 15);
    },
    moveDownCardFunc: function moveDownCardFunc(delay) {
        this._isMoveUp = false;
        var topos = new cc.Vec2(this._backPosition.x, this._backPosition.y);
        if (!delay) {
            this.O_touchcard.position = topos;
        } else {
            this.O_touchcard.runAction(cc.moveTo(delay, topos));
        }
    },

    ////////////////////////////////////////////////////////////////////////
    _isTouchInFunc: function _isTouchInFunc(touchPos) {
        var toPos = this.O_touchcard.convertToNodeSpace(touchPos);
        var toRect = new cc.Rect(0, 0, this.O_touchcard.width, this.O_touchcard.height);
        //cc.log("======_isTouchInFunc====111=====", toPos, toRect);
        if (toRect.contains(toPos)) {
            //cc.log("======_isTouchInFunc====222=====");
            return true;
        }
        return false;
    },
    _priTouchBeginFunc: function _priTouchBeginFunc(touchPos) {
        if (this._isTouchInFunc(touchPos)) {
            this._isMoveUpBack = this._isMoveUp;
            return true;
        }
        return false;
    },
    _priTouchMoveFunc: function _priTouchMoveFunc(touchPos) {
        if (this._isTouchInFunc(touchPos)) {
            if (this._isMoveUpBack != this._isMoveUp) return true;
            this._priMoveReverseCardFunc();
            return true;
        }
        this._isMoveUpBack = this._isMoveUp;
        return false;
    },
    _priTouchEndFunc: function _priTouchEndFunc(touchPos) {
        if (this._isTouchInFunc(touchPos)) {
            if (this._isMoveUpBack != this._isMoveUp) return true;
            this._priMoveReverseCardFunc();
            return true;
        }
        return false;
    },
    _priMoveReverseCardFunc: function _priMoveReverseCardFunc() {
        if (!this._isMoveUp) {
            this.moveUpCardFunc();
        } else {
            this.moveDownCardFunc();
        }
    }
});

cc._RF.pop();