"use strict";
cc._RF.push(module, '6e814CKKitH44C9/2wibNXb', 'ui-ErRenDouDiZhuHandCard');
// DdzScript/GameLogicScript/ErRenDdzScript/ui-ErRenDouDiZhuHandCard.js

"use strict";

var GameRuleLogic = require("ErRenDdzRuleLogic");
var GameRuleConfig = require("ErRenDdzRuleConfig");
cc.Class({
    extends: cc.Component,
    properties: {
        O_handcardprefab: cc.Prefab,
        O_outcardprefab: cc.Prefab,
        O_handCardSp: cc.Node,
        O_outCardSp: cc.Node,
        O_handCardNode: cc.Node,
        ///////////////////////////////////////////
        _seatNo: 0,
        _handCardSize: null,
        _outCardSize: null,
        _allCardArray: [],

        _tishiEatCardTab: [],
        _touchPreMoveUpNum: 0
    },
    // 尽量在onLoad来初始化界面，在initUI初始化和数据无关的变量
    onLoad: function onLoad() {
        cc.log("========handcard=========onLoad======================", this.O_handCardSp);
        this._handCardSize = new cc.Size(this.O_handCardSp.width, this.O_handCardSp.height);
        this.O_handCardSp.active = false;

        this._outCardSize = new cc.Size(this.O_outCardSp.width, this.O_outCardSp.height);
        this.O_outCardSp.getComponent(cc.Sprite).enabled = false;

        var self = this;
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_START, function (event) {
            //console.log("TOUCH_START");
            var touchPos = event.getLocation();
            self._priCheckTouchHandCardFunc(touchPos, 1);
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            //console.log("TOUCH_MOVE");
            var touchPos = event.getLocation();
            self._priCheckTouchHandCardFunc(touchPos, 2);
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_END, function (event) {
            //console.log("TOUCH_END");
            var touchPos = event.getLocation();
            self._priCheckTouchHandCardFunc(touchPos, 3);
        });
        // this.scheduleOnce(function(){
        //     let toCardTab = [22,140,150,24,23,21, 42,43, 44,41,63,61,62,34,73,82,83];
        //     toCardTab.sort((a, b)=>{
        //         if(a>b) return -1;
        //         return 1;
        //     })
        //     g_ERDDZGameData.setHandCardTabFunc(this._seatNo, toCardTab);
        //     ///g_ERDDZGameData.setCurOutCardTabFunc([31, 32, 33, 52, 53]);
        //     g_ERDDZGameData.removeCardTabFunc(this._seatNo, [63,61,62]);
        //     self.drawHandCardFunc(17);
        // }, 2);

        //let ret = GameRuleLogic.getCardTabCardTypeFunc([11,13,21,31,43,44,52,54]);
        //cc.log("=======GameRuleLogic.IsCardTab1CanEatCardTab2Func=========", ret);
    },

    //属于该句柄的seatNo，cardpos为手牌中心位置，cardWidth一张手牌的宽度
    initUIFunc: function initUIFunc(seatNo) {
        this._seatNo = seatNo;
    },
    resetUIFunc: function resetUIFunc() {
        this._clearHandCardFunc();
        this.clearOutCardFunc();
    },
    _clearHandCardFunc: function _clearHandCardFunc() {
        this.O_handCardNode.removeAllChildren(true);
        this._allCardArray = [];
    },
    clearOutCardFunc: function clearOutCardFunc() {
        this.O_outCardSp.removeAllChildren(true);
    },
    drawHandCardFunc: function drawHandCardFunc(numCard, isAllShow) {
        this._clearHandCardFunc();
        var handCardTab = g_ERDDZGameData.getHandCardTabFunc(this._seatNo);
        if (!handCardTab || handCardTab.length <= 0) return;
        if (!numCard || numCard > handCardTab.length) numCard = handCardTab.length;
        var beginPosX = 0;
        var beginPosY = 0;
        var toInterval = this._handCardSize.width / 2.5;
        beginPosX -= (numCard - 1) * toInterval / 2;
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        if (selfSeatNo != this._seatNo) {
            toInterval = this._handCardSize.width / 3.5;
        }
        var rangpaiNum = g_ERDDZGameData.getQiangRangNumFunc();
        if (this._seatNo == g_ERDDZGameData.getDiZhuSeatNoFunc()) {
            rangpaiNum = -1;
        }
        cc.log("========drawHandCardFunc=========", handCardTab, numCard, rangpaiNum);
        for (var i = 0; i < numCard; i++) {
            var topNode = cc.instantiate(this.O_handcardprefab);
            var toCardScript = topNode.getComponent("ui-ErRenDouDiZhuPokerCard"); //不能用var

            if (selfSeatNo == this._seatNo || isAllShow) {
                toCardScript.setCardValueFunc(handCardTab[i]);
            } else {
                var israngpai = false;
                if (i < rangpaiNum) {
                    israngpai = true;
                }
                toCardScript.setCardValueFunc(0, israngpai);
            }
            if (selfSeatNo != this._seatNo) {
                toCardScript.setCardScaleFunc(0.75);
            }
            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            //console.log("======drawHandCardFunc============", beginPosX, beginPosY);
            topNode.setLocalZOrder(i);
            beginPosX += toInterval;
            this._allCardArray.push(topNode);

            topNode.parent = this.O_handCardNode;
        }
        //按照zorder来从大到小排列，用于触摸
        this._allCardArray.reverse();
        console.log("===drawHandCardFunc====end==", this.O_handCardNode);
    },
    drawOutCardFunc: function drawOutCardFunc(outCardTab) {
        this.clearOutCardFunc();
        var numCard = outCardTab.length;
        cc.log("========drawOutCardFunc=========", outCardTab, numCard);
        var beginPosX = 0;
        var beginPosY = 0;
        var toInterval = this._outCardSize.width / 2.5;
        beginPosX -= (numCard - 1) * toInterval / 2;
        for (var i = 0; i < numCard; i++) {
            var topNode = cc.instantiate(this.O_outcardprefab);
            var toCardScript = topNode.getComponent("ui-ErRenDouDiZhuPokerCard"); //不能用var
            //cc.log("====drawOutCardFunc=======", this._seatNo, toCardScript);
            toCardScript.setCardValueFunc(outCardTab[i]);
            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            //console.log("======drawHandCardFunc============", beginPosX, beginPosY);
            topNode.setLocalZOrder(i);
            beginPosX += toInterval;

            topNode.parent = this.O_outCardSp;
        }
    },
    moveAddActionCardFunc: function moveAddActionCardFunc(actCardTab) {
        for (var j = 0; j < actCardTab.length; j++) {
            for (var i = 0; i < this._allCardArray.length; i++) {
                var cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
                if (!cardScript) return;
                if (!cardScript.isCardMoveUpFunc() && actCardTab[j] == cardScript.getCardValueFunc()) {
                    cardScript.moveUpCardFunc();
                    cardScript.moveDownCardFunc(1);
                    cardScript.showPointTipFunc(true);
                    break;
                }
            }
        }
    },
    moveTiShiHandCardFunc: function moveTiShiHandCardFunc(outCardTab) {
        cc.log("======moveTiShiHandCardFunc====11====", outCardTab);
        var handCardTab = g_ERDDZGameData.getHandCardTabFunc(this._seatNo);
        if (!handCardTab || handCardTab.length <= 0) return;
        var preTiShiLength = this._tishiEatCardTab.length;
        var isEat = GameRuleLogic.IsCardTab1CanEatCardTab2Func(this._tishiEatCardTab, outCardTab);
        if (!isEat) {
            cc.log("======moveTiShiHandCardFunc====22====");
            this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabFunc(handCardTab, outCardTab);
        } else {
            cc.log("======moveTiShiHandCardFunc====33====");
            this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabFunc(handCardTab, this._tishiEatCardTab);
            if (preTiShiLength > 0 && this._tishiEatCardTab.length <= 0) {
                this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabFunc(handCardTab, outCardTab);
            }
        }
        cc.log("======moveTiShiHandCardFunc====44====", isEat, preTiShiLength, this._tishiEatCardTab);
        this._priMoveUpCardTabFunc(this._tishiEatCardTab);
    },
    clearTiShiHandCardFunc: function clearTiShiHandCardFunc() {
        this._tishiEatCardTab = [];
    },
    getMoveUpCardTabFunc: function getMoveUpCardTabFunc(outCardTab) {
        var tab = [];
        for (var i = 0; i < this._allCardArray.length; i++) {
            var cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
            if (!cardScript) return;
            if (cardScript.isCardMoveUpFunc()) {
                tab.push(cardScript.getCardValueFunc());
            }
        }
        var ctype = GameRuleLogic.getCardTabCardTypeFunc(tab);
        if (ctype == GameRuleConfig.CardType.ErrorType) return;
        var isEat = GameRuleLogic.IsCardTab1CanEatCardTab2Func(tab, outCardTab);
        if (isEat) return tab;
    },


    //////////////////////////////////////////////////////////////////////////////////////////////
    _priMoveUpCardTabFunc: function _priMoveUpCardTabFunc(cardTab) {
        for (var i = 0; i < this._allCardArray.length; i++) {
            var cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
            if (!cardScript) return;
            cardScript.moveDownCardFunc();
        }
        for (var j = 0; j < cardTab.length; j++) {
            for (var _i = 0; _i < this._allCardArray.length; _i++) {
                var _cardScript = this._allCardArray[_i].getComponent("ui-ErRenDouDiZhuPokerCard");
                if (!_cardScript) return;
                if (!_cardScript.isCardMoveUpFunc() && cardTab[j] == _cardScript.getCardValueFunc()) {
                    _cardScript.moveUpCardFunc();
                    break;
                }
            }
        }
    },
    _priCheckTouchHandCardFunc: function _priCheckTouchHandCardFunc(touchPos, touchType) {
        if (touchType == 1) this._touchPreMoveUpNum = 0;
        var touchindex = -1;
        for (var i = 0; i < this._allCardArray.length; i++) {
            var cardScript = this._allCardArray[i].getComponent("ui-ErRenDouDiZhuPokerCard");
            if (!cardScript) return;
            if (cardScript.onChceckTouchFunc(touchPos, touchType)) {
                touchindex = i;
                break;
            }
        }
        var moveUpTab = [];
        for (var _i2 = 0; _i2 < this._allCardArray.length; _i2++) {
            var _cardScript2 = this._allCardArray[_i2].getComponent("ui-ErRenDouDiZhuPokerCard");
            if (!_cardScript2) return;
            if (_i2 != touchindex) {
                _cardScript2.onUnTouchCardFunc();
            }
            if (_cardScript2.isCardMoveUpFunc()) {
                moveUpTab.push(_cardScript2.getCardValueFunc());
            }
        }
    }
});

cc._RF.pop();