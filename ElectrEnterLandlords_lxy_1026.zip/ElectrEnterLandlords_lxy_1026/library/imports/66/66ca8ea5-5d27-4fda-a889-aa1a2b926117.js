"use strict";
cc._RF.push(module, '66ca86lXSdP2qiJqhorkmEX', 'mProtocolScript');
// DdzScript/CommScript/mProtocolScript.js

"use strict";

//游戏协议分成主协议和副协议
//主协议定义在这里，每个模块一个主协议
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
console.log("======require=====mProtocolScript==========");
var protdeftab = {};
module.exports = protdeftab;
var lrequire = function lrequire(file) {
    var rettab = require(file);
    for (var k in rettab) {
        protdeftab[k] = rettab[k];
    }
};

protdeftab.MID_Protocol_System = 1; //系统协议 
protdeftab.MID_Protocol_Errcode = 2; //错误码协议 
protdeftab.MID_Protocol_Active = 3; //心跳
protdeftab.MID_Protocol_Login = 100; //登陆协议
protdeftab.MID_Protocol_Item = 101; //物品协议
protdeftab.MID_Protocol_GM = 102; //GM命令协议
protdeftab.MID_Protocol_Lobby = 103; //大厅协议
protdeftab.MID_Protocol_Broadcast = 104; //公告协议, 聊天协议
protdeftab.MID_Protocol_Cluster = 105; //cluster协议
protdeftab.MID_Protocol_Rank = 106; //排行榜协议
protdeftab.MID_Protocol_MailBox = 107; //邮件邮箱协议
protdeftab.MID_Protocol_Friend = 108; //好友协议
protdeftab.MID_Protocol_ZhanJi = 109; //战绩协议


protdeftab.MID_Protocol_ErRenDDZ = 5001; //斗地主协议

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//包含对应的协议头文件
lrequire("ErrCodeScript");
lrequire("protItemScript");
lrequire("protLoginScript");
lrequire("protLobbyScript");
lrequire("protErRenDdzScript");
lrequire("protRankScript");
lrequire("protBroadcastScript");
lrequire("protMailBoxScript");
lrequire("protFriendScript");
lrequire("protZhanJiScript");

cc._RF.pop();