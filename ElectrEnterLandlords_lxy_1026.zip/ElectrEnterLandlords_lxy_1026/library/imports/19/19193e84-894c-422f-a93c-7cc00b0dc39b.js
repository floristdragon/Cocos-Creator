"use strict";
cc._RF.push(module, '191936EiUxCL6k8fMALDcOb', 'ui-ErRenDouDiZhuScene');
// DdzScript/GameLogicScript/ErRenDdzScript/ui-ErRenDouDiZhuScene.js

"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

require("ErRenDdzGameData");

var GameRuleLogic = require("ErRenDdzRuleLogic");
var STATUS_READY = 0; //准备
var STATUS_SENDCARD = 1; //发牌
var STATUS_QIANGDIZHU = 2; //抢地主
var STATUS_OUTCARD = 3; //出牌
var STATUS_GAMEFINISH = 4; //游戏结束
cc.Class({
    extends: require("ui-DdzRoomScene"),

    properties: {
        O_controlbtnprefab: cc.Prefab,
        O_gameresultprefab: cc.Prefab,

        O_userInfoPrefab: cc.Prefab,

        O_settingPrefab: cc.Prefab,

        //////////////////////////////////////
        _backgroundScipt: null,
        _ctlbuttonScript: null,
        _rangtipScript: null,
        _gameresultScript: null,
        _dispcardScript: null

    },

    // use this for initialization
    onLoad: function onLoad() {
        this._super(); //调用父类的onLoad
        this.setChatRoomStateFunc(true);
        //背景音乐
        g_ERDDZGameData.playBackgroundMusicFunc();

        var gameId = g_RoomManager.getCurGameIDFunc();
        var roomId = g_RoomManager.getCurRoomIDFunc();
        var selfUserId = g_UserManager.getSelfUserIDFunc();
        var roominfo = g_RoomManager.getGameRoomInfoFunc(gameId, roomId);

        var selfSeatNo = roominfo.findUserSeatNoFunc(selfUserId);
        g_ERDDZGameData.initFunc(gameId, roomId, selfSeatNo);
        cc.log("=======errenddz==mainscene=11====", gameId, roomId, selfUserId);

        //////////////////////////////////////////////////////////
        this._cplayerArray = [];
        var maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        var toSeatNo = selfSeatNo;
        for (var i = 0; i < maxPlayer; i++) {
            var playerNo = i + 1;
            var playerNode = this.node.getChildByName("player" + playerNo);
            playerNode.setLocalZOrder(100);
            console.log("=====111111=======", toSeatNo, selfSeatNo, playerNo);
            var cplayerhandler = playerNode.getComponent("ui-ErRenDouDiZhuPlayer");
            cplayerhandler.initUIFunc(toSeatNo, playerNode);
            g_ERDDZGameData.setPlayerUiFunc(cplayerhandler, i, toSeatNo);

            toSeatNo = g_ERDDZGameData.getNextSeatNoFunc(toSeatNo);
        };
        this._backgroundScipt = this.getComponent("ui-ErRenDouDiZhuBackground");
        this._backgroundScipt.showBaseTipFunc();

        this._rangtipScript = this.getComponent("ui-ErRenDouDiZhuRangTip");
        this._rangtipScript.showQiangDiZhuTipFunc(false);

        this._dispcardScript = this.getComponent("ui-ErRenDouDiZhuDispCard");
        cc.log("=========errenddz==mainscene====22====", this._dispcardScript);
        /////////////////////////////////////////////////////////////////
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_ErRenDDZ, null, this._onProtSocketMessageFunc, this);

        /////////////////////////////////////////////////////////////////
        //场景加载完毕，开始请求场景协议
        var toProtData = {};
        toProtData.gameId = g_ERDDZGameData.getGameIDFunc();
        toProtData.roomId = g_ERDDZGameData.getRoomIDFunc();
        cc.log("=========requestGameStatus===", toProtData);
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqGameStatus, toProtData);
    },
    onDestroyFunc: function onDestroyFunc() {
        cc.log("=============onDestroyFunc==============");
    },
    _resetAllUiFunc: function _resetAllUiFunc() {
        if (this._ctlbuttonScript) {
            this._getDdzControlBtn().hideDdzAllBtn();
        }
        if (this._gameresultScript) {
            this._getGameResultFunc()._showResultFunc(false);
        }
        g_ERDDZGameData.resetInitFunc();
        this._rangtipScript.hideAllTipFunc();
        this._backgroundScipt._showThreeBackCardFunc(false);
        this._backgroundScipt._showSmallBackCardFunc(false);
        this._backgroundScipt.showBaseTipFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoFunc();
        var maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        for (var i = 0; i < maxPlayer; i++) {
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
            playerui.resetUIFunc();

            var userinfo = roominfo.getUserInfoFunc(i);
            cc.log("======_resetAllUiFunc====111=======", i, userinfo);
            if (userinfo) {
                playerui.showUserInfoFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
            } else {
                playerui.showUserInfoFunc(false);
            }
        }
    },
    _requestGameReadyFunc: function _requestGameReadyFunc(delaytime) {
        var self = this;
        var _readyDdzFunc = function _readyDdzFunc() {
            //在这里进入房间后要发协议，自己默认进入房间就准备
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SReady);
        };
        if (!delaytime || delaytime <= 0) {
            _readyDdzFunc();
        } else {
            this.scheduleOnce(_readyDdzFunc, delaytime);
        }
    },
    onDdzSettingBtn: function onDdzSettingBtn(event) {
        var settingPlane = cc.instantiate(this.O_settingPrefab);
        this.node.addChild(settingPlane, 1000);
    },
    onDdzShowUserInfoPanel: function onDdzShowUserInfoPanel(node, detail) {
        cc.log("========onDdzShowUserInfoPanel=========", node, detail);
        var seatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        if (detail == 2) {
            seatNo = g_ERDDZGameData.getNextSeatNoFunc(seatNo);
        }
        var roominfo = g_ERDDZGameData.getRoomInfoFunc();
        if (roominfo.getUserInfoFunc(seatNo)) {
            var userInfoNode = cc.instantiate(this.O_userInfoPrefab);
            userInfoNode.parent = this.node;
            userInfoNode.setLocalZOrder(200);
            userInfoNode.getComponent("ui-ErRenDdzUserInfo").showInfoFunc(seatNo);
        }
    },

    //////////////////////////////////////////////////////////////////////////////
    _getDdzControlBtn: function _getDdzControlBtn() {
        var _this = this;

        if (!this._ctlbuttonScript) {
            var ctrbtn = cc.instantiate(this.O_controlbtnprefab);
            ctrbtn.parent = this.node;
            ctrbtn.setLocalZOrder(150);
            this._ctlbuttonScript = ctrbtn.getComponent("ui-ErRenDdzCtlButton");
            ctrbtn.off("outbtn-buchu");
            ctrbtn.off("outbtn-tishi");
            ctrbtn.off("outbtn-chupai");
            ctrbtn.on("outbtn-buchu", function (event) {
                _this._outCardBuChuFunc();
            }, this);
            ctrbtn.on("outbtn-tishi", function (event) {
                _this._outCardTiShiFunc();
            }, this);
            ctrbtn.on("outbtn-chupai", function (event) {
                _this._outCardChuPaiFunc();
            }, this);
        }
        return this._ctlbuttonScript;
    },
    _getGameResultFunc: function _getGameResultFunc() {
        if (!this._gameresultScript) {
            var resultnode = cc.instantiate(this.O_gameresultprefab);
            resultnode.parent = this.node;
            resultnode.setLocalZOrder(200);
            this._gameresultScript = resultnode.getComponent("ui-ErRenDouDiZhuGameResult");
        }
        return this._gameresultScript;
    },
    _outCardBuChuFunc: function _outCardBuChuFunc() {
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(selfSeatNo);
        playerui.getHandCardFunc().clearTiShiHandCardFunc();

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SBuChu);
    },
    _outCardTiShiFunc: function _outCardTiShiFunc() {
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        var outCardTab = g_ERDDZGameData.getCurOutCardTabFunc(true);
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(selfSeatNo);
        playerui.getHandCardFunc().moveTiShiHandCardFunc(outCardTab);
    },
    _outCardChuPaiFunc: function _outCardChuPaiFunc() {
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoFunc();
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(selfSeatNo);
        playerui.getHandCardFunc().clearTiShiHandCardFunc();
        var outCardTab = g_ERDDZGameData.getCurOutCardTabFunc(true);
        var outTab = playerui.getHandCardFunc().getMoveUpCardTabFunc(outCardTab);
        if (outTab && outTab.length > 0) {
            var toProtTab = {};
            toProtTab.cardTab = outTab;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SOutCard, toProtTab);
        } else {
            this.showPopupWindowFunc(true, false, "提示", "出牌不符合规则！");
        }
    },

    ////////////////////////////////////////////////////////////////////////////////
    onRecvErrcodeFunc: function onRecvErrcodeFunc(errcode, attachtab) {
        cc.log("=======onRecvErrcodeFunc============", errcode, attachtab);
        this.showPopupWindowFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },

    //其他玩家进入房间会调用这里, 进入房间协议比场景协议要先到来
    onRecvEnterRoomFunc: function onRecvEnterRoomFunc(gameId, roomId, userId) {
        //let selfUserId = g_UserManager.getSelfUserIDFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoFunc();
        var seatNo = roominfo.findUserSeatNoFunc(userId);
        var userinfo = roominfo.getUserInfoFunc(seatNo);
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(seatNo);
        cc.log("==============onRecvEnterRoomFunc==========", roomId, userId, typeof userId === "undefined" ? "undefined" : _typeof(userId), roominfo);
        playerui.showUserInfoFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
    },
    onRecvJieSanDeskFunc: function onRecvJieSanDeskFunc(gameId, roomId, userId, userName, isAuto) {
        var _this2 = this;

        cc.log("======onRecvJieSanDeskFunc==========", gameId, roomId, userId, userName, isAuto);
        if (!isAuto) {
            this.showPopupWindowFunc(true, false, "提示", "房主已经解散了房间！", function (flag) {
                _this2.runLobbySceneFunc();
            }, this);
        } else {
            this.showPopupWindowFunc(true, false, "提示", "房间局数已尽！", function (flag) {
                _this2.runLobbySceneFunc();
            }, this);
        }
    },
    onRecvLeaveDeskFunc: function onRecvLeaveDeskFunc(gameId, roomId, userId) {
        cc.log("======onRecvLeaveDeskFunc==========", gameId, roomId, userId);
        if (userId == g_UserManager.getSelfUserIDFunc()) {
            // this.showPopupWindowFunc(true, false, "提示", "您已经离开房间！", (flag)=>{
            //     this.runLobbySceneFunc();
            // }, this);
            this.runLobbySceneFunc();
        }
    },

    ////////////////////////////////////////////////////////////////////////////////
    _startDispCardFunc: function _startDispCardFunc(beginSeatNo) {
        var maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        var eachNumArray = [];
        var eachPosArray = [];
        for (var i = 0; i < maxPlayer; i++) {
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
            eachNumArray.push(17);
            eachPosArray.push(playerui.getHandCardPosFunc());
        }
        var self = this;
        this._dispcardScript.sendAllCardFunc(beginSeatNo, eachNumArray, eachPosArray, function (seatNo, num, isEnd) {
            if (!isEnd) {
                var _playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(seatNo);
                _playerui.getHandCardFunc().drawHandCardFunc(num);
            } else {
                g_ERDDZGameData.setHandCardSortFunc(true);
                self._backgroundScipt._showThreeBackCardFunc(true);
                self._backgroundScipt._showSmallBackCardFunc(false);
                var _maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
                for (var _i = 0; _i < _maxPlayer; _i++) {
                    var _playerui2 = g_ERDDZGameData.getPlayerUIBySeatNoFunc(_i);
                    _playerui2.getHandCardFunc().drawHandCardFunc();
                }
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SSendCardFinish);
            }
        });
    },

    ////////////////////////////////////////////////////////////////////////////////
    onRecvGameStatusFunc: function onRecvGameStatusFunc(protTab) {
        cc.log("==========onRecvGameStatusFunc====11=========", protTab);
        var maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoFunc();
        var selfUserId = g_UserManager.getSelfUserIDFunc();
        var selfSeatNo = roominfo.findUserSeatNoFunc(selfUserId);
        this._resetAllUiFunc();
        cc.log("==========onRecvGameStatusFunc====22=========");
        if (protTab.status == STATUS_READY) {
            for (var i = 0; i < maxPlayer; i++) {
                var playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
                var isReady = protTab.readyTab[i];
                if (i == selfSeatNo) isReady = true;
                playerui.showReadyTipFunc(isReady);
            }
            this._requestGameReadyFunc();
        } else if (protTab.status == STATUS_SENDCARD) {
            for (var _i2 = 0; _i2 < maxPlayer; _i2++) {
                g_ERDDZGameData.setHandCardTabFunc(_i2, protTab.handCardTab[_i2], true);
                var _playerui3 = g_ERDDZGameData.getPlayerUIBySeatNoFunc(_i2);
                var leftnum = g_ERDDZGameData.getHandCardCountFunc(_i2);
                _playerui3.showUserLeftCardFunc(true, leftnum);
                _playerui3.getHandCardFunc().drawHandCardFunc();
            }
            this._startDispCardFunc(selfSeatNo);
        } else if (protTab.status == STATUS_QIANGDIZHU) {
            var turnSeatNo = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortFunc(true);
            if (protTab.bankerUserId) {
                var bankSeatNo = roominfo.findUserSeatNoFunc(protTab.bankerUserId);
                g_ERDDZGameData.setDiZhuSeatNoFunc(bankSeatNo);
            }
            for (var _i3 = 0; _i3 < maxPlayer; _i3++) {
                g_ERDDZGameData.setHandCardTabFunc(_i3, protTab.handCardTab[_i3], true);
                var _playerui4 = g_ERDDZGameData.getPlayerUIBySeatNoFunc(_i3);
                var _leftnum = g_ERDDZGameData.getHandCardCountFunc(_i3);
                _playerui4.showUserLeftCardFunc(true, _leftnum);
                _playerui4.getHandCardFunc().drawHandCardFunc();
                if (turnSeatNo == _i3 && turnSeatNo != selfSeatNo) {
                    _playerui4.showTimeWaitTipFunc(true);
                } else {
                    _playerui4.showTimeWaitTipFunc(false);
                }
            }
            this._rangtipScript.showQiangDiZhuTipFunc(false);
            this._rangtipScript.showRangTipFunc();
            this._backgroundScipt._showThreeBackCardFunc(true);
            this._backgroundScipt._showSmallBackCardFunc(false);
            if (protTab.turnUserId == selfUserId) {
                if (protTab.isTurnJiaoDZ == 1) {
                    this._getDdzControlBtn().showDdzJiaoDiZhuBtn();
                } else {
                    this._getDdzControlBtn().showDdzQiangDiZhuBtn();
                    this._rangtipScript.showQiangDiZhuTipFunc(true);
                }
            }
            if (protTab.lastUserId != null) {
                var _playerui5 = g_ERDDZGameData.getPlayerUIByUserIdFunc(protTab.lastUserId);
                if (protTab.isJiaoDZ == 1) {
                    _playerui5.speekJiaoDiZhuFunc(true);
                } else {
                    _playerui5.speekQiangDiZhuFunc(true);
                }
            }
        } else if (protTab.status == STATUS_OUTCARD) {
            g_ERDDZGameData.setBackCardFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            var bankerSeatNo = roominfo.findUserSeatNoFunc(protTab.bankerUserId);
            var outSeatNo = roominfo.findUserSeatNoFunc(protTab.outUserId);
            var _turnSeatNo = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            g_ERDDZGameData.setDiZhuSeatNoFunc(bankerSeatNo);
            g_ERDDZGameData.setCurOutCardTabFunc(protTab.outTab);
            g_ERDDZGameData.setQiangRangNumFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortFunc(true);
            for (var _i4 = 0; _i4 < maxPlayer; _i4++) {
                g_ERDDZGameData.setHandCardTabFunc(_i4, protTab.handCardTab[_i4], true);
                var _playerui6 = g_ERDDZGameData.getPlayerUIBySeatNoFunc(_i4);
                _playerui6.getHandCardFunc().drawHandCardFunc();
                _playerui6.showDiZhuTipFunc(false);
                if (bankerSeatNo == _i4) {
                    _playerui6.showDiZhuTipFunc(true);
                }
                if (_i4 == outSeatNo) {
                    _playerui6.getHandCardFunc().drawOutCardFunc(protTab.outTab);
                    _playerui6.getHandCardFunc().drawHandCardFunc();
                } else {
                    _playerui6.getHandCardFunc().clearOutCardFunc();
                }
                if (_turnSeatNo == _i4 && _turnSeatNo != selfSeatNo) {
                    _playerui6.showTimeWaitTipFunc(true);
                } else {
                    _playerui6.showTimeWaitTipFunc(false);
                }
                var _leftnum2 = g_ERDDZGameData.getHandCardCountFunc(_i4);
                _playerui6.showUserLeftCardFunc(true, _leftnum2);
                if (_leftnum2 <= 3) {
                    _playerui6.showBaoJingTipFunc(true);
                }
            }
            this._backgroundScipt._showSmallBackCardFunc(false);
            this._rangtipScript.showQiangDiZhuTipFunc(false);
            this._rangtipScript.showRangTipFunc();
            if (protTab.turnUserId == selfUserId) {
                this._getDdzControlBtn().showDdzOutCardBtn(protTab.mustOut == 1);
            }
        } else if (protTab.status == STATUS_GAMEFINISH) {
            //this._requestGameReadyFunc(3);
            this._onShowGameResultFunc(protTab.finishdata);
        }
    },
    _onProtSocketMessageFunc: function _onProtSocketMessageFunc(mainId, assistId, protTab) {
        cc.log("==========_onProtSocketMessageFunc=============", mainId, assistId, protTab);
        // AErRenDDZ_S2CBeginOut = 201;   //开始出牌
        // AErRenDDZ_S2CCallLandlord = 202;  //叫地主
        // AErRenDDZ_S2COutCard    = 203;    //出牌
        // AErRenDDZ_S2CBuChu  = 204;   //不出
        // AErRenDDZ_S2CSendCard  = 205;  //发牌
        // AErRenDDZ_S2CTuoGuan = 207;   //托管
        // AErRenDDZ_S2CGameFinish = 208;    //游戏结束
        var maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoFunc();
        var selfUserId = g_UserManager.getSelfUserIDFunc();
        var selfSeatNo = roominfo.findUserSeatNoFunc(selfUserId);
        for (var i = 0; i < maxPlayer; i++) {
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
            playerui.showReadyTipFunc(false);
            playerui.showTimeWaitTipFunc(false);
            playerui.speekNothingFunc();
        }
        this._backgroundScipt.showBaseTipFunc();
        if (assistId == g_ProtDef.AErRenDDZ_S2CReady) {
            if (protTab.userId == selfUserId) {
                this._resetAllUiFunc();
            }
            var _playerui7 = g_ERDDZGameData.getPlayerUIByUserIdFunc(protTab.userId);
            _playerui7.showReadyTipFunc(true);
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CSendCard) {
            var jiaoSeatNo = roominfo.findUserSeatNoFunc(protTab.jiaoUserId);
            for (var _i5 = 0; _i5 < maxPlayer; _i5++) {
                g_ERDDZGameData.setHandCardTabFunc(_i5, protTab.handCardTab[_i5], false);
                var _playerui8 = g_ERDDZGameData.getPlayerUIBySeatNoFunc(_i5);
                _playerui8.getHandCardFunc().drawHandCardFunc();
                if (_i5 == jiaoSeatNo && jiaoSeatNo != selfSeatNo) {
                    _playerui8.showTimeWaitTipFunc(true);
                }
            }
            this._startDispCardFunc(selfSeatNo);
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CCallLandlord) {
            var turnSeatNo = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortFunc(true);
            this._getDdzControlBtn().hideDdzAllBtn();
            this._backgroundScipt._showThreeBackCardFunc(true);
            this._backgroundScipt._showSmallBackCardFunc(false);

            var _jiaoSeatNo = -1;
            if (protTab.userId) {
                //当发牌完成后，会发送一个userId为空的首次叫地主的协议过来，通知开始叫地主
                _jiaoSeatNo = roominfo.findUserSeatNoFunc(protTab.userId);
                this._rangtipScript.showQiangDiZhuTipFunc(true);
            }
            if (turnSeatNo == selfSeatNo && !protTab.isEnd) {
                if (protTab.isTurnJiaoDZ == 1) {
                    this._getDdzControlBtn().showDdzJiaoDiZhuBtn();
                } else {
                    this._getDdzControlBtn().showDdzQiangDiZhuBtn();
                }
            }
            for (var _i6 = 0; _i6 < maxPlayer; _i6++) {
                var _playerui9 = g_ERDDZGameData.getPlayerUIBySeatNoFunc(_i6);

                var leftnum = g_ERDDZGameData.getHandCardCountFunc(_i6);
                _playerui9.showUserLeftCardFunc(true, leftnum);
                if (_i6 == turnSeatNo && turnSeatNo != selfSeatNo) {
                    _playerui9.showTimeWaitTipFunc(true);
                }
                _playerui9.speekNothingFunc();
                if (_i6 == _jiaoSeatNo && protTab.isJiaoDZ != null) {
                    if (protTab.isJiaoDZ == 1) {
                        _playerui9.speekJiaoDiZhuFunc(protTab.isCall == 1);
                        g_ERDDZGameData.playJiaoDiZhuFunc(protTab.userId, protTab.isCall == 1);
                    } else {
                        _playerui9.speekQiangDiZhuFunc(protTab.isCall == 1);
                        g_ERDDZGameData.playQiangDiZhuFunc(protTab.userId, protTab.isCall == 1);
                    }
                }
            }
            this._rangtipScript.showRangTipFunc();
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CBeginOut) {
            g_ERDDZGameData.setBackCardFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            var bankSeatNo = roominfo.findUserSeatNoFunc(protTab.bankerUserId);
            g_ERDDZGameData.setHandCardSortFunc(true);
            g_ERDDZGameData.setDiZhuSeatNoFunc(bankSeatNo);
            g_ERDDZGameData.addHandCardTabFunc(bankSeatNo, protTab.backCardTab);
            g_ERDDZGameData.playGameStartFunc();
            this._rangtipScript.showQiangDiZhuTipFunc(false);
            this._rangtipScript.showRangTipFunc();
            this._backgroundScipt._showThreeBackCardFunc(true);
            this._backgroundScipt._recoverBackCardFunc();
            if (selfSeatNo == bankSeatNo) {
                this._getDdzControlBtn().showDdzOutCardBtn(true);
            }

            for (var _i7 = 0; _i7 < maxPlayer; _i7++) {
                var _playerui10 = g_ERDDZGameData.getPlayerUIBySeatNoFunc(_i7);
                _playerui10.showDiZhuTipFunc(false);
                _playerui10.getHandCardFunc().drawHandCardFunc();
                if (_i7 == bankSeatNo) {
                    _playerui10.showDiZhuTipFunc(true);
                    _playerui10.getHandCardFunc().moveAddActionCardFunc(protTab.backCardTab);
                    if (_i7 == selfSeatNo) {
                        _playerui10.showTimeWaitTipFunc(false);
                    } else {
                        _playerui10.showTimeWaitTipFunc(true);
                    }
                }
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2COutCard) {
            var outSeatNo = roominfo.findUserSeatNoFunc(protTab.userId);
            var _turnSeatNo2 = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            var outtype = GameRuleLogic.getCardTabCardTypeFunc(protTab.cardTab);
            if (protTab.newTurn == 1 || Math.random() * 100 < 50) {
                g_ERDDZGameData.playOutCardFunc(protTab.userId, protTab.cardTab[0], outtype);
            } else {
                g_ERDDZGameData.playEatCardDaNiFunc(protTab.userId);
            }
            g_ERDDZGameData.playOutTypeFunc(outtype);

            g_ERDDZGameData.setCurOutCardTabFunc(protTab.cardTab);
            g_ERDDZGameData.removeCardTabFunc(outSeatNo, protTab.cardTab);
            g_ERDDZGameData.setHandCardSortFunc(true);
            this._backgroundScipt._showThreeBackCardFunc(false);
            this._rangtipScript.showQiangDiZhuTipFunc(false);
            this._getDdzControlBtn().hideDdzAllBtn();
            for (var _i8 = 0; _i8 < maxPlayer; _i8++) {
                var _playerui11 = g_ERDDZGameData.getPlayerUIBySeatNoFunc(_i8);
                if (_i8 == outSeatNo) {
                    _playerui11.getHandCardFunc().drawOutCardFunc(protTab.cardTab);
                    _playerui11.getHandCardFunc().drawHandCardFunc();
                } else {
                    _playerui11.getHandCardFunc().clearOutCardFunc();
                }
                if (_i8 == _turnSeatNo2 && _turnSeatNo2 == selfSeatNo || _i8 == outSeatNo) {
                    _playerui11.showTimeWaitTipFunc(false);
                } else {
                    _playerui11.showTimeWaitTipFunc(true);
                }
                var _leftnum3 = g_ERDDZGameData.getHandCardCountFunc(_i8);
                _playerui11.showUserLeftCardFunc(true, _leftnum3);
                if (_leftnum3 <= 3) {
                    _playerui11.showBaoJingTipFunc(true);
                }
            }
            if (_turnSeatNo2 == selfSeatNo) {
                this._getDdzControlBtn().showDdzOutCardBtn(false);
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CBuChu) {
            var theSeatNo = roominfo.findUserSeatNoFunc(protTab.userId);
            var _turnSeatNo3 = roominfo.findUserSeatNoFunc(protTab.turnUserId);
            g_ERDDZGameData.setCurOutCardTabFunc(null);
            g_ERDDZGameData.playNotOutFunc(protTab.userId);
            this._getDdzControlBtn().hideDdzAllBtn();
            for (var _i9 = 0; _i9 < maxPlayer; _i9++) {
                var _playerui12 = g_ERDDZGameData.getPlayerUIBySeatNoFunc(_i9);
                if (_i9 == theSeatNo) {
                    _playerui12.speekBuChuFunc();
                }
                _playerui12.getHandCardFunc().clearOutCardFunc();
            }
            if (_turnSeatNo3 == selfSeatNo) {
                this._getDdzControlBtn().showDdzOutCardBtn(true);
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CTuoGuan) {} else if (assistId == g_ProtDef.AErRenDDZ_S2CGameFinish) {
            g_ERDDZGameData.playGameResultFunc(protTab.winUserId == selfUserId);
            this._onShowGameResultFunc(protTab);
            //游戏正常结束，调用基类函数
            var gameId = roominfo.getGameIDFunc();
            var roomId = roominfo.getRoomIDFunc();
            this.onBaseGameFinishFunc(gameId, roomId);
        }
    },

    ////////////////////////////////////////////////////////////////////
    _onShowGameResultFunc: function _onShowGameResultFunc(protTab) {
        this._resetAllUiFunc();
        g_ERDDZGameData.setHandCardSortFunc(true);
        var maxPlayer = g_ERDDZGameData.getMaxPlayerFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoFunc();
        var bankerSeatNo = roominfo.findUserSeatNoFunc(protTab.bankerUserId);
        var winSeatNo = roominfo.findUserSeatNoFunc(protTab.winUserId);
        for (var i = 0; i < maxPlayer; i++) {
            g_ERDDZGameData.setHandCardTabFunc(i, protTab.handCardTab[i], true);
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoFunc(i);
            playerui.getHandCardFunc().drawHandCardFunc(null, true);
            playerui.showDiZhuTipFunc(false);
            if (bankerSeatNo == i) {
                playerui.showDiZhuTipFunc(true);
            }
            if (i == winSeatNo) {
                playerui.getHandCardFunc().drawOutCardFunc(protTab.lastOutTab);
            }
            roominfo.updateUserGoldFunc(i, protTab.winScore[i]);
            playerui.showTotalScoreFunc(true, protTab.winScore[i]);
        }
        this._getGameResultFunc()._showResultFunc(true, protTab);
    }
});

cc._RF.pop();