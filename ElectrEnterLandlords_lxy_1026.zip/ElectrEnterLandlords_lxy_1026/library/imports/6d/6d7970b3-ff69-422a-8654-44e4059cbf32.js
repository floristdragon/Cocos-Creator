"use strict";
cc._RF.push(module, '6d797Cz/2lCKoZUROQFnL8y', 'ui-DdzLobbyRank');
// DdzScript/GameLogicScript/LobbyScript/ui-DdzLobbyRank.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        starsFrame: [cc.SpriteFrame],
        O_selfStar: cc.Sprite,
        numFrame: [cc.SpriteFrame],
        O_selfrank: cc.Label,
        headImg: cc.Sprite,
        playerName: cc.Label,
        O_selfWinNum: cc.Label,

        //  _PHBcontent : null,
        O_PHBcontent: cc.Prefab,

        O_scrollView: cc.Node,
        _scrollScript: null

    },

    // use this for initialization
    onLoad: function onLoad() {
        var userinfo = g_UserManager.getSelfUserInfoFunc();
        this.playerName.string = userinfo.getUserNameFunc();
    },

    setPaiHangBangFunc: function setPaiHangBangFunc(selfrank, selfnum, alllist) {
        //this.headImg.spriteFrame = playerInfo.headImg;
        this.O_selfStar.node.active = false;
        this.O_selfrank.node.active = true;
        this.O_selfrank.string = "";
        cc.log("============ui-lobbypaihangbang======initFunc======", alllist);

        if (selfrank && selfrank < 4) {
            this.O_selfStar.node.active = true;
            this.O_selfStar.spriteFrame = this.starsFrame[selfrank - 1];
            this.O_selfrank.spriteFrame = this.numFrame[selfrank - 1];
            this.O_selfrank.string = selfrank;
        }
        if (selfnum == null) selfnum = 0;
        this.O_selfWinNum.string = selfnum;
        for (var i in alllist) {
            if (!alllist[i]) continue;
            var PHBcontent = cc.instantiate(this.O_PHBcontent);
            PHBcontent.getComponent('ui-DdzLobbyRankLine').initFunc(alllist[i]);
            this._scrollScript = this.O_scrollView.getComponent('ui-DdzScrollView');
            this._scrollScript.addScrollNodeFunc(PHBcontent, null, alllist[i]);
        }

        this._scrollScript.sortAllNodeListFunc(function (a, b) {
            if (a.rank < b.rank) return -1; //表示要交换
            return 1; //不用交换
        });
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

});

cc._RF.pop();