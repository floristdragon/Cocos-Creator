"use strict";
cc._RF.push(module, '30bf0FUTMNKHLB999VJbEHf', 'include');
// DdzScript/include.js

"use strict";

console.log("============require======include=====================");
var SocketClient = require("SocketClientScript");

window.g_RoomManager = require("RoomManagerScript"); //房间信息管理
window.g_UserManager = require("UserManagerScript"); //用户信息管理
window.g_ItemManager = require("ItemManagerScript"); //物品管理器
window.g_ConfigManager = require("ConfigManagerScript"); //本地配置数据
window.g_SoundManager = require("SoundManagerScript"); //音频管理器
window.g_NetManager = new SocketClient(); //网络连接管理
window.g_ProtDef = require("mProtocolScript"); //协议模块和协议的定义

window.g_GameScene = null; //当前场景得全局句柄

cc._RF.pop();