"use strict";
cc._RF.push(module, '49117Z5GNFHKaY+DHFw8bwe', 'ui-DdzLobbyMails');
// DdzScript/GameLogicScript/LobbyScript/ui-DdzLobbyMails.js

"use strict";

var utilIconv = require("util-iconvScript");
cc.Class({
    extends: cc.Component,

    properties: {
        O_mailprefab: cc.Prefab,

        O_scrollview: cc.Node,

        O_maildetailnode: cc.Node,
        O_labelcontent: cc.Label,
        O_emptytip: cc.Node,

        _scrollscript: null,
        _detailnode: null
    },
    onLoad: function onLoad() {
        this.O_maildetailnode.active = false;
        this._scrollscript = this.O_scrollview.getComponent("ui-DdzScrollView");
        this._scrollscript.setHeightInterFunc(0);
        this._checkEmptyTipFunc();
    },
    showBoxFunc: function showBoxFunc(bVisible, bClear) {
        cc.log("=========setMailBox===========");
        this.node.active = bVisible;
        if (bClear) this._scrollscript.clearAllNodeFunc();
    },
    setBoxMailFunc: function setBoxMailFunc(maillist) {
        var _this = this;

        if (!maillist) return;

        var _loop = function _loop(i) {
            var maildata = maillist[i];
            //let iconvlite = require('iconv-lite');
            //let toData = iconvlite.decode(toTempArray, 'UTF8');
            maildata.title = utilIconv.GBKToUTF8(maildata.title);
            maildata.content = utilIconv.GBKToUTF8(maildata.content);
            var mailnode = cc.instantiate(_this.O_mailprefab);
            cc.log("======setBoxMailFunc===title===", maildata.title);
            mailnode.getComponent("ui-DdzLobbyMailLine").initFunc(maildata.mailId, maildata.title, maildata.stime);
            mailnode.on("mailbox-readmail", function () {
                _this.O_labelcontent.string = maildata.content;
                _this.O_maildetailnode.active = true;
                _this._detailnode = mailnode;
            }, _this);
            _this._scrollscript.addScrollNodeFunc(mailnode, null, maildata.stime);
        };

        for (var i = 0; i < maillist.length; i++) {
            _loop(i);
        }
        this._scrollscript.sortAllNodeListFunc(function (a, b) {
            if (a > b) return -1;
            return 1;
        });
        this._checkEmptyTipFunc();
    },
    onDdzCloseDetailClick: function onDdzCloseDetailClick(node) {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");

        cc.log("========onDdzCloseDetailClick=========", node);
        this.O_maildetailnode.active = false;
        this._scrollscript.rmScrollNodeFunc(this._detailnode);
        this._checkEmptyTipFunc();
    },
    onDdzClose: function onDdzClose() {
        g_SoundManager.playEffectFunc("DdzCommonMusic/buttonMusic");
        this.showBoxFunc(false);
    },
    _checkEmptyTipFunc: function _checkEmptyTipFunc() {
        if (this._scrollscript.getListSizeFunc() <= 0) {
            this.O_emptytip.active = true;
        } else {
            this.O_emptytip.active = false;
        }
    }
});

cc._RF.pop();