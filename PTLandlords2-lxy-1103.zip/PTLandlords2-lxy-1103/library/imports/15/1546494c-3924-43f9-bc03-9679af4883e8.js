"use strict";
cc._RF.push(module, '15464lMOSRD+bwDlnmvSIPo', 'ui-classicDdzBackgroundNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/DdzLogicScriptNov2nd/classicDdzLogicNov2nd/ui-classicDdzBackgroundNov2nd.js

"use strict";

var exFangHaoNodePos = null;
var exJuShuNodePos = null;
cc.Class({
    extends: cc.Component,

    properties: {
        O_basescorenode: cc.Node,
        O_beilvnode: cc.Node,
        O_fanghaonode: cc.Node,
        O_jushunode: cc.Node,

        O_timetext: cc.Label,

        O_smallcardparent: cc.Node,
        O_smallcardArray: {
            default: [],
            type: cc.Node
        },
        O_beilvtip: cc.Node,
        O_typetip: cc.Node,
        O_backcardprefab: cc.Prefab,

        _backcardparent: null
    },

    // use this for initialization
    onLoad: function onLoad() {
        this._setBaseNumNovBeginFunc(this.O_fanghaonode, 0);
        this._setBaseNumNovBeginFunc(this.O_basescorenode, 0);
        this._setBaseNumNovBeginFunc(this.O_beilvnode, 0);

        var self = this;
        var uptimerNovBeginFunc = function uptimerNovBeginFunc(dt) {
            var date = new Date();
            var tostr = "";
            if (date.getHours() < 10) {
                tostr += "0";
            }
            tostr += date.getHours();
            tostr += ":";
            if (date.getMinutes() < 10) {
                tostr += "0";
            }
            tostr += date.getMinutes();
            self.O_timetext.string = tostr;
        };
        uptimerNovBeginFunc();
        this.schedule(uptimerNovBeginFunc, 1);
        this.showThreeBackCardNovBeginFunc(false);

        this.O_smallcardparent.active = false;

        // this.scheduleOnce(()=>{
        //     self.recoverBackCardNovBeginFunc();
        // }, 2);
    },

    showBaseTipNovBeginFunc: function showBaseTipNovBeginFunc() {
        var roominfo = g_CLDDZGameData.getRoomInfoNovBeginFunc();
        if (roominfo) {
            this._setBaseNumNovBeginFunc(this.O_fanghaonode, roominfo.getRoomIDNovBeginFunc());
            this._setBaseNumNovBeginFunc(this.O_basescorenode, roominfo.getBaseScoreNovBeginFunc());
            this._setBaseNumNovBeginFunc(this.O_beilvnode, roominfo.getBaseBeiLvNovBeginFunc());

            if (!exFangHaoNodePos) {
                exFangHaoNodePos = new cc.Vec2(this.O_fanghaonode.position.x, this.O_fanghaonode.position.y);
            }
            if (!exJuShuNodePos) {
                exJuShuNodePos = new cc.Vec2(this.O_jushunode.position.x, this.O_jushunode.position.y);
            }
            var curjushu = roominfo.getCurJuShuNovBeginFunc();
            var maxjushu = roominfo.getMaxJuShuNovBeginFunc();
            if (maxjushu > 0) {
                this._setBaseNumNovBeginFunc(this.O_jushunode, curjushu + "/" + maxjushu);
            } else {
                this.O_jushunode.active = false;
                this.O_fanghaonode.position = exJuShuNodePos;
            }
        }
        cc.log("======ScoreTip===resetTip=============", roominfo);
    },
    showSmallBackCardNovBeginFunc: function showSmallBackCardNovBeginFunc(bVisible) {
        var _this = this;

        cc.log("=======showSmallBackCardNovBeginFunc=======", bVisible);
        this.O_smallcardparent.active = bVisible;
        if (!bVisible) return;
        this.O_beilvtip.active = false;
        this.O_typetip.active = false;
        var backCardTab = g_CLDDZGameData.getBackCardNovBeginFunc();

        var _loop = function _loop(i) {
            var toSpUrl = g_CLDDZGameData.getPokerFramePathNovBeginFunc(false, backCardTab[i]);
            var toSprite = _this.O_smallcardArray[i].getComponent(cc.Sprite);
            cc.loader.loadRes(toSpUrl, function (err, texture) {
                toSprite.spriteFrame = new cc.SpriteFrame(texture);
            });
        };

        for (var i = 0; i < this.O_smallcardArray.length; i++) {
            _loop(i);
        }
    },
    showThreeBackCardNovBeginFunc: function showThreeBackCardNovBeginFunc(bVisible) {
        if (!this._backcardparent && !bVisible) return;
        if (this._backcardparent) this._backcardparent.destroy();

        this._backcardparent = cc.instantiate(this.O_backcardprefab);
        this._backcardparent.parent = this.node;
        this._backcardparent.active = bVisible;
        cc.log("========showThreeBackCardNovBeginFunc=============", this._backcardparent);
    },
    recoverBackCardNovBeginFunc: function recoverBackCardNovBeginFunc() {
        var _this2 = this;

        cc.log("=======recoverBackCardNovBeginFunc=======");
        this.showThreeBackCardNovBeginFunc(true);
        this.O_smallcardparent.active = false;
        var backCardTab = g_CLDDZGameData.getBackCardNovBeginFunc();
        var toShowNovBeginFunc = function toShowNovBeginFunc() {
            cc.log("=======toShowNovBeginFunc=======");
            if (this.O_smallcardparent.active) return;
            this._backcardparent.active = false;
            this.showSmallBackCardNovBeginFunc(true);
        };
        var backcardArray = [];
        var toPosArray = [];
        var toSpFrameArray = [];
        for (var i = 1; i <= 3; i++) {
            var toCard = this._backcardparent.getChildByName("card" + i);
            backcardArray.push(toCard);
        }
        for (var _i = 0; _i < backCardTab.length; _i++) {
            var toSpUrl = g_CLDDZGameData.getPokerFramePathNovBeginFunc(true, backCardTab[_i], true);
            var texture = cc.textureCache.addImage(toSpUrl);
            toSpFrameArray.push(texture);
            var toPosEx = this.O_smallcardArray[_i].convertToWorldSpaceAR(cc.Vec2.ZERO);
            var toNodePos = this._backcardparent.convertToNodeSpaceAR(toPosEx);
            toPosArray.push(toNodePos);
        }

        var _loop2 = function _loop2(_i2) {
            var toRotateNovBeginFunc = function toRotateNovBeginFunc() {
                cc.log("====toRotateNovBeginFunc=========", _i2);
                var toSprite = backcardArray[_i2].getComponent(cc.Sprite);
                toSprite.spriteFrame = new cc.SpriteFrame(toSpFrameArray[_i2]);
            };
            backcardArray[_i2].runAction(cc.sequence(cc.scaleTo(0.5, 0, 1), cc.callFunc(toRotateNovBeginFunc, _this2), cc.scaleTo(0.5, 1, 1), cc.moveTo(0.5, toPosArray[_i2]), cc.callFunc(toShowNovBeginFunc, _this2), cc.hide()));
        };

        for (var _i2 = 0; _i2 < backcardArray.length; _i2++) {
            _loop2(_i2);
        }
    },


    /////////////////////////////////////////////////////////////////////////////
    _setBaseNumNovBeginFunc: function _setBaseNumNovBeginFunc(node, str) {
        node.getChildByName("num").getComponent(cc.Label).string = str;
    }
});

cc._RF.pop();