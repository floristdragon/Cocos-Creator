"use strict";
cc._RF.push(module, '25be8v8x7BFo4HJkSrWpoQz', 'ui-roomSceneNov2nd');
// ScriptNov2nd/GameUiScriptNov2nd/ui-roomSceneNov2nd.js

"use strict";

//用户进入房间
function lonProtEnterRoomNovBeginFunc(mainId, assistId, protTab) {
    //进入房间
    cc.log("==============lonProtEnterRoomNovBeginFunc==================", protTab, g_GameScene.onRecvEnterRoomNovBeginFunc);
    var gameId = protTab.info.gameId;
    var roomId = protTab.info.roomId;
    var roominfo = g_RoomManager.newRoomInfoNovBeginFunc(gameId, roomId);
    roominfo.setPackageInfoNovBeginFunc(protTab.info);
    if (g_GameScene.onRecvEnterRoomNovBeginFunc) {
        g_GameScene.onRecvEnterRoomNovBeginFunc(gameId, roomId, protTab.userId);
    }
}
function lonProtGameStatusNovBeginFunc(mainId, assistId, protTab) {
    //场景协议
    if (g_GameScene.onRecvGameStatusNovBeginFunc) {
        g_GameScene.onRecvGameStatusNovBeginFunc(protTab);
    }
}
function lonProtJieSanDeskNovBeginFunc(mainId, assistId, protTab) {
    //解散
    cc.log("======lonProtJieSanDeskNovBeginFunc==========", mainId, assistId, protTab);
    if (g_GameScene.onRecvJieSanDeskNovBeginFunc) {
        g_GameScene.onRecvJieSanDeskNovBeginFunc(protTab.gameId, protTab.roomId, protTab.userId, protTab.userName, protTab.isauto);
    }
}
function lonProtLeaveDeskNovBeginFunc(mainId, assistId, protTab) {
    //离开房间
    cc.log("======lonProtLeaveDeskNovBeginFunc==========", mainId, assistId, protTab);
    if (g_GameScene.onRecvLeaveDeskNovBeginFunc) g_GameScene.onRecvLeaveDeskNovBeginFunc(protTab.gameId, protTab.roomId, protTab.userId);
}
function lonProtCheckSignInNovBeginFunc(mainId, assistId, protTab) {
    //短线检测登陆
    cc.log("========lonProtCheckSignInNovBeginFunc=========");
    g_NetManager.clearSendPack(true);
}
//提示有信息操作


cc.Class({
    extends: require("ui-basesceneNov2nd"),

    properties: {
        _mmgamechatscript: null,
        _mmisInRoomChat: false,

        _mmChatMsgList: [],
        O_chatPrefab: cc.Prefab,

        //////////////////////////////////////////////////////Tips
        O_chatTipsNode: cc.Node,
        O_friendsTipsNode: cc.Node,
        O_mailsTipsNode: cc.Node,
        O_zhanjiTipsNode: cc.Node,
        _chatTips: null,
        _friendsTis: null,
        _mailsTips: null,
        _zhanjiTips: null
    },

    // use this for initialization
    onLoad: function onLoad() {
        var _this = this;

        this._super(); //调用父类的onLoad
        console.log("=========roomscene=onLoad=============");
        var self = this;
        g_NetManager.onopen = function () {
            console.log("======roomscene===g_NetManager.onopen=============");
            self.showLoadFlowerNovBeginFunc(false);
            //test
            // 检测登陆信息, 短线重连
            var logintab = g_ConfigManager.getLoginAccountNov2nd();
            var accName = logintab[0];
            var accPwd = logintab[1];
            if (!accName || !accPwd) {
                self.showPopupWindowNovBeginFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_LOGIN_REDO_LOGIN"), function (flag) {
                    self.switchStartSceneNovBeginFunc();
                });
            } else {
                var protTab = {};
                protTab.accName = accName;
                protTab.accPwd = accPwd;
                protTab.platform = 0;
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_C2SCheckSignIN, protTab);
            }
        };
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqEnterDesk, lonProtEnterRoomNovBeginFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CGameStatus, lonProtGameStatusNovBeginFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqJieSanDesk, lonProtJieSanDeskNovBeginFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqLeaveDesk, lonProtLeaveDeskNovBeginFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_S2CCheckSignIN, lonProtCheckSignInNovBeginFunc);

        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2CSendChatMsg, function (mid, pid, protTab) {
            if (_this._mmgamechatscript) {
                _this._mmgamechatscript.addChatMsgNovBeginFunc(protTab);
                _this._mmChatMsgList = [];
            } else {
                _this._mmChatMsgList.push(protTab);
            }
        }, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2CNoticePoint, this.onProtNoticePointNovBeginFunc, this);
    },

    //////////////////////////////////////////////////////////////////
    onBaseGameFinishNovBeginFunc: function onBaseGameFinishNovBeginFunc(gameId, roomId) {
        var roominfo = g_RoomManager.getGameRoomInfoNovBeginFunc(gameId, roomId);
        var toJuShu = roominfo.getCurJuShuNovBeginFunc();
        if (toJuShu > 0) {
            roominfo.setCurJuShuNovBeginFunc(toJuShu + 1);
        }
    },

    //提示有信息操作
    onProtNoticePointNovBeginFunc: function onProtNoticePointNovBeginFunc(mainId, assistId, protTab) {
        cc.log("=====onProtNoticePointNovBeginFunc========protTab======", protTab);
        var tipsNode = this.node.getChildByName('nodeTips');
        tipsNode.setLocalZOrder(9);
        this._chatTips = protTab[g_ProtDef.MID_Protocol_Broadcast];
        this._friendsTis = protTab[g_ProtDef.MID_Protocol_Friend];
        this._mailsTips = protTab[g_ProtDef.MID_Protocol_MailBox];
        this._zhanjiTips = protTab[g_ProtDef.MID_Protocol_ZhanJi];

        if (this._chatTips) {
            this.O_chatTipsNode.active = true;
        } else {
            this.O_chatTipsNode.active = false;
        }

        if (this._friendsTis) {
            this.O_friendsTipsNode.active = true;
        } else {
            this.O_friendsTipsNode.active = false;
        }

        if (this._mailsTips) {
            this.O_mailsTipsNode.active = true;
        } else {
            this.O_mailsTipsNode.active = false;
        }

        if (this._zhanjiTips) {
            this.O_zhanjiTipsNode.active = true;
        } else {
            this.O_zhanjiTipsNode.active = false;
        }
    },
    onChatPanelBtnNovBeginFunc: function onChatPanelBtnNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.O_chatTipsNode.active = false;
        //聊天协议
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SReqChatMsg);

        var isfirstinit = false;
        if (!this._mmgamechatscript) {
            var talkNode = cc.instantiate(this.O_chatPrefab);

            talkNode.parent = this.node;
            if (this._mmisInRoomChat) {
                talkNode.setLocalZOrder(150);
            } else {
                talkNode.setLocalZOrder(10);
            }

            this._mmgamechatscript = talkNode.getComponent('ui-gameChatNov2nd');
            isfirstinit = true;
        }
        this.setChatRoomStateNovBeginFunc(this._mmisInRoomChat);
        this._mmgamechatscript.showSiliaoTipsNovBeginFunc(this._chatTips);
        if (this._mmisInRoomChat) {
            this._mmgamechatscript.hideSiLiaoTipsNovBeginFunc(false);
        }
        this._mmgamechatscript.openChatViewNovBeginFunc();

        if (isfirstinit) {
            for (var i = 0; i < this._mmChatMsgList.length; i++) {
                this._mmgamechatscript.addChatMsgNovBeginFunc(this._mmChatMsgList[i]);
            }
        }
    },
    setChatRoomStateNovBeginFunc: function setChatRoomStateNovBeginFunc(isRoom) {
        this._mmisInRoomChat = isRoom;
        if (this._mmgamechatscript) this._mmgamechatscript.setRoomChatStateNovBeginFunc(isRoom);
    }
});

cc._RF.pop();