"use strict";
cc._RF.push(module, '334189/3Z5DA5QpGUfzNrdQ', 'ui-lobbyPrivateChatNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/lobbyLogicScriptNov2nd/ui-lobbyPrivateChatNov2nd.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_editBox: cc.EditBox,
        O_chatLinePrefab: cc.Prefab,
        O_toUserId: cc.Label,

        _toUserId: 0

    },

    onCloseEventNovBeginFunc: function onCloseEventNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.node.active = false;
    },

    initNovBeginFunc: function initNovBeginFunc(toUserid) {
        //
        //this._scrollScript = this.scrollViewNode.getComponent('ui-scrollViewNov2nd');
        this.O_toUserId.string = toUserid;
        this._toUserId = toUserid;
    },

    onSendEventNovBeginFunc: function onSendEventNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        if (g_GameScene.rejectClickEventNovBeginFunc(3)) return;
        var userstr = this.O_editBox.string;
        this.O_editBox.string = "";

        //发送协议
        var toChattab = {};
        toChattab.toUserId = this._toUserId;
        toChattab.ctype = 4;
        toChattab.content = userstr;
        toChattab.msgtype = 3;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SSendChatMsg, toChattab);

        cc.log("========onSendEventNovBeginFunc=========toChattab==========", toChattab);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();