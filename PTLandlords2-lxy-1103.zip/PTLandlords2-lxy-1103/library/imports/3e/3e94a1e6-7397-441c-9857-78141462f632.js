"use strict";
cc._RF.push(module, '3e94aHmc5dEHJhXeBQUYvYy', 'nativeCallbackNov2nd');
// ScriptNov2nd/GameUtilsScriptNov2nd/nativeCallbackNov2nd.js

"use strict";

module.exports = {
    savePhotoCall: function savePhotoCall() {}
};

cc._RF.pop();