"use strict";
cc._RF.push(module, '49117Z5GNFHKaY+DHFw8bwe', 'ui-lobbyMailBoxNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/lobbyLogicScriptNov2nd/ui-lobbyMailBoxNov2nd.js

"use strict";

var utilIconv = require("util_iconvNov2nd");
cc.Class({
    extends: cc.Component,

    properties: {
        O_mailprefab: cc.Prefab,

        O_scrollview: cc.Node,

        O_maildetailnode: cc.Node,
        O_labelcontent: cc.Label,
        O_emptytip: cc.Node,

        _scrollscript: null,
        _detailnode: null
    },
    onLoad: function onLoad() {
        this.O_maildetailnode.active = false;
        this._scrollscript = this.O_scrollview.getComponent("ui-scrollViewNov2nd");
        this._scrollscript.setHeightInterNovBeginFunc(0);
        this._checkEmptyTipNovBeginFunc();
    },
    showBoxNovBeginFunc: function showBoxNovBeginFunc(bVisible, bClear) {
        cc.log("=========setMailBox===========");
        this.node.active = bVisible;
        if (bClear) this._scrollscript.clearAllNodeNovBeginFunc();
    },
    setBoxMailNovBeginFunc: function setBoxMailNovBeginFunc(maillist) {
        var _this = this;

        if (!maillist) return;

        var _loop = function _loop(i) {
            var maildata = maillist[i];
            if (!maildata) return "continue";
            //let iconvlite = require('iconv-lite');
            //let toData = iconvlite.decode(toTempArray, 'UTF8');
            maildata.title = utilIconv.GBKToUTF8(maildata.title);
            maildata.content = utilIconv.GBKToUTF8(maildata.content);
            var mailnode = cc.instantiate(_this.O_mailprefab);
            cc.log("======setBoxMailNovBeginFunc===title===", maildata.title);
            mailnode.getComponent("ui-lobbyMailLineNov2nd").initNovBeginFunc(maildata.mailId, maildata.title, maildata.stime);
            mailnode.on("mailbox-readmail", function () {
                _this.O_labelcontent.string = maildata.content;
                _this.O_maildetailnode.active = true;
                _this._detailnode = mailnode;
            }, _this);
            _this._scrollscript.addScrollNodeNovBeginFunc(mailnode, null, maildata.stime);
        };

        for (var i = 0; i < maillist.length; i++) {
            var _ret = _loop(i);

            if (_ret === "continue") continue;
        }
        this._scrollscript.sortAllNodeListNovBeginFunc(function (a, b) {
            if (a > b) return -1;
            return 1;
        });
        this._checkEmptyTipNovBeginFunc();
    },
    onCloseDetailClickNovBeginFunc: function onCloseDetailClickNovBeginFunc(node) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        cc.log("========onCloseDetailClickNovBeginFunc=========", node);
        this.O_maildetailnode.active = false;
        this._scrollscript.rmScrollNodeNovBeginFunc(this._detailnode);
        this._checkEmptyTipNovBeginFunc();
    },
    onCloseNovBeginFunc: function onCloseNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.showBoxNovBeginFunc(false);
    },
    _checkEmptyTipNovBeginFunc: function _checkEmptyTipNovBeginFunc() {
        if (this._scrollscript.getListSizeNovBeginFunc() <= 0) {
            this.O_emptytip.active = true;
        } else {
            this.O_emptytip.active = false;
        }
    }
});

cc._RF.pop();