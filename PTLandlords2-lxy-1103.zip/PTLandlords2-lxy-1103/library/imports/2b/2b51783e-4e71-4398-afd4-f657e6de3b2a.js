"use strict";
cc._RF.push(module, '2b517g+TnFDmK/U9lfm3jsq', 'itemTypeNov2nd');
// ScriptNov2nd/CommonScriptNov2nd/dataScriptNov2nd/itemTypeNov2nd.js

"use strict";

var itemtypetab = {};
module.exports = itemtypetab;

itemtypetab[1001] = { "desc": "金币" };
itemtypetab[1002] = { "desc": "钻石" };
itemtypetab[1003] = { "desc": "房卡" };

cc._RF.pop();