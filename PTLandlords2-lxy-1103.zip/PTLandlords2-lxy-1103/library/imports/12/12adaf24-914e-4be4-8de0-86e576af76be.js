"use strict";
cc._RF.push(module, '12ada8kkU5L5I3ghuV2r3a+', 'ItemManagerNov2nd');
// ScriptNov2nd/GameBaseScriptNov2nd/ItemManagerNov2nd.js

"use strict";

module.exports = {
    _allitemtab: {},
    updateItemNovBeginFunc: function updateItemNovBeginFunc(itemid, count) {
        itemid = Math.floor(parseInt(itemid) / 1000);
        this._allitemtab[itemid] = count;
    },
    getItemNovBeginFunc: function getItemNovBeginFunc(itemid) {
        itemid = parseInt(itemid);
        return this._allitemtab[itemid];
    },
    getGoldNovBeginFunc: function getGoldNovBeginFunc() {
        if (!this._allitemtab[1001]) return 0;
        return this._allitemtab[1001];
    }
};

cc._RF.pop();