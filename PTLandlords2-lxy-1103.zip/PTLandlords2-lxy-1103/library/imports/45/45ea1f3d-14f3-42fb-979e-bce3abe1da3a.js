"use strict";
cc._RF.push(module, '45ea189FPNC+5eevOOr4do6', 'ui-classicControllBtnNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/DdzLogicScriptNov2nd/classicDdzLogicNov2nd/ui-classicControllBtnNov2nd.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_outcardbtnnode: cc.Node,
        O_qiangdzbtnnode: cc.Node,
        O_jiaodzbtnnode: cc.Node,

        O_buchubtn: cc.Button
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.hideAllButtonNovBeginFunc();
    },
    hideAllButtonNovBeginFunc: function hideAllButtonNovBeginFunc() {
        this.O_outcardbtnnode.active = false;
        this.O_qiangdzbtnnode.active = false;
        this.O_jiaodzbtnnode.active = false;
    },
    showOutCardBtnNovBeginFunc: function showOutCardBtnNovBeginFunc(bMustOut) {
        this.hideAllButtonNovBeginFunc();
        this.O_outcardbtnnode.active = true;
        this.O_buchubtn.interactable = !bMustOut;
    },
    showQiangDZBtnNovBeginFunc: function showQiangDZBtnNovBeginFunc() {
        this.hideAllButtonNovBeginFunc();
        this.O_qiangdzbtnnode.active = true;
    },
    showJiaoDZBtnNovBeginFunc: function showJiaoDZBtnNovBeginFunc() {
        this.hideAllButtonNovBeginFunc();
        this.O_jiaodzbtnnode.active = true;
    },
    ////////////////////////////////////////////////////
    onBuChuBtnNovBeginFunc: function onBuChuBtnNovBeginFunc(event) {
        this.node.emit("outbtn-buchu");
    },
    onLastHandBtnNovBeginFunc: function onLastHandBtnNovBeginFunc(event) {
        //this.node.emit("outbtn-lasthand");
    },
    onTiShiBtnNovBeginFunc: function onTiShiBtnNovBeginFunc(event) {
        this.node.emit("outbtn-tishi");
    },
    onChuPaiBtnNovBeginFunc: function onChuPaiBtnNovBeginFunc(event) {
        this.node.emit("outbtn-chupai");
    },
    /////////////////////////////////////////////////
    _priCallProtocolDZNovBeginFunc: function _priCallProtocolDZNovBeginFunc(isCall) {
        this.hideAllButtonNovBeginFunc();
        var toProtData = {};
        toProtData.isCall = isCall, g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ClassicDDZ, g_ProtDef.AClassicDDZ_C2SCallLandlord, toProtData);
    },
    onBuQiangBtnNovBeginFunc: function onBuQiangBtnNovBeginFunc(event) {
        cc.log("=========onBuQiangBtnNovBeginFunc===");
        this._priCallProtocolDZNovBeginFunc(0);
    },
    onQiangDZBtnNovBeginFunc: function onQiangDZBtnNovBeginFunc(event) {
        cc.log("=========onQiangDZBtnNovBeginFunc===");
        this._priCallProtocolDZNovBeginFunc(1);
    },
    /////////////////////////////////////////////////
    onBuJiaoBtnNovBeginFunc: function onBuJiaoBtnNovBeginFunc(event) {
        cc.log("=========onBuJiaoBtnNovBeginFunc===");
        this._priCallProtocolDZNovBeginFunc(0);
    },
    onJiaoDZBtnNovBeginFunc: function onJiaoDZBtnNovBeginFunc(event) {
        cc.log("=========onJiaoDZBtnNovBeginFunc===");
        this._priCallProtocolDZNovBeginFunc(1);
    }
});

cc._RF.pop();