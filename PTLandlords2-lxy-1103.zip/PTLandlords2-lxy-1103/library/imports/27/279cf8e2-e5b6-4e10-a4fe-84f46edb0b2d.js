"use strict";
cc._RF.push(module, '279cfji5bZOEKT+hPRu2wst', 'ui-lobbyZhanJiDtailNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/lobbyLogicScriptNov2nd/ui-lobbyZhanJiDtailNov2nd.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_namelabel: cc.Label,
        O_useridlabel: cc.Label,
        O_scorelabel: cc.Label

    },

    // use this for initialization
    onLoad: function onLoad() {
        //this.setDetailNovBeginFunc();  //不要在这里初始化，cc.instantiate会延迟调用onLoad
    },

    setDetailNovBeginFunc: function setDetailNovBeginFunc(name, userId, score) {
        cc.log("=======setDetailNovBeginFunc==========", name, userId, score);
        if (!name) name = "";
        if (!userId) userId = "";
        if (score == null) score = 0;
        this.O_namelabel.string = name;
        this.O_useridlabel.string = "ID:" + userId;
        this.O_scorelabel.string = score;
    }
});

cc._RF.pop();