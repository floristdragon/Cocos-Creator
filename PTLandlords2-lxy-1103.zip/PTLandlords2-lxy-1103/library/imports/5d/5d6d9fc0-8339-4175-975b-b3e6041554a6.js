"use strict";
cc._RF.push(module, '5d6d9/AgzlBdZdbs+YEFVSm', 'ui-gameChatNov2nd');
// ScriptNov2nd/GameUiScriptNov2nd/ui-gameChatNov2nd.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_editNode: cc.EditBox,
        O_ShuruNode: cc.Node,
        O_chatUserInfo: cc.Prefab,

        O_worldLayer: cc.Node,
        O_roomLayer: cc.Node,
        O_siliaoLayer: cc.Node,

        O_worldToggleNode: cc.Node,
        O_roomToggleNode: cc.Node,
        O_siliaoToggleNode: cc.Node,

        O_siliaoTips: cc.Node,

        _chattype: 1,
        _scrollViewNode: null,
        _isInRoomChat: false,
        _curPos: null
    },

    onLoad: function onLoad() {
        this._curPos = this.O_worldToggleNode.position;
    },

    openChatViewNovBeginFunc: function openChatViewNovBeginFunc() {
        this.node.active = true;
        if (this._isInRoomChat) {
            this._onRoomToggleBtnNovBeginFunc();
            this.O_roomToggleNode.active = true;
            this.node.setLocalZOrder(151);
        } else {
            var toggleWorld = this.O_worldToggleNode.getComponent(cc.Toggle);
            var toggleSiliao = this.O_siliaoToggleNode.getComponent(cc.Toggle);
            if (toggleWorld.isChecked) {
                this.onWorldToggleBtnNovBeginFunc();
            } else if (toggleSiliao.isChecked) {
                this.onSiLiaoToggleBtnNovBeginFunc();
            }
        }
    },


    onSendEventNovBeginFunc: function onSendEventNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        if (g_GameScene.rejectClickEventNovBeginFunc(3)) return;

        var sendstr = this.O_editNode.string;
        this.O_editNode.string = "";

        if (!sendstr) return;

        var talkProtab = {};
        talkProtab.ctype = 4;
        talkProtab.content = sendstr;
        talkProtab.msgtype = this._chattype;
        if (talkProtab.msgtype == 2) {
            talkProtab.gameId = g_RoomManager.getCurGameIdNovBeginFunc();
            talkProtab.roomId = g_RoomManager.getCurRoomIdNovBeginFunc();
        }
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SSendChatMsg, talkProtab);

        cc.log("=============onSendEventNovBeginFunc========this._chattype======", this._chattype);
    },

    onWorldToggleBtnNovBeginFunc: function onWorldToggleBtnNovBeginFunc(event) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        this.O_worldLayer.active = true;
        this.O_siliaoLayer.active = false;
        this.O_roomLayer.active = false;
        this._chattype = 1;
        this.O_ShuruNode.active = true;
        cc.log("=============onWorldToggleBtnNovBeginFunc========this._chattype======", this._chattype);
    },

    onSiLiaoToggleBtnNovBeginFunc: function onSiLiaoToggleBtnNovBeginFunc(event) {
        this.O_siliaoTips.active = false;
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SReqChatMsg);
        this.O_worldLayer.active = false;
        this.O_siliaoLayer.active = true;
        this.O_roomLayer.active = false;
        this._chattype = 3;
        this.O_ShuruNode.active = false;
        cc.log("=============onSiLiaoToggleBtnNovBeginFunc========this._chattype======", this._chattype);
    },

    _onRoomToggleBtnNovBeginFunc: function _onRoomToggleBtnNovBeginFunc(event) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        this.O_worldLayer.active = false;
        this.O_siliaoLayer.active = false;
        this.O_roomLayer.active = true;
        this._chattype = 2;
        this.O_ShuruNode.active = true;

        if (this._isInRoomChat) {
            this.O_worldToggleNode.active = false;
            var worldtoggle = this.O_worldToggleNode.getComponent(cc.Toggle);
            worldtoggle.isChecked = false;

            this.O_siliaoToggleNode.active = false;
            var siliaotoggle = this.O_siliaoToggleNode.getComponent(cc.Toggle);
            siliaotoggle.isChecked = false;

            this.O_roomToggleNode.position = this._curPos;
        }
        cc.log("=============_onRoomToggleBtnNovBeginFunc========this._chattype======", this._chattype);
    },
    addChatMsgNovBeginFunc: function addChatMsgNovBeginFunc(msgtab) {
        if (msgtab.msgtype == 1) {
            this._scrollViewNode = this.node.getChildByName('worldLayer').getComponent('ui-scrollViewNov2nd');
            this._scrollViewNode.setMoveAddNodeNovBeginFunc(true);
            this._scrollViewNode.setLimitNodeMaxNovBeginFunc(30);
        } else if (msgtab.msgtype == 2) {
            this._scrollViewNode = this.node.getChildByName('roomLayer').getComponent('ui-scrollViewNov2nd');
            this._scrollViewNode.setMoveAddNodeNovBeginFunc(true);
            this._scrollViewNode.setLimitNodeMaxNovBeginFunc(30);
        } else if (msgtab.msgtype == 3) {
            this._scrollViewNode = this.node.getChildByName('siliaoLayer').getComponent('ui-scrollViewNov2nd');
            this._scrollViewNode.setMoveAddNodeNovBeginFunc(true);
            this._scrollViewNode.setLimitNodeMaxNovBeginFunc(30);
        }

        var infoNode = cc.instantiate(this.O_chatUserInfo);
        var infoscript = infoNode.getComponent('ui-gameChatInfoNov2nd');
        infoscript.setTalkInfoNovBeginFunc(msgtab);

        this._scrollViewNode.addScrollNodeNovBeginFunc(infoNode, 0);
        cc.log("=======onProtAddTalks==========msgtab=========", msgtab);
    },


    onHideChatPanelNovBeginFunc: function onHideChatPanelNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.node.active = false;
    },

    showSiliaoTipsNovBeginFunc: function showSiliaoTipsNovBeginFunc(flag) {
        cc.log("========siliaoFlag==================", flag);
        if (flag) {
            this.O_siliaoTips.active = true;
        }
    },
    hideSiLiaoTipsNovBeginFunc: function hideSiLiaoTipsNovBeginFunc() {
        this.O_siliaoTips.active = false;
    },

    setRoomChatStateNovBeginFunc: function setRoomChatStateNovBeginFunc(isRoom) {
        this._isInRoomChat = isRoom;
    }
});

cc._RF.pop();