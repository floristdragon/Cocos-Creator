"use strict";
cc._RF.push(module, '017b4Dl4mdHMIrHnVoWPY3D', 'ui-chatUserInfoNov2nd');
// ScriptNov2nd/GameUiScriptNov2nd/ui-chatUserInfoNov2nd.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_userId: cc.Label,
        O_siliaoPrefab: cc.Prefab
    },

    // use this for initialization
    initNovBeginFunc: function initNovBeginFunc(userId) {
        this.O_userId.string = userId;
    },

    onCloseEventNovBeginFunc: function onCloseEventNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.node.active = false;
    },

    onShenqingEvent: function onShenqingEvent() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        //发送申请好友协议
        var idtoProt = {};
        idtoProt.userId = this.O_userId.string;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SReqAddFriend, idtoProt);

        cc.log("======onShenqingEvent========idtoProt========", idtoProt);
    },

    onSiliaoEvent: function onSiliaoEvent() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        this.node.active = false;
        var siliaoNode = cc.instantiate(this.O_siliaoPrefab);
        var canNode = cc.director.getScene();
        siliaoNode.parent = canNode.getChildByName('Canvas');
        siliaoNode.setLocalZOrder(11);
        var siliaoScript = siliaoNode.getComponent('ui-lobbyPrivateChatNov2nd');
        siliaoScript.initNovBeginFunc(this.O_userId.string);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();