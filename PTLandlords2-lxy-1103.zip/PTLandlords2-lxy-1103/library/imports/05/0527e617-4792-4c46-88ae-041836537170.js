"use strict";
cc._RF.push(module, '0527eYXR5JMRoiuBBg2U3Fw', 'ui-classicPokerCardNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/DdzLogicScriptNov2nd/classicDdzLogicNov2nd/ui-classicPokerCardNov2nd.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_touchcard: cc.Node,
        O_pointnode: cc.Node,

        _cardValue: 0,
        _backPosition: null,
        _isMoveUp: false,
        _isMoveUpBack: false
    },

    // use this for initialization
    onLoad: function onLoad() {
        this._backPosition = new cc.Vec2(this.O_touchcard.position.x, this.O_touchcard.position.y);
        this._isMoveUp = false;
        this.showPointTipNovBeginFunc(false);
    },
    setCardScaleNovBeginFunc: function setCardScaleNovBeginFunc(scale) {
        this.node.scale = scale;
    },
    setCardWidthNovBeginFunc: function setCardWidthNovBeginFunc(width) {
        this.node.width = width;
    },
    setCardHeightNovBeginFunc: function setCardHeightNovBeginFunc(height) {
        this.node.height = height;
    },
    showPointTipNovBeginFunc: function showPointTipNovBeginFunc(isVisible) {
        this.O_pointnode.active = isVisible;
    },
    setCardValueNovBeginFunc: function setCardValueNovBeginFunc(value, isRangpai) {
        var self = this;
        cc.log("========setCardValueNovBeginFunc============", value, isRangpai);
        if (!value) value = -1;
        this._cardValue = value;
        var toSpUrl = void 0;
        if (isRangpai) {
            toSpUrl = g_CLDDZGameData.getRangPokerFramePathNovBeginFunc(true);
        } else {
            toSpUrl = g_CLDDZGameData.getPokerFramePathNovBeginFunc(true, this._cardValue, true);
        }
        var texture = cc.textureCache.addImage(toSpUrl);
        var toSprite = self.O_touchcard.getComponent(cc.Sprite);
        toSprite.spriteFrame = new cc.SpriteFrame(texture);
        // cc.loader.loadRes(toSpUrl, function(err, texture){
        //     toSprite.spriteFrame = new cc.SpriteFrame(texture);
        // });
    },
    getCardValueNovBeginFunc: function getCardValueNovBeginFunc() {
        return this._cardValue;
    },
    onUnTouchCardNovBeginFunc: function onUnTouchCardNovBeginFunc() {
        this._isMoveUpBack = this._isMoveUp;
        this._isTouchCard = false;
    },
    onCheckTouchNovBeginFunc: function onCheckTouchNovBeginFunc(touchPos, touchType) {
        if (touchType == 1) {
            return this._priTouchBeginNovBeginFunc(touchPos);
        } else if (touchType == 2) {
            return this._priTouchMoveNovBeginFunc(touchPos);
        } else if (touchType == 3) {
            return this._priTouchEndNovBeginFunc(touchPos);
        }
    },
    isCardMoveUpNovBeginFunc: function isCardMoveUpNovBeginFunc() {
        return this._isMoveUp;
    },
    moveUpCardNovBeginFunc: function moveUpCardNovBeginFunc() {
        this._isMoveUp = true;
        this.O_touchcard.position = new cc.Vec2(this._backPosition.x, this._backPosition.y + 15);
    },
    moveDownCardNovBeginFunc: function moveDownCardNovBeginFunc(delay) {
        this._isMoveUp = false;
        var topos = new cc.Vec2(this._backPosition.x, this._backPosition.y);
        if (!delay) {
            this.O_touchcard.position = topos;
        } else {
            this.O_touchcard.runAction(cc.moveTo(delay, topos));
        }
    },

    ////////////////////////////////////////////////////////////////////////
    _isTouchInNovBeginFunc: function _isTouchInNovBeginFunc(touchPos) {
        var toPos = this.O_touchcard.convertToNodeSpace(touchPos);
        var toRect = new cc.Rect(0, 0, this.O_touchcard.width, this.O_touchcard.height);
        //cc.log("======_isTouchInNovBeginFunc====111=====", toPos, toRect);
        if (toRect.contains(toPos)) {
            //cc.log("======_isTouchInNovBeginFunc====222=====");
            return true;
        }
        return false;
    },
    _priTouchBeginNovBeginFunc: function _priTouchBeginNovBeginFunc(touchPos) {
        if (this._isTouchInNovBeginFunc(touchPos)) {
            this._isMoveUpBack = this._isMoveUp;
            return true;
        }
        return false;
    },
    _priTouchMoveNovBeginFunc: function _priTouchMoveNovBeginFunc(touchPos) {
        if (this._isTouchInNovBeginFunc(touchPos)) {
            if (this._isMoveUpBack != this._isMoveUp) return true;
            this._priMoveReverseCardNovBeginFunc();
            return true;
        }
        this._isMoveUpBack = this._isMoveUp;
        return false;
    },
    _priTouchEndNovBeginFunc: function _priTouchEndNovBeginFunc(touchPos) {
        if (this._isTouchInNovBeginFunc(touchPos)) {
            if (this._isMoveUpBack != this._isMoveUp) return true;
            this._priMoveReverseCardNovBeginFunc();
            return true;
        }
        return false;
    },
    _priMoveReverseCardNovBeginFunc: function _priMoveReverseCardNovBeginFunc() {
        if (!this._isMoveUp) {
            this.moveUpCardNovBeginFunc();
        } else {
            this.moveDownCardNovBeginFunc();
        }
    }
});

cc._RF.pop();