"use strict";
cc._RF.push(module, '191936EiUxCL6k8fMALDcOb', 'ui-erRenDdzSceneNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/DdzLogicScriptNov2nd/erRenDdzLogicNov2nd/ui-erRenDdzSceneNov2nd.js

"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

require("erRenDdzGameDataNov2nd");

var GameRuleLogic = require("DdzRuleLogicNov2nd");
var STATUS_READY = 0; //准备
var STATUS_SENDCARD = 1; //发牌
var STATUS_QIANGDIZHU = 2; //抢地主
var STATUS_OUTCARD = 3; //出牌
var STATUS_GAMEFINISH = 4; //游戏结束
cc.Class({
    extends: require("ui-roomSceneNov2nd"),

    properties: {
        O_controlbtnprefab: cc.Prefab,
        O_gameresultprefab: cc.Prefab,

        O_userInfoPrefab: cc.Prefab,

        O_settingPrefab: cc.Prefab,

        //////////////////////////////////////
        _backgroundScipt: null,
        _ctlbuttonScript: null,
        _rangtipScript: null,
        _gameresultScript: null,
        _dispcardScript: null

    },

    // use this for initialization
    onLoad: function onLoad() {
        this._super(); //调用父类的onLoad
        this.setChatRoomStateNovBeginFunc(true);
        //背景音乐
        g_ERDDZGameData.playBackgroundMusicNovBeginFunc();

        var gameId = g_RoomManager.getCurGameIdNovBeginFunc();
        var roomId = g_RoomManager.getCurRoomIdNovBeginFunc();
        var selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        var roominfo = g_RoomManager.getGameRoomInfoNovBeginFunc(gameId, roomId);

        var selfSeatNo = roominfo.findUserSeatNoNovBeginFunc(selfUserId);
        g_ERDDZGameData.initNovBeginFunc(gameId, roomId, selfSeatNo);
        cc.log("=======DdzResNov2nd==mainscene=11====", gameId, roomId, selfUserId);

        //////////////////////////////////////////////////////////
        this._cplayerArray = [];
        var maxPlayer = g_ERDDZGameData.getMaxPlayerNovBeginFunc();
        var toSeatNo = selfSeatNo;
        for (var i = 0; i < maxPlayer; i++) {
            var playerNo = i + 1;
            var playerNode = this.node.getChildByName("player" + playerNo);
            playerNode.setLocalZOrder(100);
            console.log("=====111111=======", toSeatNo, selfSeatNo, playerNo);
            var cplayerhandler = playerNode.getComponent("ui-erRenDdzPlayerNov2nd");
            cplayerhandler.initUiNovBeginFunc(toSeatNo, playerNode);
            g_ERDDZGameData.setPlayerUiNovBeginFunc(cplayerhandler, i, toSeatNo);

            toSeatNo = g_ERDDZGameData.getNextSeatNoNovBeginFunc(toSeatNo);
        };
        this._backgroundScipt = this.getComponent("ui-erRenDdzBackgroundNov2nd");
        this._backgroundScipt.showBaseTipNovBeginFunc();

        this._rangtipScript = this.getComponent("ui-erRenDdzRangTipNov2nd");
        this._rangtipScript.showQiangDZTipNovBeginFunc(false);

        this._dispcardScript = this.getComponent("ui-erRenDdzDispcardNov2nd");
        cc.log("=========DdzResNov2nd==mainscene====22====", this._dispcardScript);
        /////////////////////////////////////////////////////////////////
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_ErRenDDZ, null, this.onProtSocketMessageNovBeginFunc, this);

        /////////////////////////////////////////////////////////////////
        //场景加载完毕，开始请求场景协议
        var toProtData = {};
        toProtData.gameId = g_ERDDZGameData.getGameIdNovBeginFunc();
        toProtData.roomId = g_ERDDZGameData.getRoomIDNovBeginFunc();
        cc.log("=========requestGameStatus===", toProtData);
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqGameStatus, toProtData);
    },
    onDestroyNovBeginFunc: function onDestroyNovBeginFunc() {
        cc.log("=============onDestroyNovBeginFunc==============");
    },
    _resetAllUiNovBeginFunc: function _resetAllUiNovBeginFunc() {
        if (this._ctlbuttonScript) {
            this._getControlBtnNovBeginFunc().hideAllButtonNovBeginFunc();
        }
        if (this._gameresultScript) {
            this._getGameResultNovBeginFunc().showResultNovBeginFunc(false);
        }
        g_ERDDZGameData.resetInitNovBeginFunc();
        this._rangtipScript.hideAllTipNovBeginFunc();
        this._backgroundScipt.showThreeBackCardNovBeginFunc(false);
        this._backgroundScipt.showSmallBackCardNovBeginFunc(false);
        this._backgroundScipt.showBaseTipNovBeginFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoNovBeginFunc();
        var maxPlayer = g_ERDDZGameData.getMaxPlayerNovBeginFunc();
        for (var i = 0; i < maxPlayer; i++) {
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
            playerui.resetUiNovBeginFunc();

            var userinfo = roominfo.getUserInfoNovBeginFunc(i);
            cc.log("======_resetAllUiNovBeginFunc====111=======", i, userinfo);
            if (userinfo) {
                playerui.showUserInfoNovBeginFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
            } else {
                playerui.showUserInfoNovBeginFunc(false);
            }
        }
    },
    _requestGameReadyNovBeginFunc: function _requestGameReadyNovBeginFunc(delaytime) {
        var self = this;
        var readyNovBeginFunc = function readyNovBeginFunc() {
            //在这里进入房间后要发协议，自己默认进入房间就准备
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SReady);
        };
        if (!delaytime || delaytime <= 0) {
            readyNovBeginFunc();
        } else {
            this.scheduleOnce(readyNovBeginFunc, delaytime);
        }
    },
    onSettingBtnNovBeginFunc: function onSettingBtnNovBeginFunc(event) {
        var settingPlane = cc.instantiate(this.O_settingPrefab);
        this.node.addChild(settingPlane, 1000);
    },
    onShowUserInfoPanelNovBeginFunc: function onShowUserInfoPanelNovBeginFunc(node, detail) {
        cc.log("========onShowUserInfoPanelNovBeginFunc=========", node, detail);
        var seatNo = g_ERDDZGameData.getSelfSeatNoNovBeginFunc();
        if (detail == 2) {
            seatNo = g_ERDDZGameData.getNextSeatNoNovBeginFunc(seatNo);
        }
        var roominfo = g_ERDDZGameData.getRoomInfoNovBeginFunc();
        if (roominfo.getUserInfoNovBeginFunc(seatNo)) {
            var userInfoNode = cc.instantiate(this.O_userInfoPrefab);
            userInfoNode.parent = this.node;
            userInfoNode.setLocalZOrder(200);
            userInfoNode.getComponent("ui-erRenDdzUserInfoNov2nd").showInfoNovBeginFunc(seatNo);
        }
    },

    //////////////////////////////////////////////////////////////////////////////
    _getControlBtnNovBeginFunc: function _getControlBtnNovBeginFunc() {
        var _this = this;

        if (!this._ctlbuttonScript) {
            var ctrbtn = cc.instantiate(this.O_controlbtnprefab);
            ctrbtn.parent = this.node;
            ctrbtn.setLocalZOrder(150);
            this._ctlbuttonScript = ctrbtn.getComponent("ui-erRenDdzCtonrollBtnNov2nd");
            ctrbtn.off("outbtn-buchu");
            ctrbtn.off("outbtn-tishi");
            ctrbtn.off("outbtn-chupai");
            ctrbtn.on("outbtn-buchu", function (event) {
                _this._OutCardBuChuNovBeginFunc();
            }, this);
            ctrbtn.on("outbtn-tishi", function (event) {
                _this._OutCardTiShiNovBeginFunc();
            }, this);
            ctrbtn.on("outbtn-chupai", function (event) {
                _this._OutCardChuPaiNovBeginFunc();
            }, this);
        }
        return this._ctlbuttonScript;
    },
    _getGameResultNovBeginFunc: function _getGameResultNovBeginFunc() {
        if (!this._gameresultScript) {
            var resultnode = cc.instantiate(this.O_gameresultprefab);
            resultnode.parent = this.node;
            resultnode.setLocalZOrder(200);
            this._gameresultScript = resultnode.getComponent("ui-erRenDdzGameResultNov2nd");
        }
        return this._gameresultScript;
    },
    _OutCardBuChuNovBeginFunc: function _OutCardBuChuNovBeginFunc() {
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoNovBeginFunc();
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(selfSeatNo);
        playerui.getHandCardNovBeginFunc().clearTiShiHandCardNovBeginFunc();

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SBuChu);
    },
    _OutCardTiShiNovBeginFunc: function _OutCardTiShiNovBeginFunc() {
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoNovBeginFunc();
        var outCardTab = g_ERDDZGameData.getCurOutCardTabNovBeginFunc(true);
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(selfSeatNo);
        playerui.getHandCardNovBeginFunc().moveTiShiHandCardNovBeginFunc(outCardTab);
    },
    _OutCardChuPaiNovBeginFunc: function _OutCardChuPaiNovBeginFunc() {
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoNovBeginFunc();
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(selfSeatNo);
        playerui.getHandCardNovBeginFunc().clearTiShiHandCardNovBeginFunc();
        var outCardTab = g_ERDDZGameData.getCurOutCardTabNovBeginFunc(true);
        var outTab = playerui.getHandCardNovBeginFunc().getMoveUpCardTabNovBeginFunc(outCardTab);
        if (outTab && outTab.length > 0) {
            var toProtTab = {};
            toProtTab.cardTab = outTab;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SOutCard, toProtTab);
        } else {
            this.showPopupWindowNovBeginFunc(true, false, "提示", "出牌不符合规则！");
        }
    },

    ////////////////////////////////////////////////////////////////////////////////
    onRecvErrcodeNovBeginFunc: function onRecvErrcodeNovBeginFunc(errcode, attachtab) {
        cc.log("=======onRecvErrcodeNovBeginFunc============", errcode, attachtab);
        this.showPopupWindowNovBeginFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },

    //其他玩家进入房间会调用这里, 进入房间协议比场景协议要先到来
    onRecvEnterRoomNovBeginFunc: function onRecvEnterRoomNovBeginFunc(gameId, roomId, userId) {
        //let selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoNovBeginFunc();
        var seatNo = roominfo.findUserSeatNoNovBeginFunc(userId);
        var userinfo = roominfo.getUserInfoNovBeginFunc(seatNo);
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(seatNo);
        cc.log("==============onRecvEnterRoomNovBeginFunc==========", roomId, userId, typeof userId === "undefined" ? "undefined" : _typeof(userId), roominfo);
        playerui.showUserInfoNovBeginFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
    },
    onRecvJieSanDeskNovBeginFunc: function onRecvJieSanDeskNovBeginFunc(gameId, roomId, userId, userName, isAuto) {
        var _this2 = this;

        cc.log("======onRecvJieSanDeskNovBeginFunc==========", gameId, roomId, userId, userName, isAuto);
        if (!isAuto) {
            this.showPopupWindowNovBeginFunc(true, false, "提示", "房主已经解散了房间！", function (flag) {
                _this2.switchLobbySceneNovBeginFunc();
            }, this);
        } else {
            this.showPopupWindowNovBeginFunc(true, false, "提示", "房间局数已尽！", function (flag) {
                _this2.switchLobbySceneNovBeginFunc();
            }, this);
        }
    },
    onRecvLeaveDeskNovBeginFunc: function onRecvLeaveDeskNovBeginFunc(gameId, roomId, userId) {
        cc.log("======onRecvLeaveDeskNovBeginFunc==========", gameId, roomId, userId);
        if (userId == g_UserManager.getSelfUserIdNovBeginFunc()) {
            // this.showPopupWindowNovBeginFunc(true, false, "提示", "您已经离开房间！", (flag)=>{
            //     this.switchLobbySceneNovBeginFunc();
            // }, this);
            this.switchLobbySceneNovBeginFunc();
        }
    },

    ////////////////////////////////////////////////////////////////////////////////
    _startDispCardNovBeginFunc: function _startDispCardNovBeginFunc(beginSeatNo) {
        var maxPlayer = g_ERDDZGameData.getMaxPlayerNovBeginFunc();
        var eachNumArray = [];
        var eachPosArray = [];
        for (var i = 0; i < maxPlayer; i++) {
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
            eachNumArray.push(17);
            eachPosArray.push(playerui.getHandCardPosNovBeginFunc());
        }
        var self = this;
        this._dispcardScript.sendAllCardNovBeginFunc(beginSeatNo, eachNumArray, eachPosArray, function (seatNo, num, isEnd) {
            if (!isEnd) {
                var _playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(seatNo);
                _playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc(num);
            } else {
                g_ERDDZGameData.setHandCardSortNovBeginFunc(true);
                self._backgroundScipt.showThreeBackCardNovBeginFunc(true);
                self._backgroundScipt.showSmallBackCardNovBeginFunc(false);
                var _maxPlayer = g_ERDDZGameData.getMaxPlayerNovBeginFunc();
                for (var _i = 0; _i < _maxPlayer; _i++) {
                    var _playerui2 = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(_i);
                    _playerui2.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                }
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SSendCardFinish);
            }
        });
    },

    ////////////////////////////////////////////////////////////////////////////////
    onRecvGameStatusNovBeginFunc: function onRecvGameStatusNovBeginFunc(protTab) {
        cc.log("==========onRecvGameStatusNovBeginFunc====11=========", protTab);
        var maxPlayer = g_ERDDZGameData.getMaxPlayerNovBeginFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoNovBeginFunc();
        var selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        var selfSeatNo = roominfo.findUserSeatNoNovBeginFunc(selfUserId);
        this._resetAllUiNovBeginFunc();
        cc.log("==========onRecvGameStatusNovBeginFunc====22=========");
        if (protTab.status == STATUS_READY) {
            for (var i = 0; i < maxPlayer; i++) {
                var playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                var isReady = protTab.readyTab[i];
                if (i == selfSeatNo) isReady = true;
                playerui.showReadyTipNovBeginFunc(isReady);
            }
            this._requestGameReadyNovBeginFunc();
        } else if (protTab.status == STATUS_SENDCARD) {
            for (var _i2 = 0; _i2 < maxPlayer; _i2++) {
                g_ERDDZGameData.setHandCardTabNovBeginFunc(_i2, protTab.handCardTab[_i2], true);
                var _playerui3 = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(_i2);
                var leftnum = g_ERDDZGameData.getHandCardCountNovBeginFunc(_i2);
                _playerui3.showUserLeftCardNovBeginFunc(true, leftnum);
                _playerui3.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
            }
            this._startDispCardNovBeginFunc(selfSeatNo);
        } else if (protTab.status == STATUS_QIANGDIZHU) {
            var turnSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumNovBeginFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortNovBeginFunc(true);
            if (protTab.bankerUserId) {
                var bankSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.bankerUserId);
                g_ERDDZGameData.setDiZhuSeatNoNovBeginFunc(bankSeatNo);
            }
            for (var _i3 = 0; _i3 < maxPlayer; _i3++) {
                g_ERDDZGameData.setHandCardTabNovBeginFunc(_i3, protTab.handCardTab[_i3], true);
                var _playerui4 = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(_i3);
                var _leftnum = g_ERDDZGameData.getHandCardCountNovBeginFunc(_i3);
                _playerui4.showUserLeftCardNovBeginFunc(true, _leftnum);
                _playerui4.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                if (turnSeatNo == _i3 && turnSeatNo != selfSeatNo) {
                    _playerui4.showTimeWaitTipNovBeginFunc(true);
                } else {
                    _playerui4.showTimeWaitTipNovBeginFunc(false);
                }
            }
            this._rangtipScript.showQiangDZTipNovBeginFunc(false);
            this._rangtipScript.showRangTipNovBeginFunc();
            this._backgroundScipt.showThreeBackCardNovBeginFunc(true);
            this._backgroundScipt.showSmallBackCardNovBeginFunc(false);
            if (protTab.turnUserId == selfUserId) {
                if (protTab.isTurnJiaoDZ == 1) {
                    this._getControlBtnNovBeginFunc().showJiaoDZBtnNovBeginFunc();
                } else {
                    this._getControlBtnNovBeginFunc().showQiangDZBtnNovBeginFunc();
                    this._rangtipScript.showQiangDZTipNovBeginFunc(true);
                }
            }
            if (protTab.lastUserId != null) {
                var _playerui5 = g_ERDDZGameData.getPlayerUIByUserIdNovBeginFunc(protTab.lastUserId);
                if (protTab.isJiaoDZ == 1) {
                    _playerui5.speekJiaoDiZhuNovBeginFunc(true);
                } else {
                    _playerui5.speekQiangDiZhuNovBeginFunc(true);
                }
            }
        } else if (protTab.status == STATUS_OUTCARD) {
            g_ERDDZGameData.setBackCardNovBeginFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            var bankerSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.bankerUserId);
            var outSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.outUserId);
            var _turnSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            g_ERDDZGameData.setDiZhuSeatNoNovBeginFunc(bankerSeatNo);
            g_ERDDZGameData.setCurOutCardTabNovBeginFunc(protTab.outTab);
            g_ERDDZGameData.setQiangRangNumNovBeginFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortNovBeginFunc(true);
            for (var _i4 = 0; _i4 < maxPlayer; _i4++) {
                g_ERDDZGameData.setHandCardTabNovBeginFunc(_i4, protTab.handCardTab[_i4], true);
                var _playerui6 = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(_i4);
                _playerui6.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                _playerui6.showDiZhuTipNovBeginFunc(false);
                if (bankerSeatNo == _i4) {
                    _playerui6.showDiZhuTipNovBeginFunc(true);
                }
                if (_i4 == outSeatNo) {
                    _playerui6.getHandCardNovBeginFunc().drawOutCardNovBeginFunc(protTab.outTab);
                    _playerui6.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                } else {
                    _playerui6.getHandCardNovBeginFunc().clearOutCardNovBeginFunc();
                }
                if (_turnSeatNo == _i4 && _turnSeatNo != selfSeatNo) {
                    _playerui6.showTimeWaitTipNovBeginFunc(true);
                } else {
                    _playerui6.showTimeWaitTipNovBeginFunc(false);
                }
                var _leftnum2 = g_ERDDZGameData.getHandCardCountNovBeginFunc(_i4);
                _playerui6.showUserLeftCardNovBeginFunc(true, _leftnum2);
                if (_leftnum2 <= 3) {
                    _playerui6.showBaoJingTipNovBeginFunc(true);
                }
            }
            this._backgroundScipt.showSmallBackCardNovBeginFunc(true);
            this._rangtipScript.showQiangDZTipNovBeginFunc(false);
            this._rangtipScript.showRangTipNovBeginFunc();
            if (protTab.turnUserId == selfUserId) {
                this._getControlBtnNovBeginFunc().showOutCardBtnNovBeginFunc(protTab.mustOut == 1);
            }
        } else if (protTab.status == STATUS_GAMEFINISH) {
            //this._requestGameReadyNovBeginFunc(3);
            this._onShowGameResultNovBeginFunc(protTab.finishdata);
        }
    },
    onProtSocketMessageNovBeginFunc: function onProtSocketMessageNovBeginFunc(mainId, assistId, protTab) {
        cc.log("==========onProtSocketMessageNovBeginFunc=============", mainId, assistId, protTab);
        // AErRenDDZ_S2CBeginOut = 201;   //开始出牌
        // AErRenDDZ_S2CCallLandlord = 202;  //叫地主
        // AErRenDDZ_S2COutCard    = 203;    //出牌
        // AErRenDDZ_S2CBuChu  = 204;   //不出
        // AErRenDDZ_S2CSendCard  = 205;  //发牌
        // AErRenDDZ_S2CTuoGuan = 207;   //托管
        // AErRenDDZ_S2CGameFinish = 208;    //游戏结束
        var maxPlayer = g_ERDDZGameData.getMaxPlayerNovBeginFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoNovBeginFunc();
        var selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        var selfSeatNo = roominfo.findUserSeatNoNovBeginFunc(selfUserId);
        for (var i = 0; i < maxPlayer; i++) {
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
            playerui.showReadyTipNovBeginFunc(false);
            playerui.showTimeWaitTipNovBeginFunc(false);
            playerui.speekNothingNovBeginFunc();
        }
        this._backgroundScipt.showBaseTipNovBeginFunc();
        if (assistId == g_ProtDef.AErRenDDZ_S2CReady) {
            if (protTab.userId == selfUserId) {
                this._resetAllUiNovBeginFunc();
            }
            var _playerui7 = g_ERDDZGameData.getPlayerUIByUserIdNovBeginFunc(protTab.userId);
            _playerui7.showReadyTipNovBeginFunc(true);
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CSendCard) {
            var jiaoSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.jiaoUserId);
            for (var _i5 = 0; _i5 < maxPlayer; _i5++) {
                g_ERDDZGameData.setHandCardTabNovBeginFunc(_i5, protTab.handCardTab[_i5], false);
                var _playerui8 = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(_i5);
                _playerui8.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                if (_i5 == jiaoSeatNo && jiaoSeatNo != selfSeatNo) {
                    _playerui8.showTimeWaitTipNovBeginFunc(true);
                }
            }
            this._startDispCardNovBeginFunc(selfSeatNo);
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CCallLandlord) {
            var turnSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumNovBeginFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortNovBeginFunc(true);
            this._getControlBtnNovBeginFunc().hideAllButtonNovBeginFunc();
            this._backgroundScipt.showThreeBackCardNovBeginFunc(true);
            this._backgroundScipt.showSmallBackCardNovBeginFunc(false);

            var _jiaoSeatNo = -1;
            if (protTab.userId) {
                //当发牌完成后，会发送一个userId为空的首次叫地主的协议过来，通知开始叫地主
                _jiaoSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.userId);
                this._rangtipScript.showQiangDZTipNovBeginFunc(true);
            }
            if (turnSeatNo == selfSeatNo && !protTab.isEnd) {
                if (protTab.isTurnJiaoDZ == 1) {
                    this._getControlBtnNovBeginFunc().showJiaoDZBtnNovBeginFunc();
                } else {
                    this._getControlBtnNovBeginFunc().showQiangDZBtnNovBeginFunc();
                }
            }
            for (var _i6 = 0; _i6 < maxPlayer; _i6++) {
                var _playerui9 = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(_i6);

                var leftnum = g_ERDDZGameData.getHandCardCountNovBeginFunc(_i6);
                _playerui9.showUserLeftCardNovBeginFunc(true, leftnum);
                if (_i6 == turnSeatNo && turnSeatNo != selfSeatNo) {
                    _playerui9.showTimeWaitTipNovBeginFunc(true);
                }
                _playerui9.speekNothingNovBeginFunc();
                if (_i6 == _jiaoSeatNo && protTab.isJiaoDZ != null) {
                    if (protTab.isJiaoDZ == 1) {
                        _playerui9.speekJiaoDiZhuNovBeginFunc(protTab.isCall == 1);
                        g_ERDDZGameData.playJiaoDiZhuNovBeginFunc(protTab.userId, protTab.isCall == 1);
                    } else {
                        _playerui9.speekQiangDiZhuNovBeginFunc(protTab.isCall == 1);
                        g_ERDDZGameData.playQiangDiZhuNovBeginFunc(protTab.userId, protTab.isCall == 1);
                    }
                }
            }
            this._rangtipScript.showRangTipNovBeginFunc();
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CBeginOut) {
            g_ERDDZGameData.setBackCardNovBeginFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            var bankSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.bankerUserId);
            g_ERDDZGameData.setHandCardSortNovBeginFunc(true);
            g_ERDDZGameData.setDiZhuSeatNoNovBeginFunc(bankSeatNo);
            g_ERDDZGameData.addHandCardTabNovBeginFunc(bankSeatNo, protTab.backCardTab);
            g_ERDDZGameData.playGameStartNovBeginFunc();
            this._rangtipScript.showQiangDZTipNovBeginFunc(false);
            this._rangtipScript.showRangTipNovBeginFunc();
            this._backgroundScipt.showThreeBackCardNovBeginFunc(true);
            this._backgroundScipt.recoverBackCardNovBeginFunc();
            if (selfSeatNo == bankSeatNo) {
                this._getControlBtnNovBeginFunc().showOutCardBtnNovBeginFunc(true);
            }

            for (var _i7 = 0; _i7 < maxPlayer; _i7++) {
                var _playerui10 = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(_i7);
                _playerui10.showDiZhuTipNovBeginFunc(false);
                _playerui10.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                if (_i7 == bankSeatNo) {
                    _playerui10.showDiZhuTipNovBeginFunc(true);
                    _playerui10.getHandCardNovBeginFunc().moveAddActionCardNovBeginFunc(protTab.backCardTab);
                    if (_i7 == selfSeatNo) {
                        _playerui10.showTimeWaitTipNovBeginFunc(false);
                    } else {
                        _playerui10.showTimeWaitTipNovBeginFunc(true);
                    }
                }
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2COutCard) {
            var outSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.userId);
            var _turnSeatNo2 = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            var outtype = GameRuleLogic.getCardTabCardTypeNovBeginFunc(protTab.cardTab);
            if (protTab.newTurn == 1 || Math.random() * 100 < 50) {
                g_ERDDZGameData.playOutCardNovBeginFunc(protTab.userId, protTab.cardTab[0], outtype);
            } else {
                g_ERDDZGameData.playEatCardDaNiNovBeginFunc(protTab.userId);
            }
            g_ERDDZGameData.playOutTypeNovBeginFunc(outtype);

            g_ERDDZGameData.setCurOutCardTabNovBeginFunc(protTab.cardTab);
            g_ERDDZGameData.removeCardTabNovBeginFunc(outSeatNo, protTab.cardTab);
            g_ERDDZGameData.setHandCardSortNovBeginFunc(true);
            this._backgroundScipt.showThreeBackCardNovBeginFunc(false);
            this._rangtipScript.showQiangDZTipNovBeginFunc(false);
            this._getControlBtnNovBeginFunc().hideAllButtonNovBeginFunc();
            for (var _i8 = 0; _i8 < maxPlayer; _i8++) {
                var _playerui11 = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(_i8);
                if (_i8 == outSeatNo) {
                    _playerui11.getHandCardNovBeginFunc().drawOutCardNovBeginFunc(protTab.cardTab);
                    _playerui11.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                } else {
                    _playerui11.getHandCardNovBeginFunc().clearOutCardNovBeginFunc();
                }
                if (_i8 == _turnSeatNo2 && _turnSeatNo2 == selfSeatNo || _i8 == outSeatNo) {
                    _playerui11.showTimeWaitTipNovBeginFunc(false);
                } else {
                    _playerui11.showTimeWaitTipNovBeginFunc(true);
                }
                var _leftnum3 = g_ERDDZGameData.getHandCardCountNovBeginFunc(_i8);
                _playerui11.showUserLeftCardNovBeginFunc(true, _leftnum3);
                if (_leftnum3 <= 3) {
                    _playerui11.showBaoJingTipNovBeginFunc(true);
                }
            }
            if (_turnSeatNo2 == selfSeatNo) {
                this._getControlBtnNovBeginFunc().showOutCardBtnNovBeginFunc(false);
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CBuChu) {
            var theSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.userId);
            var _turnSeatNo3 = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            g_ERDDZGameData.setCurOutCardTabNovBeginFunc(null);
            g_ERDDZGameData.playNotOutNovBeginFunc(protTab.userId);
            this._getControlBtnNovBeginFunc().hideAllButtonNovBeginFunc();
            for (var _i9 = 0; _i9 < maxPlayer; _i9++) {
                var _playerui12 = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(_i9);
                if (_i9 == theSeatNo) {
                    _playerui12.speekBuChuNovBeginFunc();
                }
                _playerui12.getHandCardNovBeginFunc().clearOutCardNovBeginFunc();
            }
            if (_turnSeatNo3 == selfSeatNo) {
                this._getControlBtnNovBeginFunc().showOutCardBtnNovBeginFunc(true);
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CTuoGuan) {} else if (assistId == g_ProtDef.AErRenDDZ_S2CGameFinish) {
            g_ERDDZGameData.playGameResultNovBeginFunc(protTab.winUserId == selfUserId);
            this._onShowGameResultNovBeginFunc(protTab);
            //游戏正常结束，调用基类函数
            var gameId = roominfo.getGameIdNovBeginFunc();
            var roomId = roominfo.getRoomIDNovBeginFunc();
            this.onBaseGameFinishNovBeginFunc(gameId, roomId);
        }
    },

    ////////////////////////////////////////////////////////////////////
    _onShowGameResultNovBeginFunc: function _onShowGameResultNovBeginFunc(protTab) {
        this._resetAllUiNovBeginFunc();
        g_ERDDZGameData.setHandCardSortNovBeginFunc(true);
        g_ERDDZGameData.setBackCardNovBeginFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
        this._backgroundScipt.showSmallBackCardNovBeginFunc(true);
        var maxPlayer = g_ERDDZGameData.getMaxPlayerNovBeginFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoNovBeginFunc();
        var bankerSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.bankerUserId);
        var winSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.winUserId);
        for (var i = 0; i < maxPlayer; i++) {
            g_ERDDZGameData.setHandCardTabNovBeginFunc(i, protTab.handCardTab[i], true);
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
            playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc(null, true);
            playerui.showDiZhuTipNovBeginFunc(false);
            if (bankerSeatNo == i) {
                playerui.showDiZhuTipNovBeginFunc(true);
            }
            if (i == winSeatNo) {
                playerui.getHandCardNovBeginFunc().drawOutCardNovBeginFunc(protTab.lastOutTab);
            }
            roominfo.updateUserGoldNovBeginFunc(i, protTab.winScore[i]);
            playerui.showTotalScoreNovBeginFunc(true, protTab.winScore[i]);
        }
        this._getGameResultNovBeginFunc().showResultNovBeginFunc(true, protTab);
    }
});

cc._RF.pop();