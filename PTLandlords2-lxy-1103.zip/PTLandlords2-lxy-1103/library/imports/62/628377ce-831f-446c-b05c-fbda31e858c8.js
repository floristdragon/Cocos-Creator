"use strict";
cc._RF.push(module, '62837fOgx9EbLBc+9ox6FjI', 'ui-lobbyZhanJiLineNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/lobbyLogicScriptNov2nd/ui-lobbyZhanJiLineNov2nd.js

"use strict";

var gameconfig = require("gameConfigNov2nd");
cc.Class({
    extends: cc.Component,

    properties: {
        O_gameidlabel: cc.Label,
        O_roomidlabel: cc.Label,
        O_timelabel: cc.Label,

        _userdatalist: null
    },

    setDataNovBeginFunc: function setDataNovBeginFunc(gameid, roomid, jushu, stime, userlist) {
        this.O_gameidlabel.string = gameconfig[parseInt(gameid)].desc;
        this.O_roomidlabel.string = roomid + "-" + jushu;
        this._userdatalist = userlist;
        var date = new Date(stime * 1000);
        var extfunc = function extfunc(time) {
            if (time < 10) return "0" + time;
            return time + "";
        };
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        this.O_timelabel.string = ' ' + year + "/" + extfunc(month) + "/" + extfunc(date.getDate()) + "-" + extfunc(date.getHours()) + ":" + extfunc(date.getMinutes()) + ' ';
    },
    onClickBtnNovBeginFunc: function onClickBtnNovBeginFunc() {
        cc.log("=======onClickBtnNovBeginFunc========", this._userdatalist);
        if (this._userdatalist) {
            this.node.emit("zhanjiline-event", this._userdatalist);
        }
    }
});

cc._RF.pop();