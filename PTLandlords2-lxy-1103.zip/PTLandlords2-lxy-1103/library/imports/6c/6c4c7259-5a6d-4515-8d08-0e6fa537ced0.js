"use strict";
cc._RF.push(module, '6c4c7JZWm1FFY0IDm+lN87Q', 'ui-lobbyActivityNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/lobbyLogicScriptNov2nd/ui-lobbyActivityNov2nd.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        label: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {},

    onCloseClickNovBeginFunc: function onCloseClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();