"use strict";
cc._RF.push(module, '3a3adUwKZFM3Ih2zOnzNPz9', 'ui-classicGameResultNov2nd');
// ScriptNov2nd/GameLogicScriptNov2nd/DdzLogicScriptNov2nd/classicDdzLogicNov2nd/ui-classicGameResultNov2nd.js

"use strict";

var nativeExtend = require("nativeExtendNov2nd");
cc.Class({
    extends: cc.Component,

    properties: {
        O_giveuptip: cc.Node,
        O_winnode: cc.Node,
        O_lossnode: cc.Node,

        O_winAniNode: cc.Node,
        O_lossAniNode: cc.Node,
        O_springAniNode: cc.Node,
        O_jiesuannode: cc.Node,

        O_zongbeishulabel: cc.Label,
        O_qiangdzlabel: cc.Label,
        O_dipailabel: cc.Label,
        O_zhadanlabel: cc.Label,
        O_chuntianlabel: cc.Label,
        O_rangxianlabel: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.showResultNovBeginFunc(false);
    },
    showResultNovBeginFunc: function showResultNovBeginFunc(isVisible, isGameWin, resultdata) {
        this.node.active = isVisible;
        if (!isVisible) {
            return;
        }
        var selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        var isGiveUp = false;
        this.O_giveuptip.active = isGiveUp;
        this.O_winnode.active = isGameWin;
        this.O_lossnode.active = !isGameWin;

        this.O_lossAniNode.active = false;
        this.O_springAniNode.active = false;
        this.O_winAniNode.active = false;
        if (!isGameWin) {
            this.O_lossAniNode.active = true;
            this.O_lossAniNode.getComponent(cc.Animation).play();
        } else {
            if (resultdata.springBeiShu > 0) {
                this.O_springAniNode.active = true;
                this.O_springAniNode.getComponent(cc.Animation).play();
            } else {
                this.O_winAniNode.active = true;
                this.O_winAniNode.getComponent(cc.Animation).play();
            }
        }

        this.O_zongbeishulabel.string = "X" + resultdata.totalBeiShu;
        this.O_qiangdzlabel.string = "X" + resultdata.qiangdzBeiShu;
        this.O_dipailabel.string = "X" + resultdata.dipaiBeiShu;
        this.O_zhadanlabel.string = "X" + resultdata.zhadanBeiShu;
        this.O_chuntianlabel.string = "X" + resultdata.springBeiShu;
        this.O_rangxianlabel.string = "X0";

        this.O_jiesuannode.active = true;
        this.O_jiesuannode.opacity = 0;
        this.O_jiesuannode.runAction(cc.sequence(cc.delayTime(1.0), cc.fadeIn(0.5)));
    },

    onExitGameBtnNovBeginFunc: function onExitGameBtnNovBeginFunc(event) {
        this.showResultNovBeginFunc(false);
        var toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIdNovBeginFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIdNovBeginFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqLeaveDesk, toProtTab);
    },
    onShareBtnNovBeginFunc: function onShareBtnNovBeginFunc(event) {
        nativeExtend.screenShoot(function (path, w, h) {
            nativeExtend.shareImageNative("image", path, "");
        });
    },
    onContinueBtnNovBeginFunc: function onContinueBtnNovBeginFunc(event) {
        this.showResultNovBeginFunc(false);

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ClassicDDZ, g_ProtDef.AClassicDDZ_C2SReady);
    }
});

cc._RF.pop();