//var utilbase64 = require("utilBase64Nov2nd");
var globalConfig = require("globalConfig");

var exSecretkey= 'open_fwclient'; // 加密密钥
var exConfigKey = "ConfigManager_local";

var exLocalConfPath = "";
var exConfigDataTab = null;
var fwriteStorageTabNov2nd = function(datatab){
    if(!datatab) return ;
    let stringdata = JSON.stringify(datatab);
    //js.fileUtils().writeStringToFile(stringdata, exLocalConfPath);
    var encrypted = stringdata;//utilEncryptJS.encryptWithAES(stringdata,exSecretkey,256);
    cc.sys.localStorage.setItem(exConfigKey, encrypted);
};
var freadStorageTabNov2nd = function(){
    // exLocalConfPath = jsb.fileUtils().getWritablePath() + "userconfig";
    // let datastr = jsb.fileUtils().getStringFromFile(exLocalConfPath);
    let datastr = cc.sys.localStorage.getItem(exConfigKey);
    if(datastr && datastr!=""){
        //return JSON.parse(utilEncryptJS.decryptWithAES(cipherText,exSecretkey));
        return JSON.parse(datastr);
    }
    return {};
};
module.exports = {
    ////////////////////////////////////////////////////
    //用户读写本地数据
    _checkLoadConfigNov2nd(){
        if(!exConfigDataTab){
            exConfigDataTab = freadStorageTabNov2nd();
        }
    },
    getGlobalConfigNov2nd(key) {
        return globalConfig[key];
    },
    getHotfixVersionNov2nd(){
        let cifVersion = this.getKeyNov2nd("CIFHotFixVersion", "0");
        let curVersion = this.getGlobalConfigNov2nd("HotFixVersion");
        let toVersion;
        do{
            if(!cifVersion) {
                toVersion = curVersion; //如果没有写配置，则用代码里面的配置
                break;
            }
            if(curVersion>cifVersion) {
                toVersion = curVersion; //如果代码里面配置比本地配置高，则用高版本
                break;
            }
            toVersion = cifVersion; //否则用本地配置版本
        }while(0);
        return toVersion;
    },
    setHotfixVersionNov2nd(version){
        this.setKeyNov2nd("CIFHotFixVersion", version+"");
        this.flushNov2nd();
    },
    getKeyNov2nd(key, defaultData){
        this._checkLoadConfigNov2nd();
        if(!exConfigDataTab[key]){
            exConfigDataTab[key] = defaultData;
        }
        return exConfigDataTab[key];
    },
    
    setKeyNov2nd(key, data, autoflush){
        console.log("======g_ConfigManager==setKeyNov2nd===========", key, data);
        this._checkLoadConfigNov2nd();
        exConfigDataTab[key] = data;
        if(autoflush){
            this.flushNov2nd();
        }
    },
    
    flushNov2nd(){
        fwriteStorageTabNov2nd(exConfigDataTab);
    },
    /////////////////////////////////////////////////////////////////////////
    //登陆相关
    setLoginAccountNov2nd(account, pwd){
        this.setKeyNov2nd("TLOGINACCOUNT", account);
        this.setKeyNov2nd("TLOGINPWD", pwd);
        this.flushNov2nd();
    },
    getLoginAccountNov2nd(){
        let loginAcc = this.getKeyNov2nd("TLOGINACCOUNT", "")
        let loginPwd = this.getKeyNov2nd("TLOGINPWD", "")
        return [loginAcc, loginPwd];
    },
    setIsAlreadyLoginNov2nd(flag){
        this.m_bIsAlreadyLogin = flag;
    },
    getIsAlreadyLoginNov2nd(){
        return this.m_bIsAlreadyLogin;
    },
    checkIsCanLoginLobbyNovBeginFunc(maxWait) {
        if(!this.m_iLoginLobbyFlag){
            this.m_iLoginLobbyFlag = 0;
        }
        this.m_iLoginLobbyFlag = this.m_iLoginLobbyFlag + 1;
        return this.m_iLoginLobbyFlag==maxWait;
    },
    resetIsCanLoginLobbyNovBeginFunc(){
        this.m_iLoginLobbyFlag = 0;
    },
}
