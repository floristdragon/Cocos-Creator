
var configManager = require("ConfigManagerNov2nd");
var nativeVoice = require("nativeVoiceNov2nd");

var CIFMusicKEY = "Music_PLAY";
var CIFEffectKEY = "Effect_PLAY";
var CIFMusicVolKEY = "Music_Volumn";
var CIFEffectVolKEY = "Music_Volumn";
var mAllEffectTab = {};
var lisSoundOpenNovBeginFunc = function(isMusic){
    if(isMusic){
        return configManager.getKeyNov2nd(CIFMusicKEY, "1")=="1";
    }else{
        return configManager.getKeyNov2nd(CIFEffectKEY, "1")=="1";
    }
};
var lsetSoundOpenNovBeginFunc = function(isMusic, isOpen){
    let openflag = "0";
    if(isOpen) openflag = "1";
    if(isMusic){
        configManager.setKeyNov2nd(CIFMusicKEY, openflag);
    }else{
        configManager.setKeyNov2nd(CIFEffectKEY, openflag);
    }
    configManager.flushNov2nd();
};
var lgetSoundVolumnNovBeginFunc = function(isMusic){
    let toVolumn;
    if(isMusic){
        toVolumn = configManager.getKeyNov2nd(CIFMusicVolKEY, "1");
    }else{
        toVolumn = configManager.getKeyNov2nd(CIFEffectVolKEY, "1");
    }
    return parseFloat(toVolumn);
};
var lsetSoundVolumnNovBeginFunc = function(isMusic, volumn){
    if(volumn<0) volumn = 0;
    if(volumn>1.0) volumn = 1.0;
    let toVolumn = ""+volumn;
    if(isMusic){
        configManager.setKeyNov2nd(CIFMusicVolKEY, toVolumn);
    }else{
        configManager.setKeyNov2nd(CIFEffectVolKEY, toVolumn);
    }
    configManager.flushNov2nd();
};
///////////////////////////////////////////////////////////////////////////
//用于操控音效的声音大小
var lsetAllEffectVolumnNovBeginFunc = function(volumn){
    for(let id in mAllEffectTab){
        cc.audioEngine.setVolume(id, volumn);
    }
};
var lplayBeginEffectNovBeginFunc = function(voiceid){
    mAllEffectTab[voiceid] = 0;
};
var lplayFinishEffectNovBeginFunc = function(voiceid){
    mAllEffectTab[voiceid] = null;
};
var exIsOpenMusicBK = true;
var exIsOpenEffectBK = true;
///////////////////////////////////////////////////////////////////////////
module.exports = {
    _musicVolume : 1.0,
    _effectVolume : 1.0,

    _musicPlayID : -1,
    _musicPath : null,


    _voiceRecord : null,
    /////////////////////////////////////////////////////////////////////////
    getVoiceRecordNovBeginFunc(){
        if (!this._voiceRecord){
            this._voiceRecord = nativeVoice;
            this._voiceRecord.initNovBeginFunc(this);
        }
        return this._voiceRecord;
    },
    //加载并播放音乐
    //url以"asset/resources/"为相对路径
    //callback在播放开始回调，参数为路径
    //isMustPlay是否必须播放
    playMusicNovBeginFunc(url, bMustPlay, callback) {
        cc.log("===playMusicNovBeginFunc====111======SoundManagerNov2nd===", url);
        if(!url || bMustPlay && !lisSoundOpenNovBeginFunc(true)) return;
        cc.log("====playMusicNovBeginFunc===222======SoundManagerNov2nd===", url);
        let self = this;
        cc.loader.loadRes(url, (err, path)=>{
            self.stopMusicNovBeginFunc();
            cc.log("====playMusicNovBeginFunc===333======SoundManagerNov2nd===", path);
            if(bMustPlay || lisSoundOpenNovBeginFunc(true)){
                cc.log("====playMusicNovBeginFunc===444======SoundManagerNov2nd===", path);
                self._musicPlayID = cc.audioEngine.play(path, true, self._musicVolume);
                //fix engine bug
                cc.audioEngine.setVolume(self._musicPlayID, self._musicVolume);
            }
            if(callback) callback(path);
        });
    },
    //加载并播放音效
    //url以"asset/resources/"为相对路径
    //callback在播放开始回调，参数一为路径，参数二为总时长
    //isMustPlay是否必须播放
    playEffectNovBeginFunc(url, bMustPlay, callback) {
        cc.log("===playEffectNovBeginFunc====111======SoundManagerNov2nd===", url);
        if(!url || bMustPlay && !lisSoundOpenNovBeginFunc(false)) return ;
        cc.log("====playEffectNovBeginFunc===222======SoundManagerNov2nd===", url);
        let self = this;
        cc.loader.loadRes(url, (err, path)=>{
            let durt = 0;
            cc.log("====playEffectNovBeginFunc===333======SoundManagerNov2nd===", path);
            if(bMustPlay || lisSoundOpenNovBeginFunc(false)) {
                cc.log("====playEffectNovBeginFunc===444======SoundManagerNov2nd===", path, self._effectVolume);
                if (self._effectVolume > 0) {
                    let audioId = cc.audioEngine.play(path, false, self._effectVolume);
                    lplayBeginEffectNovBeginFunc(audioId);
                    cc.audioEngine.setFinishCallback(audioId, function(){
                        lplayFinishEffectNovBeginFunc(audioId);
                    });
                    durt = cc.audioEngine.getDuration(audioId);
                }
            }
            if(callback) callback(path, durt);
        });
    },
    //0~1.0之间
    setEffectVolumeNovBeginFunc(v) {
        this._effectVolume = v;
        lsetSoundVolumnNovBeginFunc(this._effectVolume);
        lsetAllEffectVolumnNovBeginFunc(this._effectVolume);
    },
    getEffectVolumeNovBeginFunc(){
        return this._effectVolume;
    },

    //0~1.0之间
    setMusicVolumeNovBeginFunc(v) {
        this._musicVolume = v;
        lsetSoundVolumnNovBeginFunc(this._musicVolume);
        if(this._musicPlayID<0) return ;
        cc.audioEngine.setVolume(this._musicPlayID, v);
    },
    getMusicVolumeNovBeginFunc(){
        return this._musicVolume;
    },

    setMusicOpenNovBeginFunc(isOpen){
        if(!isOpen) this.stopMusicNovBeginFunc();
        lsetSoundOpenNovBeginFunc(true, isOpen);
    },
    setEffectOpenNovBeginFunc(isOpen){
        lsetSoundOpenNovBeginFunc(false, isOpen);
    },
    isMusicOpenNovBeginFunc(){
        return lisSoundOpenNovBeginFunc(true);
    },
    isEffectOpenNovBeginFunc(){
        return lisSoundOpenNovBeginFunc(false);
    },
    //打断，唤醒，如用于播放语音时候
    stopAllNovBeginFunc() {
        //备份状态
        exIsOpenMusicBK = lisSoundOpenNovBeginFunc(true);
        exIsOpenEffectBK = lisSoundOpenNovBeginFunc(false);
        cc.log("=======stopAllNovBeginFunc===========", exIsOpenEffectBK, exIsOpenMusicBK);
        lsetSoundOpenNovBeginFunc(false, false);
        lsetSoundOpenNovBeginFunc(true, false);
        cc.audioEngine.pauseAll();
    },

    openAllNovBeginFunc() {
        //恢复状态
        cc.log("=======openAllNovBeginFunc===========", exIsOpenEffectBK, exIsOpenMusicBK);
        lsetSoundOpenNovBeginFunc(false, exIsOpenEffectBK);
        lsetSoundOpenNovBeginFunc(true, exIsOpenMusicBK);
        cc.audioEngine.resumeAll();
    },
    //清空关闭
    clearAllNovBeginFunc() {
        this._musicPlayID = -1;
        cc.audioEngine.stopAll();
    },
    stopMusicNovBeginFunc(){
        if(this._musicPlayID>=0){
            cc.audioEngine.stop(this._musicPlayID);
        }
        this._musicPlayID = -1;
    },
    preload(url, callback){
        cc.audioEngine.preload(path, callback);
    },
    /////////////////////////////////////
};