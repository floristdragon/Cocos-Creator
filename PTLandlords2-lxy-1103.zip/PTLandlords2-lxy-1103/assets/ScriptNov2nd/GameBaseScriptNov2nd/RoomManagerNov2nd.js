let RoomInfo = require("RoomInfoNov2nd");
let lAllGameRoomTab = {};
module.exports = {
    _curGameId : null,
    _curRoomId : null,
    ///////////////////////////////////////////////////////
    newRoomInfoNovBeginFunc(gameId, roomId){
        let rinfo = new RoomInfo(gameId, roomId);
        if(gameId && roomId){
            return this._addRoomInfoNovBeginFunc(rinfo);
        }
    },
    _addRoomInfoNovBeginFunc(roominfo){
        let gameId = roominfo.getGameIdNovBeginFunc();
        let roomId = roominfo.getRoomIDNovBeginFunc();
        if(!lAllGameRoomTab[gameId])lAllGameRoomTab[gameId] = {};
        lAllGameRoomTab[gameId][roomId] = roominfo;
        return roominfo;
    },
    getGameRoomInfoNovBeginFunc(gameId, roomId){
        if(!gameId) return ;
        if(!roomId) return lAllGameRoomTab[gameId];
        return lAllGameRoomTab[gameId][roomId];
    },
    setCurGameRoomNovBeginFunc(gameId, roomId){
        this._curGameId = gameId;
        this._curRoomId = roomId;
    },
    getCurGameIdNovBeginFunc(){
        return this._curGameId;
    },
    getCurRoomIdNovBeginFunc(){
        return this._curRoomId;
    },
}
