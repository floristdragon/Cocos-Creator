

let UserInfo = require("UserInfoNov2nd");

let lAllUserIDTab = {};
module.exports = {    
    m_SelfUserInfo : null,
    //isSelfInfo表示是否是客户端自己的用户信息
    newUserNovBeginFunc(userid, username, isSelfInfo){
        let userinfo = new UserInfo(userid, username);
        this._addUserNovBeginFunc(userinfo);
        if(isSelfInfo)this.m_SelfUserInfo = userinfo;
        return userinfo;
    },
    //添加或者重置用户信息表
    _addUserNovBeginFunc(userinfo){
        lAllUserIDTab[userinfo.getUserIdNovBeginFunc()] = userinfo;
    },
    //移除用户信息
    removeUserNovBeginFunc(userid){
        let userinfo = getUserInfoByIdNovBeginFunc(userid);
        lAllUserIDTab[userinfo.getUserIdNovBeginFunc()] = nil;
    },
    clearAllUserNovBeginFunc(){
        lAllUserIDTab = {};
    },
    //通过用户ID获取用户信息
    getUserInfoByIdNovBeginFunc(userid){
        if(!userid || userid<=0) return ;
        return lAllUserIDTab[userid]
    },
     //获取自己的userinfo
    getSelfUserInfoNovBeginFunc(){
        return this.m_SelfUserInfo;
    },
    getSelfUserIdNovBeginFunc(){
        if(this.m_SelfUserInfo) return this.m_SelfUserInfo.getUserIdNovBeginFunc();
    },
    //是否是自己
    IsSelfUserInfoNovBeginFunc(userinfo){
        if(!userinfo) return false;
        return this.m_SelfUserInfo.getUserIdNovBeginFunc()==userinfo.getUserIdNovBeginFunc();
    },
    IsSelfUserIdNovBeginFunc(userid) {
        if(!userid) return false;
        return this.m_SelfUserInfo.getUserIdNovBeginFunc()==userid;
    },
}