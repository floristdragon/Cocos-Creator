
module.exports = {
    _allitemtab : {},
    updateItemNovBeginFunc(itemid, count) {
        itemid = Math.floor(parseInt(itemid) / 1000);
        this._allitemtab[itemid] = count;
    },

    getItemNovBeginFunc(itemid){
        itemid = parseInt(itemid);
        return this._allitemtab[itemid];
    },
    getGoldNovBeginFunc(){
        if(!this._allitemtab[1001]) return 0;
        return this._allitemtab[1001];
    },
};