let gameconfig = require("gameConfigNov2nd");
cc.Class({
    extends: cc.Component,

    properties: {
        O_gameidlabel : cc.Label,
        O_roomidlabel : cc.Label,
        O_timelabel : cc.Label,

        _userdatalist : null,
    },

    setDataNovBeginFunc(gameid, roomid, jushu, stime, userlist) {
        this.O_gameidlabel.string = gameconfig[parseInt(gameid)].desc;
        this.O_roomidlabel.string = roomid + "-" + jushu;
        this._userdatalist = userlist;
        let date = new Date(stime * 1000);
        let extfunc = function(time){
            if(time<10) return "0"+time;
            return time + "";
        };
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        this.O_timelabel.string = ' '+year+"/"+extfunc(month)+"/"+
                extfunc(date.getDate())+"-"+extfunc(date.getHours())+":" + extfunc(date.getMinutes())+' ';
    },

    onClickBtnNovBeginFunc(){
        cc.log("=======onClickBtnNovBeginFunc========", this._userdatalist)
        if(this._userdatalist){
            this.node.emit("zhanjiline-event", this._userdatalist);
        }
    },
});
