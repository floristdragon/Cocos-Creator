cc.Class({
    extends: cc.Component,

    properties: {
        O_inputNode : cc.Node,

        //////////////////////////////
        _enterNoArray : null,
        _inputlabelArray : null,
        _enableInput : true,
    },

    // use this for initialization
    onLoad: function () {
        this._enterNoArray = [];
        this._inputlabelArray = [];
        for(let i=1; i<=6; i++){
            let plabel = this.O_inputNode.getChildByName('labelground'+i).getChildByName("label"+i).getComponent(cc.Label);
            plabel.string = "";
            this._inputlabelArray.push(plabel);
        }
        this._enableInput = true;
    },
    onPressNumBtnNovBeginFunc : function(event, detail){
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        if(!this._enableInput) return ;
        let pressNum = parseInt(detail);
        let isEnterEnd = false;
        if(pressNum>=0 && pressNum<=9){
            if(this._enterNoArray.length<6){
                this._enterNoArray.push(pressNum);
                if(this._enterNoArray.length>=6){
                    isEnterEnd = true;
                }
            }
        }
        else{
            if(pressNum==10){
                this._enterNoArray = [];
            }else if(pressNum==11){
                this._enterNoArray.pop();
            }
        }
        let allnumstr = "";
        for(let k=0; k<this._inputlabelArray.length; k++){
            this._inputlabelArray[k].string = "";
            let tonum = this._enterNoArray[k];
            if(tonum != null){
                this._inputlabelArray[k].string = tonum;
                allnumstr += tonum;
            }
        }
        if(isEnterEnd && allnumstr!=""){
            cc.log("=-======enter====end======", this._enterNoArray, allnumstr);
            //this.node.emit("lobby-joinroom", allnumstr);
            this._enableInput = false;
            let self = this;
            this.scheduleOnce(function(){
                self._enableInput = true;
            }, 0.5);
            let toProtTab = {};
            toProtTab.roomId = allnumstr;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqEnterDesk, toProtTab)
        }
        cc.log("============onPressNumBtnNovBeginFunc=============", detail, this._enterNoArray);
        

    },

    clearInputNumNovBeginFunc : function() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        for(var i=1;i<7;i++){
            let plabel = this.O_inputNode.getChildByName('labelground'+i).getChildByName("label"+i).getComponent(cc.Label);
            plabel.string = "";
        }
        this._enterNoArray = [];
    },
    onCloseBtnNovBeginFunc : function(event, detail){
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        
        this.node.active = false;
        this.clearInputNumNovBeginFunc();

    },
});
