
let utilIconv = require("util_iconvNov2nd")
cc.Class({
    extends: cc.Component,

    properties: {
        O_mailprefab : cc.Prefab,

        O_scrollview : cc.Node,
        
        O_maildetailnode : cc.Node,
        O_labelcontent : cc.Label,
        O_emptytip : cc.Node,

        _scrollscript : null,
        _detailnode : null,
    },
    onLoad(){
        this.O_maildetailnode.active = false;
        this._scrollscript = this.O_scrollview.getComponent("ui-scrollViewNov2nd");
        this._scrollscript.setHeightInterNovBeginFunc(0);
        this._checkEmptyTipNovBeginFunc();
    },

    showBoxNovBeginFunc(bVisible, bClear){
        cc.log("=========setMailBox===========");
        this.node.active = bVisible;
        if(bClear) this._scrollscript.clearAllNodeNovBeginFunc();
    },
    setBoxMailNovBeginFunc(maillist){
        if(!maillist) return ;
        for(let i=0; i<maillist.length; i++){
            let maildata = maillist[i];
            if(!maildata) continue;
            //let iconvlite = require('iconv-lite');
            //let toData = iconvlite.decode(toTempArray, 'UTF8');
            maildata.title = utilIconv.GBKToUTF8(maildata.title);
            maildata.content = utilIconv.GBKToUTF8(maildata.content);
            let mailnode = cc.instantiate(this.O_mailprefab);
            cc.log("======setBoxMailNovBeginFunc===title===", maildata.title);
            mailnode.getComponent("ui-lobbyMailLineNov2nd").initNovBeginFunc(maildata.mailId, maildata.title, maildata.stime);
            mailnode.on("mailbox-readmail", ()=>{
                this.O_labelcontent.string = maildata.content;
                this.O_maildetailnode.active = true;
                this._detailnode = mailnode;
            }, this);
            this._scrollscript.addScrollNodeNovBeginFunc(mailnode, null, maildata.stime);
        }
        this._scrollscript.sortAllNodeListNovBeginFunc((a, b)=>{
            if(a>b) return -1;
            return 1;
        });
        this._checkEmptyTipNovBeginFunc();
    },

    onCloseDetailClickNovBeginFunc(node) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        cc.log("========onCloseDetailClickNovBeginFunc=========", node);
        this.O_maildetailnode.active = false;
        this._scrollscript.rmScrollNodeNovBeginFunc(this._detailnode);
        this._checkEmptyTipNovBeginFunc();
    },
    onCloseNovBeginFunc(){
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.showBoxNovBeginFunc(false);
    },
    
    _checkEmptyTipNovBeginFunc(){
        if(this._scrollscript.getListSizeNovBeginFunc()<=0){
            this.O_emptytip.active = true;
        }else{
            this.O_emptytip.active = false;            
        }
    },
});
