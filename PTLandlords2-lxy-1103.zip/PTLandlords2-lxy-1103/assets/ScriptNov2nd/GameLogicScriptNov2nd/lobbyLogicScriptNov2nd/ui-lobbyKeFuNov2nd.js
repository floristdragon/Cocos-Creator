cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // use this for initialization
    onLoad: function () {

    },

    onCloseClickNovBeginFunc : function () {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        
        this.node.active = false;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
