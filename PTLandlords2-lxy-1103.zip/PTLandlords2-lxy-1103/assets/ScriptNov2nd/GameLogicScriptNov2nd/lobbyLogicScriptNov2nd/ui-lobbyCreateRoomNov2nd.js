let gameconfig = require("gameConfigNov2nd");

cc.Class({
    extends: cc.Component,

    properties: {
        _enableInput : true,
        _maxJuShu : null,
        _selectgameId : null,

        O_erRenDdzToggleBtn: cc.Toggle,
        O_sanRenDdzToggleBtn: cc.Toggle,

        O_8toggleBtn : cc.Toggle,
        O_16toggleBtn : cc.Toggle,
    },

    // use this for initialization
    onLoad: function (data01, data02, data03) {
        cc.log("=======createroom===onload===", data01, data02, data03);
        this._enableInput = true;
        // if(this.O_8toggleBtn.isChecked) {
        //     this._maxJuShu = 8;

        // }
        // if(this.O_16toggleBtn.isChecked) {
        //     this._maxJuShu = 16;

        // }
        this._checkAllToggleNovBeginFunc();
    },

    _checkAllToggleNovBeginFunc() {
        this._maxJuShu = 8;
        this._selectgameId = null;
        if (this.O_8toggleBtn.isChecked) {
            this._maxJuShu = 8;
        } else if (this.O_16toggleBtn.isChecked) {
            this._maxJuShu = 16;
        };

        if (this.O_erRenDdzToggleBtn.isChecked) {
            this._selectgameId = g_ProtDef.MID_Protocol_ErRenDDZ;
        } else if (this.O_sanRenDdzToggleBtn.isChecked) {
            this._selectgameId = g_ProtDef.MID_Protocol_ClassicDDZ;
        }
    },

    onToggleBtnClickNovBeginFunc : function (event,detail) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        if(this.O_8toggleBtn.isChecked) {
            this._maxJuShu = parseInt(detail);
        }
        if(this.O_16toggleBtn.isChecked) {
            this._maxJuShu = parseInt(detail);
        }
        cc.log("=======this.O_8toggleBtn.isChecked=====this._maxJuShu=======", this._maxJuShu);
    },
    onToggleErRenDdzBtnClickNovBeginFunc: function(event, detail){
        if(this.O_8toggleBtn.isChecked) {
            this._selectgameId = g_ProtDef.MID_Protocol_ErRenDDZ;
        }else{
            this._selectgameId = null;
        }
    },
    onToggleSanRenDdzBtnClickNovBeginFunc: function(event, detail){
        if(this.O_8toggleBtn.isChecked) {
            this._selectgameId = g_ProtDef.MID_Protocol_ClassicDDZ;
        }else{
            this._selectgameId = null;
        }
    },



    onCreateBtnNovBeginFunc(event){
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        if(!this._enableInput) return ;
        this._enableInput = false;
        let self = this;
        this.scheduleOnce(function(){
            self._enableInput = true;
        }, 0.5);
        if(!this._selectgameId || !gameconfig[this._selectgameId]){
            return g_GameScene.showPopupWindowNovBeginFunc(true, false, "提示", 
                    g_ProtDef.GetErrDiscByCode("M_LOBBY_CREATEROOM_CONFIG_ERR"));
        }
        
        let protTab = {};
        protTab.gameId = this._selectgameId;	//游戏名称
        protTab.userId = g_UserManager.getSelfUserIdNovBeginFunc();
        protTab.pwd = ""; //房间密码
        protTab.maxJuShu = this._maxJuShu;
        protTab.config = {};    //创建配置
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SCreatDesk, protTab)
    },
    onCloseBtnNovBeginFunc(event){
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        
        this.node.active = false;
    },
});
