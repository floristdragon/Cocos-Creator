cc.Class({
    extends: cc.Component,

    properties: {

        O_musicToggle : cc.Toggle,
        O_effectToggle :cc.Toggle,
        
        _isCheckToggleClick : true,
    },
    onLoad(){
        this._isCheckToggleClick = false;
        if(g_SoundManager.isMusicOpenNovBeginFunc()){
            cc.log("=======onLoad===11================");
            this.O_musicToggle.check();
        }else{
            cc.log("=======onLoad===22================");
            this.O_musicToggle.uncheck();
        }
        if(g_SoundManager.isEffectOpenNovBeginFunc()){
            cc.log("=======onLoad===33================");
            this.O_effectToggle.check();
        }else{
            cc.log("=======onLoad===44================");
            this.O_effectToggle.uncheck();
        }
        this._isCheckToggleClick = true;
    },

    showSettingNodeNovBeginFunc : function() {
        this.node.active = true;
    },

    onMusicToggleClickNovBeginFunc(toggle) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        cc.log("================onMusicToggleClickNovBeginFunc======================", toggle, toggle.isChecked)
        if(!this._isCheckToggleClick) return ;
        if (toggle.isChecked) {
            g_SoundManager.setMusicOpenNovBeginFunc(true);
            g_SoundManager.playMusicNovBeginFunc("DdzResNov2nd/soundResNov2nd/musicResNov2nd/bg_happyNov2nd");
        }
        else {
            g_SoundManager.setMusicOpenNovBeginFunc(false);
        }
    },

    onEffectToggleClick(toggle) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        cc.log("==========================onEffectClickNovBeginFunc===============", toggle, toggle.isChecked);
        if(!this._isCheckToggleClick) return ;
        if (toggle.isChecked) {
            g_SoundManager.setEffectOpenNovBeginFunc(true);
        }
        else {
            g_SoundManager.setEffectOpenNovBeginFunc(false);
        }
    },

    onCloseClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        
        this.node.active = false;
    },
});
