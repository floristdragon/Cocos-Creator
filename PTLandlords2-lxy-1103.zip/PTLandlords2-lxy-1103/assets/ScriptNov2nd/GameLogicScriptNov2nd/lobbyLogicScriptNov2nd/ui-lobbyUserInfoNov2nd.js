cc.Class({
    extends: cc.Component,

    properties: {
        O_userName : cc.Label,
        O_userId : cc.Label,
        O_userIp : cc.Label,
        O_userHead : cc.Node,

    },

    onLoad(){
        let userinfo = g_UserManager.getSelfUserInfoNovBeginFunc();
        this.O_userName.string = userinfo.getUserNameNovBeginFunc();
        this.O_userId.string = userinfo.getUserIdNovBeginFunc();
        this.O_userIp.string = userinfo.getIpAddrNovBeginFunc();
        cc.log("===========userinfo=========", userinfo);
        let headurl = userinfo.getHeadUrlNovBeginFunc();
        if (headurl && headurl.length > 0) {
            let toSprite = this.O_userHead.getComponent(cc.Sprite);
            let toType = "png";
            if(headurl.indexOf(".jpg")){
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },
    
    onChangeUserBtnNovBeginFunc : function () {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        g_GameScene.switchStartSceneNovBeginFunc();
        this.onCloseNovBeginFunc();
    },

    onCloseNovBeginFunc : function () {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        
        this.node.destroy();
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
