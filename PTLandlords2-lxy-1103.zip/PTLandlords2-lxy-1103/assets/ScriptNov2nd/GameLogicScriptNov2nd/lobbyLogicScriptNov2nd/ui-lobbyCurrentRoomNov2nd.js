cc.Class({
    extends: cc.Component,

    properties: {
        O_curroomlineprefab : cc.Prefab,
        O_scrollviewnode : cc.Node,

        _scrollviewscript : null,
    },

    onLoad(){
        this._scrollviewscript = this.O_scrollviewnode.getComponent("ui-scrollViewNov2nd");
    },

    // use this for initialization
    addOneRoomRecordNovBeginFunc(gameId, roomId, curjushu, maxjushu){
        cc.log("=====addOneRoomRecordNovBeginFunc========", gameId, roomId, curjushu, maxjushu)
        let croomlinenode = cc.instantiate(this.O_curroomlineprefab);
        let croomlinescript = croomlinenode.getComponent("ui-lobbyCurrentRoomLineNov2nd");
        croomlinescript.setDataNovBeginFunc(gameId, roomId, curjushu, maxjushu);
        this._scrollviewscript.addScrollNodeNovBeginFunc(croomlinenode);
    },

    onCloseEventNovBeginFunc : function() {
        this.node.destroy();
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
