let utilIconv = require("util_iconvNov2nd")
cc.Class({
    extends: require("ui-roomSceneNov2nd"),

    properties: {

        O_bottmBtns: cc.Node,

        O_isRoomExitPrefab: cc.Prefab,
        O_createRoomprefab: cc.Prefab,
        O_joinRoomprefab: cc.Prefab,
        O_userinfoprefab: cc.Prefab,

        //bottomButtons Prefab
        O_friendsPrefab: cc.Prefab,
        O_kefuPrefab: cc.Prefab,
        O_zhanjiPrefab: cc.Prefab,
        O_mailPrefab: cc.Prefab,
        O_messagePrefab: cc.Prefab,
        O_acctivityPrefab: cc.Prefab,

        //topButtons Prefab
        O_settingPrefab: cc.Prefab,
        O_rulePrefab: cc.Prefab,

        O_noticeMaskNode: cc.Node,
        O_namelabel: cc.Label,
        O_useridlabel: cc.Label,

        O_paihangbangPrefab: cc.Prefab,
        O_showChat: cc.Node,
        ///////////////////////////////////////////////////////
        _createroomNode: null,
        _joinroomNode: null,
        _mailBoxScript: null,
        _friendNode: null,
        _friendnodeScript: null,
        _ctrCreateOrJoinRoomFlag: null,


        _paihangbangNode: null,
        _zhanjiNodeScript: null,
    },

    // use this for initialization
    onLoad() {
        this._super(); //调用父类的
        this.O_bottmBtns.setLocalZOrder(5);
        this.O_showChat.setLocalZOrder(5);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CQueryMyDesk, this.onProtCurrentRoomExitNovBeginFunc, this);
        //注册回调函数
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CCreatDesk, this.onProtCreateRoomNovBeginFunc, this);
        //排行榜协议
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Rank, g_ProtDef.ARank_S2CReqRankList, this.onProtReqRankListNovBeginFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_MailBox, g_ProtDef.AMailBox_S2CQueryAllMail, this.onProtMailListNovBeginFunc, this);
        //大厅公告
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2ClobbyNotice, this.onProtLobbyNoticeNovBeginFunc, this);

        //初始化数据
        let userinfo = g_UserManager.getSelfUserInfoNovBeginFunc();
        this.O_namelabel.string = userinfo.getUserNameNovBeginFunc();
        this.O_useridlabel.string = "ID:" + userinfo.getUserIdNovBeginFunc();
        cc.log("=====lobbbyscene===onLoad=======", this.O_namelabel.string);
        this._showRankNodeNovBeginFunc();

        g_SoundManager.playMusicNovBeginFunc("CommonResNov2nd/bgMusicNov2nd-lobby");
        //请求一些信息
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Rank, g_ProtDef.ARank_C2SReqRankList);
        //
        let toBcProtTab = {}
        toBcProtTab.AppGameID = g_ConfigManager.getGlobalConfigNov2nd("AppGameID");
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SlobbyNotice, toBcProtTab);
    },
    _runNoticeLabelActionNovBeginFunc(str, repeatnum) {
        let noticelabel = this.O_noticeMaskNode.getChildByName("label");
        noticelabel.getComponent(cc.Label).string = str;
        noticelabel.stopAllActions();
        let maskWidth = this.O_noticeMaskNode.width;
        if (maskWidth < noticelabel.width) maskWidth = noticelabel.width;
        let toPosY = noticelabel.position.y;
        let toPosX = 0;
        let toRightPos = new cc.Vec2(toPosX - maskWidth - 5, toPosY);
        let toLeftPos = new cc.Vec2(toPosX + maskWidth + 5, toPosY);
        let toAction = cc.sequence(cc.moveTo(15, toRightPos), cc.moveTo(0, toLeftPos));
        if (!repeatnum || repeatnum <= 0) {
            noticelabel.runAction(cc.repeatForever(toAction));
        } else {
            noticelabel.runAction(cc.repeat(toAction, repeatnum));
        }
    },
    ///////////////////////////////////////////////////////////////
    //协议回调 
    //玩家查询属于自己创建的桌子房间状态
    onProtCurrentRoomExitNovBeginFunc(mainId, assistId, protTab) {
        cc.log("=====onProtCurrentRoomExitNovBeginFunc===================", mainId, assistId, protTab);
        this.showLoadFlowerNovBeginFunc(false);
        if (protTab && protTab.length > 0) {
            let curroomnode = cc.instantiate(this.O_isRoomExitPrefab);
            curroomnode.parent = this.node;
            curroomnode.setLocalZOrder(10);
            curroomnode.active = true;
            var croomexitScript = curroomnode.getComponent('ui-lobbyCurrentRoomNov2nd');
            for (let i = 0; i < protTab.length; i++) {
                let toroomdata = protTab[i];
                croomexitScript.addOneRoomRecordNovBeginFunc(toroomdata.gameId, toroomdata.roomId, toroomdata.curjushu, toroomdata.maxjushu);
            }
        } else {
            if (this._ctrCreateOrJoinRoomFlag == 1) {
                this.showCreateRoomNodeNovBeginFunc(true);
            } else if (this._ctrCreateOrJoinRoomFlag == 2) {
                this.showJoinRoomNodeNovBeginFunc(true);
            }
        }

    },
    //用户创建房间
    onProtCreateRoomNovBeginFunc(mainId, assistId, protTab) {
        cc.log("=====onProtCreateRoomNovBeginFunc===================", mainId, assistId, protTab);
        let roominfo = g_RoomManager.newRoomInfoNovBeginFunc(protTab.gameId, protTab.roomId);
        roominfo.setPackageInfoNovBeginFunc(protTab);

        let toProtTab = {};
        toProtTab.gameId = roominfo.getGameIdNovBeginFunc(); //游戏id
        toProtTab.roomId = roominfo.getRoomIDNovBeginFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqEnterDesk, toProtTab);
    },
    //请求大厅公告
    onProtLobbyNoticeNovBeginFunc(mainId, assistId, protTab) {
        cc.log("======lobbyScene=======onProtLobbyNoticeNovBeginFunc========", protTab);
        if (protTab.itype == 0) {
            let toContent = utilIconv.GBKToUTF8(protTab.content);
            this._runNoticeLabelActionNovBeginFunc(toContent, protTab.repeatnum);
        }
    },
    //排行榜
    onProtReqRankListNovBeginFunc(mainId, assistId, protTab) {
        cc.log("=========ui-lobbySceneNov2nd=========onRankInit=========", protTab);
        if (!this._paihangbangNode) {
            this._paihangbangNode = cc.instantiate(this.O_paihangbangPrefab);
            this._paihangbangNode.parent = this.node;
            this._paihangbangNode.setLocalZOrder(2);
        }
        let phbscript = this._paihangbangNode.getComponent('ui-lobbyRankNov2nd');
        phbscript.setPaiHangBangNovBeginFunc(protTab.rank, protTab.winNum, protTab.list);
    },

    onProtMailListNovBeginFunc(mainId, assistId, protTab) {
        cc.log("=========ui-lobbySceneNov2nd=============onProtMailListNovBeginFunc========", protTab);
        if (this._mailBoxScript) this._mailBoxScript.setBoxMailNovBeginFunc(protTab.mailtab);
    },
    ///////////////////////////////////////////////////////////////
    onRecvErrcodeNovBeginFunc(errcode, attachtab) {
        cc.log("=======onRecvErrcodeNovBeginFunc============", errcode, attachtab);
        this.showPopupWindowNovBeginFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },
    onRecvEnterRoomNovBeginFunc(gameId, roomId, userId) {
        cc.log("==========lobbyscene====onRecvEnterRoomNovBeginFunc=====", gameId, roomId, userId);
        g_RoomManager.setCurGameRoomNovBeginFunc(null, null);
        let selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        if (selfUserId == userId) {
            g_RoomManager.setCurGameRoomNovBeginFunc(gameId, roomId);
            if (gameId == g_ProtDef.MID_Protocol_ErRenDDZ) {
                this.switchErRenDdzSceneNovBeginFunc();
            } else if (gameId == g_ProtDef.MID_Protocol_ClassicDDZ) {
                this.switchClassicDdzSceneNovBeginFunc()
            }
        }
    },
    showCreateRoomNodeNovBeginFunc(isVisible) {
        if (!this._createroomNode) {
            this._createroomNode = cc.instantiate(this.O_createRoomprefab);
            this._createroomNode.parent = this.node;
            this._createroomNode.setLocalZOrder(10);
        }
        this._createroomNode.active = isVisible;
    },
    showJoinRoomNodeNovBeginFunc(isVisible) {
        if (!this._joinroomNode) {
            this._joinroomNode = cc.instantiate(this.O_joinRoomprefab);
            cc.log("======= this._joinroomNode ========", this._joinroomNode);
            this._joinroomNode.parent = this.node;
            this._joinroomNode.setLocalZOrder(10);
        }
        this._joinroomNode.active = isVisible;
    },
    onExitGameBtnNovBeginFunc(event) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        let self = this;
        self.showPopupWindowNovBeginFunc(true, true, "提示", "是否退出游戏？", function(okflag) {
            cc.log("===========showPopupWindowNovBeginFunc=============", okflag);
            if (okflag == 1) {
                cc.game.end();
            }
        });
    },
    _showRankNodeNovBeginFunc() {
        //
        this._paihangbangNode = cc.instantiate(this.O_paihangbangPrefab);
        this._paihangbangNode.parent = this.node;
        this._paihangbangNode.setLocalZOrder(2);
    },
    onCreateRoomBtnNovBeginFunc(event) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.showLoadFlowerNovBeginFunc(true);
        this._ctrCreateOrJoinRoomFlag = 1;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SQueryMyDesk);
    },
    onJoinRoomBtnNovBeginFunc(event) {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.showLoadFlowerNovBeginFunc(true);
        this._ctrCreateOrJoinRoomFlag = 2;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SQueryMyDesk);
    },
    onUserInfoBtnNovBeginFunc(event) {

    },

    //分享点击事件
    onFriendsClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.O_friendsTipsNode.active = false;
        if (!this._friendNode) {
            let friendNode = cc.instantiate(this.O_friendsPrefab);
            friendNode.parent = this.node;
            friendNode.setLocalZOrder(10);
            this._friendNode = friendNode;
        }
        this._friendnodeScript = this._friendNode.getComponent('ui-lobbyFriendsNov2nd');
        if (this._friendsTis == 1) {
            this._friendnodeScript.showApplyTipsNovBeginFunc(this._friendsTis);
            this._friendsTis = 0;
        }
        this._friendnodeScript.openFriendsViewNovBeginFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend, g_ProtDef.AFriend_C2SQueryFriend);


    },

    onSettingClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        let settingNode = cc.instantiate(this.O_settingPrefab);
        settingNode.parent = this.node;
        settingNode.setLocalZOrder(10);
    },

    onKeFuClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        let kefuNode = cc.instantiate(this.O_kefuPrefab);
        kefuNode.parent = this.node;
        kefuNode.setLocalZOrder(10);
    },

    onMessageClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        let messageNode = cc.instantiate(this.O_messagePrefab);
        messageNode.parent = this.node;
        messageNode.setLocalZOrder(10);
    },

    onActivityClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        let activityNode = cc.instantiate(this.O_acctivityPrefab);
        activityNode.parent = this.node;
        activityNode.setLocalZOrder(10);
    },

    onMailClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        cc.log("========ui-lobbySceneNov2nd=====onMailClickNovBeginFunc===============");

        //邮箱协议
        let toProtTab = {}
        toProtTab.AppGameID = g_ConfigManager.getGlobalConfigNov2nd("AppGameID");
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_MailBox, g_ProtDef.AMailBox_C2SQueryAllMail, toProtTab);

        if (!this._mailBoxScript) {
            let mailBoxNode = cc.instantiate(this.O_mailPrefab);
            mailBoxNode.parent = this.node;
            mailBoxNode.setLocalZOrder(10);
            this._mailBoxScript = mailBoxNode.getComponent('ui-lobbyMailBoxNov2nd');
        }
        this._mailBoxScript.showBoxNovBeginFunc(true, true);
    },

    onRuleClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        let ruleNode = cc.instantiate(this.O_rulePrefab);
        ruleNode.setLocalZOrder(10);
        ruleNode.parent = this.node;
        let close = ruleNode.getChildByName('close');
        close.off("touchstart");
        close.on('touchstart', function(event) {
            g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
            ruleNode.active = false;
        });
    },


    onZhanjiClickNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        this.O_zhanjiTipsNode.active = false;
        if (!this._zhanjiNodeScript) {
            let zhanjiNode = cc.instantiate(this.O_zhanjiPrefab);
            zhanjiNode.parent = this.node;
            zhanjiNode.setLocalZOrder(10);

            this._zhanjiNodeScript = zhanjiNode.getComponent("ui-lobbyZhanJiNov2nd");
        }
        cc.log("==============onZhanjiClickNovBeginFunc============", this._zhanjiNodeScript);
        this._zhanjiNodeScript.showUiNovBeginFunc(true);
    },

    onShowUserInfoPanelNovBeginFunc() {
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        let userInfoNode = cc.instantiate(this.O_userinfoprefab);
        userInfoNode.setLocalZOrder(100);
        userInfoNode.parent = this.node;
    },



});