cc.Class({
    extends: cc.Component,

    properties: {
        starsFrame: [cc.SpriteFrame],
        O_selfStar: cc.Sprite,
        numFrame: [cc.SpriteFrame],
        O_selfrank: cc.Label,
        headImg: cc.Sprite,
        playerName: cc.Label,
        O_selfWinNum: cc.Label,

      //  _PHBcontent : null,
        O_PHBcontent : cc.Prefab,

        O_scrollView : cc.Node,
        _scrollScript : null,
       
    },

    // use this for initialization
    onLoad: function () {
        let userinfo = g_UserManager.getSelfUserInfoNovBeginFunc();
        this.playerName.string = userinfo.getUserNameNovBeginFunc();
    },

    setPaiHangBangNovBeginFunc(selfrank, selfnum, alllist) {
        //this.headImg.spriteFrame = playerInfo.headImg;
        this.O_selfStar.node.active = false;
        this.O_selfrank.node.active = true;
        this.O_selfrank.string = "";
        cc.log("============ui-lobbypaihangbang======initNovBeginFunc======", alllist);
        
        if (selfrank && selfrank < 4) {
            this.O_selfStar.node.active = true;           
            this.O_selfStar.spriteFrame = this.starsFrame[selfrank - 1];
            this.O_selfrank.spriteFrame = this.numFrame[selfrank - 1];        
            this.O_selfrank.string = selfrank;  
        }
        if(selfnum==null) selfnum = 0;
        this.O_selfWinNum.string = selfnum;
        for(let i in alllist) {
            if(!alllist[i]) continue;
            let PHBcontent = cc.instantiate(this.O_PHBcontent);
            PHBcontent.getComponent('ui-lobbyRankLineNov2nd').initNovBeginFunc(alllist[i]);
            this._scrollScript = this.O_scrollView.getComponent('ui-scrollViewNov2nd');
            this._scrollScript.addScrollNodeNovBeginFunc(PHBcontent,null,alllist[i]);
        }

        this._scrollScript.sortAllNodeListNovBeginFunc(function(a, b){
            if(a.rank<b.rank) return -1; //表示要交换
            return 1; //不用交换
        });
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
