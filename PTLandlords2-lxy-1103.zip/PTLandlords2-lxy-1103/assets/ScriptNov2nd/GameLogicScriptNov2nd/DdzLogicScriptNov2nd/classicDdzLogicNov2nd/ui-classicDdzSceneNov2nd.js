

require("erRenDdzGameDataNov2nd");

let GameRuleLogic =  require("DdzRuleLogicNov2nd");
let STATUS_READY = 0;		//准备
let STATUS_SENDCARD = 1;	//发牌
let STATUS_QIANGDIZHU = 2; //抢地主
let STATUS_OUTCARD = 3;	    //出牌
let STATUS_GAMEFINISH = 4; //游戏结束
cc.Class({
    extends: require("ui-roomSceneNov2nd"),

    properties: {
        O_controlbtnprefab : cc.Prefab,
        O_gameresultprefab : cc.Prefab,

        O_userInfoPrefab:cc.Prefab,

        O_settingPrefab : cc.Prefab,

        //////////////////////////////////////
        _backgroundScipt : null,
        _ctlbuttonScript : null,
        _gameresultScript : null,
        _dispcardScript : null,

    },

    // use this for initialization
    onLoad:function(){
        this._super(); //调用父类的onLoad
        this.setChatRoomStateNovBeginFunc(true);
        //背景音乐
        g_CLDDZGameData.playBackgroundMusicNovBeginFunc();

        let gameId = g_RoomManager.getCurGameIdNovBeginFunc();
        let roomId = g_RoomManager.getCurRoomIdNovBeginFunc();
        let selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        let roominfo = g_RoomManager.getGameRoomInfoNovBeginFunc(gameId, roomId);
        
        let selfSeatNo = roominfo.findUserSeatNoNovBeginFunc(selfUserId);
        g_CLDDZGameData.initNovBeginFunc(gameId, roomId, selfSeatNo);
        cc.log("=======DdzResNov2nd==mainscene=11====", gameId, roomId, selfUserId);

        //////////////////////////////////////////////////////////
        this._cplayerArray = [];
        let maxPlayer = g_CLDDZGameData.getMaxPlayerNovBeginFunc();
        let toSeatNo = selfSeatNo;
        for(let i=0; i<maxPlayer; i++){
            let playerNo = i + 1;
            let playerNode = this.node.getChildByName("player"+playerNo);
            playerNode.setLocalZOrder(100);
            console.log("=====111111=======", toSeatNo, selfSeatNo, playerNo);
            let cplayerhandler = playerNode.getComponent("ui-classicDdzPlayerNov2nd");
            cplayerhandler.initUiNovBeginFunc(toSeatNo, playerNode);            
            g_CLDDZGameData.setPlayerUiNovBeginFunc(cplayerhandler, i, toSeatNo);

            toSeatNo = g_CLDDZGameData.getNextSeatNoNovBeginFunc(toSeatNo);
        };
        this._backgroundScipt = this.getComponent("ui-classicDdzBackgroundNov2nd");
        this._backgroundScipt.showBaseTipNovBeginFunc();

        this._dispcardScript = this.getComponent("ui-classicDdzDispcardNov2nd");
        cc.log("=========DdzResNov2nd==mainscene====22====", this._dispcardScript);
        /////////////////////////////////////////////////////////////////
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_ClassicDDZ, null, this.onProtSocketMessageNovBeginFunc, this);
        
        /////////////////////////////////////////////////////////////////
        //场景加载完毕，开始请求场景协议
        let toProtData = {};
        toProtData.gameId = g_CLDDZGameData.getGameIdNovBeginFunc();
        toProtData.roomId = g_CLDDZGameData.getRoomIDNovBeginFunc();
        cc.log("=========requestGameStatus===", toProtData);
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqGameStatus, toProtData);
    },
    onDestroyNovBeginFunc() {
        cc.log("=============onDestroyNovBeginFunc==============");
    },
    _resetAllUiNovBeginFunc(){
        if(this._ctlbuttonScript){
            this._getControlBtnNovBeginFunc().hideAllButtonNovBeginFunc();
        }
        if(this._gameresultScript){
            this._getGameResultNovBeginFunc().showResultNovBeginFunc(false);
        }
        g_CLDDZGameData.resetInitNovBeginFunc();
        this._backgroundScipt.showThreeBackCardNovBeginFunc(false);
        this._backgroundScipt.showSmallBackCardNovBeginFunc(false);
        this._backgroundScipt.showBaseTipNovBeginFunc();
        let roominfo = g_CLDDZGameData.getRoomInfoNovBeginFunc();
        let maxPlayer = g_CLDDZGameData.getMaxPlayerNovBeginFunc();
        for(let i=0; i<maxPlayer; i++){
            let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
            playerui.resetUiNovBeginFunc();
            
            let userinfo = roominfo.getUserInfoNovBeginFunc(i);
            cc.log("======_resetAllUiNovBeginFunc====111=======", i, userinfo);
            if(userinfo){
                playerui.showUserInfoNovBeginFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
            }else{
                playerui.showUserInfoNovBeginFunc(false);
            }
        }
    },
    _requestGameReadyNovBeginFunc(delaytime){
        let self = this;
        let readyNovBeginFunc = function(){
            //在这里进入房间后要发协议，自己默认进入房间就准备
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ClassicDDZ, g_ProtDef.AClassicDDZ_C2SReady);
        };
        if(!delaytime || delaytime<=0){
            readyNovBeginFunc();
        }else{
            this.scheduleOnce(readyNovBeginFunc, delaytime);
        }
    },
    onSettingBtnNovBeginFunc(event){
        var settingPlane = cc.instantiate(this.O_settingPrefab);
        this.node.addChild(settingPlane, 1000);
    },
    onShowUserInfoPanelNovBeginFunc(node, detail) {
        cc.log("========onShowUserInfoPanelNovBeginFunc=========", node, detail);
        let seatNo = g_CLDDZGameData.getSelfSeatNoNovBeginFunc();
        if(detail==2){
            seatNo = g_CLDDZGameData.getNextSeatNoNovBeginFunc(seatNo);
        }
        let roominfo = g_CLDDZGameData.getRoomInfoNovBeginFunc();
        if(roominfo.getUserInfoNovBeginFunc(seatNo)){
            var userInfoNode = cc.instantiate(this.O_userInfoPrefab);
            userInfoNode.parent = this.node;
            userInfoNode.setLocalZOrder(200);
            userInfoNode.getComponent("ui-classicDdzUserInfoNov2nd").showInfoNovBeginFunc(seatNo);
        }
    },
    //////////////////////////////////////////////////////////////////////////////
    _getControlBtnNovBeginFunc(){
        if(!this._ctlbuttonScript){
            let ctrbtn = cc.instantiate(this.O_controlbtnprefab);
            ctrbtn.parent = this.node;
            ctrbtn.setLocalZOrder(150);
            this._ctlbuttonScript = ctrbtn.getComponent("ui-classicControllBtnNov2nd");
            ctrbtn.off("outbtn-buchu");
            ctrbtn.off("outbtn-tishi");
            ctrbtn.off("outbtn-chupai");
            ctrbtn.on("outbtn-buchu", (event)=>{
                this._OutCardBuChuNovBeginFunc();
            }, this);
            ctrbtn.on("outbtn-tishi", (event)=>{
                this._OutCardTiShiNovBeginFunc();
            }, this);
            ctrbtn.on("outbtn-chupai", (event)=>{
                this._OutCardChuPaiNovBeginFunc();
            }, this);
        }
        return this._ctlbuttonScript;
    },
    _getGameResultNovBeginFunc(){
        if(!this._gameresultScript){
            let resultnode = cc.instantiate(this.O_gameresultprefab);
            resultnode.parent = this.node;
            resultnode.setLocalZOrder(200);
            this._gameresultScript = resultnode.getComponent("ui-classicGameResultNov2nd");
        }
        return this._gameresultScript;
    },
    _OutCardBuChuNovBeginFunc(){
        let selfSeatNo = g_CLDDZGameData.getSelfSeatNoNovBeginFunc();
        let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(selfSeatNo);
        playerui.getHandCardNovBeginFunc().clearTiShiHandCardNovBeginFunc();

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ClassicDDZ, g_ProtDef.AClassicDDZ_C2SBuChu);
    },
    _OutCardTiShiNovBeginFunc(){
        let selfSeatNo = g_CLDDZGameData.getSelfSeatNoNovBeginFunc();
        let outCardTab = g_CLDDZGameData.getCurOutCardTabNovBeginFunc(true);
        let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(selfSeatNo);
        playerui.getHandCardNovBeginFunc().moveTiShiHandCardNovBeginFunc(outCardTab);
    },
    _OutCardChuPaiNovBeginFunc(){
        let selfSeatNo = g_CLDDZGameData.getSelfSeatNoNovBeginFunc();
        let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(selfSeatNo);
        playerui.getHandCardNovBeginFunc().clearTiShiHandCardNovBeginFunc();
        let outCardTab = g_CLDDZGameData.getCurOutCardTabNovBeginFunc(true);
        let outTab = playerui.getHandCardNovBeginFunc().getMoveUpCardTabNovBeginFunc(outCardTab);
        if(outTab && outTab.length>0){
            let toProtTab = {};
            toProtTab.cardTab = outTab;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ClassicDDZ, g_ProtDef.AClassicDDZ_C2SOutCard, toProtTab);
        }else{
            this.showPopupWindowNovBeginFunc(true, false, "提示", "出牌不符合规则！");
        }
    },
    ////////////////////////////////////////////////////////////////////////////////
    onRecvErrcodeNovBeginFunc(errcode, attachtab){
        cc.log("=======onRecvErrcodeNovBeginFunc============", errcode, attachtab);
        this.showPopupWindowNovBeginFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },
    //其他玩家进入房间会调用这里, 进入房间协议比场景协议要先到来
    onRecvEnterRoomNovBeginFunc(gameId, roomId, userId){
        //let selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        let roominfo = g_CLDDZGameData.getRoomInfoNovBeginFunc();
        let seatNo = roominfo.findUserSeatNoNovBeginFunc(userId);
        let userinfo = roominfo.getUserInfoNovBeginFunc(seatNo);
        let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(seatNo);
        cc.log("==============onRecvEnterRoomNovBeginFunc==========", roomId, userId, typeof(userId), roominfo);
        playerui.showUserInfoNovBeginFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
    },
    onRecvJieSanDeskNovBeginFunc(gameId, roomId, userId, userName, isAuto){
        cc.log("======onRecvJieSanDeskNovBeginFunc==========", gameId, roomId, userId, userName, isAuto);
        if(!isAuto){
            this.showPopupWindowNovBeginFunc(true, false, "提示", "房主已经解散了房间！", (flag)=>{
                this.switchLobbySceneNovBeginFunc();
            }, this);
        }else{
            this.showPopupWindowNovBeginFunc(true, false, "提示", "房间局数已尽！", (flag)=>{
                this.switchLobbySceneNovBeginFunc();
            }, this);            
        }
    },
    onRecvLeaveDeskNovBeginFunc(gameId, roomId, userId){
        cc.log("======onRecvLeaveDeskNovBeginFunc==========", gameId, roomId, userId);
        if(userId==g_UserManager.getSelfUserIdNovBeginFunc()){
            // this.showPopupWindowNovBeginFunc(true, false, "提示", "您已经离开房间！", (flag)=>{
            //     this.switchLobbySceneNovBeginFunc();
            // }, this);
            this.switchLobbySceneNovBeginFunc();
        }
    },
    ////////////////////////////////////////////////////////////////////////////////
    _startDispCardNovBeginFunc(beginSeatNo){
        let maxPlayer = g_CLDDZGameData.getMaxPlayerNovBeginFunc();
        let eachNumArray = [];
        let eachPosArray = [];
        for(let i=0; i<maxPlayer; i++){
            let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
            eachNumArray.push(17);
            eachPosArray.push(playerui.getHandCardPosNovBeginFunc());
        }
        let self = this;
        this._dispcardScript.sendAllCardNovBeginFunc(beginSeatNo, eachNumArray, eachPosArray, (seatNo, num, isEnd)=>{
            if(!isEnd){
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(seatNo);
                playerui.showUserLeftCardNovBeginFunc(true, num);
                playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc(num);
            }else{
                g_CLDDZGameData.setHandCardSortNovBeginFunc(true);
                self._backgroundScipt.showThreeBackCardNovBeginFunc(true);
                self._backgroundScipt.showSmallBackCardNovBeginFunc(false);
                let maxPlayer = g_CLDDZGameData.getMaxPlayerNovBeginFunc();
                for(let i=0; i<maxPlayer; i++){
                    let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                    let leftnum = g_CLDDZGameData.getHandCardCountNovBeginFunc(i);
                    playerui.showUserLeftCardNovBeginFunc(true, leftnum);
                    playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                }
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ClassicDDZ, g_ProtDef.AClassicDDZ_C2SSendCardFinish);
            }
        });
    },
    ////////////////////////////////////////////////////////////////////////////////
    onRecvGameStatusNovBeginFunc(protTab){
        cc.log("==========onRecvGameStatusNovBeginFunc====11=========", protTab);
        let maxPlayer = g_CLDDZGameData.getMaxPlayerNovBeginFunc();
        let roominfo = g_CLDDZGameData.getRoomInfoNovBeginFunc();
        let selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        let selfSeatNo = roominfo.findUserSeatNoNovBeginFunc(selfUserId);
        this._resetAllUiNovBeginFunc();
        cc.log("==========onRecvGameStatusNovBeginFunc====22=========");
        if(protTab.status == STATUS_READY){
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                let isReady = protTab.readyTab[i];
                if(i==selfSeatNo) isReady = true;
                playerui.showReadyTipNovBeginFunc(isReady);
            }
            this._requestGameReadyNovBeginFunc();
        }else if(protTab.status == STATUS_SENDCARD){
            for(let i=0; i<maxPlayer; i++){
                g_CLDDZGameData.setHandCardTabNovBeginFunc(i, protTab.handCardTab[i], true);
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                let leftnum = g_CLDDZGameData.getHandCardCountNovBeginFunc(i);
                playerui.showUserLeftCardNovBeginFunc(true, leftnum);
                playerui.showTimeWaitTipNovBeginFunc(false);
                playerui.speekNothingNovBeginFunc();
                playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
            }
            this._startDispCardNovBeginFunc(selfSeatNo);
        }else if(protTab.status == STATUS_QIANGDIZHU){
            let turnSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            g_CLDDZGameData.setQiangRangNumNovBeginFunc(protTab.qiangCount);
            g_CLDDZGameData.setHandCardSortNovBeginFunc(true);
            if(protTab.bankerUserId) {
                let bankSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.bankerUserId);
                g_CLDDZGameData.setDiZhuSeatNoNovBeginFunc(bankSeatNo);
            } 
            for(let i=0; i<maxPlayer; i++){
                g_CLDDZGameData.setHandCardTabNovBeginFunc(i, protTab.handCardTab[i], true);
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                let leftnum = g_CLDDZGameData.getHandCardCountNovBeginFunc(i);
                playerui.showUserLeftCardNovBeginFunc(true, leftnum);
                playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                if(turnSeatNo==i && i!=selfSeatNo){
                    playerui.showTimeWaitTipNovBeginFunc(true);
                }else{
                    playerui.showTimeWaitTipNovBeginFunc(false);
                }
            }
            this._backgroundScipt.showThreeBackCardNovBeginFunc(true);
            this._backgroundScipt.showSmallBackCardNovBeginFunc(false);
            if(protTab.turnUserId==selfUserId){
                if(protTab.isTurnJiaoDZ==1){
                    this._getControlBtnNovBeginFunc().showJiaoDZBtnNovBeginFunc();
                }else{
                    this._getControlBtnNovBeginFunc().showQiangDZBtnNovBeginFunc();
                }
            }
            if(protTab.lastUserId!=null){
                let playerui = g_CLDDZGameData.getPlayerUIByUserIdNovBeginFunc(protTab.lastUserId);
                if(protTab.isJiaoDZ==1){
                    playerui.speekJiaoDiZhuNovBeginFunc(true);
                }else{
                    playerui.speekQiangDiZhuNovBeginFunc(true);
                }
            }
        }else if(protTab.status == STATUS_OUTCARD){
            g_CLDDZGameData.setBackCardNovBeginFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            let bankerSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.bankerUserId);
            let outSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.outUserId);
            let turnSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            g_CLDDZGameData.setDiZhuSeatNoNovBeginFunc(bankerSeatNo);
            g_CLDDZGameData.setCurOutCardTabNovBeginFunc(protTab.outTab);
            g_CLDDZGameData.setQiangRangNumNovBeginFunc(protTab.qiangCount);
            g_CLDDZGameData.setHandCardSortNovBeginFunc(true);
            for(let i=0; i<maxPlayer; i++){
                g_CLDDZGameData.setHandCardTabNovBeginFunc(i, protTab.handCardTab[i], true);
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                playerui.showDiZhuTipNovBeginFunc(false);
                if(bankerSeatNo==i){
                    playerui.showDiZhuTipNovBeginFunc(true);
                }
                if(i==outSeatNo){
                    playerui.getHandCardNovBeginFunc().drawOutCardNovBeginFunc(protTab.outTab);
                    playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                }else{
                    playerui.getHandCardNovBeginFunc().clearOutCardNovBeginFunc();
                }
                if(turnSeatNo==i && i!=selfSeatNo){
                    playerui.showTimeWaitTipNovBeginFunc(true);
                }else{
                    playerui.showTimeWaitTipNovBeginFunc(false);
                }
                let leftnum = g_CLDDZGameData.getHandCardCountNovBeginFunc(i);
                playerui.showUserLeftCardNovBeginFunc(true, leftnum);
                if(leftnum<=3){
                    playerui.showBaoJingTipNovBeginFunc(true)
                }
                
                if(g_CLDDZGameData.getNextSeatNoNovBeginFunc(outSeatNo)!=turnSeatNo){
                    if(i!=turnSeatNo && i!=outSeatNo){
                        playerui.speekBuChuNovBeginFunc();
                    }
                }
            }
            this._backgroundScipt.showSmallBackCardNovBeginFunc(true);
            if(protTab.turnUserId==selfUserId){
                this._getControlBtnNovBeginFunc().showOutCardBtnNovBeginFunc(protTab.mustOut==1);
            }
        }else if(protTab.status == STATUS_GAMEFINISH){
            //this._requestGameReadyNovBeginFunc(3);
            this._onShowGameResultNovBeginFunc(protTab.finishdata);
        }
    },
    onProtSocketMessageNovBeginFunc(mainId, assistId, protTab){
        cc.log("==========onProtSocketMessageNovBeginFunc=============", mainId, assistId, protTab);
        // AClassicDDZ_S2CBeginOut = 201;   //开始出牌
        // AClassicDDZ_S2CCallLandlord = 202;  //叫地主
        // AClassicDDZ_S2COutCard    = 203;    //出牌
        // AClassicDDZ_S2CBuChu  = 204;   //不出
        // AClassicDDZ_S2CSendCard  = 205;  //发牌
        // AClassicDDZ_S2CTuoGuan = 207;   //托管
        // AClassicDDZ_S2CGameFinish = 208;    //游戏结束
        let maxPlayer = g_CLDDZGameData.getMaxPlayerNovBeginFunc();
        let roominfo = g_CLDDZGameData.getRoomInfoNovBeginFunc();
        let selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        let selfSeatNo = roominfo.findUserSeatNoNovBeginFunc(selfUserId);
        for(let i=0; i<maxPlayer; i++){
            let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
            playerui.showReadyTipNovBeginFunc(false);
            playerui.showTimeWaitTipNovBeginFunc(false);
            playerui.speekNothingNovBeginFunc();
        }
        this._backgroundScipt.showBaseTipNovBeginFunc();
        if(assistId==g_ProtDef.AClassicDDZ_S2CReady){
            if(protTab.userId==selfUserId){
                this._resetAllUiNovBeginFunc();
            }
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                playerui.showReadyTipNovBeginFunc(protTab.readyTab[i]==1);
            }
        }else if(assistId==g_ProtDef.AClassicDDZ_S2CSendCard){
            for(let i=0; i<maxPlayer; i++){
                g_CLDDZGameData.setHandCardTabNovBeginFunc(i, protTab.handCardTab[i], false);
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                playerui.showUserLeftCardNovBeginFunc(true, 0);
                playerui.showTimeWaitTipNovBeginFunc(false);
                playerui.speekNothingNovBeginFunc();
            }
            this._startDispCardNovBeginFunc(selfSeatNo);
        }else if(assistId==g_ProtDef.AClassicDDZ_S2CCallLandlord){
            let turnSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            g_CLDDZGameData.setQiangRangNumNovBeginFunc(protTab.qiangCount);
            g_CLDDZGameData.setHandCardSortNovBeginFunc(true);
            this._getControlBtnNovBeginFunc().hideAllButtonNovBeginFunc();
            this._backgroundScipt.showThreeBackCardNovBeginFunc(true);
            this._backgroundScipt.showSmallBackCardNovBeginFunc(false);
            
            let jiaoSeatNo = -1;
            if (protTab.userId) {
                //当发牌完成后，会发送一个userId为空的首次叫地主的协议过来，通知开始叫地主
                jiaoSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.userId);
            }
            if(turnSeatNo==selfSeatNo && !protTab.isEnd){
                if(protTab.isTurnJiaoDZ==1){
                    this._getControlBtnNovBeginFunc().showJiaoDZBtnNovBeginFunc();
                }else{
                    this._getControlBtnNovBeginFunc().showQiangDZBtnNovBeginFunc();
                }
            }
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);

                let leftnum = g_CLDDZGameData.getHandCardCountNovBeginFunc(i);
                playerui.showUserLeftCardNovBeginFunc(true, leftnum);
                if(i==turnSeatNo && turnSeatNo!=selfSeatNo){
                    playerui.showTimeWaitTipNovBeginFunc(true);
                }
                playerui.speekNothingNovBeginFunc();
                if(i==jiaoSeatNo && protTab.isJiaoDZ!=null){
                    if(protTab.isJiaoDZ==1){
                        playerui.speekJiaoDiZhuNovBeginFunc(protTab.isCall==1);
                        g_CLDDZGameData.playJiaoDiZhuNovBeginFunc(protTab.userId, protTab.isCall==1);
                    }else{
                        playerui.speekQiangDiZhuNovBeginFunc(protTab.isCall==1);
                        g_CLDDZGameData.playQiangDiZhuNovBeginFunc(protTab.userId, protTab.isCall==1);
                    }
                }
            }
        }else if(assistId==g_ProtDef.AClassicDDZ_S2CBeginOut){
            g_CLDDZGameData.setBackCardNovBeginFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            let bankSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.bankerUserId);
            g_CLDDZGameData.setHandCardSortNovBeginFunc(true);
            g_CLDDZGameData.setDiZhuSeatNoNovBeginFunc(bankSeatNo);
            g_CLDDZGameData.addHandCardTabNovBeginFunc(bankSeatNo, protTab.backCardTab);
            g_CLDDZGameData.playGameStartNovBeginFunc();
            this._backgroundScipt.showThreeBackCardNovBeginFunc(true);
            this._backgroundScipt.recoverBackCardNovBeginFunc();
            if(selfSeatNo==bankSeatNo){
                this._getControlBtnNovBeginFunc().showOutCardBtnNovBeginFunc(true);
            }
            
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                playerui.showDiZhuTipNovBeginFunc(false);
                playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                let leftnum = g_CLDDZGameData.getHandCardCountNovBeginFunc(i);
                playerui.showUserLeftCardNovBeginFunc(true, leftnum);
                if(i==bankSeatNo){
                    playerui.showDiZhuTipNovBeginFunc(true);
                    playerui.getHandCardNovBeginFunc().moveAddActionCardNovBeginFunc(protTab.backCardTab);
                    if(i==selfSeatNo){
                        playerui.showTimeWaitTipNovBeginFunc(false);
                    }else{
                        playerui.showTimeWaitTipNovBeginFunc(true);
                    }
                }
            }
        }else if(assistId==g_ProtDef.AClassicDDZ_S2COutCard){
            let outSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.userId);
            let turnSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            let outtype = GameRuleLogic.getCardTabCardTypeNovBeginFunc(protTab.cardTab);
            if(protTab.newTurn==1 || Math.random()*100 < 50){
                g_CLDDZGameData.playOutCardNovBeginFunc(protTab.userId, protTab.cardTab[0], outtype);
            }else{
                g_CLDDZGameData.playEatCardDaNiNovBeginFunc(protTab.userId);
            }
            g_CLDDZGameData.playOutTypeNovBeginFunc(outtype);

            g_CLDDZGameData.setCurOutCardTabNovBeginFunc(protTab.cardTab);
            g_CLDDZGameData.removeCardTabNovBeginFunc(outSeatNo, protTab.cardTab);
            g_CLDDZGameData.setHandCardSortNovBeginFunc(true);
            this._backgroundScipt.showThreeBackCardNovBeginFunc(false);
            this._getControlBtnNovBeginFunc().hideAllButtonNovBeginFunc();
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                if(i==outSeatNo){
                    playerui.getHandCardNovBeginFunc().drawOutCardNovBeginFunc(protTab.cardTab);
                    playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc();
                }else if(i==turnSeatNo){
                    playerui.getHandCardNovBeginFunc().clearOutCardNovBeginFunc();
                }
                if(turnSeatNo==i && i!=selfSeatNo){
                    playerui.showTimeWaitTipNovBeginFunc(true);
                }else{
                    playerui.showTimeWaitTipNovBeginFunc(false);
                }
                let leftnum = g_CLDDZGameData.getHandCardCountNovBeginFunc(i);
                playerui.showUserLeftCardNovBeginFunc(true, leftnum);
                if(leftnum<=3){
                    playerui.showBaoJingTipNovBeginFunc(true)
                }
            }
            if(turnSeatNo==selfSeatNo){
                this._getControlBtnNovBeginFunc().showOutCardBtnNovBeginFunc(false);
            }
        }else if(assistId==g_ProtDef.AClassicDDZ_S2CBuChu){
            let theSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.userId);
            let turnSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.turnUserId);
            g_CLDDZGameData.playNotOutNovBeginFunc(protTab.userId);
            this._getControlBtnNovBeginFunc().hideAllButtonNovBeginFunc();
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
                if(protTab.newTurn==1){
                    g_CLDDZGameData.setCurOutCardTabNovBeginFunc(null);
                    playerui.getHandCardNovBeginFunc().clearOutCardNovBeginFunc();
                }else if(i==theSeatNo){
                    playerui.speekBuChuNovBeginFunc();
                    playerui.getHandCardNovBeginFunc().clearOutCardNovBeginFunc();
                }else if(i==turnSeatNo){
                    playerui.getHandCardNovBeginFunc().clearOutCardNovBeginFunc();                    
                }
            }
            if(turnSeatNo==selfSeatNo){
                this._getControlBtnNovBeginFunc().showOutCardBtnNovBeginFunc(protTab.newTurn==1);
            }
        }else if(assistId==g_ProtDef.AClassicDDZ_S2CTuoGuan){
        }else if(assistId==g_ProtDef.AClassicDDZ_S2CGameFinish){
            g_CLDDZGameData.playGameResultNovBeginFunc(protTab.winUserId == selfUserId);
            this._onShowGameResultNovBeginFunc(protTab);
            //游戏正常结束，调用基类函数
            let gameId = roominfo.getGameIdNovBeginFunc();
            let roomId = roominfo.getRoomIDNovBeginFunc();
            this.onBaseGameFinishNovBeginFunc(gameId, roomId);
        }
    },
    ////////////////////////////////////////////////////////////////////
    _onShowGameResultNovBeginFunc(protTab){
        this._resetAllUiNovBeginFunc();
        g_CLDDZGameData.setHandCardSortNovBeginFunc(true);
        g_CLDDZGameData.setBackCardNovBeginFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
        this._backgroundScipt.showSmallBackCardNovBeginFunc(true);
        let maxPlayer = g_CLDDZGameData.getMaxPlayerNovBeginFunc();
        let roominfo = g_CLDDZGameData.getRoomInfoNovBeginFunc();
        let bankerSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.bankerUserId);
        let winSeatNo = roominfo.findUserSeatNoNovBeginFunc(protTab.winUserId);
        let selfSeatNo = g_CLDDZGameData.getSelfSeatNoNovBeginFunc();
        for(let i=0; i<maxPlayer; i++){
            g_CLDDZGameData.setHandCardTabNovBeginFunc(i, protTab.handCardTab[i], true);
            let playerui = g_CLDDZGameData.getPlayerUIBySeatNoNovBeginFunc(i);
            playerui.getHandCardNovBeginFunc().drawHandCardNovBeginFunc(null, true);
            playerui.showDiZhuTipNovBeginFunc(false);
            if(bankerSeatNo==i){
                playerui.showDiZhuTipNovBeginFunc(true);
            }
            if(i==winSeatNo) {
                playerui.getHandCardNovBeginFunc().drawOutCardNovBeginFunc(protTab.lastOutTab);
            }
            roominfo.updateUserGoldNovBeginFunc(i, protTab.winScore[i]);
            playerui.showTotalScoreNovBeginFunc(true, protTab.winScore[i]);
        }
        this._getGameResultNovBeginFunc().showResultNovBeginFunc(true, protTab.isWinTab[selfSeatNo]==1, protTab);
    },
});
