var exFangHaoNodePos = null;
var exJuShuNodePos = null;
cc.Class({
    extends: cc.Component,

    properties: {
        O_basescorenode : cc.Node,
        O_beilvnode : cc.Node,
        O_fanghaonode : cc.Node,
        O_jushunode : cc.Node,

        O_timetext : cc.Label,
        
        O_smallcardparent : cc.Node,
        O_smallcardArray : {
            default : [],
            type : cc.Node
        },
        O_beilvtip : cc.Node,
        O_typetip : cc.Node,
        O_backcardprefab : cc.Prefab,
        
        _backcardparent : null,
    },

    // use this for initialization
    onLoad: function () {
        this._setBaseNumNovBeginFunc(this.O_fanghaonode, 0);
        this._setBaseNumNovBeginFunc(this.O_basescorenode, 0);
        this._setBaseNumNovBeginFunc(this.O_beilvnode, 0);

        let self = this;
        let uptimerNovBeginFunc = function(dt){
            let date = new Date();
            let tostr = "";
            if(date.getHours()<10){
                tostr += "0";
            }
            tostr += date.getHours();
            tostr += ":";
            if(date.getMinutes()<10){
                tostr += "0";
            }
            tostr += date.getMinutes();
            self.O_timetext.string = tostr;
        };
        uptimerNovBeginFunc();
        this.schedule(uptimerNovBeginFunc, 1);
        this.showThreeBackCardNovBeginFunc(false);

        this.O_smallcardparent.active = false;

        // this.scheduleOnce(()=>{
        //     self.recoverBackCardNovBeginFunc();
        // }, 2);
    },

    showBaseTipNovBeginFunc(){
        let roominfo = g_CLDDZGameData.getRoomInfoNovBeginFunc();
        if(roominfo){
            this._setBaseNumNovBeginFunc(this.O_fanghaonode, roominfo.getRoomIDNovBeginFunc());
            this._setBaseNumNovBeginFunc(this.O_basescorenode, roominfo.getBaseScoreNovBeginFunc());
            this._setBaseNumNovBeginFunc(this.O_beilvnode, roominfo.getBaseBeiLvNovBeginFunc());
            
            if(!exFangHaoNodePos){
                exFangHaoNodePos = new cc.Vec2(this.O_fanghaonode.position.x, this.O_fanghaonode.position.y);
            }
            if(!exJuShuNodePos){
                exJuShuNodePos = new cc.Vec2(this.O_jushunode.position.x, this.O_jushunode.position.y);
            }
            let curjushu = roominfo.getCurJuShuNovBeginFunc();
            let maxjushu = roominfo.getMaxJuShuNovBeginFunc();
            if(maxjushu>0){
                this._setBaseNumNovBeginFunc(this.O_jushunode, curjushu + "/" + maxjushu);
            }else{
                this.O_jushunode.active = false;
                this.O_fanghaonode.position = exJuShuNodePos; 
            }
        }
        cc.log("======ScoreTip===resetTip=============", roominfo);
    },    
    showSmallBackCardNovBeginFunc(bVisible){
        cc.log("=======showSmallBackCardNovBeginFunc=======", bVisible);
        this.O_smallcardparent.active = bVisible;
        if(!bVisible) return ;
        this.O_beilvtip.active = false;
        this.O_typetip.active = false;
        let backCardTab = g_CLDDZGameData.getBackCardNovBeginFunc();
        for(let i=0; i<this.O_smallcardArray.length; i++){
            let toSpUrl = g_CLDDZGameData.getPokerFramePathNovBeginFunc(false, backCardTab[i]);
            let toSprite = this.O_smallcardArray[i].getComponent(cc.Sprite);
            cc.loader.loadRes(toSpUrl, function(err, texture){
                toSprite.spriteFrame = new cc.SpriteFrame(texture);
            });
        }
    },
    showThreeBackCardNovBeginFunc(bVisible){
        if(!this._backcardparent && !bVisible) return ;
        if(this._backcardparent) this._backcardparent.destroy();
        
        this._backcardparent = cc.instantiate(this.O_backcardprefab);
        this._backcardparent.parent = this.node;
        this._backcardparent.active = bVisible;
        cc.log("========showThreeBackCardNovBeginFunc=============", this._backcardparent);
    },
    recoverBackCardNovBeginFunc(){
        cc.log("=======recoverBackCardNovBeginFunc=======");
        this.showThreeBackCardNovBeginFunc(true);
        this.O_smallcardparent.active = false;
        let backCardTab = g_CLDDZGameData.getBackCardNovBeginFunc();
        let toShowNovBeginFunc = function(){
            cc.log("=======toShowNovBeginFunc=======");
            if(this.O_smallcardparent.active) return ;
            this._backcardparent.active = false;
            this.showSmallBackCardNovBeginFunc(true);
        };
        let backcardArray = [];
        let toPosArray = [];
        let toSpFrameArray = [];
        for(let i=1; i<=3; i++){
            let toCard = this._backcardparent.getChildByName("card" + i);
            backcardArray.push(toCard);
        }
        for(let i=0; i<backCardTab.length; i++){
            let toSpUrl = g_CLDDZGameData.getPokerFramePathNovBeginFunc(true, backCardTab[i], true);
            var texture = cc.textureCache.addImage(toSpUrl);
            toSpFrameArray.push(texture);
            let toPosEx = this.O_smallcardArray[i].convertToWorldSpaceAR(cc.Vec2.ZERO);
            let toNodePos = this._backcardparent.convertToNodeSpaceAR(toPosEx);
            toPosArray.push(toNodePos);
        }
        for(let i=0; i<backcardArray.length; i++){
            let toRotateNovBeginFunc = ()=>{
                cc.log("====toRotateNovBeginFunc=========", i);
                let toSprite = backcardArray[i].getComponent(cc.Sprite);
                toSprite.spriteFrame = new cc.SpriteFrame(toSpFrameArray[i]);
            };
            backcardArray[i].runAction(cc.sequence(cc.scaleTo(0.5, 0, 1), cc.callFunc(toRotateNovBeginFunc, this), 
                cc.scaleTo(0.5, 1, 1), cc.moveTo(0.5, toPosArray[i]), cc.callFunc(toShowNovBeginFunc, this), cc.hide()));
        }
    },

    /////////////////////////////////////////////////////////////////////////////
    _setBaseNumNovBeginFunc(node, str){
        node.getChildByName("num").getComponent(cc.Label).string = str;
    },
});
