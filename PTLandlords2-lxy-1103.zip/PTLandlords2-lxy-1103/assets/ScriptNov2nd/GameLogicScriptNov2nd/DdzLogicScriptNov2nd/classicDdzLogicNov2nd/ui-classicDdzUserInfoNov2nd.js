cc.Class({
    extends: cc.Component,

    properties: {
        O_userName : cc.Label,
        O_userId : cc.Label,
        O_userIp : cc.Label,
        O_userHead : cc.Node,
    },

    // use this for initialization
    onLoad: function () {

    },

    showInfoNovBeginFunc(seatNo){
        let roominfo = g_CLDDZGameData.getRoomInfoNovBeginFunc();
        let userinfo = roominfo.getUserInfoNovBeginFunc(seatNo);
        cc.log("===========showInfoNovBeginFunc=========", roominfo, userinfo);
        
        this.O_userName.string = userinfo.userName;
        this.O_userId.string = userinfo.userId;
        this.O_userIp.string = userinfo.addr;
        let headurl = userinfo.headurl;
        if (headurl && headurl.length > 0) {
            let toSprite = this.O_userHead.getComponent(cc.Sprite);
            let toType = "png";
            if(headurl.indexOf(".jpg")){
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },
    onCloseBtnNovBeginFunc(){
        this.node.destroy();
    },
});
