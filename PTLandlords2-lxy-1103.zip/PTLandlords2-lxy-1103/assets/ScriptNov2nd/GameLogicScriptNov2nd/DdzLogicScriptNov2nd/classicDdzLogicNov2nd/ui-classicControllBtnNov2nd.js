cc.Class({
    extends: cc.Component,

    properties: {
        O_outcardbtnnode : cc.Node,
        O_qiangdzbtnnode : cc.Node,
        O_jiaodzbtnnode : cc.Node,

        O_buchubtn : cc.Button,
    },

    // use this for initialization
    onLoad: function () {
        this.hideAllButtonNovBeginFunc();
    },
    hideAllButtonNovBeginFunc : function(){
        this.O_outcardbtnnode.active = false;
        this.O_qiangdzbtnnode.active = false;
        this.O_jiaodzbtnnode.active = false;
    },
    showOutCardBtnNovBeginFunc : function(bMustOut){
        this.hideAllButtonNovBeginFunc();
        this.O_outcardbtnnode.active = true;
        this.O_buchubtn.interactable = !bMustOut;
    },
    showQiangDZBtnNovBeginFunc : function(){
        this.hideAllButtonNovBeginFunc();
        this.O_qiangdzbtnnode.active = true;
    },
    showJiaoDZBtnNovBeginFunc : function(){
        this.hideAllButtonNovBeginFunc();
        this.O_jiaodzbtnnode.active = true;
    },
    ////////////////////////////////////////////////////
    onBuChuBtnNovBeginFunc : function(event){
        this.node.emit("outbtn-buchu");
    },
    onLastHandBtnNovBeginFunc : function(event){
        //this.node.emit("outbtn-lasthand");
    },
    onTiShiBtnNovBeginFunc : function(event){
        this.node.emit("outbtn-tishi");
    },
    onChuPaiBtnNovBeginFunc : function(event){
        this.node.emit("outbtn-chupai");
    },
    /////////////////////////////////////////////////
    _priCallProtocolDZNovBeginFunc : function(isCall){
        this.hideAllButtonNovBeginFunc();
        let toProtData = {};
        toProtData.isCall = isCall,
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ClassicDDZ, g_ProtDef.AClassicDDZ_C2SCallLandlord, toProtData);
    },
    onBuQiangBtnNovBeginFunc : function(event){
        cc.log("=========onBuQiangBtnNovBeginFunc===");
        this._priCallProtocolDZNovBeginFunc(0);
    },
    onQiangDZBtnNovBeginFunc : function(event){
        cc.log("=========onQiangDZBtnNovBeginFunc===");
        this._priCallProtocolDZNovBeginFunc(1);
    },
    /////////////////////////////////////////////////
    onBuJiaoBtnNovBeginFunc : function(event){
        cc.log("=========onBuJiaoBtnNovBeginFunc===");
        this._priCallProtocolDZNovBeginFunc(0);
    },
    onJiaoDZBtnNovBeginFunc : function(event){
        cc.log("=========onJiaoDZBtnNovBeginFunc===");
        this._priCallProtocolDZNovBeginFunc(1);
    },
});
