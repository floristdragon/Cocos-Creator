cc.Class({
    extends: cc.Component,

    properties: {
        _seatNo : 0,
        _handCardHandler : null,
    },
    onLoad(){
        //this.resetUiNovBeginFunc();
    },
    initUiNovBeginFunc(seatNo){
        this._seatNo = seatNo;

        this._handCardHandler = this.getComponent("ui-erRenDdzHandCardNov2nd");
        this._handCardHandler.initUiNovBeginFunc(this._seatNo);

        this.resetUiNovBeginFunc();
        cc.log("=========player===initUiNovBeginFunc===========", seatNo, g_ERDDZGameData.getSelfSeatNoNovBeginFunc());
    },
    resetUiNovBeginFunc(){
        this.speekNothingNovBeginFunc();
        this.showUserInfoNovBeginFunc(false);
        this.showDiZhuTipNovBeginFunc(false);
        this.showUserLeftCardNovBeginFunc(false, 0);
        this.showBaoJingTipNovBeginFunc(false);
        this.showTotalScoreNovBeginFunc(false,0);
        this.showTimeWaitTipNovBeginFunc(false);
        this.showTuoGuanNovBeginFunc(false);
        this.showReadyTipNovBeginFunc(false);
        this._handCardHandler.resetUiNovBeginFunc();
    },
    getSeatNoNovBeginFunc(){
        return this._seatNo;
    },
    getHandCardNovBeginFunc(){
        return this._handCardHandler;
    },
    getHandCardPosNovBeginFunc(){
        let toNode = this.node.getChildByName("handcard");
        return toNode.convertToWorldSpaceAR(cc.Vec2.ZERO);
    },
    showUserInfoNovBeginFunc(isVisible, name, score, headurl){
        let nameNode = this.node.getChildByName("name");
        let scoreNode = this.node.getChildByName("score");
        let faceNode = this.node.getChildByName("playerface");
        nameNode.active = isVisible;
        scoreNode.active = isVisible;
        faceNode.active = isVisible;
        if(!isVisible) return ;
        cc.log("=======showUserInfoNovBeginFunc=======", name, score, headurl);
        if(!name) name = "";
        if(!score) score = "0";
        let nametext = nameNode.getComponent(cc.RichText);
        let scoretext = scoreNode.getComponent(cc.RichText);
        nametext.string = name;
        scoretext.string = score+"";

        faceNode.scaleY = 1;
        faceNode.scaleX = 1;
        if (headurl && headurl.length > 0) {
            let toSprite = faceNode.getComponent(cc.Sprite);
            let toType = "png";
            if(headurl.indexOf(".jpg")){
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },
    showDiZhuTipNovBeginFunc(isDiZhu){
        let tipNode = this.node.getChildByName("dizhutip");
        tipNode.active = isDiZhu;
    },
    showUserLeftCardNovBeginFunc(isVisible, leftnum){
        let tipNode = this.node.getChildByName("leftnum");
        tipNode.active = isVisible;
        let ctext = tipNode.getComponent(cc.RichText);
        if(!leftnum) leftnum = "0";
        ctext.string = leftnum+"";
    },
    showBaoJingTipNovBeginFunc(isVisible){
        let tipNode = this.node.getChildByName("baojingtip");
        tipNode.active  = isVisible;
    },
    showTotalScoreNovBeginFunc(isVisible, totalscore){
        let tipNode = this.node.getChildByName("totalscore");
        tipNode.active = isVisible;
        let ctext = tipNode.getComponent(cc.Label);
        if(!totalscore) totalscore = "0";
        ctext.string = totalscore+"";
    },
    showTimeWaitTipNovBeginFunc(isVisible){
        let tipNode = this.node.getChildByName("timewaittip");
        tipNode.active  = isVisible;
    },
    showTuoGuanNovBeginFunc(istuoguan){
        let tipNode = this.node.getChildByName("tuoguantip");
        tipNode.active  = istuoguan;
    },
    showReadyTipNovBeginFunc(isVisible){
        let tipNode = this.node.getChildByName("readytip");
        tipNode.active  = isVisible;
    },
    /////////////////////////////////////////////////////////
    _priSpeakThingNovBeginFunc(flag){
        let loadurl = "DdzResNov2nd/speakTipNov2nd/Nov2nd_tp_speak_"+flag;
        let tipNode = this.node.getChildByName("speakTipNov2nd");
        tipNode.active = true;
        let spNode = tipNode.getComponent(cc.Sprite);
        cc.loader.loadRes(loadurl, function(err, texture){
            spNode.spriteFrame = new cc.SpriteFrame(texture);
        });
    },
    speekNothingNovBeginFunc(){
        let tipNode = this.node.getChildByName("speakTipNov2nd");
        tipNode.active = false;
    },
    speekBuChuNovBeginFunc(){
        this._priSpeakThingNovBeginFunc(1);
    },
    speekJiaoDiZhuNovBeginFunc(isCall){
        if(isCall){
            this._priSpeakThingNovBeginFunc(5);
        }else{
            this._priSpeakThingNovBeginFunc(2);
        }
    },
    speekQiangDiZhuNovBeginFunc(isCall){
        if(isCall){
            this._priSpeakThingNovBeginFunc(6);
        }else{
            this._priSpeakThingNovBeginFunc(3);
        }
    },
    speekRangPaiNovBeginFunc(isRang){
        if(isRang){
            this._priSpeakThingNovBeginFunc(7);
        }else{
            this._priSpeakThingNovBeginFunc(4);
        }
    },
});
