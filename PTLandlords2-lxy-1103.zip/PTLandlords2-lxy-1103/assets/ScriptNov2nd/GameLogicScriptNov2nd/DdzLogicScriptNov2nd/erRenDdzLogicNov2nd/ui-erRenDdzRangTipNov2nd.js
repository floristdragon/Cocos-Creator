cc.Class({
    extends: cc.Component,

    properties: {
        O_ifrangxiantip : cc.Node,
        O_ninbeirangtip : cc.Node,
        O_ninrangtip : cc.Node,
        O_qiangdizhutip : cc.Node,
    },

    // use this for initialization
    onLoad: function () {
        this.hideAllTipNovBeginFunc();
    },
    hideAllTipNovBeginFunc(){
        this.O_ifrangxiantip.active = false;
        this.O_ninbeirangtip.active = false;
        this.O_ninrangtip.active = false;
        this.O_qiangdizhutip.active = false;
    },
    showQiangDZTipNovBeginFunc(bVisible) {
        let qiangNum = g_ERDDZGameData.getQiangRangNumNovBeginFunc();
        cc.log("==========showQiangDZTipNovBeginFunc=========", qiangNum);
        if(!qiangNum) qiangNum = "0";
        this.O_qiangdizhutip.active = bVisible;
        if(bVisible){
            let numlabel = this.O_qiangdizhutip.getChildByName("num").getComponent(cc.Label);
            numlabel.string = qiangNum;
        }
    },
    showRangTipNovBeginFunc(){
        this.O_ifrangxiantip.active = false;
        this.O_ninbeirangtip.active = false;
        this.O_ninrangtip.active = false;

        let qiangNum = g_ERDDZGameData.getQiangRangNumNovBeginFunc();
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoNovBeginFunc();
        let isDiZhu = (g_ERDDZGameData.getDiZhuSeatNoNovBeginFunc()==selfSeatNo);

        let nodzleftnum = 0;
        if(isDiZhu) {
            let duijiaSeatNo = g_ERDDZGameData.getNextSeatNoNovBeginFunc(selfSeatNo);
            nodzleftnum = g_ERDDZGameData.getHandCardCountNovBeginFunc(duijiaSeatNo);
        }else{
            nodzleftnum = g_ERDDZGameData.getHandCardCountNovBeginFunc(selfSeatNo);
        }
        let toleftnum = nodzleftnum - qiangNum;
        cc.log("=========showRangTipNovBeginFunc================", nodzleftnum, qiangNum, isDiZhu);
        if(toleftnum<0) toleftnum = 0;
        if(isDiZhu){
            this.O_ninrangtip.active = true;
            let numlabel1 = this.O_ninrangtip.getChildByName("num1").getComponent(cc.Label);
            let numlabel2 = this.O_ninrangtip.getChildByName("num2").getComponent(cc.Label);
            numlabel1.string = qiangNum + "";
            numlabel2.string = toleftnum + "";
        }else{
            this.O_ninbeirangtip.active = true;
            let numlabel1 = this.O_ninbeirangtip.getChildByName("num1").getComponent(cc.Label);
            let numlabel2 = this.O_ninbeirangtip.getChildByName("num2").getComponent(cc.Label);
            numlabel1.string = qiangNum + "";
            numlabel2.string = toleftnum + "";
        }

    },
});
