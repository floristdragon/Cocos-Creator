let nativeExtend = require("nativeExtendNov2nd");
cc.Class({
    extends: cc.Component,

    properties: {
        O_giveuptip : cc.Node,
        O_winnode : cc.Node,
        O_lossnode : cc.Node,

        O_winAniNode : cc.Node,
        O_lossAniNode : cc.Node,
        O_springAniNode : cc.Node,
        O_jiesuannode : cc.Node,

        O_zongbeishulabel : cc.Label,
        O_qiangdzlabel : cc.Label,
        O_dipailabel : cc.Label,
        O_zhadanlabel : cc.Label,
        O_chuntianlabel : cc.Label,
        O_rangxianlabel : cc.Label,
    },

    // use this for initialization
    onLoad: function () {
        this.showResultNovBeginFunc(false);
    },
    showResultNovBeginFunc : function(isVisible, resultdata){
        this.node.active = isVisible;
        if(!isVisible){
            return ;
        }
        let selfUserId = g_UserManager.getSelfUserIdNovBeginFunc();
        let isGameWin = (resultdata.winUserId==selfUserId);
        let isGiveUp = false;
        if(resultdata.giveupUserId && resultdata.giveupUserId!=selfUserId){
            isGiveUp = true; //对方主动认输
        }
        this.O_giveuptip.active = isGiveUp;
        this.O_winnode.active = isGameWin;
        this.O_lossnode.active = !isGameWin;

        this.O_lossAniNode.active = false;
        this.O_springAniNode.active = false;
        this.O_winAniNode.active = false;
        if(!isGameWin){
            this.O_lossAniNode.active = true;
            this.O_lossAniNode.getComponent(cc.Animation).play();
        }else{
            if(resultdata.springBeiShu>0){
                this.O_springAniNode.active = true;
                this.O_springAniNode.getComponent(cc.Animation).play();
            }else{
                this.O_winAniNode.active = true;
                this.O_winAniNode.getComponent(cc.Animation).play();
            }
        }

        this.O_zongbeishulabel.string = "X"+resultdata.totalBeiShu;
        this.O_qiangdzlabel.string = "X"+resultdata.qiangdzBeiShu;
        this.O_dipailabel.string = "X"+resultdata.dipaiBeiShu;
        this.O_zhadanlabel.string = "X"+resultdata.zhadanBeiShu;
        this.O_chuntianlabel.string = "X"+resultdata.springBeiShu;
        this.O_rangxianlabel.string = "X0";

        this.O_jiesuannode.active = true;
        this.O_jiesuannode.opacity = 0
        this.O_jiesuannode.runAction(cc.sequence(cc.delayTime(1.0), cc.fadeIn(0.5)));
    },

    onExitGameBtnNovBeginFunc : function(event){
        this.showResultNovBeginFunc(false);
        let toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIdNovBeginFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIdNovBeginFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqLeaveDesk, toProtTab);
    },
    onShareBtnNovBeginFunc : function(event){
        nativeExtend.screenShoot((path, w, h)=>{
            nativeExtend.shareImageNative("image", path, "");
        });
    },
    onContinueBtnNovBeginFunc : function(event){
        this.showResultNovBeginFunc(false);

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SReady);
    },
});
