
var GameRuleLogic = require("DdzRuleLogicNov2nd");
var GameRuleConfig =  require("DdzRuleConfigNov2nd");
cc.Class({
    extends : cc.Component,
    properties: {
        O_handcardprefab : cc.Prefab,
        O_outcardprefab : cc.Prefab,
        O_handCardSp : cc.Node,
        O_outCardSp : cc.Node,
        O_handCardNode : cc.Node,
        ///////////////////////////////////////////
        _seatNo : 0,
        _handCardSize : null,
        _outCardSize : null,
        _allCardArray : [],

        _tishiEatCardTab : [],
        _touchPreMoveUpNum : 0,
    },
    // 尽量在onLoad来初始化界面，在initUI初始化和数据无关的变量
    onLoad(){
        cc.log("========handcard=========onLoad======================", this.O_handCardSp);
        this._handCardSize = new cc.Size(this.O_handCardSp.width, this.O_handCardSp.height);
        this.O_handCardSp.active = false;

        this._outCardSize = new cc.Size(this.O_outCardSp.width, this.O_outCardSp.height);
        this.O_outCardSp.getComponent(cc.Sprite).enabled = false;

        let self = this;
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_START, function(event){
            //console.log("TOUCH_START");
            let touchPos = event.getLocation();
            self._priCheckTouchHandCardNovBeginFunc(touchPos, 1);
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_MOVE, function(event){
            //console.log("TOUCH_MOVE");
            let touchPos = event.getLocation();
            self._priCheckTouchHandCardNovBeginFunc(touchPos, 2);
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_END, function(event){
            //console.log("TOUCH_END");
            let touchPos = event.getLocation();
            self._priCheckTouchHandCardNovBeginFunc(touchPos, 3);
        });
        // this.scheduleOnce(function(){
        //     let toCardTab = [22,140,150,24,23,21, 42,43, 44,41,63,61,62,34,73,82,83];
        //     toCardTab.sort((a, b)=>{
        //         if(a>b) return -1;
        //         return 1;
        //     })
        //     g_ERDDZGameData.setHandCardTabNovBeginFunc(this._seatNo, toCardTab);
        //     ///g_ERDDZGameData.setCurOutCardTabNovBeginFunc([31, 32, 33, 52, 53]);
        //     g_ERDDZGameData.removeCardTabNovBeginFunc(this._seatNo, [63,61,62]);
        //     self.drawHandCardNovBeginFunc(17);
        // }, 2);

        //let ret = GameRuleLogic.getCardTabCardTypeNovBeginFunc([11,13,21,31,43,44,52,54]);
        //cc.log("=======GameRuleLogic.IsCardTab1CanEatCardTab2NovBeginFunc=========", ret);
    },
    //属于该句柄的seatNo，cardpos为手牌中心位置，cardWidth一张手牌的宽度
    initUiNovBeginFunc(seatNo){
        this._seatNo = seatNo;
    },
    resetUiNovBeginFunc(){
        this._clearHandCardNovBeginFunc();
        this.clearOutCardNovBeginFunc();
    },
    _clearHandCardNovBeginFunc(){
        this.O_handCardNode.removeAllChildren(true);
        this._allCardArray = [];
    }, 
    clearOutCardNovBeginFunc(){
        this.O_outCardSp.removeAllChildren(true);
    },
    drawHandCardNovBeginFunc(numCard, isAllShow){
        this._clearHandCardNovBeginFunc();
        let handCardTab = g_ERDDZGameData.getHandCardTabNovBeginFunc(this._seatNo);
        if(!handCardTab || handCardTab.length<=0) return ;
        if(!numCard || numCard>handCardTab.length) numCard = handCardTab.length;
        let beginPosX = 0;
        let beginPosY = 0;
        let toInterval = this._handCardSize.width/2.5;
        beginPosX -= (numCard-1) * toInterval / 2;
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoNovBeginFunc();
        if(selfSeatNo!=this._seatNo){
            toInterval = this._handCardSize.width/3.5;
        }
        let rangpaiNum = g_ERDDZGameData.getQiangRangNumNovBeginFunc();
        if(this._seatNo==g_ERDDZGameData.getDiZhuSeatNoNovBeginFunc()){
            rangpaiNum = -1;
        }
        cc.log("========drawHandCardNovBeginFunc=========", handCardTab, numCard, rangpaiNum);
        for(let i=0; i<numCard; i++){
            let topNode = cc.instantiate(this.O_handcardprefab);
            let toCardScript = topNode.getComponent("ui-erRenDdzPokerCardNov2nd"); //不能用var

            if(selfSeatNo==this._seatNo || isAllShow){  
                toCardScript.setCardValueNovBeginFunc(handCardTab[i]);
            }else{
                let israngpai = false;
                if(i<rangpaiNum){
                    israngpai = true;
                }
                toCardScript.setCardValueNovBeginFunc(0, israngpai);                
            }
            if(selfSeatNo!=this._seatNo){
                toCardScript.setCardScaleNovBeginFunc(0.75);
            }
            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            //console.log("======drawHandCardNovBeginFunc============", beginPosX, beginPosY);
            topNode.setLocalZOrder(i);
            beginPosX += toInterval;
            this._allCardArray.push(topNode);
            
            topNode.parent = this.O_handCardNode;
        }
        //按照zorder来从大到小排列，用于触摸
        this._allCardArray.reverse();
        console.log("===drawHandCardNovBeginFunc====end==", this.O_handCardNode);
    },  
    drawOutCardNovBeginFunc(outCardTab){
        this.clearOutCardNovBeginFunc();
        let numCard = outCardTab.length;
        cc.log("========drawOutCardNovBeginFunc=========", outCardTab, numCard);
        let beginPosX = 0;
        let beginPosY = 0;
        let toInterval = this._outCardSize.width/2.5;
        beginPosX -= (numCard-1) * toInterval / 2;
        for(let i=0; i<numCard; i++){
            let topNode = cc.instantiate(this.O_outcardprefab);
            let toCardScript = topNode.getComponent("ui-erRenDdzPokerCardNov2nd"); //不能用var
            //cc.log("====drawOutCardNovBeginFunc=======", this._seatNo, toCardScript);
            toCardScript.setCardValueNovBeginFunc(outCardTab[i]);
            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            //console.log("======drawHandCardNovBeginFunc============", beginPosX, beginPosY);
            topNode.setLocalZOrder(i);
            beginPosX += toInterval;
            
            topNode.parent = this.O_outCardSp;
        }
    },
    moveAddActionCardNovBeginFunc(actCardTab){
        for(let j=0; j<actCardTab.length; j++){
            for(let i=0; i<this._allCardArray.length; i++){
                let cardScript = this._allCardArray[i].getComponent("ui-erRenDdzPokerCardNov2nd");
                if(!cardScript) return ;
                if(!cardScript.isCardMoveUpNovBeginFunc() && actCardTab[j]==cardScript.getCardValueNovBeginFunc()){
                    cardScript.moveUpCardNovBeginFunc();
                    cardScript.moveDownCardNovBeginFunc(1);
                    cardScript.showPointTipNovBeginFunc(true);
                    break;
                }
            }
        }
    },
    moveTiShiHandCardNovBeginFunc(outCardTab){
        cc.log("======moveTiShiHandCardNovBeginFunc====11====", outCardTab);
        let handCardTab = g_ERDDZGameData.getHandCardTabNovBeginFunc(this._seatNo);
        if(!handCardTab || handCardTab.length<=0) return ;
        let preTiShiLength = this._tishiEatCardTab.length;
        let isEat = GameRuleLogic.IsCardTab1CanEatCardTab2NovBeginFunc(this._tishiEatCardTab, outCardTab);
        if(!isEat){
            cc.log("======moveTiShiHandCardNovBeginFunc====22====");
            this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabNovBeginFunc(handCardTab, outCardTab);
        }else{
            cc.log("======moveTiShiHandCardNovBeginFunc====33====");
            this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabNovBeginFunc(handCardTab, this._tishiEatCardTab);
            if(preTiShiLength > 0 && this._tishiEatCardTab.length<=0){
                this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabNovBeginFunc(handCardTab, outCardTab);
            }
        }
        cc.log("======moveTiShiHandCardNovBeginFunc====44====", isEat, preTiShiLength, this._tishiEatCardTab);
        this._priMoveUpCardTabNovBeginFunc(this._tishiEatCardTab);
    },
    clearTiShiHandCardNovBeginFunc(){
        this._tishiEatCardTab = [];
    },
    getMoveUpCardTabNovBeginFunc(outCardTab){
        let tab = [];
        for(let i=0; i<this._allCardArray.length; i++){
            let cardScript = this._allCardArray[i].getComponent("ui-erRenDdzPokerCardNov2nd");
            if(!cardScript) return ;
            if(cardScript.isCardMoveUpNovBeginFunc()){
                tab.push(cardScript.getCardValueNovBeginFunc());
            }
        }
        let ctype = GameRuleLogic.getCardTabCardTypeNovBeginFunc(tab);
        if(ctype == GameRuleConfig.CardType.ErrorType)return ;
        let isEat = GameRuleLogic.IsCardTab1CanEatCardTab2NovBeginFunc(tab, outCardTab);
        if(isEat) return tab;
    },

    //////////////////////////////////////////////////////////////////////////////////////////////
    _priMoveUpCardTabNovBeginFunc(cardTab){
        for(let i=0; i<this._allCardArray.length; i++){
            let cardScript = this._allCardArray[i].getComponent("ui-erRenDdzPokerCardNov2nd");
            if(!cardScript) return ;
            cardScript.moveDownCardNovBeginFunc();
        }
        for(let j=0; j<cardTab.length; j++){
            for(let i=0; i<this._allCardArray.length; i++){
                let cardScript = this._allCardArray[i].getComponent("ui-erRenDdzPokerCardNov2nd");
                if(!cardScript) return ;
                if(!cardScript.isCardMoveUpNovBeginFunc() && cardTab[j]==cardScript.getCardValueNovBeginFunc()){
                    cardScript.moveUpCardNovBeginFunc();
                    break;
                }
            }
        }
    },
    _priCheckTouchHandCardNovBeginFunc(touchPos, touchType){
        if(touchType==1) this._touchPreMoveUpNum = 0;
        let touchindex = -1;
        for(let i=0; i<this._allCardArray.length; i++){
            let cardScript = this._allCardArray[i].getComponent("ui-erRenDdzPokerCardNov2nd");
            if(!cardScript) return ;
            if(cardScript.onCheckTouchNovBeginFunc(touchPos, touchType)) {
                touchindex = i;
                break;
            }
        }
        let moveUpTab = [];
        for(let i=0; i<this._allCardArray.length; i++){
            let cardScript = this._allCardArray[i].getComponent("ui-erRenDdzPokerCardNov2nd");
            if(!cardScript) return ;
            if(i!=touchindex){
                cardScript.onUnTouchCardNovBeginFunc();
            }
            if(cardScript.isCardMoveUpNovBeginFunc()) {
                moveUpTab.push(cardScript.getCardValueNovBeginFunc());
            }
        }
    }
});
