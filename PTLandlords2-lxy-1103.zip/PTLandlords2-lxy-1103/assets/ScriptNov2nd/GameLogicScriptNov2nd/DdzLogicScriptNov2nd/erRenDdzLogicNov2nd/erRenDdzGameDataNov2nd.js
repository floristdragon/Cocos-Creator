
require("include");
let gameconfig = require("gameConfigNov2nd");
let GameRuleConfig =  require("DdzRuleConfigNov2nd");

//在两个数之间随机一个整数
var MathRandomNovBeginFunc = function(min, max){
    if(min>max) return min;
    let to = Math.random() * (max-min) + min;
    let toi = Math.floor(to);
    if(to < toi + 0.5) return toi;
    return toi + 1;
};  
window.g_ERDDZGameData = {
    _gameId : 0,
    _roomId : 0,

    _playerUIArray : [],
    _seatToUIArray : [],

    _selfSeatNo : 0,

    _handCardTab : [],
    _outCardTab : [],
    _tuoguanTab : [],
    _curOutCardTab : [],
    _backCardTab : [],
    _dizhuSeatNo : -1,

    _mingpaiCardId : 0,
    _qiangRangNum : 0,
    _ishandcardSort : false,
    _isrequestStatus : false,
    //------------------------------------
    //------------------------------------
    initNovBeginFunc(gameId, roomId, selfSeatNo){
        this._gameId = gameId;
        this._roomId = roomId;
        this._selfSeatNo = selfSeatNo;
        this.resetInitNovBeginFunc();
    },
    resetInitNovBeginFunc(){
        this._handCardTab = [];
        this._outCardTab = [];
        this._tuoguanTab = [];
        this._curOutCardTab = [];
        this._backCardTab = [];
        this._dizhuSeatNo = -1;

        this._mingpaiCardId = 0;
        this._qiangRangNum = 0;
        this._ishandcardSort = false;
        this._isrequestStatus = false;
    },
    setPlayerUiNovBeginFunc(playerui, index, seatNo){
        this._playerUIArray[index] = playerui;
        this._seatToUIArray[seatNo] = index;
    },
    getPlayerUIBySeatNoNovBeginFunc(seatNo){
        let index = this._seatToUIArray[seatNo];
        return this._playerUIArray[index];
    },
    getPlayerUIByUserIdNovBeginFunc(userId){
        let roominfo = this.getRoomInfoNovBeginFunc();
        let seatNo = roominfo.findUserSeatNoNovBeginFunc(userId);
        return this.getPlayerUIBySeatNoNovBeginFunc(seatNo);
    },
    ///////////////////////////////////////////////////
    getSelfSeatNoNovBeginFunc(){
        return this._selfSeatNo;
    },
    getNextSeatNoNovBeginFunc(curSeatNo){
        if(curSeatNo==null) curSeatNo = this._selfSeatNo;
        let maxPeople = this.getMaxPlayerNovBeginFunc();
        curSeatNo = curSeatNo + 1;
        if(curSeatNo>=maxPeople)curSeatNo = 0; //下标从0开始
        return curSeatNo;
    },
    getLastSeatNoNovBeginFunc(curSeatNo){
        if(curSeatNo==null) curSeatNo = this._selfSeatNo;
        let maxPeople = this.getMaxPlayerNovBeginFunc();
        curSeatNo = curSeatNo - 1;
        if(curSeatNo<0)curSeatNo = maxPeople;
        return curSeatNo;
    },
    setDiZhuSeatNoNovBeginFunc(seatNo){
        this._dizhuSeatNo = seatNo;
    },
    getDiZhuSeatNoNovBeginFunc(){
        return this._dizhuSeatNo;
    },
    ////////////////////////////////////////////////////
    getRoomInfoNovBeginFunc(){
        return g_RoomManager.getGameRoomInfoNovBeginFunc(this._gameId, this._roomId);
    },
    getGameIdNovBeginFunc(){
        return this._gameId;
    },
    getRoomIDNovBeginFunc(){
        return this._roomId;
    },
    //------------------------------------
    getMaxPlayerNovBeginFunc(){
        if(!this._gameId) this._gameId = g_ProtDef.MID_Protocol_ErRenDDZ;
        console.log("====getMaxPlayerNovBeginFunc===========", gameconfig, this._gameId, g_ProtDef.MID_Protocol_ErRenDDZ);
        return gameconfig[this._gameId].maxPlayer;
    },
    //------------------------------------
    setHandCardTabNovBeginFunc(seatNo, cardtab, isCopy){
        let toTab = cardtab;
        if(isCopy){
            toTab = [];
            for(let i=0; i<cardtab.length; i++){
                toTab[i] = cardtab[i];
            }
        }
        this._handCardTab[seatNo] = toTab;
        this.setHandCardSortNovBeginFunc(this._ishandcardSort);
    },
    setHandCardSortNovBeginFunc(isSort){
        this._ishandcardSort = isSort;
        if(this._ishandcardSort){
            let sortNovBeginFunc = (a, b)=>{
                if(a>b) return -1;
                return 1;
            };
            for(let i=0; i<this.getMaxPlayerNovBeginFunc();i++){
                if(this._handCardTab[i]){
                    this._handCardTab[i].sort(sortNovBeginFunc);
                }
            }
        }
    },
    addHandCardTabNovBeginFunc(seatNo, cardtab){
        if(!this._handCardTab[seatNo])this._handCardTab[seatNo] = {};
        for(let i=0; i<cardtab.length; i++){
            this._handCardTab[seatNo].push(cardtab[i]);
        }
        this.setHandCardSortNovBeginFunc(this._ishandcardSort);
    },
    getHandCardTabNovBeginFunc(seatNo, isCopy){
        let toTab = [];
        if(isCopy){
            if(this._handCardTab[seatNo]){
                for(let i=0; i<this._handCardTab[seatNo].length; i++){
                    toTab[i] = this._handCardTab[i];
                }
            }
        }else{
            toTab = this._handCardTab[seatNo];
        }
        console.log("========getHandCardTabNovBeginFunc===========", seatNo, toTab);
        return toTab;
    },
    getHandCardCountNovBeginFunc(seatNo){
        if(!this._handCardTab[seatNo]) return 0;
        return this._handCardTab[seatNo].length;
    },
    removeCardTabNovBeginFunc(seatNo, rmCardTab) {
        let toHandTab = this._handCardTab[seatNo];
        let removeNum = 0;
        for(let i=0; i<rmCardTab.length; i++){
            for(let j=0; j<toHandTab.length; j++){
                if(toHandTab[j]==rmCardTab[i]){
                    toHandTab.splice(j, 1);
                    removeNum++;
                    break;
                }
            }
        }
        cc.log("=====removeCardTabNovBeginFunc=======", toHandTab);
        return removeNum;
    },
    //------------------------------------
    addOutCardTabNovBeginFunc(seatNo, outTab){
        if(!this._outCardTab[seatNo]) this._outCardTab[seatNo] = [];
        this._outCardTab[seatNo].push(outTab);
    },
    getAllOutCardTabNovBeginFunc(seatNo){
        if(!seatNo) return this._outCardTab;
        return this._outCardTab[seatNo];
    },
    setCurOutCardTabNovBeginFunc(outTab){
        this._curOutCardTab = [];
        if(outTab){
            for(let i in outTab){
                this._curOutCardTab[i] = outTab[i];
            }
        }
    },
    getCurOutCardTabNovBeginFunc(isCopy){
        if(!isCopy) this._curOutCardTab;
        let totab = [];
        for(let i=0; i<this._curOutCardTab.length; i++){
            totab[i] = this._curOutCardTab[i];
        }
        return totab;
    },
    //------------------------------------
    //三张底牌
    setBackCardNovBeginFunc(card1, card2, card3){
        this._backCardTab = [];
        this._backCardTab.push(card1);
        this._backCardTab.push(card2);
        this._backCardTab.push(card3);
    },
    getBackCardNovBeginFunc(){
        return this._backCardTab;
    },
    //------------------------------------
    //明牌id
    setMingPaiIdNovBeginFunc(cardId){
        this._mingpaiCardId = cardId;
    },
    getMingPaiIdNovBeginFunc(){
        return this._mingpaiCardId;
    },
    //抢地主数量
    setQiangRangNumNovBeginFunc(num){
        this._qiangRangNum = num;
    },
    getQiangRangNumNovBeginFunc(){
        return this._qiangRangNum;
    },
    //------------------------------------
    //--托管
    setTuoGuanNovBeginFunc(seatNo, bTuoGuan){
        this._tuoguanTab[seatNo] = bTuoGuan;
    },
    isTuoGuanNovBeginFunc(seatNo){
        return this._tuoguanTab[seatNo];
    },
    //////////////////////////////////////////////
    //value为空，表示背牌
    getPokerFramePathNovBeginFunc(isBigPoker, value, bRawPath){
        let topath = "DdzResNov2nd/smallPokerResNov2nd/smallNov2nd_";
        if(isBigPoker){
            topath = "DdzResNov2nd/bigPokerResNov2nd/bigNov2nd_";
        }
        do{
            if(!value || value<=0){
                topath = topath + "cardback";
                break;
            }
            let cindex = GameRuleConfig.GetCardIndexNovBeginFunc(value);
            if(cindex==GameRuleConfig.CardType.XiaoWangID){
                topath = topath + "xiaowang";
                break;
            }else if(cindex==GameRuleConfig.CardType.DaWangID){
                topath = topath + "dawang";
                break;
            }
            if(cindex <= GameRuleConfig.CardType.KID){
                cindex += 2;
            }else if(cindex==GameRuleConfig.CardType.ErID){
                cindex = 2;
            }else if(cindex==GameRuleConfig.CardType.YiID){
                cindex = 1;
            }
            let ccolor = GameRuleConfig.GetCardColorNovBeginFunc(value);
            topath += ccolor;
            topath += "_";
            topath += cindex;
        }while(0);
        if(bRawPath){
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },
    getRangPokerFramePathNovBeginFunc(bRawPath){
        let topath = "DdzResNov2nd/bigPokerResNov2nd/bigNov2nd_rangpai";
        if(bRawPath){
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },
    //////////////////////////////////////////////////////////////////
    playBackgroundMusicNovBeginFunc(){
        g_SoundManager.playMusicNovBeginFunc("DdzResNov2nd/soundResNov2nd/musicResNov2nd/bg_happyNov2nd");
    },
    _getCardIdIndexNovBeginFunc(value){
        let cindex = GameRuleConfig.GetCardIndexNovBeginFunc(value);
        if(cindex==GameRuleConfig.CardType.XiaoWangID){
            return cindex;
        }else if(cindex==GameRuleConfig.CardType.DaWangID){
            return cindex;
        }
        if(cindex <= GameRuleConfig.CardType.KID){
            cindex += 2;
        }else if(cindex==GameRuleConfig.CardType.ErID){
            cindex = 2;
        }else if(cindex==GameRuleConfig.CardType.YiID){
            cindex = 1;
        }
        return cindex;
    },
    _getBaseEffectPathNovBeginFunc(userId){
        let userinfo = this.getRoomInfoNovBeginFunc().getUserInfoByUserIdNovBeginFunc(userId);
        if(!userinfo) return ;
        let effectpath = "DdzResNov2nd/soundResNov2nd/effectResNov2nd/";
        if(userinfo.isBoy==1){
            effectpath += "boySound/";
        }else{
            effectpath += "girlSound/";            
        }
        return effectpath;
    },
    playGameStartNovBeginFunc(){
        g_SoundManager.playEffectNovBeginFunc("DdzResNov2nd/soundResNov2nd/effectResNov2nd/gameStartSound");
    },
    playSendCardNovBeginFunc(){
        g_SoundManager.playEffectNovBeginFunc("DdzResNov2nd/soundResNov2nd/effectResNov2nd/sendCardSound");
    },
    playGameResultNovBeginFunc(isWin){
        if(isWin){
            g_SoundManager.playEffectNovBeginFunc("DdzResNov2nd/soundResNov2nd/effectResNov2nd/winSound");
        }else{
            g_SoundManager.playEffectNovBeginFunc("DdzResNov2nd/soundResNov2nd/effectResNov2nd/failedSound");
        }
    },
    playJiaoDiZhuNovBeginFunc(userId, isJiao){
        let effectpath = this._getBaseEffectPathNovBeginFunc(userId);
        if(isJiao){
            effectpath += "jiaodizhu";
        }else{
            effectpath += "bujiao" + MathRandomNovBeginFunc(1, 2);
        }
        g_SoundManager.playEffectNovBeginFunc(effectpath);
    },
    playQiangDiZhuNovBeginFunc(userId, isQiang){
        let effectpath = this._getBaseEffectPathNovBeginFunc(userId);
        if(isQiang){
            if(MathRandomNovBeginFunc(1, 100)<50){
                effectpath += "qiangdizhu";
            }else{
                effectpath += "woqiang";                
            }
        }else{
            effectpath += "buqiang";
        }
        g_SoundManager.playEffectNovBeginFunc(effectpath);
    },
    playNotOutNovBeginFunc(userId){
        let effectpath = this._getBaseEffectPathNovBeginFunc(userId);
        effectpath += "buyao" + MathRandomNovBeginFunc(1, 4);
        g_SoundManager.playEffectNovBeginFunc(effectpath);
    },
    playEatCardDaNiNovBeginFunc(userId){
        let effectpath = this._getBaseEffectPathNovBeginFunc(userId);
        effectpath += "dani" + MathRandomNovBeginFunc(1, 3);
        g_SoundManager.playEffectNovBeginFunc(effectpath);
    },
    playOutTypeNovBeginFunc(cardtype){
        if(cardtype==GameRuleConfig.CardType.FeiJiNoPai ||
            cardtype==GameRuleConfig.CardType.FeiJiDanPai ||
            cardtype==GameRuleConfig.CardType.FeiJiDuiPai){
                g_SoundManager.playEffectNovBeginFunc("DdzResNov2nd/soundResNov2nd/effectResNov2nd/airplaneSound");
        }else if(cardtype==GameRuleConfig.CardType.WangZha){
            g_SoundManager.playEffectNovBeginFunc("DdzResNov2nd/soundResNov2nd/effectResNov2nd/rocketSound");
        }
    },
    playOutCardNovBeginFunc(userId, cardId, cardtype){
        g_SoundManager.playEffectNovBeginFunc("DdzResNov2nd/soundResNov2nd/effectResNov2nd/outCardSound");
        let effectpath = this._getBaseEffectPathNovBeginFunc(userId);
        let cindex = this._getCardIdIndexNovBeginFunc(cardId);
        if(cardtype==GameRuleConfig.CardType.DanPai){
            effectpath += cindex;
        }else if(cardtype==GameRuleConfig.CardType.DuiZi){
            effectpath += "dui" + this._getCardIdIndexNovBeginFunc(cardId);
        }else if(cardtype==GameRuleConfig.CardType.SanTiao){
            if(MathRandomNovBeginFunc(1, 100)<50){
                effectpath += "sange";
            }else{
                effectpath += "sanzhang";
            }
        }else if(cardtype==GameRuleConfig.CardType.SanDaiYi){
            effectpath += "sandaiyi";
        }else if(cardtype==GameRuleConfig.CardType.SanDaiYiDui){
            effectpath += "sandaiyidui";
        }else if(cardtype==GameRuleConfig.CardType.ShunZi){
            if(MathRandomNovBeginFunc(1, 100)<50){
                effectpath += "shunzi";
            }else{
                effectpath += "danshun";
            }
        }else if(cardtype==GameRuleConfig.CardType.ZhaDan){
            effectpath += "zhadan";
        }else if(cardtype==GameRuleConfig.CardType.SiDaiDanPai){
            effectpath += "sidaier";
        }else if(cardtype==GameRuleConfig.CardType.SiDaiErDui){
            effectpath += "sidailiangdui";
        }else if(cardtype==GameRuleConfig.CardType.WangZha){
            effectpath += "wangzha";
        }else if(cardtype==GameRuleConfig.CardType.FeiJiNoPai){
            effectpath += "feiji";
        }else if(cardtype==GameRuleConfig.CardType.FeiJiDanPai){
            effectpath += "feijichibang";
        }else if(cardtype==GameRuleConfig.CardType.FeiJiDuiPai){
            effectpath += "feijichibang";
        }else if(cardtype==GameRuleConfig.CardType.LianDui){
            effectpath += "liandui";
        }else{
            effectpath = null;
        }
        if(effectpath){
            g_SoundManager.playEffectNovBeginFunc(effectpath);
        }
    },
};