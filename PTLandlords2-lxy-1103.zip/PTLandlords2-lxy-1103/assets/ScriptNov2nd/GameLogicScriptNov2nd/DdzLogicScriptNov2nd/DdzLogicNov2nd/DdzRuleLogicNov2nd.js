
let GameRuleData = require("DdzRuleDataNov2nd");
let GameRuleConfig = require("DdzRuleConfigNov2nd");

module.exports = {
	//卡组1能否吃掉卡组2
	IsCardTab1CanEatCardTab2NovBeginFunc(cardTab1, cardTab2){
		console.log("=====IsCardTab1CanEatCardTab2NovBeginFunc===11=======", cardTab1, cardTab2);
		if(!cardTab1 || cardTab1.length<=0) return false;
		if(!cardTab2 || cardTab2.length<=0) return true;
		let gamedata1 = new GameRuleData(cardTab1);
		let ctype1 = gamedata1.getSelfCardTypeNovBeginFunc();
		if(ctype1==GameRuleConfig.CardType.ErrorType) return false;
		let gamedata2 = new GameRuleData(cardTab2);
		let ctype2 = gamedata2.getSelfCardTypeNovBeginFunc();
		console.log("=====IsCardTab1CanEatCardTab2NovBeginFunc===22=======", ctype1, ctype2);
		if(ctype1!=ctype2) {
			if(GameRuleConfig.IsType1CanEatType2NovBegeinFunc(ctype1, ctype2)) return true;
			return false;
		}
		let eatcardtab1 = gamedata1.getCardTypeMinEatIdOrLinkCountNovBeginFunc(ctype1);
		let eatcardtab2 = gamedata2.getCardTypeMinEatIdOrLinkCountNovBeginFunc(ctype2);
		console.log("=====IsCardTab1CanEatCardTab2NovBeginFunc===33=======", eatcardtab1, eatcardtab2);
		if(!eatcardtab2) return true;
		if(!eatcardtab1) return false;
		
		return eatcardtab1[0]>eatcardtab2[0] && eatcardtab1[1]==eatcardtab2[1];
	},
	//获取卡组的类型
	getCardTabCardTypeNovBeginFunc(cardTab){
		let gamedata = new GameRuleData(cardTab);
		return gamedata.getSelfCardTypeNovBeginFunc();
	},
	//从手牌中获取能吃掉eatCardTab的卡组
	getOutTipCardTabNovBeginFunc(handCardTab, eatCardTab){
		console.log("=====getOutTipCardTabNovBeginFunc===11=======", handCardTab, eatCardTab);
		let handdata = new GameRuleData(handCardTab);
		if(!eatCardTab || eatCardTab.length<=0){
			let tishitab = handdata.getMaxLengthCardTypeTabNovBeginFunc();
			return GameRuleConfig.exchangeIndexToCardIdNovBegeinFunc(handCardTab, tishitab);
		}
		let eatdata = new GameRuleData(eatCardTab);
		let eattype = eatdata.getSelfCardTypeNovBeginFunc();
		console.log("=====getOutTipCardTabNovBeginFunc===22=======", eattype);
		let eatcardtab = eatdata.getCardTypeMinEatIdOrLinkCountNovBeginFunc(eattype);
		console.log("=====getOutTipCardTabNovBeginFunc===33=======", eatcardtab);
		if(!eatcardtab) return [];
		let tishiTab = handdata.getEatCardTypeCardTabNovBeginFunc(eattype, eatcardtab[0], eatcardtab[1]);
		console.log("=====getOutTipCardTabNovBeginFunc===44=======", tishiTab);
		return GameRuleConfig.exchangeIndexToCardIdNovBegeinFunc(handCardTab, tishiTab);
	},
};