cc.Class({
    extends: cc.Component,

    properties: {
        xieYiToggle:cc.Toggle,
    },

    // use this for initialization
    onLoad: function () {
        this.node.setScale(0);
        this.node.runAction(cc.scaleTo(0.2, 1));
    },

    onLoginBtnNovBeginFunc : function(event){
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        if(this.xieYiToggle.isChecked == false){
            console.log("请勾选提示框");
            let eventparam = {};
            this.node.emit("login-xieyi-not-select", eventparam);
            return;
        }

        let accText = this.node.getChildByName("enteracc").getComponent(cc.EditBox).string;
        let pwdText = this.node.getChildByName("enterpwd").getComponent(cc.EditBox).string;
        let eventparam = {acc : accText, pwd : pwdText};
        console.log("====onLoginBtnNovBeginFunc=======", eventparam);
        //有两种发射方式，emit比较方便，区别不大，详细看官方文档
        //传参可以用任何类型变量，数组、对象、字符串等等，这里传入什么参数，on接受到的detail就是什么。
        this.node.emit("login-loginacc", eventparam);
        // let eventcon = new cc.Event.EventCustom('login-loginacc', true);
        // eventcon.detail = eventparam;
        // this.node.dispatchEvent(eventcon);
    },
    onRegisterBtnNovBeginFunc : function(event){
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        
        console.log("====onRegisterBtnNovBeginFunc=======");
        this.node.emit("login-showregister");
    },

    onXieYiBtnNovBeginFunc:function (event) {
    	g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        console.log("====onXieYiBtnNovBeginFunc=======");
        this.node.emit("login-showxieyi");
    },


});
