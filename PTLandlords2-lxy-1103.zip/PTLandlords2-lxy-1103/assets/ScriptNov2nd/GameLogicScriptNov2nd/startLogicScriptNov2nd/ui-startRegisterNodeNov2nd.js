
cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function () {

    },

    onCancelBtnNovBeginFunc : function(){
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");

        console.log("====onCancelBtnNovBeginFunc=======");
        this.node.emit("register-hideregnode");
    },
    onOkBtnNovBeginFunc : function(){
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        
        let accText = this.node.getChildByName("enteracc").getComponent(cc.EditBox).string;
        let pwdText = this.node.getChildByName("enterpwd").getComponent(cc.EditBox).string;
        let eventparam = {acc : accText, pwd : pwdText};
        console.log("====onOkBtnNovBeginFunc=======", eventparam);
        this.node.emit("register-regaccount", eventparam);
    },
});
