cc.Class({
    extends: cc.Component,

    properties: {
        O_flowerNode : cc.Node,
    },

    // use this for initialization
    onLoad: function () {

    },
    showFlowerNovBeginFunc : function(isVisible){
        this.O_flowerNode.stopAllActions();
        this.node.stopAllActions();
        this.node.opacity = 255;
        this.node.active = isVisible;
        if(isVisible){
            this.node.opacity = 0;
            //this.node.setScale(0);
            this.node.runAction(cc.fadeIn(0.4));
            this.O_flowerNode.runAction(cc.repeatForever(cc.rotateBy(Math.random()*0.3 + 0.2, 180)));
        }
    },
});
