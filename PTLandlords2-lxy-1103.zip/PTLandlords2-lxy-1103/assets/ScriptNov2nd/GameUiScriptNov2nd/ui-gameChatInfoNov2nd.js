
let utilIconv = require("util_iconvNov2nd")
cc.Class({
    extends: cc.Component,

    properties: {
        O_username : cc.Label,
        O_userHead : cc.Node,
        O_userTalk : cc.RichText,

        O_userinfoPrefab : cc.Prefab,

        _userInfo : null,
    },

    // use this for initialization
    setTalkInfoNovBeginFunc : function (userInfo) {
        this._userInfo = userInfo;

        let info = g_UserManager.getSelfUserInfoNovBeginFunc();
        this.O_username.string = userInfo.fromName;
        this.O_userTalk.string = utilIconv.GBKToUTF8(userInfo.content);;

        let headurl = userInfo.fromHeadUrl;
        
        if (headurl && headurl.length > 0) {
            let toSprite = this.O_userHead.getComponent(cc.Sprite);
            let toType = "png";
            if(headurl.indexOf(".jpg")){
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },

    onUserInfoEvent : function() {
        if(this._userInfo.fromId == g_UserManager.getSelfUserIdNovBeginFunc()){
            return;
        }
        g_SoundManager.playEffectNovBeginFunc("CommonResNov2nd/musicNov2nd-btn");
        
        var user = cc.instantiate(this.O_userinfoPrefab);
        var canNode = cc.director.getScene();
        cc.log("======onUserInfoEvent=========canNode===========",canNode);
        user.parent = canNode.getChildByName('Canvas');
        user.setLocalZOrder(11);

        var userScript = user.getComponent("ui-chatUserInfoNov2nd");
        userScript.initNovBeginFunc(this._userInfo.fromId);
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
