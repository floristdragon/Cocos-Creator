
console.log("============require======include=====================");
let SocketClient  = require("SocketClientNov2nd");

window.g_RoomManager = require("RoomManagerNov2nd"); //房间信息管理
window.g_UserManager = require("UserManagerNov2nd"); //用户信息管理
window.g_ItemManager = require("ItemManagerNov2nd"); //物品管理器
window.g_ConfigManager = require("ConfigManagerNov2nd"); //本地配置数据
window.g_SoundManager = require("SoundManagerNov2nd");    //音频管理器
window.g_NetManager = new SocketClient(); //网络连接管理
window.g_ProtDef = require("mProtocolNov2nd"); //协议模块和协议的定义

window.g_GameScene = null; //当前场景得全局句柄