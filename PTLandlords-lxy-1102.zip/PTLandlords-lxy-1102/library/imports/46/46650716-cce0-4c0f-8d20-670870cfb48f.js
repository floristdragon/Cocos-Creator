"use strict";
cc._RF.push(module, '46650cWzOBMD40gZwhwz7SP', 'ui-lobbyCurrentRoomOct30th');
// ScriptOct30th/gameLogicOct30th/LobbyLogicOct30th/ui-lobbyCurrentRoomOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_curroomlineprefab: cc.Prefab,
        O_scrollviewnode: cc.Node,

        _scrollviewscript: null
    },

    onLoad: function onLoad() {
        this._scrollviewscript = this.O_scrollviewnode.getComponent("ui-scrollViewOct30th");
    },


    // use this for initialization
    addOneRoomRecordOctFunc: function addOneRoomRecordOctFunc(gameId, roomId, curjushu, maxjushu) {
        cc.log("=====addOneRoomRecordOctFunc========", gameId, roomId, curjushu, maxjushu);
        var croomlinenode = cc.instantiate(this.O_curroomlineprefab);
        var croomlinescript = croomlinenode.getComponent("ui-lobbyCurrentRoomLineOct30th");
        croomlinescript.setDataOctFunc(gameId, roomId, curjushu, maxjushu);
        this._scrollviewscript.addScrollNodeOctFunc(croomlinenode);
    },


    onCloseBtnOctFunc: function onCloseBtnOctFunc() {
        this.node.destroy();
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();