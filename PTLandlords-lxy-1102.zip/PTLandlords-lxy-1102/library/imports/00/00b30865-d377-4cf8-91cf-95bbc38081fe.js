"use strict";
cc._RF.push(module, '00b30hl03dM+JHPlbvDgIH+', 'nativeVoiceOct30th');
// ScriptOct30th/gameUtilsScriptOct30th/nativeVoiceOct30th.js

"use strict";

var radix = 12;
var base = 128 - radix;
function crypto(value) {
    value -= base;
    var h = Math.floor(value / radix) + base;
    var l = value % radix + base;
    return String.fromCharCode(h) + String.fromCharCode(l);
}

var encodermap = {};
var decodermap = {};
for (var i = 0; i < 256; ++i) {
    var code = null;
    var v = i + 1;
    if (v >= base) {
        code = crypto(v);
    } else {
        code = String.fromCharCode(v);
    }

    encodermap[i] = code;
    decodermap[code] = i;
}

function encode(data) {
    var content = "";
    var len = data.length;
    var a = len >> 24 & 0xff;
    var b = len >> 16 & 0xff;
    var c = len >> 8 & 0xff;
    var d = len & 0xff;
    content += encodermap[a];
    content += encodermap[b];
    content += encodermap[c];
    content += encodermap[d];
    for (var i = 0; i < data.length; ++i) {
        content += encodermap[data[i]];
    }
    return content;
}

function getCode(content, index) {
    var c = content.charCodeAt(index);
    if (c >= base) {
        c = content.charAt(index) + content.charAt(index + 1);
    } else {
        c = content.charAt(index);
    }
    return c;
}
function decode(content) {
    var index = 0;
    var len = 0;
    for (var i = 0; i < 4; ++i) {
        var c = getCode(content, index);
        index += c.length;
        var v = decodermap[c];
        len |= v << (3 - i) * 8;
    }

    var newData = new Uint8Array(len);
    var cnt = 0;
    while (index < content.length) {
        var c = getCode(content, index);
        index += c.length;
        newData[cnt] = decodermap[c];
        cnt++;
    }
    return newData;
}

module.exports = {
    name: "VoiceCtrl",
    _voiceMediaPath: null,
    _soundManager: null,
    ///////////////////////////////////////////////////////
    initOctFunc: function initOctFunc(soundmgr) {
        this._soundManager = soundmgr;
        if (cc.sys.isNative) {
            this._voiceMediaPath = jsb.fileUtils.getWritablePath() + "/voicemsgs/";
            this.setStorageDir(this._voiceMediaPath);
        }
    },
    prepare: function prepare(filename) {
        if (!cc.sys.isNative) {
            return;
        }

        this._soundManager.stopAllOctFunc();

        this.clearCache(filename);
        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/voicesdk/VoiceRecorder", "prepare", "(Ljava/lang/String;)V", filename);
        } else if (cc.sys.os == cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod("VoiceSDK", "prepareRecord:", filename);
        }
    },
    release: function release() {
        if (!cc.sys.isNative) {
            return;
        }
        this._soundManager.openAllOctFunc();

        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/voicesdk/VoiceRecorder", "release", "()V");
        } else if (cc.sys.os == cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod("VoiceSDK", "finishRecord");
        }
    },
    cancel: function cancel() {
        if (!cc.sys.isNative) {
            return;
        }
        this._soundManager.openAllOctFunc();
        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/voicesdk/VoiceRecorder", "cancel", "()V");
        } else if (cc.sys.os == cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod("VoiceSDK", "cancelRecord");
        }
    },
    writeVoice: function writeVoice(filename, voiceData) {
        if (!cc.sys.isNative) {
            return;
        }
        if (voiceData && voiceData.length > 0) {
            var fileData = decode(voiceData);
            var url = this._voiceMediaPath + filename;
            this.clearCache(filename);
            jsb.fileUtils.writeDataToFile(fileData, url);
        }
    },
    clearCache: function clearCache(filename) {
        if (cc.sys.isNative) {
            var url = this._voiceMediaPath + filename;
            if (jsb.fileUtils.isFileExist(url)) {
                jsb.fileUtils.removeFile(url);
            }
            if (jsb.fileUtils.isFileExist(url + ".wav")) {
                jsb.fileUtils.removeFile(url + ".wav");
            }
        }
    },
    play: function play(filename) {
        if (!cc.sys.isNative) {
            return;
        }
        this._soundManager.setMusicVolumeOctFunc(0.3);

        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/voicesdk/VoicePlayer", "play", "(Ljava/lang/String;)V", filename);
        } else if (cc.sys.os == cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod("VoiceSDK", "play:", filename);
        }
    },
    stop: function stop() {
        if (!cc.sys.isNative) {
            return;
        }

        this._soundManager.setMusicVolumeOctFunc(1);

        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/voicesdk/VoicePlayer", "stop", "()V");
        } else if (cc.sys.os == cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod("VoiceSDK", "stopPlay");
        }
    },
    getVoiceLevel: function getVoiceLevel(maxLevel) {
        return Math.floor(Math.random() * maxLevel + 1);
    },
    getVoiceData: function getVoiceData(filename) {
        if (cc.sys.isNative) {
            var fileData = jsb.fileUtils.getDataFromFile(this._voiceMediaPath + filename);
            if (fileData) {
                return encode(fileData);
            }
        }
        return "";
    },
    setStorageDir: function setStorageDir(dir) {
        if (!cc.sys.isNative) {
            return;
        }
        if (cc.sys.os == cc.sys.OS_ANDROID) {
            jsb.reflection.callStaticMethod("org/cocos2dx/voicesdk/VoiceRecorder", "setStorageDir", "(Ljava/lang/String;)V", dir);
        } else if (cc.sys.os == cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod("VoiceSDK", "setStorageDir:", dir);
            if (!jsb.fileUtils.isDirectoryExist(dir)) {
                jsb.fileUtils.createDirectory(dir);
            }
        }
    }
};

cc._RF.pop();