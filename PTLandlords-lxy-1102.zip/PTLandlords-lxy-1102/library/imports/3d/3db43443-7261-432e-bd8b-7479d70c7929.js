"use strict";
cc._RF.push(module, '3db43RDcmFDLr2LdHnXDHkp', 'ui-lobbyMessageOct30th');
// ScriptOct30th/gameLogicOct30th/LobbyLogicOct30th/ui-lobbyMessageOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        messageLabel: cc.Label
    },

    // use this for initialization
    initOctFunc: function initOctFunc(message) {
        if (message) {
            this.messageLabel.string = message;
        }
    },

    onCloseClickOctFunc: function onCloseClickOctFunc() {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();