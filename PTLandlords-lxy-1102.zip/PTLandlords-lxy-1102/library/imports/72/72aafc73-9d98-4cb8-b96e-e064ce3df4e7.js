"use strict";
cc._RF.push(module, '72aafxznZhMuLlu4GTOPfTn', 'httpRequestOct30th');
// ScriptOct30th/gameUtilsScriptOct30th/httpRequestOct30th.js

"use strict";

module.exports = cc.Class({
    name: 'HttpRequest',
    properties: {
        onTimeout: null,
        onSuccess: null,
        onError: null,

        timeoutDelay: 0,
        maxRequestCount: 0,

        _requestEntity: null
    },

    ctor: function ctor() {
        var timeoutDelay = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 8000;
        var maxRequestCount = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;

        this.timeoutDelay = timeoutDelay;
        this.maxRequestCount = maxRequestCount;
    },
    sendGet: function sendGet(url) {
        this._send("GET", url, null);
    },
    sendPost: function sendPost(url, data) {
        this._send("POST", url, data);
    },
    _send: function _send(method, url, data) {
        var _this = this;

        if (!this._requestEntity) {
            this._requestEntity = {
                count: 0,
                method: method,
                url: url,
                data: data
            };
        }

        var xhreq = cc.loader.getXMLHttpRequest();
        xhreq.open(method, url, true);
        //不添加超时处理，因为有可能有些网络慢的一定会超时，无法这里添加超时时间
        // xhreq.timeout = this.timeoutDelay;
        // xhreq.ontimeout = () => {
        //     cc.log("====HttpRequest=ontimeout========");
        //     if (!this._requestAgain()) {
        //         if (this.onTimeout) {
        //             this.onTimeout();
        //         }
        //     }
        // };
        //xhreq.setRequestHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
        xhreq.onreadystatechange = function () {
            cc.log("======onreadystatechange========", xhreq, xhreq.responseText);
            if (xhreq.readyState === 4) {
                if (xhreq.status >= 200 && xhreq.status < 300) {
                    if (_this.onSuccess) {
                        _this.onSuccess(xhreq.response);
                    }
                } else if (xhreq.status >= 400 || xhreq.status === 0) {
                    if (!_this._requestAgain()) {
                        if (_this.onError) {
                            _this.onError();
                        }
                    }
                }
            }
        };
        xhreq.send(data);
    },
    _requestAgain: function _requestAgain() {
        if (++this._requestEntity.count <= this.maxRequestCount) {
            this._send(this._requestEntity.method, this._requestEntity.url, this._requestEntity.data);
            cc.log('request again:' + this._requestEntity.count);
            return true;
        }
        return false;
    }
});

cc._RF.pop();