"use strict";
cc._RF.push(module, '5d6d9/AgzlBdZdbs+YEFVSm', 'ui-gameChatOct30th');
// ScriptOct30th/gameUIOct30th/ui-gameChatOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_editNode: cc.EditBox,
        O_ShuruNode: cc.Node,
        O_chatUserInfo: cc.Prefab,

        O_worldLayer: cc.Node,
        O_roomLayer: cc.Node,
        O_siliaoLayer: cc.Node,

        O_worldToggleNode: cc.Node,
        O_roomToggleNode: cc.Node,
        O_siliaoToggleNode: cc.Node,

        O_siliaoTips: cc.Node,

        _chattype: 1,
        _scrollViewNode: null,
        _isInRoomChat: false,
        _curPos: null
    },

    onLoad: function onLoad() {
        this._curPos = this.O_worldToggleNode.position;
    },

    openChatViewOctFunc: function openChatViewOctFunc() {
        this.node.active = true;
        if (this._isInRoomChat) {
            this._onRoomToggleBtnOctFunc();
            this.O_roomToggleNode.active = true;
            this.node.setLocalZOrder(151);
        } else {
            var toggleWorld = this.O_worldToggleNode.getComponent(cc.Toggle);
            var toggleSiliao = this.O_siliaoToggleNode.getComponent(cc.Toggle);
            if (toggleWorld.isChecked) {
                this._onWorldToggleBtnOctFunc();
            } else if (toggleSiliao.isChecked) {
                this._onSiliaoToggleBtnOctFunc();
            }
        }
    },


    onSendEventOctFunc: function onSendEventOctFunc() {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        if (g_GameScene.rejectClickEventOctFunc(3)) return;

        var sendstr = this.O_editNode.string;
        this.O_editNode.string = "";

        if (!sendstr) return;

        var talkProtab = {};
        talkProtab.ctype = 4;
        talkProtab.content = sendstr;
        talkProtab.msgtype = this._chattype;
        if (talkProtab.msgtype == 2) {
            talkProtab.gameId = g_RoomManager.getCurGameIdOctFunc();
            talkProtab.roomId = g_RoomManager.getCurRoomIdOctFunc();
        }
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SSendChatMsg, talkProtab);

        cc.log("=============onSendEventOctFunc========this._chattype======", this._chattype);
    },

    _onWorldToggleBtnOctFunc: function _onWorldToggleBtnOctFunc(event) {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        this.O_worldLayer.active = true;
        this.O_siliaoLayer.active = false;
        this.O_roomLayer.active = false;
        this._chattype = 1;
        this.O_ShuruNode.active = true;
        cc.log("=============_onWorldToggleBtnOctFunc========this._chattype======", this._chattype);
    },

    _onSiliaoToggleBtnOctFunc: function _onSiliaoToggleBtnOctFunc(event) {
        this.O_siliaoTips.active = false;
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SReqChatMsg);
        this.O_worldLayer.active = false;
        this.O_siliaoLayer.active = true;
        this.O_roomLayer.active = false;
        this._chattype = 3;
        this.O_ShuruNode.active = false;
        cc.log("=============_onSiliaoToggleBtnOctFunc========this._chattype======", this._chattype);
    },

    _onRoomToggleBtnOctFunc: function _onRoomToggleBtnOctFunc(event) {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        this.O_worldLayer.active = false;
        this.O_siliaoLayer.active = false;
        this.O_roomLayer.active = true;
        this._chattype = 2;
        this.O_ShuruNode.active = true;

        if (this._isInRoomChat) {
            this.O_worldToggleNode.active = false;
            var worldtoggle = this.O_worldToggleNode.getComponent(cc.Toggle);
            worldtoggle.isChecked = false;

            this.O_siliaoToggleNode.active = false;
            var siliaotoggle = this.O_siliaoToggleNode.getComponent(cc.Toggle);
            siliaotoggle.isChecked = false;

            this.O_roomToggleNode.position = this._curPos;
        }
        cc.log("=============_onRoomToggleBtnOctFunc========this._chattype======", this._chattype);
    },
    addChatMsgOctFunc: function addChatMsgOctFunc(msgtab) {
        if (msgtab.msgtype == 1) {
            this._scrollViewNode = this.node.getChildByName('worldLayer').getComponent('ui-scrollViewOct30th');
            this._scrollViewNode.setMoveAddNodeOctFunc(true);
            this._scrollViewNode.setLimitNodeMaxOctFunc(30);
        } else if (msgtab.msgtype == 2) {
            this._scrollViewNode = this.node.getChildByName('roomLayer').getComponent('ui-scrollViewOct30th');
            this._scrollViewNode.setMoveAddNodeOctFunc(true);
            this._scrollViewNode.setLimitNodeMaxOctFunc(30);
        } else if (msgtab.msgtype == 3) {
            this._scrollViewNode = this.node.getChildByName('siliaoLayer').getComponent('ui-scrollViewOct30th');
            this._scrollViewNode.setMoveAddNodeOctFunc(true);
            this._scrollViewNode.setLimitNodeMaxOctFunc(30);
        }

        var infoNode = cc.instantiate(this.O_chatUserInfo);
        var infoscript = infoNode.getComponent('ui-gameChatInfoOct30th');
        infoscript.setTalkInfoOctFunc(msgtab);

        this._scrollViewNode.addScrollNodeOctFunc(infoNode, 0);
        cc.log("=======onProtAddTalks==========msgtab=========", msgtab);
    },


    onHideChatPanelOctFunc: function onHideChatPanelOctFunc() {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        this.node.active = false;
    },

    showSiliaoTipsOctFunc: function showSiliaoTipsOctFunc(flag) {
        cc.log("========siliaoFlag==================", flag);
        if (flag) {
            this.O_siliaoTips.active = true;
        }
    },
    hideSiliaoTipsOctFunc: function hideSiliaoTipsOctFunc() {
        this.O_siliaoTips.active = false;
    },

    setRoomChatStateOctFunc: function setRoomChatStateOctFunc(isRoom) {
        this._isInRoomChat = isRoom;
    }
});

cc._RF.pop();