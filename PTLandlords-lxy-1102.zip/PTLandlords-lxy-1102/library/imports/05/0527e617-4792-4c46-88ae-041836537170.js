"use strict";
cc._RF.push(module, '0527eYXR5JMRoiuBBg2U3Fw', 'ui-classicDdzPokerCardOct30th');
// ScriptOct30th/gameLogicOct30th/DdzLogicOct30th/ClassicDdzOct30th/ui-classicDdzPokerCardOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_touchcard: cc.Node,
        O_pointnode: cc.Node,

        _cardValue: 0,
        _backPosition: null,
        _isMoveUp: false,
        _isMoveUpBack: false
    },

    // use this for initialization
    onLoad: function onLoad() {
        this._backPosition = new cc.Vec2(this.O_touchcard.position.x, this.O_touchcard.position.y);
        this._isMoveUp = false;
        this.showPointTipOctFunc(false);
    },
    setCardScaleOctFunc: function setCardScaleOctFunc(scale) {
        this.node.scale = scale;
    },
    setCardWidthOctFunc: function setCardWidthOctFunc(width) {
        this.node.width = width;
    },
    setCardHeightOctFunc: function setCardHeightOctFunc(height) {
        this.node.height = height;
    },
    showPointTipOctFunc: function showPointTipOctFunc(isVisible) {
        this.O_pointnode.active = isVisible;
    },
    setCardValueOctFunc: function setCardValueOctFunc(value, isRangpai) {
        var self = this;
        cc.log("========setCardValueOctFunc============", value, isRangpai);
        if (!value) value = -1;
        this._cardValue = value;
        var toSpUrl = void 0;
        if (isRangpai) {
            toSpUrl = g_CLDDZGameData.getRangPokerFramePathOctFunc(true);
        } else {
            toSpUrl = g_CLDDZGameData.getPokerFramePathOctFunc(true, this._cardValue, true);
        }
        var texture = cc.textureCache.addImage(toSpUrl);
        var toSprite = self.O_touchcard.getComponent(cc.Sprite);
        toSprite.spriteFrame = new cc.SpriteFrame(texture);
        // cc.loader.loadRes(toSpUrl, function(err, texture){
        //     toSprite.spriteFrame = new cc.SpriteFrame(texture);
        // });
    },
    getCardValueOctFunc: function getCardValueOctFunc() {
        return this._cardValue;
    },
    onUnTouchCardOctFunc: function onUnTouchCardOctFunc() {
        this._isMoveUpBack = this._isMoveUp;
        this._isTouchCard = false;
    },
    onChceckTouchOctFunc: function onChceckTouchOctFunc(touchPos, touchType) {
        if (touchType == 1) {
            return this._priTouchBeginOctFunc(touchPos);
        } else if (touchType == 2) {
            return this._priTouchMoveOctFunc(touchPos);
        } else if (touchType == 3) {
            return this._priTouchEndOctFunc(touchPos);
        }
    },
    isCardMoveUpOctFunc: function isCardMoveUpOctFunc() {
        return this._isMoveUp;
    },
    moveUpCardOctFunc: function moveUpCardOctFunc() {
        this._isMoveUp = true;
        this.O_touchcard.position = new cc.Vec2(this._backPosition.x, this._backPosition.y + 15);
    },
    moveDownCardOctFunc: function moveDownCardOctFunc(delay) {
        this._isMoveUp = false;
        var topos = new cc.Vec2(this._backPosition.x, this._backPosition.y);
        if (!delay) {
            this.O_touchcard.position = topos;
        } else {
            this.O_touchcard.runAction(cc.moveTo(delay, topos));
        }
    },

    ////////////////////////////////////////////////////////////////////////
    _isTouchInOctFunc: function _isTouchInOctFunc(touchPos) {
        var toPos = this.O_touchcard.convertToNodeSpace(touchPos);
        var toRect = new cc.Rect(0, 0, this.O_touchcard.width, this.O_touchcard.height);
        //cc.log("======_isTouchInOctFunc====111=====", toPos, toRect);
        if (toRect.contains(toPos)) {
            //cc.log("======_isTouchInOctFunc====222=====");
            return true;
        }
        return false;
    },
    _priTouchBeginOctFunc: function _priTouchBeginOctFunc(touchPos) {
        if (this._isTouchInOctFunc(touchPos)) {
            this._isMoveUpBack = this._isMoveUp;
            return true;
        }
        return false;
    },
    _priTouchMoveOctFunc: function _priTouchMoveOctFunc(touchPos) {
        if (this._isTouchInOctFunc(touchPos)) {
            if (this._isMoveUpBack != this._isMoveUp) return true;
            this._priMoveReverseCardOctFunc();
            return true;
        }
        this._isMoveUpBack = this._isMoveUp;
        return false;
    },
    _priTouchEndOctFunc: function _priTouchEndOctFunc(touchPos) {
        if (this._isTouchInOctFunc(touchPos)) {
            if (this._isMoveUpBack != this._isMoveUp) return true;
            this._priMoveReverseCardOctFunc();
            return true;
        }
        return false;
    },
    _priMoveReverseCardOctFunc: function _priMoveReverseCardOctFunc() {
        if (!this._isMoveUp) {
            this.moveUpCardOctFunc();
        } else {
            this.moveDownCardOctFunc();
        }
    }
});

cc._RF.pop();