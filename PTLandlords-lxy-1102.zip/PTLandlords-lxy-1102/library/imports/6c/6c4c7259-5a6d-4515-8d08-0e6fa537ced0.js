"use strict";
cc._RF.push(module, '6c4c7JZWm1FFY0IDm+lN87Q', 'ui-lobbyActivityOct30th');
// ScriptOct30th/gameLogicOct30th/LobbyLogicOct30th/ui-lobbyActivityOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        label: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {},

    onCloseClickOctFunc: function onCloseClickOctFunc() {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();