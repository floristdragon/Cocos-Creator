"use strict";
cc._RF.push(module, '15464lMOSRD+bwDlnmvSIPo', 'ui-classicBackgroundOct30th');
// ScriptOct30th/gameLogicOct30th/DdzLogicOct30th/ClassicDdzOct30th/ui-classicBackgroundOct30th.js

"use strict";

var exFangHaoNodePos = null;
var exJuShuNodePos = null;
cc.Class({
    extends: cc.Component,

    properties: {
        O_basescorenode: cc.Node,
        O_beilvnode: cc.Node,
        O_fanghaonode: cc.Node,
        O_jushunode: cc.Node,

        O_timetext: cc.Label,

        O_smallcardparent: cc.Node,
        O_smallcardArray: {
            default: [],
            type: cc.Node
        },
        O_beilvtip: cc.Node,
        O_typetip: cc.Node,
        O_backcardprefab: cc.Prefab,

        _backcardparent: null
    },

    // use this for initialization
    onLoad: function onLoad() {
        this._setBaseNumOctFunc(this.O_fanghaonode, 0);
        this._setBaseNumOctFunc(this.O_basescorenode, 0);
        this._setBaseNumOctFunc(this.O_beilvnode, 0);

        var self = this;
        var uptimerOctFunc = function uptimerOctFunc(dt) {
            var date = new Date();
            var tostr = "";
            if (date.getHours() < 10) {
                tostr += "0";
            }
            tostr += date.getHours();
            tostr += ":";
            if (date.getMinutes() < 10) {
                tostr += "0";
            }
            tostr += date.getMinutes();
            self.O_timetext.string = tostr;
        };
        uptimerOctFunc();
        this.schedule(uptimerOctFunc, 1);
        this.showThreeBackCardOctFunc(false);

        this.O_smallcardparent.active = false;

        // this.scheduleOnce(()=>{
        //     self.recoverBackCardOctFunc();
        // }, 2);
    },

    showBaseTipOctFunc: function showBaseTipOctFunc() {
        var roominfo = g_CLDDZGameData.getRoomInfoOctFunc();
        if (roominfo) {
            this._setBaseNumOctFunc(this.O_fanghaonode, roominfo.getRoomIdOctFunc());
            this._setBaseNumOctFunc(this.O_basescorenode, roominfo.getBaseScoreOctFunc());
            this._setBaseNumOctFunc(this.O_beilvnode, roominfo.getBaseBeiLvOctFunc());

            if (!exFangHaoNodePos) {
                exFangHaoNodePos = new cc.Vec2(this.O_fanghaonode.position.x, this.O_fanghaonode.position.y);
            }
            if (!exJuShuNodePos) {
                exJuShuNodePos = new cc.Vec2(this.O_jushunode.position.x, this.O_jushunode.position.y);
            }
            var curjushu = roominfo.getCurJuShuOctFunc();
            var maxjushu = roominfo.getMaxJuShuOctFunc();
            if (maxjushu > 0) {
                this._setBaseNumOctFunc(this.O_jushunode, curjushu + "/" + maxjushu);
            } else {
                this.O_jushunode.active = false;
                this.O_fanghaonode.position = exJuShuNodePos;
            }
        }
        cc.log("======ScoreTip===resetTip=============", roominfo);
    },
    showSmallBackCardOctFunc: function showSmallBackCardOctFunc(bVisible) {
        var _this = this;

        cc.log("=======showSmallBackCardOctFunc=======", bVisible);
        this.O_smallcardparent.active = bVisible;
        if (!bVisible) return;
        this.O_beilvtip.active = false;
        this.O_typetip.active = false;
        var backCardTab = g_CLDDZGameData.getBackCardOctFunc();

        var _loop = function _loop(i) {
            var toSpUrl = g_CLDDZGameData.getPokerFramePathOctFunc(false, backCardTab[i]);
            var toSprite = _this.O_smallcardArray[i].getComponent(cc.Sprite);
            cc.loader.loadRes(toSpUrl, function (err, texture) {
                toSprite.spriteFrame = new cc.SpriteFrame(texture);
            });
        };

        for (var i = 0; i < this.O_smallcardArray.length; i++) {
            _loop(i);
        }
    },
    showThreeBackCardOctFunc: function showThreeBackCardOctFunc(bVisible) {
        if (!this._backcardparent && !bVisible) return;
        if (this._backcardparent) this._backcardparent.destroy();

        this._backcardparent = cc.instantiate(this.O_backcardprefab);
        this._backcardparent.parent = this.node;
        this._backcardparent.active = bVisible;
        cc.log("========showThreeBackCardOctFunc=============", this._backcardparent);
    },
    recoverBackCardOctFunc: function recoverBackCardOctFunc() {
        var _this2 = this;

        cc.log("=======recoverBackCardOctFunc=======");
        this.showThreeBackCardOctFunc(true);
        this.O_smallcardparent.active = false;
        var backCardTab = g_CLDDZGameData.getBackCardOctFunc();
        var toshowOctFunc = function toshowOctFunc() {
            cc.log("=======toshowOctFunc=======");
            if (this.O_smallcardparent.active) return;
            this._backcardparent.active = false;
            this.showSmallBackCardOctFunc(true);
        };
        var backcardArray = [];
        var toPosArray = [];
        var toSpFrameArray = [];
        for (var i = 1; i <= 3; i++) {
            var toCard = this._backcardparent.getChildByName("card" + i);
            backcardArray.push(toCard);
        }
        for (var _i = 0; _i < backCardTab.length; _i++) {
            var toSpUrl = g_CLDDZGameData.getPokerFramePathOctFunc(true, backCardTab[_i], true);
            var texture = cc.textureCache.addImage(toSpUrl);
            toSpFrameArray.push(texture);
            var toPosEx = this.O_smallcardArray[_i].convertToWorldSpaceAR(cc.Vec2.ZERO);
            var toNodePos = this._backcardparent.convertToNodeSpaceAR(toPosEx);
            toPosArray.push(toNodePos);
        }

        var _loop2 = function _loop2(_i2) {
            var toRotateOctFunc = function toRotateOctFunc() {
                cc.log("====toRotateOctFunc=========", _i2);
                var toSprite = backcardArray[_i2].getComponent(cc.Sprite);
                toSprite.spriteFrame = new cc.SpriteFrame(toSpFrameArray[_i2]);
            };
            backcardArray[_i2].runAction(cc.sequence(cc.scaleTo(0.5, 0, 1), cc.callFunc(toRotateOctFunc, _this2), cc.scaleTo(0.5, 1, 1), cc.moveTo(0.5, toPosArray[_i2]), cc.callFunc(toshowOctFunc, _this2), cc.hide()));
        };

        for (var _i2 = 0; _i2 < backcardArray.length; _i2++) {
            _loop2(_i2);
        }
    },


    /////////////////////////////////////////////////////////////////////////////
    _setBaseNumOctFunc: function _setBaseNumOctFunc(node, str) {
        node.getChildByName("num").getComponent(cc.Label).string = str;
    }
});

cc._RF.pop();