"use strict";
cc._RF.push(module, '30bf0FUTMNKHLB999VJbEHf', 'includeOct30th');
// ScriptOct30th/includeOct30th.js

"use strict";

console.log("============require======include=====================");
var SocketClient = require("SocketClientOct30th");

window.g_RoomManager = require("RoomManagerOct30th"); //房间信息管理
window.g_UserManager = require("UserManagerOct30th"); //用户信息管理
window.g_ItemManager = require("ItemManagerOct30th"); //物品管理器
window.g_ConfigManager = require("ConfigManagerOct30th"); //本地配置数据
window.g_SoundManager = require("SoundManagerOct30th"); //音频管理器
window.g_NetManager = new SocketClient(); //网络连接管理
window.g_ProtDef = require("mProtocolOct30th"); //协议模块和协议的定义

window.g_GameScene = null; //当前场景得全局句柄

cc._RF.pop();