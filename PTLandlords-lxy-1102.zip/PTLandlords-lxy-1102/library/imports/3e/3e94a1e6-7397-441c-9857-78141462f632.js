"use strict";
cc._RF.push(module, '3e94aHmc5dEHJhXeBQUYvYy', 'nativeCallbackOct30th');
// ScriptOct30th/gameUtilsScriptOct30th/nativeCallbackOct30th.js

"use strict";

module.exports = {
    savePhotoCall: function savePhotoCall() {}
};

cc._RF.pop();