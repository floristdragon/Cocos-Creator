"use strict";
cc._RF.push(module, '41477YvcnlMnpORjh7x0QK9', 'ui-classicDdzSettingOct30th');
// ScriptOct30th/gameLogicOct30th/DdzLogicOct30th/ClassicDdzOct30th/ui-classicDdzSettingOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_jiesannode: cc.Node,
        O_leavenode: cc.Node,
        O_musicToggle: cc.Toggle,
        O_effectToggle: cc.Toggle,

        _isCheckToggleClick: true
    },

    // use this for initialization
    onLoad: function onLoad() {
        var roominfo = g_CLDDZGameData.getRoomInfoOctFunc();
        var ownerUserId = roominfo.getOwnerUserIdOctFunc();
        var selfSeatNo = g_CLDDZGameData.getSelfSeatNoOctFunc();
        var selfUserId = roominfo.getUserInfoOctFunc(selfSeatNo).userId;

        this.O_jiesannode.active = false;
        this.O_leavenode.active = false;
        if (ownerUserId == selfUserId) {
            this.O_jiesannode.active = true;
        } else {
            this.O_leavenode.active = true;
        }

        this._isCheckToggleClick = false;
        if (g_SoundManager.isMusicOpenOctFunc()) {
            this.O_musicToggle.check();
        } else {
            this.O_musicToggle.uncheck();
        }
        if (g_SoundManager.isEffectOpenOctFunc()) {
            this.O_effectToggle.check();
        } else {
            this.O_effectToggle.uncheck();
        }
        this._isCheckToggleClick = true;
    },
    onMusicToggleClickOctFunc: function onMusicToggleClickOctFunc(toggle) {
        cc.log("================onMusicToggleClickOctFunc======================", toggle, toggle.isChecked);
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setMusicOpenOctFunc(true);
            g_CLDDZGameData.playBackgroundMusicOctFunc();
        } else {
            g_SoundManager.setMusicOpenOctFunc(false);
        }
    },
    onEffectClickOctFunc: function onEffectClickOctFunc(toggle) {
        cc.log("==========================onEffectClickOctFunc===============", toggle, toggle.isChecked);
        if (!this._isCheckToggleClick) return;
        if (toggle.isChecked) {
            g_SoundManager.setEffectOpenOctFunc(true);
        } else {
            g_SoundManager.setEffectOpenOctFunc(false);
        }
    },
    onCloseClickOctFunc: function onCloseClickOctFunc() {
        this.node.destroy();
    },
    onLeaveClickOctFunc: function onLeaveClickOctFunc() {
        var toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIdOctFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIdOctFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqLeaveDesk, toProtTab);
        this.onCloseClickOctFunc();
    },
    onJieSanClickOctFunc: function onJieSanClickOctFunc() {
        var toProtTab = {};
        toProtTab.gameId = g_RoomManager.getCurGameIdOctFunc();
        toProtTab.roomId = g_RoomManager.getCurRoomIdOctFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqJieSanDesk, toProtTab);
        this.onCloseClickOctFunc();
    }
});

cc._RF.pop();