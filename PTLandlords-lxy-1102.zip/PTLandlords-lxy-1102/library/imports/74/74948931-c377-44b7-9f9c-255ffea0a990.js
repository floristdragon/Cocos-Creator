"use strict";
cc._RF.push(module, '74948kxw3dEt5+cJV/+oKmQ', 'ui-classicDdzHandCardOct30th');
// ScriptOct30th/gameLogicOct30th/DdzLogicOct30th/ClassicDdzOct30th/ui-classicDdzHandCardOct30th.js

"use strict";

var GameRuleLogic = require("DdzRuleLogicOct30th");
var GameRuleConfig = require("DdzRuleConfigOct30th");
cc.Class({
    extends: cc.Component,
    properties: {
        O_handcardprefab: cc.Prefab,
        O_outcardprefab: cc.Prefab,
        O_handCardSp: cc.Node,
        O_outCardSp: cc.Node,
        O_handCardNode: cc.Node,
        ///////////////////////////////////////////
        _seatNo: 0,
        _handCardSize: null,
        _outCardSize: null,
        _allCardArray: [],

        _tishiEatCardTab: [],
        _touchPreMoveUpNum: 0
    },
    // 尽量在onLoad来初始化界面，在initUI初始化和数据无关的变量
    onLoad: function onLoad() {
        cc.log("========handcard=========onLoad======================", this.O_handCardSp);
        this._handCardSize = new cc.Size(this.O_handCardSp.width, this.O_handCardSp.height);
        this.O_handCardSp.active = false;

        this._outCardSize = new cc.Size(this.O_outCardSp.width, this.O_outCardSp.height);
        this.O_outCardSp.getComponent(cc.Sprite).enabled = false;

        var self = this;
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_START, function (event) {
            //console.log("TOUCH_START");
            var touchPos = event.getLocation();
            self._priCheckTouchHandCardOctFunc(touchPos, 1);
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
            //console.log("TOUCH_MOVE");
            var touchPos = event.getLocation();
            self._priCheckTouchHandCardOctFunc(touchPos, 2);
        });
        self.O_handCardNode.on(cc.Node.EventType.TOUCH_END, function (event) {
            //console.log("TOUCH_END");
            var touchPos = event.getLocation();
            self._priCheckTouchHandCardOctFunc(touchPos, 3);
        });
        // this.scheduleOnce(function(){
        //     let toCardTab = [22,140,150,24,23,21, 42,43, 44,41,63,61,62,34,73,82,83];
        //     toCardTab.sort((a, b)=>{
        //         if(a>b) return -1;
        //         return 1;
        //     })
        //     g_CLDDZGameData.setHandCardTabOctFunc(this._seatNo, toCardTab);
        //     ///g_CLDDZGameData.setCurOutCardTabOctFunc([31, 32, 33, 52, 53]);
        //     g_CLDDZGameData.removeCardTabOctFunc(this._seatNo, [63,61,62]);
        //     self.drawHandCardOctFunc(17);
        // }, 2);

        //let ret = GameRuleLogic.getCardTabCardTypeOctFunc([11,13,21,31,43,44,52,54]);
        //cc.log("=======GameRuleLogic.IsCardTab1CanEatCardTab2OctFunc=========", ret);
    },

    //属于该句柄的seatNo，cardpos为手牌中心位置，cardWidth一张手牌的宽度
    initUIOctFunc: function initUIOctFunc(seatNo) {
        this._seatNo = seatNo;
    },
    resetUIOctFunc: function resetUIOctFunc() {
        this._clearHandCardOctFunc();
        this.clearOutCardOctFunc();
    },
    _clearHandCardOctFunc: function _clearHandCardOctFunc() {
        this.O_handCardNode.removeAllChildren(true);
        this._allCardArray = [];
    },
    clearOutCardOctFunc: function clearOutCardOctFunc() {
        this.O_outCardSp.removeAllChildren(true);
    },
    drawHandCardOctFunc: function drawHandCardOctFunc(numCard, isAllShow) {
        this._clearHandCardOctFunc();
        var handCardTab = g_CLDDZGameData.getHandCardTabOctFunc(this._seatNo);
        if (!handCardTab || handCardTab.length <= 0) return;
        if (!numCard || numCard > handCardTab.length) numCard = handCardTab.length;
        var beginPosX = 0;
        var beginPosY = 0;
        var toInterZOrder = 1;
        var toInterval = this._handCardSize.width / 2.5;
        var selfSeatNo = g_CLDDZGameData.getSelfSeatNoOctFunc();
        if (selfSeatNo != this._seatNo) {
            toInterval = this._handCardSize.width / 3.5;
        }
        if (this._seatNo == g_CLDDZGameData.getLastSeatNoOctFunc()) {
            beginPosX = 0;
        } else if (this._seatNo == g_CLDDZGameData.getNextSeatNoOctFunc()) {
            beginPosX = 0;
            toInterval *= -1;
            toInterZOrder *= -1;
        } else {
            beginPosX -= (numCard - 1) * toInterval / 2;
        }
        var rangpaiNum = 0; //g_CLDDZGameData.getQiangRangNumOctFunc();
        if (this._seatNo == g_CLDDZGameData.getDiZhuSeatNoOctFunc()) {
            rangpaiNum = -1;
        }
        cc.log("========drawHandCardOctFunc=========", handCardTab, numCard, rangpaiNum);
        for (var i = 0; i < numCard; i++) {
            if (selfSeatNo != this._seatNo && !isAllShow) break;
            var topNode = cc.instantiate(this.O_handcardprefab);
            var toCardScript = topNode.getComponent("ui-classicDdzPokerCardOct30th"); //不能用var

            if (selfSeatNo == this._seatNo || isAllShow) {
                toCardScript.setCardValueOctFunc(handCardTab[i]);
            } else {
                var israngpai = false;
                if (i < rangpaiNum) {
                    israngpai = true;
                }
                toCardScript.setCardValueOctFunc(0, israngpai);
            }
            if (selfSeatNo != this._seatNo) {
                toCardScript.setCardScaleOctFunc(0.75);
            }
            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            //console.log("======drawHandCardOctFunc============", beginPosX, beginPosY);
            topNode.setLocalZOrder(i * toInterZOrder);
            beginPosX += toInterval;
            this._allCardArray.push(topNode);

            topNode.parent = this.O_handCardNode;
        }
        //按照zorder来从大到小排列，用于触摸
        this._allCardArray.reverse();
        console.log("===drawHandCardOctFunc====end==", this.O_handCardNode);
    },
    drawOutCardOctFunc: function drawOutCardOctFunc(outCardTab) {
        this.clearOutCardOctFunc();
        var numCard = outCardTab.length;
        cc.log("========drawOutCardOctFunc=========", outCardTab, numCard);
        var beginPosX = 0;
        var beginPosY = 0;
        var toInterZOrder = 1;
        var toInterval = this._outCardSize.width / 2.5;
        if (this._seatNo == g_CLDDZGameData.getLastSeatNoOctFunc()) {
            beginPosX = 0;
        } else if (this._seatNo == g_CLDDZGameData.getNextSeatNoOctFunc()) {
            beginPosX = 0;
            toInterval *= -1;
            toInterZOrder *= -1;
        } else {
            beginPosX -= (numCard - 1) * toInterval / 2;
        }

        for (var i = 0; i < numCard; i++) {
            var topNode = cc.instantiate(this.O_outcardprefab);
            var toCardScript = topNode.getComponent("ui-classicDdzPokerCardOct30th"); //不能用var
            //cc.log("====drawOutCardOctFunc=======", this._seatNo, toCardScript);
            toCardScript.setCardValueOctFunc(outCardTab[i]);
            topNode.position = new cc.Vec2(beginPosX, beginPosY);
            //console.log("======drawHandCardOctFunc============", beginPosX, beginPosY);
            topNode.setLocalZOrder(i * toInterZOrder);
            beginPosX += toInterval;

            topNode.parent = this.O_outCardSp;
        }
    },
    moveAddActionCardOctFunc: function moveAddActionCardOctFunc(actCardTab) {
        for (var j = 0; j < actCardTab.length; j++) {
            for (var i = 0; i < this._allCardArray.length; i++) {
                var cardScript = this._allCardArray[i].getComponent("ui-classicDdzPokerCardOct30th");
                if (!cardScript) return;
                if (!cardScript.isCardMoveUpOctFunc() && actCardTab[j] == cardScript.getCardValueOctFunc()) {
                    cardScript.moveUpCardOctFunc();
                    cardScript.moveDownCardOctFunc(1);
                    cardScript.showPointTipOctFunc(true);
                    break;
                }
            }
        }
    },
    moveTiShiHandCardOctFunc: function moveTiShiHandCardOctFunc(outCardTab) {
        cc.log("======moveTiShiHandCardOctFunc====11====", outCardTab);
        var handCardTab = g_CLDDZGameData.getHandCardTabOctFunc(this._seatNo);
        if (!handCardTab || handCardTab.length <= 0) return;
        var preTiShiLength = this._tishiEatCardTab.length;
        var isEat = GameRuleLogic.IsCardTab1CanEatCardTab2OctFunc(this._tishiEatCardTab, outCardTab);
        if (!isEat) {
            cc.log("======moveTiShiHandCardOctFunc====22====");
            this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabOctFunc(handCardTab, outCardTab);
        } else {
            cc.log("======moveTiShiHandCardOctFunc====33====");
            this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabOctFunc(handCardTab, this._tishiEatCardTab);
            if (preTiShiLength > 0 && this._tishiEatCardTab.length <= 0) {
                this._tishiEatCardTab = GameRuleLogic.getOutTipCardTabOctFunc(handCardTab, outCardTab);
            }
        }
        cc.log("======moveTiShiHandCardOctFunc====44====", isEat, preTiShiLength, this._tishiEatCardTab);
        this._priMoveUpCardTabOctFunc(this._tishiEatCardTab);
    },
    clearTiShiHandCardOctFunc: function clearTiShiHandCardOctFunc() {
        this._tishiEatCardTab = [];
    },
    getMoveUpCardTabOctFunc: function getMoveUpCardTabOctFunc(outCardTab) {
        var tab = [];
        for (var i = 0; i < this._allCardArray.length; i++) {
            var cardScript = this._allCardArray[i].getComponent("ui-classicDdzPokerCardOct30th");
            if (!cardScript) return;
            if (cardScript.isCardMoveUpOctFunc()) {
                tab.push(cardScript.getCardValueOctFunc());
            }
        }
        var ctype = GameRuleLogic.getCardTabCardTypeOctFunc(tab);
        if (ctype == GameRuleConfig.CardType.ErrorType) return;
        var isEat = GameRuleLogic.IsCardTab1CanEatCardTab2OctFunc(tab, outCardTab);
        if (isEat) return tab;
    },


    //////////////////////////////////////////////////////////////////////////////////////////////
    _priMoveUpCardTabOctFunc: function _priMoveUpCardTabOctFunc(cardTab) {
        for (var i = 0; i < this._allCardArray.length; i++) {
            var cardScript = this._allCardArray[i].getComponent("ui-classicDdzPokerCardOct30th");
            if (!cardScript) return;
            cardScript.moveDownCardOctFunc();
        }
        for (var j = 0; j < cardTab.length; j++) {
            for (var _i = 0; _i < this._allCardArray.length; _i++) {
                var _cardScript = this._allCardArray[_i].getComponent("ui-classicDdzPokerCardOct30th");
                if (!_cardScript) return;
                if (!_cardScript.isCardMoveUpOctFunc() && cardTab[j] == _cardScript.getCardValueOctFunc()) {
                    _cardScript.moveUpCardOctFunc();
                    break;
                }
            }
        }
    },
    _priCheckTouchHandCardOctFunc: function _priCheckTouchHandCardOctFunc(touchPos, touchType) {
        if (touchType == 1) this._touchPreMoveUpNum = 0;
        var touchindex = -1;
        for (var i = 0; i < this._allCardArray.length; i++) {
            var cardScript = this._allCardArray[i].getComponent("ui-classicDdzPokerCardOct30th");
            if (!cardScript) return;
            if (cardScript.onChceckTouchOctFunc(touchPos, touchType)) {
                touchindex = i;
                break;
            }
        }
        var moveUpTab = [];
        for (var _i2 = 0; _i2 < this._allCardArray.length; _i2++) {
            var _cardScript2 = this._allCardArray[_i2].getComponent("ui-classicDdzPokerCardOct30th");
            if (!_cardScript2) return;
            if (_i2 != touchindex) {
                _cardScript2.onUnTouchCardOctFunc();
            }
            if (_cardScript2.isCardMoveUpOctFunc()) {
                moveUpTab.push(_cardScript2.getCardValueOctFunc());
            }
        }
    }
});

cc._RF.pop();