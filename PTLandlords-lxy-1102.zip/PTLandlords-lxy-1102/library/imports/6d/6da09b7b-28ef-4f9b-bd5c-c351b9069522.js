"use strict";
cc._RF.push(module, '6da09t7KO9Pm71cw1G5BpUi', 'ui-registerNodeOct30th');
// ScriptOct30th/gameLogicOct30th/startOct30th/ui-registerNodeOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    onCancelBtnEventOctFunc: function onCancelBtnEventOctFunc() {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        console.log("====onCancelBtnEventOctFunc=======");
        this.node.emit("register-hideregnode");
    },
    onOkBtnEventOctFunc: function onOkBtnEventOctFunc() {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        var accText = this.node.getChildByName("enteracc").getComponent(cc.EditBox).string;
        var pwdText = this.node.getChildByName("enterpwd").getComponent(cc.EditBox).string;
        var eventparam = { acc: accText, pwd: pwdText };
        console.log("====onOkBtnEventOctFunc=======", eventparam);
        this.node.emit("register-regaccount", eventparam);
    }
});

cc._RF.pop();