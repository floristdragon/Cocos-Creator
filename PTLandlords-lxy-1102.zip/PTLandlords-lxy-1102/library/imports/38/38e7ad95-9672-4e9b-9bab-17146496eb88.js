"use strict";
cc._RF.push(module, '38e7a2VlnJOm5urFxRkluuI', 'ui-lobbyCurrentRoomLineOct30th');
// ScriptOct30th/gameLogicOct30th/LobbyLogicOct30th/ui-lobbyCurrentRoomLineOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_roomidlabel: cc.Label,
        O_jushulabel: cc.Label,

        _roomId: null,
        _gameId: null
    },

    setDataOctFunc: function setDataOctFunc(gameId, roomId, curjushu, maxjushu) {
        cc.log("===ui-lobbyCurrentRoomLineOct30th==setDataOctFunc========", gameId, roomId, curjushu, maxjushu);
        this._gameId = gameId;
        this._roomId = roomId;
        this.O_roomidlabel.string = roomId + "";
        this.O_jushulabel.string = curjushu + "/" + maxjushu;
    },
    onJoinRoomBtnEventOctFunc: function onJoinRoomBtnEventOctFunc() {
        if (!this._gameId || !this._roomId) return;
        var toProtTab = {};
        toProtTab.gameId = this._gameId;
        toProtTab.roomId = this._roomId;
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqEnterDesk, toProtTab);
    }
});

cc._RF.pop();