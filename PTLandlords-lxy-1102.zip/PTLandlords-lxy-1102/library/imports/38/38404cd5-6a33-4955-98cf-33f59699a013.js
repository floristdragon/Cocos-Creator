"use strict";
cc._RF.push(module, '38404zVajNJVZjPM/WWmaAT', 'ui-xieYiNodeOct30th');
// ScriptOct30th/gameLogicOct30th/startOct30th/ui-xieYiNodeOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    onCloseBtnOctFunc: function onCloseBtnOctFunc(event) {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        this.node.emit("login-hidexieyi");
    }

});

cc._RF.pop();