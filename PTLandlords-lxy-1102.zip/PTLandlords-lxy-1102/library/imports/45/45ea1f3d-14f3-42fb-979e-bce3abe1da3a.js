"use strict";
cc._RF.push(module, '45ea189FPNC+5eevOOr4do6', 'ui-classicDdzControllbtnOct30th');
// ScriptOct30th/gameLogicOct30th/DdzLogicOct30th/ClassicDdzOct30th/ui-classicDdzControllbtnOct30th.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        O_outcardbtnnode: cc.Node,
        O_qiangdzbtnnode: cc.Node,
        O_jiaodzbtnnode: cc.Node,

        O_buchubtn: cc.Button
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.hideAllButtonOctFunc();
    },
    hideAllButtonOctFunc: function hideAllButtonOctFunc() {
        this.O_outcardbtnnode.active = false;
        this.O_qiangdzbtnnode.active = false;
        this.O_jiaodzbtnnode.active = false;
    },
    showOutCardBtnOctFunc: function showOutCardBtnOctFunc(bMustOut) {
        this.hideAllButtonOctFunc();
        this.O_outcardbtnnode.active = true;
        this.O_buchubtn.interactable = !bMustOut;
    },
    showQiangDZBtnOctFunc: function showQiangDZBtnOctFunc() {
        this.hideAllButtonOctFunc();
        this.O_qiangdzbtnnode.active = true;
    },
    showJiaoDZBtnOctFunc: function showJiaoDZBtnOctFunc() {
        this.hideAllButtonOctFunc();
        this.O_jiaodzbtnnode.active = true;
    },
    ////////////////////////////////////////////////////
    onBuChuBtnEventOctFunc: function onBuChuBtnEventOctFunc(event) {
        this.node.emit("outbtn-buchu");
    },
    onLastHandBtnEventOctFunc: function onLastHandBtnEventOctFunc(event) {
        //this.node.emit("outbtn-lasthand");
    },
    onTiShiBtnEventOctFunc: function onTiShiBtnEventOctFunc(event) {
        this.node.emit("outbtn-tishi");
    },
    onChuPaiBtnEventOctFunc: function onChuPaiBtnEventOctFunc(event) {
        this.node.emit("outbtn-chupai");
    },
    /////////////////////////////////////////////////
    _priCallProtocolDiZhuOctFunc: function _priCallProtocolDiZhuOctFunc(isCall) {
        this.hideAllButtonOctFunc();
        var toProtData = {};
        toProtData.isCall = isCall, g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ClassicDDZ, g_ProtDef.AClassicDDZ_C2SCallLandlord, toProtData);
    },
    onBuQiangBtnEventOctFunc: function onBuQiangBtnEventOctFunc(event) {
        cc.log("=========onBuQiangBtnEventOctFunc===");
        this._priCallProtocolDiZhuOctFunc(0);
    },
    onQiangDZBtnEventOctFunc: function onQiangDZBtnEventOctFunc(event) {
        cc.log("=========onQiangDZBtnEventOctFunc===");
        this._priCallProtocolDiZhuOctFunc(1);
    },
    /////////////////////////////////////////////////
    onBuJiaoBtnEventOctFunc: function onBuJiaoBtnEventOctFunc(event) {
        cc.log("=========onBuJiaoBtnEventOctFunc===");
        this._priCallProtocolDiZhuOctFunc(0);
    },
    onJiaoDZBtnEventOctFunc: function onJiaoDZBtnEventOctFunc(event) {
        cc.log("=========onJiaoDZBtnEventOctFunc===");
        this._priCallProtocolDiZhuOctFunc(1);
    }
});

cc._RF.pop();