"use strict";
cc._RF.push(module, '12ada8kkU5L5I3ghuV2r3a+', 'ItemManagerOct30th');
// ScriptOct30th/gameBaseScriptOct30th/ItemManagerOct30th.js

"use strict";

module.exports = {
    _allitemtab: {},
    updateItemOctFunc: function updateItemOctFunc(itemid, count) {
        itemid = Math.floor(parseInt(itemid) / 1000);
        this._allitemtab[itemid] = count;
    },
    getItemOctFunc: function getItemOctFunc(itemid) {
        itemid = parseInt(itemid);
        return this._allitemtab[itemid];
    },
    getGoldOctFunc: function getGoldOctFunc() {
        if (!this._allitemtab[1001]) return 0;
        return this._allitemtab[1001];
    }
};

cc._RF.pop();