"use strict";
cc._RF.push(module, '62837fOgx9EbLBc+9ox6FjI', 'ui-lobbyZhanJiLineOct30th');
// ScriptOct30th/gameLogicOct30th/LobbyLogicOct30th/ui-lobbyZhanJiLineOct30th.js

"use strict";

var gameconfig = require("gameConfigOct30th");
cc.Class({
    extends: cc.Component,

    properties: {
        O_gameidlabel: cc.Label,
        O_roomidlabel: cc.Label,
        O_timelabel: cc.Label,

        _userdatalist: null
    },

    setDataOctFunc: function setDataOctFunc(gameid, roomid, jushu, stime, userlist) {
        this.O_gameidlabel.string = gameconfig[parseInt(gameid)].desc;
        this.O_roomidlabel.string = roomid + "-" + jushu;
        this._userdatalist = userlist;
        var date = new Date(stime * 1000);
        var extfunc = function extfunc(time) {
            if (time < 10) return "0" + time;
            return time + "";
        };
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        this.O_timelabel.string = ' ' + year + "/" + extfunc(month) + "/" + extfunc(date.getDate()) + "-" + extfunc(date.getHours()) + ":" + extfunc(date.getMinutes()) + ' ';
    },
    onClickBtnEventOctFunc: function onClickBtnEventOctFunc() {
        cc.log("=======onClickBtnEventOctFunc========", this._userdatalist);
        if (this._userdatalist) {
            this.node.emit("zhanjiline-event", this._userdatalist);
        }
    }
});

cc._RF.pop();