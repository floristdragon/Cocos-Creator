"use strict";
cc._RF.push(module, '191936EiUxCL6k8fMALDcOb', 'ui-erRenDdzSceneOct30th');
// ScriptOct30th/gameLogicOct30th/DdzLogicOct30th/ErRenDdzOct30th/ui-erRenDdzSceneOct30th.js

"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

require("ErRenDdzGameDataOct30th");

var GameRuleLogic = require("DdzRuleLogicOct30th");
var STATUS_READY = 0; //准备
var STATUS_SENDCARD = 1; //发牌
var STATUS_QIANGDIZHU = 2; //抢地主
var STATUS_OUTCARD = 3; //出牌
var STATUS_GAMEFINISH = 4; //游戏结束
cc.Class({
    extends: require("ui-roomSceneOct30th"),

    properties: {
        O_controlbtnprefab: cc.Prefab,
        O_gameresultprefab: cc.Prefab,

        O_userInfoPrefab: cc.Prefab,

        O_settingPrefab: cc.Prefab,

        //////////////////////////////////////
        _backgroundScipt: null,
        _ctlbuttonScript: null,
        _rangtipScript: null,
        _gameresultScript: null,
        _dispcardScript: null

    },

    // use this for initialization
    onLoad: function onLoad() {
        this._super(); //调用父类的onLoad
        this._setChatRoomStateOctFunc(true);
        //背景音乐
        g_ERDDZGameData.playBackgroundMusicOctFunc();

        var gameId = g_RoomManager.getCurGameIdOctFunc();
        var roomId = g_RoomManager.getCurRoomIdOctFunc();
        var selfUserId = g_UserManager.getSelfUserIdOctFunc();
        var roominfo = g_RoomManager.getGameRoomInfoOctFunc(gameId, roomId);

        var selfSeatNo = roominfo.findUserSeatNoOctFunc(selfUserId);
        g_ERDDZGameData.initOctFunc(gameId, roomId, selfSeatNo);
        cc.log("=======DdzResOct30th==mainscene=11====", gameId, roomId, selfUserId);

        //////////////////////////////////////////////////////////
        this._cplayerArray = [];
        var maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        var toSeatNo = selfSeatNo;
        for (var i = 0; i < maxPlayer; i++) {
            var playerNo = i + 1;
            var playerNode = this.node.getChildByName("player" + playerNo);
            playerNode.setLocalZOrder(100);
            console.log("=====111111=======", toSeatNo, selfSeatNo, playerNo);
            var cplayerhandler = playerNode.getComponent("ui-erRenDdzPlayerOct30th");
            cplayerhandler.initUIOctFunc(toSeatNo, playerNode);
            g_ERDDZGameData.setPlayerUIOctFunc(cplayerhandler, i, toSeatNo);

            toSeatNo = g_ERDDZGameData.getNextSeatNoOctFunc(toSeatNo);
        };
        this._backgroundScipt = this.getComponent("ui-erRenDdzBackgroundOct30th");
        this._backgroundScipt.showBaseTipOctFunc();

        this._rangtipScript = this.getComponent("ui-erRenDdzRangTipOct30th");
        this._rangtipScript.showQiangDZTipOctFunc(false);

        this._dispcardScript = this.getComponent("ui-erRenDdzDispcardOct30th");
        cc.log("=========DdzResOct30th==mainscene====22====", this._dispcardScript);
        /////////////////////////////////////////////////////////////////
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_ErRenDDZ, null, this._onProtSocketMessageOctFunc, this);

        /////////////////////////////////////////////////////////////////
        //场景加载完毕，开始请求场景协议
        var toProtData = {};
        toProtData.gameId = g_ERDDZGameData.getGameIdOctFunc();
        toProtData.roomId = g_ERDDZGameData.getRoomIdOctFunc();
        cc.log("=========requestGameStatus===", toProtData);
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqGameStatus, toProtData);
    },
    onDestroyOctFunc: function onDestroyOctFunc() {
        cc.log("=============onDestroyOctFunc==============");
    },
    _resetAllUIOctFunc: function _resetAllUIOctFunc() {
        if (this._ctlbuttonScript) {
            this._getControlBtnOctFunc().hideAllButtonOctFunc();
        }
        if (this._gameresultScript) {
            this._getGameResultOctFunc().showResultOctFunc(false);
        }
        g_ERDDZGameData._resetInitOctFunc();
        this._rangtipScript.hideAllTipOctFunc();
        this._backgroundScipt.showThreeBackCardOctFunc(false);
        this._backgroundScipt.showSmallBackCardOctFunc(false);
        this._backgroundScipt.showBaseTipOctFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        var maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        for (var i = 0; i < maxPlayer; i++) {
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
            playerui.resetUIOctFunc();

            var userinfo = roominfo.getUserInfoOctFunc(i);
            cc.log("======_resetAllUIOctFunc====111=======", i, userinfo);
            if (userinfo) {
                playerui.showUserInfoOctFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
            } else {
                playerui.showUserInfoOctFunc(false);
            }
        }
    },
    _requestGameReadyOctFunc: function _requestGameReadyOctFunc(delaytime) {
        var self = this;
        var readyOctFunc = function readyOctFunc() {
            //在这里进入房间后要发协议，自己默认进入房间就准备
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SReady);
        };
        if (!delaytime || delaytime <= 0) {
            readyOctFunc();
        } else {
            this.scheduleOnce(readyOctFunc, delaytime);
        }
    },
    onSettingBtnEventOctFunc: function onSettingBtnEventOctFunc(event) {
        var settingPlane = cc.instantiate(this.O_settingPrefab);
        this.node.addChild(settingPlane, 1000);
    },
    onShowUserInfoPanelOctFunc: function onShowUserInfoPanelOctFunc(node, detail) {
        cc.log("========onShowUserInfoPanelOctFunc=========", node, detail);
        var seatNo = g_ERDDZGameData.getSelfSeatNoOctFunc();
        if (detail == 2) {
            seatNo = g_ERDDZGameData.getNextSeatNoOctFunc(seatNo);
        }
        var roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        if (roominfo.getUserInfoOctFunc(seatNo)) {
            var userInfoNode = cc.instantiate(this.O_userInfoPrefab);
            userInfoNode.parent = this.node;
            userInfoNode.setLocalZOrder(200);
            userInfoNode.getComponent("ui-erRenDdzUserInfoOct30th").showInfoOctFunc(seatNo);
        }
    },

    //////////////////////////////////////////////////////////////////////////////
    _getControlBtnOctFunc: function _getControlBtnOctFunc() {
        var _this = this;

        if (!this._ctlbuttonScript) {
            var ctrbtn = cc.instantiate(this.O_controlbtnprefab);
            ctrbtn.parent = this.node;
            ctrbtn.setLocalZOrder(150);
            this._ctlbuttonScript = ctrbtn.getComponent("ui-erRenDdzControllbtnOct30th");
            ctrbtn.off("outbtn-buchu");
            ctrbtn.off("outbtn-tishi");
            ctrbtn.off("outbtn-chupai");
            ctrbtn.on("outbtn-buchu", function (event) {
                _this._OutCardBuChuOctFunc();
            }, this);
            ctrbtn.on("outbtn-tishi", function (event) {
                _this._OutCardTiShiOctFunc();
            }, this);
            ctrbtn.on("outbtn-chupai", function (event) {
                _this.OutCardChuPaiOctFunc();
            }, this);
        }
        return this._ctlbuttonScript;
    },
    _getGameResultOctFunc: function _getGameResultOctFunc() {
        if (!this._gameresultScript) {
            var resultnode = cc.instantiate(this.O_gameresultprefab);
            resultnode.parent = this.node;
            resultnode.setLocalZOrder(200);
            this._gameresultScript = resultnode.getComponent("ui-erRenDdzGameResultOct30th");
        }
        return this._gameresultScript;
    },
    _OutCardBuChuOctFunc: function _OutCardBuChuOctFunc() {
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoOctFunc();
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(selfSeatNo);
        playerui.getHandCardOctFunc().clearTiShiHandCardOctFunc();

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SBuChu);
    },
    _OutCardTiShiOctFunc: function _OutCardTiShiOctFunc() {
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoOctFunc();
        var outCardTab = g_ERDDZGameData.getCurOutCardTabOctFunc(true);
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(selfSeatNo);
        playerui.getHandCardOctFunc().moveTiShiHandCardOctFunc(outCardTab);
    },
    OutCardChuPaiOctFunc: function OutCardChuPaiOctFunc() {
        var selfSeatNo = g_ERDDZGameData.getSelfSeatNoOctFunc();
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(selfSeatNo);
        playerui.getHandCardOctFunc().clearTiShiHandCardOctFunc();
        var outCardTab = g_ERDDZGameData.getCurOutCardTabOctFunc(true);
        var outTab = playerui.getHandCardOctFunc().getMoveUpCardTabOctFunc(outCardTab);
        if (outTab && outTab.length > 0) {
            var toProtTab = {};
            toProtTab.cardTab = outTab;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SOutCard, toProtTab);
        } else {
            this.showPopupWindowOctFunc(true, false, "提示", "出牌不符合规则！");
        }
    },

    ////////////////////////////////////////////////////////////////////////////////
    onRecvErrcodeOctFunc: function onRecvErrcodeOctFunc(errcode, attachtab) {
        cc.log("=======onRecvErrcodeOctFunc============", errcode, attachtab);
        this.showPopupWindowOctFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },

    //其他玩家进入房间会调用这里, 进入房间协议比场景协议要先到来
    onRecvEnterRoomOctFunc: function onRecvEnterRoomOctFunc(gameId, roomId, userId) {
        //let selfUserId = g_UserManager.getSelfUserIdOctFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        var seatNo = roominfo.findUserSeatNoOctFunc(userId);
        var userinfo = roominfo.getUserInfoOctFunc(seatNo);
        var playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(seatNo);
        cc.log("==============onRecvEnterRoomOctFunc==========", roomId, userId, typeof userId === "undefined" ? "undefined" : _typeof(userId), roominfo);
        playerui.showUserInfoOctFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
    },
    onRecvJieSanDeskOctFunc: function onRecvJieSanDeskOctFunc(gameId, roomId, userId, userName, isAuto) {
        var _this2 = this;

        cc.log("======onRecvJieSanDeskOctFunc==========", gameId, roomId, userId, userName, isAuto);
        if (!isAuto) {
            this.showPopupWindowOctFunc(true, false, "提示", "房主已经解散了房间！", function (flag) {
                _this2.switchLobbySceneOctFunc();
            }, this);
        } else {
            this.showPopupWindowOctFunc(true, false, "提示", "房间局数已尽！", function (flag) {
                _this2.switchLobbySceneOctFunc();
            }, this);
        }
    },
    onRecvLeaveDeskOctFunc: function onRecvLeaveDeskOctFunc(gameId, roomId, userId) {
        cc.log("======onRecvLeaveDeskOctFunc==========", gameId, roomId, userId);
        if (userId == g_UserManager.getSelfUserIdOctFunc()) {
            // this.showPopupWindowOctFunc(true, false, "提示", "您已经离开房间！", (flag)=>{
            //     this.switchLobbySceneOctFunc();
            // }, this);
            this.switchLobbySceneOctFunc();
        }
    },

    ////////////////////////////////////////////////////////////////////////////////
    _startDispCardOctFunc: function _startDispCardOctFunc(beginSeatNo) {
        var maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        var eachNumArray = [];
        var eachPosArray = [];
        for (var i = 0; i < maxPlayer; i++) {
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
            eachNumArray.push(17);
            eachPosArray.push(playerui.getHandCardPosOctFunc());
        }
        var self = this;
        this._dispcardScript.sendAllCardOctFunc(beginSeatNo, eachNumArray, eachPosArray, function (seatNo, num, isEnd) {
            if (!isEnd) {
                var _playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(seatNo);
                _playerui.getHandCardOctFunc().drawHandCardOctFunc(num);
            } else {
                g_ERDDZGameData.setHandCardSortOctFunc(true);
                self._backgroundScipt.showThreeBackCardOctFunc(true);
                self._backgroundScipt.showSmallBackCardOctFunc(false);
                var _maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
                for (var _i = 0; _i < _maxPlayer; _i++) {
                    var _playerui2 = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(_i);
                    _playerui2.getHandCardOctFunc().drawHandCardOctFunc();
                }
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SSendCardFinish);
            }
        });
    },

    ////////////////////////////////////////////////////////////////////////////////
    onRecvGameStatusOctFunc: function onRecvGameStatusOctFunc(protTab) {
        cc.log("==========onRecvGameStatusOctFunc====11=========", protTab);
        var maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        var selfUserId = g_UserManager.getSelfUserIdOctFunc();
        var selfSeatNo = roominfo.findUserSeatNoOctFunc(selfUserId);
        this._resetAllUIOctFunc();
        cc.log("==========onRecvGameStatusOctFunc====22=========");
        if (protTab.status == STATUS_READY) {
            for (var i = 0; i < maxPlayer; i++) {
                var playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                var isReady = protTab.readyTab[i];
                if (i == selfSeatNo) isReady = true;
                playerui.showReadyTipOctFunc(isReady);
            }
            this._requestGameReadyOctFunc();
        } else if (protTab.status == STATUS_SENDCARD) {
            for (var _i2 = 0; _i2 < maxPlayer; _i2++) {
                g_ERDDZGameData.setHandCardTabOctFunc(_i2, protTab.handCardTab[_i2], true);
                var _playerui3 = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(_i2);
                var leftnum = g_ERDDZGameData.getHandCardCountOctFunc(_i2);
                _playerui3.showUserLeftCardOctFunc(true, leftnum);
                _playerui3.getHandCardOctFunc().drawHandCardOctFunc();
            }
            this._startDispCardOctFunc(selfSeatNo);
        } else if (protTab.status == STATUS_QIANGDIZHU) {
            var turnSeatNo = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumOctFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            if (protTab.bankerUserId) {
                var bankSeatNo = roominfo.findUserSeatNoOctFunc(protTab.bankerUserId);
                g_ERDDZGameData.setDiZhuSeatNoOctFunc(bankSeatNo);
            }
            for (var _i3 = 0; _i3 < maxPlayer; _i3++) {
                g_ERDDZGameData.setHandCardTabOctFunc(_i3, protTab.handCardTab[_i3], true);
                var _playerui4 = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(_i3);
                var _leftnum = g_ERDDZGameData.getHandCardCountOctFunc(_i3);
                _playerui4.showUserLeftCardOctFunc(true, _leftnum);
                _playerui4.getHandCardOctFunc().drawHandCardOctFunc();
                if (turnSeatNo == _i3 && turnSeatNo != selfSeatNo) {
                    _playerui4.showTimeWaitTipOctFunc(true);
                } else {
                    _playerui4.showTimeWaitTipOctFunc(false);
                }
            }
            this._rangtipScript.showQiangDZTipOctFunc(false);
            this._rangtipScript.showRangTipOctFunc();
            this._backgroundScipt.showThreeBackCardOctFunc(true);
            this._backgroundScipt.showSmallBackCardOctFunc(false);
            if (protTab.turnUserId == selfUserId) {
                if (protTab.isTurnJiaoDZ == 1) {
                    this._getControlBtnOctFunc().showJiaoDZBtnOctFunc();
                } else {
                    this._getControlBtnOctFunc().showQiangDZBtnOctFunc();
                    this._rangtipScript.showQiangDZTipOctFunc(true);
                }
            }
            if (protTab.lastUserId != null) {
                var _playerui5 = g_ERDDZGameData.getPlayerUIByUserIdOctFunc(protTab.lastUserId);
                if (protTab.isJiaoDZ == 1) {
                    _playerui5.speekJiaoDiZhuOctFunc(true);
                } else {
                    _playerui5.speekQiangDiZhuOctFunc(true);
                }
            }
        } else if (protTab.status == STATUS_OUTCARD) {
            g_ERDDZGameData.setBackCardOctFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            var bankerSeatNo = roominfo.findUserSeatNoOctFunc(protTab.bankerUserId);
            var outSeatNo = roominfo.findUserSeatNoOctFunc(protTab.outUserId);
            var _turnSeatNo = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            g_ERDDZGameData.setDiZhuSeatNoOctFunc(bankerSeatNo);
            g_ERDDZGameData.setCurOutCardTabOctFunc(protTab.outTab);
            g_ERDDZGameData.setQiangRangNumOctFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            for (var _i4 = 0; _i4 < maxPlayer; _i4++) {
                g_ERDDZGameData.setHandCardTabOctFunc(_i4, protTab.handCardTab[_i4], true);
                var _playerui6 = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(_i4);
                _playerui6.getHandCardOctFunc().drawHandCardOctFunc();
                _playerui6.showDiZhuTipOctFunc(false);
                if (bankerSeatNo == _i4) {
                    _playerui6.showDiZhuTipOctFunc(true);
                }
                if (_i4 == outSeatNo) {
                    _playerui6.getHandCardOctFunc().drawOutCardOctFunc(protTab.outTab);
                    _playerui6.getHandCardOctFunc().drawHandCardOctFunc();
                } else {
                    _playerui6.getHandCardOctFunc().clearOutCardOctFunc();
                }
                if (_turnSeatNo == _i4 && _turnSeatNo != selfSeatNo) {
                    _playerui6.showTimeWaitTipOctFunc(true);
                } else {
                    _playerui6.showTimeWaitTipOctFunc(false);
                }
                var _leftnum2 = g_ERDDZGameData.getHandCardCountOctFunc(_i4);
                _playerui6.showUserLeftCardOctFunc(true, _leftnum2);
                if (_leftnum2 <= 3) {
                    _playerui6.showBaoJingTipOctFunc(true);
                }
            }
            this._backgroundScipt.showSmallBackCardOctFunc(true);
            this._rangtipScript.showQiangDZTipOctFunc(false);
            this._rangtipScript.showRangTipOctFunc();
            if (protTab.turnUserId == selfUserId) {
                this._getControlBtnOctFunc().showOutCardBtnOctFunc(protTab.mustOut == 1);
            }
        } else if (protTab.status == STATUS_GAMEFINISH) {
            //this._requestGameReadyOctFunc(3);
            this._onShowGameResultOctFunc(protTab.finishdata);
        }
    },
    _onProtSocketMessageOctFunc: function _onProtSocketMessageOctFunc(mainId, assistId, protTab) {
        cc.log("==========_onProtSocketMessageOctFunc=============", mainId, assistId, protTab);
        // AErRenDDZ_S2CBeginOut = 201;   //开始出牌
        // AErRenDDZ_S2CCallLandlord = 202;  //叫地主
        // AErRenDDZ_S2COutCard    = 203;    //出牌
        // AErRenDDZ_S2CBuChu  = 204;   //不出
        // AErRenDDZ_S2CSendCard  = 205;  //发牌
        // AErRenDDZ_S2CTuoGuan = 207;   //托管
        // AErRenDDZ_S2CGameFinish = 208;    //游戏结束
        var maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        var selfUserId = g_UserManager.getSelfUserIdOctFunc();
        var selfSeatNo = roominfo.findUserSeatNoOctFunc(selfUserId);
        for (var i = 0; i < maxPlayer; i++) {
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
            playerui.showReadyTipOctFunc(false);
            playerui.showTimeWaitTipOctFunc(false);
            playerui.speekNothingOctFunc();
        }
        this._backgroundScipt.showBaseTipOctFunc();
        if (assistId == g_ProtDef.AErRenDDZ_S2CReady) {
            if (protTab.userId == selfUserId) {
                this._resetAllUIOctFunc();
            }
            var _playerui7 = g_ERDDZGameData.getPlayerUIByUserIdOctFunc(protTab.userId);
            _playerui7.showReadyTipOctFunc(true);
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CSendCard) {
            var jiaoSeatNo = roominfo.findUserSeatNoOctFunc(protTab.jiaoUserId);
            for (var _i5 = 0; _i5 < maxPlayer; _i5++) {
                g_ERDDZGameData.setHandCardTabOctFunc(_i5, protTab.handCardTab[_i5], false);
                var _playerui8 = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(_i5);
                _playerui8.getHandCardOctFunc().drawHandCardOctFunc();
                if (_i5 == jiaoSeatNo && jiaoSeatNo != selfSeatNo) {
                    _playerui8.showTimeWaitTipOctFunc(true);
                }
            }
            this._startDispCardOctFunc(selfSeatNo);
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CCallLandlord) {
            var turnSeatNo = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumOctFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            this._getControlBtnOctFunc().hideAllButtonOctFunc();
            this._backgroundScipt.showThreeBackCardOctFunc(true);
            this._backgroundScipt.showSmallBackCardOctFunc(false);

            var _jiaoSeatNo = -1;
            if (protTab.userId) {
                //当发牌完成后，会发送一个userId为空的首次叫地主的协议过来，通知开始叫地主
                _jiaoSeatNo = roominfo.findUserSeatNoOctFunc(protTab.userId);
                this._rangtipScript.showQiangDZTipOctFunc(true);
            }
            if (turnSeatNo == selfSeatNo && !protTab.isEnd) {
                if (protTab.isTurnJiaoDZ == 1) {
                    this._getControlBtnOctFunc().showJiaoDZBtnOctFunc();
                } else {
                    this._getControlBtnOctFunc().showQiangDZBtnOctFunc();
                }
            }
            for (var _i6 = 0; _i6 < maxPlayer; _i6++) {
                var _playerui9 = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(_i6);

                var leftnum = g_ERDDZGameData.getHandCardCountOctFunc(_i6);
                _playerui9.showUserLeftCardOctFunc(true, leftnum);
                if (_i6 == turnSeatNo && turnSeatNo != selfSeatNo) {
                    _playerui9.showTimeWaitTipOctFunc(true);
                }
                _playerui9.speekNothingOctFunc();
                if (_i6 == _jiaoSeatNo && protTab.isJiaoDZ != null) {
                    if (protTab.isJiaoDZ == 1) {
                        _playerui9.speekJiaoDiZhuOctFunc(protTab.isCall == 1);
                        g_ERDDZGameData.playJiaoDiZhuOctFunc(protTab.userId, protTab.isCall == 1);
                    } else {
                        _playerui9.speekQiangDiZhuOctFunc(protTab.isCall == 1);
                        g_ERDDZGameData.playQiangDiZhuOctFunc(protTab.userId, protTab.isCall == 1);
                    }
                }
            }
            this._rangtipScript.showRangTipOctFunc();
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CBeginOut) {
            g_ERDDZGameData.setBackCardOctFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            var bankSeatNo = roominfo.findUserSeatNoOctFunc(protTab.bankerUserId);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            g_ERDDZGameData.setDiZhuSeatNoOctFunc(bankSeatNo);
            g_ERDDZGameData.addHandCardTabOctFunc(bankSeatNo, protTab.backCardTab);
            g_ERDDZGameData.playGameStartOctFunc();
            this._rangtipScript.showQiangDZTipOctFunc(false);
            this._rangtipScript.showRangTipOctFunc();
            this._backgroundScipt.showThreeBackCardOctFunc(true);
            this._backgroundScipt.recoverBackCardOctFunc();
            if (selfSeatNo == bankSeatNo) {
                this._getControlBtnOctFunc().showOutCardBtnOctFunc(true);
            }

            for (var _i7 = 0; _i7 < maxPlayer; _i7++) {
                var _playerui10 = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(_i7);
                _playerui10.showDiZhuTipOctFunc(false);
                _playerui10.getHandCardOctFunc().drawHandCardOctFunc();
                if (_i7 == bankSeatNo) {
                    _playerui10.showDiZhuTipOctFunc(true);
                    _playerui10.getHandCardOctFunc().moveAddActionCardOctFunc(protTab.backCardTab);
                    if (_i7 == selfSeatNo) {
                        _playerui10.showTimeWaitTipOctFunc(false);
                    } else {
                        _playerui10.showTimeWaitTipOctFunc(true);
                    }
                }
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2COutCard) {
            var outSeatNo = roominfo.findUserSeatNoOctFunc(protTab.userId);
            var _turnSeatNo2 = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            var outtype = GameRuleLogic.getCardTabCardTypeOctFunc(protTab.cardTab);
            if (protTab.newTurn == 1 || Math.random() * 100 < 50) {
                g_ERDDZGameData.playOutCardOctFunc(protTab.userId, protTab.cardTab[0], outtype);
            } else {
                g_ERDDZGameData.playEatCardDaniOctFunc(protTab.userId);
            }
            g_ERDDZGameData.playOutTypeOctFunc(outtype);

            g_ERDDZGameData.setCurOutCardTabOctFunc(protTab.cardTab);
            g_ERDDZGameData.removeCardTabOctFunc(outSeatNo, protTab.cardTab);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            this._backgroundScipt.showThreeBackCardOctFunc(false);
            this._rangtipScript.showQiangDZTipOctFunc(false);
            this._getControlBtnOctFunc().hideAllButtonOctFunc();
            for (var _i8 = 0; _i8 < maxPlayer; _i8++) {
                var _playerui11 = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(_i8);
                if (_i8 == outSeatNo) {
                    _playerui11.getHandCardOctFunc().drawOutCardOctFunc(protTab.cardTab);
                    _playerui11.getHandCardOctFunc().drawHandCardOctFunc();
                } else {
                    _playerui11.getHandCardOctFunc().clearOutCardOctFunc();
                }
                if (_i8 == _turnSeatNo2 && _turnSeatNo2 == selfSeatNo || _i8 == outSeatNo) {
                    _playerui11.showTimeWaitTipOctFunc(false);
                } else {
                    _playerui11.showTimeWaitTipOctFunc(true);
                }
                var _leftnum3 = g_ERDDZGameData.getHandCardCountOctFunc(_i8);
                _playerui11.showUserLeftCardOctFunc(true, _leftnum3);
                if (_leftnum3 <= 3) {
                    _playerui11.showBaoJingTipOctFunc(true);
                }
            }
            if (_turnSeatNo2 == selfSeatNo) {
                this._getControlBtnOctFunc().showOutCardBtnOctFunc(false);
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CBuChu) {
            var theSeatNo = roominfo.findUserSeatNoOctFunc(protTab.userId);
            var _turnSeatNo3 = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            g_ERDDZGameData.setCurOutCardTabOctFunc(null);
            g_ERDDZGameData.playNotOutOctFunc(protTab.userId);
            this._getControlBtnOctFunc().hideAllButtonOctFunc();
            for (var _i9 = 0; _i9 < maxPlayer; _i9++) {
                var _playerui12 = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(_i9);
                if (_i9 == theSeatNo) {
                    _playerui12.speekBuChuOctFunc();
                }
                _playerui12.getHandCardOctFunc().clearOutCardOctFunc();
            }
            if (_turnSeatNo3 == selfSeatNo) {
                this._getControlBtnOctFunc().showOutCardBtnOctFunc(true);
            }
        } else if (assistId == g_ProtDef.AErRenDDZ_S2CTuoGuan) {} else if (assistId == g_ProtDef.AErRenDDZ_S2CGameFinish) {
            g_ERDDZGameData.playGameResultOctFunc(protTab.winUserId == selfUserId);
            this._onShowGameResultOctFunc(protTab);
            //游戏正常结束，调用基类函数
            var gameId = roominfo.getGameIdOctFunc();
            var roomId = roominfo.getRoomIdOctFunc();
            this.onBaseGameFinishOctFunc(gameId, roomId);
        }
    },

    ////////////////////////////////////////////////////////////////////
    _onShowGameResultOctFunc: function _onShowGameResultOctFunc(protTab) {
        this._resetAllUIOctFunc();
        g_ERDDZGameData.setHandCardSortOctFunc(true);
        g_ERDDZGameData.setBackCardOctFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
        this._backgroundScipt.showSmallBackCardOctFunc(true);
        var maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        var roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        var bankerSeatNo = roominfo.findUserSeatNoOctFunc(protTab.bankerUserId);
        var winSeatNo = roominfo.findUserSeatNoOctFunc(protTab.winUserId);
        for (var i = 0; i < maxPlayer; i++) {
            g_ERDDZGameData.setHandCardTabOctFunc(i, protTab.handCardTab[i], true);
            var playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
            playerui.getHandCardOctFunc().drawHandCardOctFunc(null, true);
            playerui.showDiZhuTipOctFunc(false);
            if (bankerSeatNo == i) {
                playerui.showDiZhuTipOctFunc(true);
            }
            if (i == winSeatNo) {
                playerui.getHandCardOctFunc().drawOutCardOctFunc(protTab.lastOutTab);
            }
            roominfo.updateUserGoldOctFunc(i, protTab.winScore[i]);
            playerui.showTotalScoreOctFunc(true, protTab.winScore[i]);
        }
        this._getGameResultOctFunc().showResultOctFunc(true, protTab);
    }
});

cc._RF.pop();