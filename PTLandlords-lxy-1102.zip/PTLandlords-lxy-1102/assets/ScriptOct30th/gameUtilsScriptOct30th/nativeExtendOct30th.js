/**
 * 与原生环境做交互
 */


var Caller = {
    ios : 'AppController',
    android : 'org/cocos2dx/javascript/AppActivity'
};

/**
 * Social========================================
 */

var Social = {};
module.exports = Social;

/*
设置状态栏隐藏0或显示1
*/
Social.setOpenStatusBar = function(openflag){ // 0 or 1
    if (!cc.sys.isNative) {
        cc.log("==err===", openflag);
    } else {
        if(openflag) {
            openflag = 1;
        }else{
            openflag = 0;
        }
        cc.log("====setOpenStatusBar===2132====", cc.sys.os, cc.sys.OS_IOS);
        if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(Caller.ios, 'setOpenStatusBar:openflag', openflag);
        } else {
            jsb.reflection.callStaticMethod(Caller.android, 'setOpenStatusBar', '(I)V', openflag);
        }
    }
};

/*
开启或关闭推送功能
*/
Social.setOpenJPushTuiSong = function(openflag){
    if (!cc.sys.isNative) {
        cc.log("==err===", openflag);
    } else {
        if(openflag) {
            openflag = 1;
        }else{
            openflag = 0;
        }
        if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(Caller.ios, 'setOpenJPushTuiSong:openflag', openflag);
        } else {
            jsb.reflection.callStaticMethod(Caller.android, 'setOpenJPushTuiSong', '(I)V', openflag);
        }
    }
};

/*
显示分享栏
*/
Social.showShareSelectFold = function(openflag){
    if (!cc.sys.isNative) {
        cc.log("==err===", openflag);
    } else {
        if(openflag) {
            openflag = 1;
        }else{
            openflag = 0;
        }
        if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(Caller.ios, 'showShareSelectFold:openflag', openflag);
            return true;
        } else {
            jsb.reflection.callStaticMethod(Caller.android, 'showShareSelectFold', '(I)V',openflag);
        }
    }
    return false;
};

Social.shareLinkWithWX = function(url, title, description, scene) {
    if (!cc.sys.isNative) {
        cc.log(url, title, description, scene);
    } else {
        if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(Caller.ios, 'shareLinkWithWX:title:description:scene:', url, title, description, scene);
        } else {
            jsb.reflection.callStaticMethod(Caller.android, 'shareLinkWithWX', '(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V',
                url, title, description, scene);
        }
    }
};

/**
 * 微信-发送超链接给好友
 * @param {[string]} url   [超链接]
 * @param {[string]} title [标题]
 * @param {[string]} description [描述]
 */
Social.shareLinkToFriendWithWX = function(url, title, description) {
    Social.shareLinkWithWX(url, title, description, 0);
};

/**
 * 微信-发送超链接给朋友圈
 * @param {[string]} url   [超链接]
 * @param {[string]} title [标题]
 * @param {[string]} description [描述]
 */
Social.shareLinkToTimelineWithWX = function(url, title, description) {
    Social.shareLinkWithWX(url, title, description, 1);
};

Social.shareTextToFriendWithWX = function(text) {
    Social.shareTextWithWX(text, 0);
};

Social.shareTextToTimelineWithWX = function(text) {
    Social.shareTextToTimelineWithWX(text, 1);
};

/**
 * 微信分享文字
 * @param  {[string]} text  [内容]
 * @param  {[int]}    scene [场景]
 * @return
 */
Social.shareTextWithWX = function(text, scene) {
    if (!cc.sys.isNative) {
        cc.log(text, scene);
    } else {
        if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(Caller.ios, 'shareTextWithWX:scene:', text, scene);
        } else {
            jsb.reflection.callStaticMethod(Caller.android, 'shareTextWithWX', '(Ljava/lang/String;I)V', text, scene);
        }
    }
};

Social.shareImageToFriendWithWX = function(path, width, height) {
    Social.shareImageWithWX(path,width, height, 0);
};

Social.shareImageToTimelineWithWX = function(path,width, height) {
    Social.shareImageWithWX(path, 1);
};

/**
 * 微信分享照片
 * @param  {[string]} path  [图片路径]
 * @param  {[int]}    scene [场景]
 * @return
 */
Social.shareImageWithWX = function(path, width, height,scene) {
    if (!cc.sys.isNative) {
        cc.log(path, scene);
    } else {
        if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(Caller.ios, 'shareImageWithWX:scene:', path, scene);
        } else {
            jsb.reflection.callStaticMethod(Caller.android, 'shareImageWithWX', '(Ljava/lang/String;III)V', path, width, height,scene);
        }
    }
};

/*
原生分享
*/
Social.shareImageNative = function(title, imagePath, shareUrl) {
    if(cc.sys.os === cc.sys.OS_IOS){
         jsb.reflection.callStaticMethod(Caller.ios, 'shareNative:imagePath:shareUrl:',title,imagePath,shareUrl);
    }
};

/**
 * 通知相册更新
 * @param  {[string]} path  [图片路径]
 * @param  {[int]}    scene [场景]
 * @return
 */
Social.saveToPhoto = function(path) {
    if (!cc.sys.isNative) {
        cc.log(path);
    } else {
        if (cc.sys.os === cc.sys.OS_IOS) {
            jsb.reflection.callStaticMethod(Caller.ios, 'saveToPhoto:scene:', path, 0);
        } else {
            jsb.reflection.callStaticMethod(Caller.android, 'saveToPhoto', '(Ljava/lang/String;)V', path);
        }
    }
};

/**
 * 微信-登录授权
 */
Social.sendAuthToWX = function() {
    if (cc.sys.os === cc.sys.OS_IOS) {
        jsb.reflection.callStaticMethod(Caller.ios, 'sendAuthToWX');
    } else {
        jsb.reflection.callStaticMethod(Caller.android, 'sendAuthToWX', '()V');
    }
};

Social.isWXInstalled = function () {
    if (!cc.sys.isNative) {
        return false;
    }
    
    if (cc.sys.os === cc.sys.OS_IOS) {
        return jsb.reflection.callStaticMethod(Caller.ios, 'isWxInstalled');
    } else {
        return jsb.reflection.callStaticMethod(Caller.android, 'isWxInstalled', '()Z');
    }
}

//===============================================

/**
 * 截屏
 * @param  {[function]} func 回调函数
 * @return
 */
Social.screenShoot = function (func, thumbHeight = 100) {
    if (!cc.sys.isNative) return;
    let dirpath = jsb.fileUtils.getWritablePath() + 'ScreenShoot/';
    if (!jsb.fileUtils.isDirectoryExist(dirpath)) {
        jsb.fileUtils.createDirectory(dirpath);
    }
    
    let name = 'ScreenShoot-' + (new Date()).valueOf() + '.png';
    let filepath = dirpath + name;
    let size = cc.winSize;
    let h = thumbHeight;
    let scale = h / size.height;
    let w = Math.floor(size.width * scale);

    let rt = cc.RenderTexture.create(size.width, size.height, cc.Texture2D.PIXEL_FORMAT_RGBA8888, gl.DEPTH24_STENCIL8_OES);
    cc.director.getScene()._sgNode.addChild(rt);
    rt.setVisible(false);
    rt.begin();
    cc.director.getScene()._sgNode.visit();
    rt.end();
    rt.saveToFile('ScreenShoot/' + name, cc.ImageFormat.PNG, true, function () {
        cc.log('save succ');
        rt.removeFromParent();
        if (func) {
            func(filepath, w, h);
        }
    });
};

