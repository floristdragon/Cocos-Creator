module.exports = cc.Class({
    name: 'HttpRequest',
    properties: {
        onTimeout: null,
        onSuccess: null,
        onError: null,

        timeoutDelay: 0,
        maxRequestCount: 0,

        _requestEntity: null,
    },

    ctor(timeoutDelay = 8000, maxRequestCount = 2) {
        this.timeoutDelay = timeoutDelay;
        this.maxRequestCount = maxRequestCount;
    },

    sendGet(url){
        this._send("GET", url, null);
    },
    sendPost(url, data){
        this._send("POST", url, data);
    },
    _send(method, url, data) {
        if (!this._requestEntity) {
            this._requestEntity = {
                count: 0,
                method: method,
                url: url,
                data: data
            }
        }

        var xhreq = cc.loader.getXMLHttpRequest();
        xhreq.open(method, url, true);
        //不添加超时处理，因为有可能有些网络慢的一定会超时，无法这里添加超时时间
        // xhreq.timeout = this.timeoutDelay;
        // xhreq.ontimeout = () => {
        //     cc.log("====HttpRequest=ontimeout========");
        //     if (!this._requestAgain()) {
        //         if (this.onTimeout) {
        //             this.onTimeout();
        //         }
        //     }
        // };
        //xhreq.setRequestHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
        xhreq.onreadystatechange = () => {
            cc.log("======onreadystatechange========", xhreq, xhreq.responseText);
            if (xhreq.readyState === 4) {
                if (xhreq.status >= 200 && xhreq.status < 300) {
                    if (this.onSuccess) {
                        this.onSuccess(xhreq.response);
                    }
                } else if (xhreq.status >= 400 || xhreq.status === 0) {
                    if (!this._requestAgain()) {
                        if (this.onError) {
                            this.onError();
                        }
                    }
                }
            }
        }
        xhreq.send(data);
    },
    _requestAgain() {
        if (++this._requestEntity.count <= this.maxRequestCount) {
            this._send(this._requestEntity.method, this._requestEntity.url, this._requestEntity.data);
            cc.log('request again:' + this._requestEntity.count);
            return true;
        }
        return false;
    }


});
