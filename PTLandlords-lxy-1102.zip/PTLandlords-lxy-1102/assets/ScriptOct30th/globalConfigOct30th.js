
module.exports = {
    HotFixVersion : "1.2.0",    //热更新版本
    HotFixUrl : "http://39.108.141.178:8080/hotFixOct30th/creator/version.manifest", //热更新生成的version文件
    AppGameID : "ffy20171025",  //以时间为基准，并且附带上个人名字首字母, 表示改游戏独有的游戏ID

    VERSION : "1.0", //游戏版本
    ServerIP : "39.108.232.240",
    ServerPort : 11010,
};  