
//用户进入房间
function lonProtEnterRoomOctFunc(mainId, assistId, protTab){  //进入房间
    cc.log("==============lonProtEnterRoomOctFunc==================", protTab, g_GameScene.onRecvEnterRoomOctFunc);
    let gameId = protTab.info.gameId;
    let roomId = protTab.info.roomId;
    let roominfo = g_RoomManager.newRoomInfoOctFunc(gameId, roomId);
    roominfo.setPackageInfoOctFunc(protTab.info);
    if(g_GameScene.onRecvEnterRoomOctFunc){
        g_GameScene.onRecvEnterRoomOctFunc(gameId, roomId, protTab.userId);
    }
}
function lonProtGameStatusOctFunc(mainId, assistId, protTab){ //场景协议
    if(g_GameScene.onRecvGameStatusOctFunc) {
        g_GameScene.onRecvGameStatusOctFunc(protTab);
    }
}
function lonProtJieSanDeskOctFunc(mainId, assistId, protTab){ //解散
    cc.log("======lonProtJieSanDeskOctFunc==========", mainId, assistId, protTab);
    if(g_GameScene.onRecvJieSanDeskOctFunc) {
        g_GameScene.onRecvJieSanDeskOctFunc(protTab.gameId, protTab.roomId, protTab.userId, protTab.userName, protTab.isauto);
    }
}
function lonProtLeaveDeskOctFunc(mainId, assistId, protTab){ //离开房间
    cc.log("======lonProtLeaveDeskOctFunc==========", mainId, assistId, protTab);
    if(g_GameScene.onRecvLeaveDeskOctFunc) g_GameScene.onRecvLeaveDeskOctFunc(protTab.gameId, protTab.roomId, protTab.userId);
}
function lonProtCheckSignInOctFunc(mainId, assistId, protTab) { //短线检测登陆
    cc.log("========lonProtCheckSignInOctFunc=========")
    g_NetManager.clearSendPack(true);
}
//提示有信息操作





cc.Class({
    extends: require("ui-baseSceneOct30th"),

    properties: {
        _mmgamechatscript : null,
        _mmisInRoomChat : false,

        _mmChatMsgList : [],
        O_chatPrefab: cc.Prefab,

        //////////////////////////////////////////////////////Tips
        O_chatTipsNode : cc.Node,
        O_friendsTipsNode : cc.Node,
        O_mailsTipsNode : cc.Node,
        O_zhanjiTipsNode : cc.Node,
        _chatTips : null,
        _friendsTis : null,
        _mailsTips : null,
        _zhanjiTips : null,
    },

    // use this for initialization
    onLoad: function () {
        this._super(); //调用父类的onLoad
        console.log("=========roomscene=onLoad=============");
        let self = this;
        g_NetManager.onopen = function(){
            console.log("======roomscene===g_NetManager.onopen=============");
            self.showLoadFlowerOctFunc(false);
            //test
            // 检测登陆信息, 短线重连
            let logintab = g_ConfigManager.getLoginAccountOctFunc()
            let accName = logintab[0];
            let accPwd = logintab[1];
            if(!accName || !accPwd){
                self.showPopupWindowOctFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_LOGIN_REDO_LOGIN"), function(flag){
                    self.switchStartSceneOctFunc();
                });
            }else{
                let protTab = {};
                protTab.accName = accName;
                protTab.accPwd = accPwd;
                protTab.platform = 0;
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_C2SCheckSignIN, protTab);
            }
        };
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqEnterDesk, lonProtEnterRoomOctFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CGameStatus, lonProtGameStatusOctFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqJieSanDesk, lonProtJieSanDeskOctFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqLeaveDesk, lonProtLeaveDeskOctFunc);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_S2CCheckSignIN, lonProtCheckSignInOctFunc);
        
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_S2CSendChatMsg, (mid, pid, protTab)=>{
            if(this._mmgamechatscript){
                this._mmgamechatscript.addChatMsgOctFunc(protTab);
                this._mmChatMsgList = [];
            }else{
                this._mmChatMsgList.push(protTab);
            }
        }, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Broadcast,g_ProtDef.ABroadcast_S2CNoticePoint,this._onProtNoticePointOctFunc,this);
    },
    
    //////////////////////////////////////////////////////////////////
    onBaseGameFinishOctFunc(gameId, roomId){
        let roominfo = g_RoomManager.getGameRoomInfoOctFunc(gameId, roomId);
        let toJuShu = roominfo.getCurJuShuOctFunc();
        if(toJuShu>0){
            roominfo.setCurJuShuOctFunc(toJuShu+1);
        }
    },
    //提示有信息操作
    _onProtNoticePointOctFunc(mainId, assistId, protTab){
        cc.log("=====_onProtNoticePointOctFunc========protTab======",protTab);
        var tipsNode = this.node.getChildByName('nodeTips');
        tipsNode.setLocalZOrder(9);
        this._chatTips = protTab[g_ProtDef.MID_Protocol_Broadcast];
        this._friendsTis = protTab[g_ProtDef.MID_Protocol_Friend];
        this._mailsTips = protTab[g_ProtDef.MID_Protocol_MailBox];
        this._zhanjiTips = protTab[g_ProtDef.MID_Protocol_ZhanJi];
        
        if(this._chatTips){
            this.O_chatTipsNode.active = true;
        }else{
            this.O_chatTipsNode.active = false;
        }
        
        if(this._friendsTis) {
            this.O_friendsTipsNode.active = true;
        }else{
            this.O_friendsTipsNode.active = false;
        }
            
        if(this._mailsTips) {
            this.O_mailsTipsNode.active = true;
        }
        else{
            this.O_mailsTipsNode.active = false;
        }
            
        if(this._zhanjiTips) {
            this.O_zhanjiTipsNode.active = true;
        }
        else{
            this.O_zhanjiTipsNode.active = false;
        }
            
    },
    
    onChatPanelBtnEventOctFunc() {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        this.O_chatTipsNode.active = false;
        //聊天协议
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast, g_ProtDef.ABroadcast_C2SReqChatMsg);

        let isfirstinit = false;
        if(!this._mmgamechatscript){
            var talkNode = cc.instantiate(this.O_chatPrefab);
            
            talkNode.parent = this.node;
            if(this._mmisInRoomChat){
                talkNode.setLocalZOrder(150);
            }
            else{
                talkNode.setLocalZOrder(10);
            }
            
            this._mmgamechatscript = talkNode.getComponent('ui-gameChatOct30th');
            isfirstinit = true;
        }
        this._setChatRoomStateOctFunc(this._mmisInRoomChat);
        this._mmgamechatscript.showSiliaoTipsOctFunc(this._chatTips);
        if(this._mmisInRoomChat){
            this._mmgamechatscript.hideSiliaoTipsOctFunc(false);
        }
        this._mmgamechatscript.openChatViewOctFunc();

        if(isfirstinit){
            for(let i=0; i<this._mmChatMsgList.length; i++){
                this._mmgamechatscript.addChatMsgOctFunc(this._mmChatMsgList[i]);
            }
        }
    },
    _setChatRoomStateOctFunc(isRoom){
        this._mmisInRoomChat  = isRoom;
        if(this._mmgamechatscript)this._mmgamechatscript.setRoomChatStateOctFunc(isRoom);
    },
});
