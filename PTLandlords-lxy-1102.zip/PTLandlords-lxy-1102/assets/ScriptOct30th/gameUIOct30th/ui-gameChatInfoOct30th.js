
let utilIconv = require("util-iconvOct30th")
cc.Class({
    extends: cc.Component,

    properties: {
        O_username : cc.Label,
        O_userHead : cc.Node,
        O_userTalk : cc.RichText,

        O_userinfoPrefab : cc.Prefab,

        _userInfo : null,
    },

    // use this for initialization
    setTalkInfoOctFunc : function (userInfo) {
        this._userInfo = userInfo;

        let info = g_UserManager.getSelfUserInfoOctFunc();
        this.O_username.string = userInfo.fromName;
        this.O_userTalk.string = utilIconv.GBKToUTF8(userInfo.content);;

        let headurl = userInfo.fromHeadUrl;
        
        if (headurl && headurl.length > 0) {
            let toSprite = this.O_userHead.getComponent(cc.Sprite);
            let toType = "png";
            if(headurl.indexOf(".jpg")){
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },

    onUserInfoEventOctFunc : function() {
        if(this._userInfo.fromId == g_UserManager.getSelfUserIdOctFunc()){
            return;
        }
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        
        var user = cc.instantiate(this.O_userinfoPrefab);
        var canNode = cc.director.getScene();
        cc.log("======onUserInfoEventOctFunc=========canNode===========",canNode);
        user.parent = canNode.getChildByName('Canvas');
        user.setLocalZOrder(11);

        var userScript = user.getComponent("ui-chatUserInfoOct30th");
        userScript.initOctFunc(this._userInfo.fromId);
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
