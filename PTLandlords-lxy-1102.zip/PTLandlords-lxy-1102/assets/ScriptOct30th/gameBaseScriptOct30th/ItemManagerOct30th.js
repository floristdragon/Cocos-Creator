
module.exports = {
    _allitemtab : {},
    updateItemOctFunc(itemid, count) {
        itemid = Math.floor(parseInt(itemid) / 1000);
        this._allitemtab[itemid] = count;
    },

    getItemOctFunc(itemid){
        itemid = parseInt(itemid);
        return this._allitemtab[itemid];
    },
    getGoldOctFunc(){
        if(!this._allitemtab[1001]) return 0;
        return this._allitemtab[1001];
    },
};