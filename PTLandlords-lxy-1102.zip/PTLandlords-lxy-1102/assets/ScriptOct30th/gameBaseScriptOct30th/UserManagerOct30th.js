

let UserInfo = require("UserInfoOct30th");

let lAllUserIDTab = {};
module.exports = {    
    m_SelfUserInfo : null,
    //isSelfInfo表示是否是客户端自己的用户信息
    newUserOctFunc(userid, username, isSelfInfo){
        let userinfo = new UserInfo(userid, username);
        this._addUserOctFunc(userinfo);
        if(isSelfInfo)this.m_SelfUserInfo = userinfo;
        return userinfo;
    },
    //添加或者重置用户信息表
    _addUserOctFunc(userinfo){
        lAllUserIDTab[userinfo.getUserIdOctFunc()] = userinfo;
    },
    //移除用户信息
    removeUserOctFunc(userid){
        let userinfo = getUserInfoByIdOctFunc(userid);
        lAllUserIDTab[userinfo.getUserIdOctFunc()] = nil;
    },
    clearAllUserOctFunc(){
        lAllUserIDTab = {};
    },
    //通过用户ID获取用户信息
    getUserInfoByIdOctFunc(userid){
        if(!userid || userid<=0) return ;
        return lAllUserIDTab[userid]
    },
     //获取自己的userinfo
    getSelfUserInfoOctFunc(){
        return this.m_SelfUserInfo;
    },
    getSelfUserIdOctFunc(){
        if(this.m_SelfUserInfo) return this.m_SelfUserInfo.getUserIdOctFunc();
    },
    //是否是自己
    IsSelfUserInfoOctFunc(userinfo){
        if(!userinfo) return false;
        return this.m_SelfUserInfo.getUserIdOctFunc()==userinfo.getUserIdOctFunc();
    },
    IsSelfUserIdOctFunc(userid) {
        if(!userid) return false;
        return this.m_SelfUserInfo.getUserIdOctFunc()==userid;
    },
}