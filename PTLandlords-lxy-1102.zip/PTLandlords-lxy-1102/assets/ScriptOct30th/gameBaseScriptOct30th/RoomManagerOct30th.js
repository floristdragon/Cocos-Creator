let RoomInfo = require("RoomInfoOct30th");
let lAllGameRoomTab = {};
module.exports = {
    _curGameId : null,
    _curRoomId : null,
    ///////////////////////////////////////////////////////
    newRoomInfoOctFunc(gameId, roomId){
        let rinfo = new RoomInfo(gameId, roomId);
        if(gameId && roomId){
            return this._addRoomInfoOctFunc(rinfo);
        }
    },
    _addRoomInfoOctFunc(roominfo){
        let gameId = roominfo.getGameIdOctFunc();
        let roomId = roominfo.getRoomIdOctFunc();
        if(!lAllGameRoomTab[gameId])lAllGameRoomTab[gameId] = {};
        lAllGameRoomTab[gameId][roomId] = roominfo;
        return roominfo;
    },
    getGameRoomInfoOctFunc(gameId, roomId){
        if(!gameId) return ;
        if(!roomId) return lAllGameRoomTab[gameId];
        return lAllGameRoomTab[gameId][roomId];
    },
    setCurGameRoomOctFunc(gameId, roomId){
        this._curGameId = gameId;
        this._curRoomId = roomId;
    },
    getCurGameIdOctFunc(){
        return this._curGameId;
    },
    getCurRoomIdOctFunc(){
        return this._curRoomId;
    },
}
