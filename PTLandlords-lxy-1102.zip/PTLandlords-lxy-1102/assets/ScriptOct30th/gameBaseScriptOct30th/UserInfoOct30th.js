

let UserInfoOctFunc = function(userid, username){
    //私有变量定义在构造函数中，每次new时候都会新建
    this._userId = userid;
    this._userName = username;
    this._gold = 0;
    this._diamond = 0;
    this._ipaddr = "";    //ip
    this._isBoy = 1;
    this._headurl = "";
    this._platform = 0;
};
//静态函数, 只能通过类名访问，不能用new的对象访问,最好定义函数来访问
//UserInfoOctFunc.staticParam = "111111"; 
UserInfoOctFunc.prototype = {
    //共享变量或者共享函数定义在prototype中，所有new对象公用
    constructor : UserInfoOctFunc,
    /*
    示例: 
    showStatic(){
        console.log("=====showStatic=======", UserInfoOctFunc.staticParam, this._stparam);
    },
    setStaticValue(val){
        UserInfoOctFunc.staticParam = val;
        this._stparam = val; //若构造函数未明确定义的变量，则新建一个变量
    },
    */
    setUserInfoPackageOctFunc(infotab){
        this._userId = infotab.userId;
        this._userName = infotab.userName;
        this._diamond = infotab.diamond;
        this._gold = infotab.gold;
        this._ipaddr = infotab.addr;
        this._headurl = infotab.headurl;
        this._platform = infotab.platform;
        this._isBoy = infotab.isBoy;
    },
    getUserIdOctFunc(){
        return this._userId;
    },
    getUserNameOctFunc(){
        return this._userName;
    },
    setUserNameOctFunc(name){
        if(!name) name = "";
        this._userName = name;
    },
    setGoldOctFunc(num){
        if(!num) num = 0;
        this._gold = num;
    },
    getGoldOctFunc(){
        return this._gold;
    },
    setDiamondOctFunc(num){
        if(!num) num = 0;
        this._diamond = num;
    },
    getDiamondOctFunc(){
        return this._diamond;
    },
    getIpAddrOctFunc(){
        return this._ipaddr;
    },
    setIpAddrOctFunc(addr){
        this._ipaddr = addr;
    },
    getHeadUrlOctFunc(){
        return this._headurl;
    },
    setHeadUrlOctFunc(headurl){
        this._headurl = headurl;
    },
    getIsBoyOctFunc(){
        return this._isBoy;
    },
    setIsBoyOctFunc(isboy){
        this._isBoy = isboy;
    },
    getLoginPlatformOctFunc(){
        return this._platform;
    },
}

module.exports = UserInfoOctFunc;