
var configManager = require("ConfigManagerOct30th");
var nativeVoice = require("nativeVoiceOct30th");

var CIFMusicKEY = "Music_PLAY";
var CIFEffectKEY = "Effect_PLAY";
var CIFMusicVolKEY = "Music_Volumn";
var CIFEffectVolKEY = "Music_Volumn";
var mAllEffectTab = {};
var lisSoundOpenOctFunc = function(isMusic){
    if(isMusic){
        return configManager.getKeyOctFunc(CIFMusicKEY, "1")=="1";
    }else{
        return configManager.getKeyOctFunc(CIFEffectKEY, "1")=="1";
    }
};
var lsetSoundOpenOctFunc = function(isMusic, isOpen){
    let openflag = "0";
    if(isOpen) openflag = "1";
    if(isMusic){
        configManager.setKeyOctFunc(CIFMusicKEY, openflag);
    }else{
        configManager.setKeyOctFunc(CIFEffectKEY, openflag);
    }
    configManager.flushOctFunc();
};
var lgetSoundVolumnOctFunc = function(isMusic){
    let toVolumn;
    if(isMusic){
        toVolumn = configManager.getKeyOctFunc(CIFMusicVolKEY, "1");
    }else{
        toVolumn = configManager.getKeyOctFunc(CIFEffectVolKEY, "1");
    }
    return parseFloat(toVolumn);
};
var lsetSoundVolumnOctFunc = function(isMusic, volumn){
    if(volumn<0) volumn = 0;
    if(volumn>1.0) volumn = 1.0;
    let toVolumn = ""+volumn;
    if(isMusic){
        configManager.setKeyOctFunc(CIFMusicVolKEY, toVolumn);
    }else{
        configManager.setKeyOctFunc(CIFEffectVolKEY, toVolumn);
    }
    configManager.flushOctFunc();
};
///////////////////////////////////////////////////////////////////////////
//用于操控音效的声音大小
var lsetAllEffectVolumnOctFunc = function(volumn){
    for(let id in mAllEffectTab){
        cc.audioEngine.setVolume(id, volumn);
    }
};
var lplayBeginEffectOctFunc = function(voiceid){
    mAllEffectTab[voiceid] = 0;
};
var lplayFinishEffectOctFunc = function(voiceid){
    mAllEffectTab[voiceid] = null;
};
var exIsOpenMusicBK = true;
var exIsOpenEffectBK = true;
///////////////////////////////////////////////////////////////////////////
module.exports = {
    _musicVolume : 1.0,
    _effectVolume : 1.0,

    _musicPlayID : -1,
    _musicPath : null,


    _voiceRecord : null,
    /////////////////////////////////////////////////////////////////////////
    getVoiceRecordOctFunc(){
        if (!this._voiceRecord){
            this._voiceRecord = nativeVoice;
            this._voiceRecord.initOctFunc(this);
        }
        return this._voiceRecord;
    },
    //加载并播放音乐
    //url以"asset/resources/"为相对路径
    //callback在播放开始回调，参数为路径
    //isMustPlay是否必须播放
    playMusicOctFunc(url, bMustPlay, callback) {
        cc.log("===playMusicOctFunc====111======SoundManagerOct30th===", url);
        if(!url || bMustPlay && !lisSoundOpenOctFunc(true)) return;
        cc.log("====playMusicOctFunc===222======SoundManagerOct30th===", url);
        let self = this;
        cc.loader.loadRes(url, (err, path)=>{
            self.stopMusicOctFunc();
            cc.log("====playMusicOctFunc===333======SoundManagerOct30th===", path);
            if(bMustPlay || lisSoundOpenOctFunc(true)){
                cc.log("====playMusicOctFunc===444======SoundManagerOct30th===", path);
                self._musicPlayID = cc.audioEngine.play(path, true, self._musicVolume);
                //fix engine bug
                cc.audioEngine.setVolume(self._musicPlayID, self._musicVolume);
            }
            if(callback) callback(path);
        });
    },
    //加载并播放音效
    //url以"asset/resources/"为相对路径
    //callback在播放开始回调，参数一为路径，参数二为总时长
    //isMustPlay是否必须播放
    playEffectOctFunc(url, bMustPlay, callback) {
        cc.log("===playEffectOctFunc====111======SoundManagerOct30th===", url);
        if(!url || bMustPlay && !lisSoundOpenOctFunc(false)) return ;
        cc.log("====playEffectOctFunc===222======SoundManagerOct30th===", url);
        let self = this;
        cc.loader.loadRes(url, (err, path)=>{
            let durt = 0;
            cc.log("====playEffectOctFunc===333======SoundManagerOct30th===", path);
            if(bMustPlay || lisSoundOpenOctFunc(false)) {
                cc.log("====playEffectOctFunc===444======SoundManagerOct30th===", path, self._effectVolume);
                if (self._effectVolume > 0) {
                    let audioId = cc.audioEngine.play(path, false, self._effectVolume);
                    lplayBeginEffectOctFunc(audioId);
                    cc.audioEngine.setFinishCallback(audioId, function(){
                        lplayFinishEffectOctFunc(audioId);
                    });
                    durt = cc.audioEngine.getDuration(audioId);
                }
            }
            if(callback) callback(path, durt);
        });
    },
    //0~1.0之间
    setEffectVolumeOctFunc(v) {
        this._effectVolume = v;
        lsetSoundVolumnOctFunc(this._effectVolume);
        lsetAllEffectVolumnOctFunc(this._effectVolume);
    },
    getEffectVolumeOctFunc(){
        return this._effectVolume;
    },

    //0~1.0之间
    setMusicVolumeOctFunc(v) {
        this._musicVolume = v;
        lsetSoundVolumnOctFunc(this._musicVolume);
        if(this._musicPlayID<0) return ;
        cc.audioEngine.setVolume(this._musicPlayID, v);
    },
    getMusicVolumeOctFunc(){
        return this._musicVolume;
    },

    setMusicOpenOctFunc(isOpen){
        if(!isOpen) this.stopMusicOctFunc();
        lsetSoundOpenOctFunc(true, isOpen);
    },
    setEffectOpenOctFunc(isOpen){
        lsetSoundOpenOctFunc(false, isOpen);
    },
    isMusicOpenOctFunc(){
        return lisSoundOpenOctFunc(true);
    },
    isEffectOpenOctFunc(){
        return lisSoundOpenOctFunc(false);
    },
    //打断，唤醒，如用于播放语音时候
    stopAllOctFunc() {
        //备份状态
        exIsOpenMusicBK = lisSoundOpenOctFunc(true);
        exIsOpenEffectBK = lisSoundOpenOctFunc(false);
        cc.log("=======stopAllOctFunc===========", exIsOpenEffectBK, exIsOpenMusicBK);
        lsetSoundOpenOctFunc(false, false);
        lsetSoundOpenOctFunc(true, false);
        cc.audioEngine.pauseAll();
    },

    openAllOctFunc() {
        //恢复状态
        cc.log("=======openAllOctFunc===========", exIsOpenEffectBK, exIsOpenMusicBK);
        lsetSoundOpenOctFunc(false, exIsOpenEffectBK);
        lsetSoundOpenOctFunc(true, exIsOpenMusicBK);
        cc.audioEngine.resumeAll();
    },
    //清空关闭
    clearAllOctFunc() {
        this._musicPlayID = -1;
        cc.audioEngine.stopAll();
    },
    stopMusicOctFunc(){
        if(this._musicPlayID>=0){
            cc.audioEngine.stop(this._musicPlayID);
        }
        this._musicPlayID = -1;
    },
    preload(url, callback){
        cc.audioEngine.preload(path, callback);
    },
    /////////////////////////////////////
};