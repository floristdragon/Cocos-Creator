//var utilbase64 = require("utilBase64Oct30th");
var globalConfig = require("globalConfigOct30th");

var exSecretkey= 'open_fwclient'; // 加密密钥
var exConfigKey = "ConfigManager_local";

var exLocalConfPath = "";
var exConfigDataTab = null;
var fwriteStorageTabOctFunc = function(datatab){
    if(!datatab) return ;
    let stringdata = JSON.stringify(datatab);
    //js.fileUtils().writeStringToFile(stringdata, exLocalConfPath);
    var encrypted = stringdata;//utilEncryptJS.encryptWithAES(stringdata,exSecretkey,256);
    cc.sys.localStorage.setItem(exConfigKey, encrypted);
};
var freadStorageTabOctFunc = function(){
    // exLocalConfPath = jsb.fileUtils().getWritablePath() + "userconfig";
    // let datastr = jsb.fileUtils().getStringFromFile(exLocalConfPath);
    let datastr = cc.sys.localStorage.getItem(exConfigKey);
    if(datastr && datastr!=""){
        //return JSON.parse(utilEncryptJS.decryptWithAES(cipherText,exSecretkey));
        return JSON.parse(datastr);
    }
    return {};
};
module.exports = {
    ////////////////////////////////////////////////////
    //用户读写本地数据
    _checkLoadConfigOctFunc(){
        if(!exConfigDataTab){
            exConfigDataTab = freadStorageTabOctFunc();
        }
    },
    getGlobalConfigOctFunc(key) {
        return globalConfig[key];
    },
    getHotfixVersionOctFunc(){
        let cifVersion = this.getKeyOctFunc("CIFHotFixVersion", "0");
        let curVersion = this.getGlobalConfigOctFunc("HotFixVersion");
        let toVersion;
        do{
            if(!cifVersion) {
                toVersion = curVersion; //如果没有写配置，则用代码里面的配置
                break;
            }
            if(curVersion>cifVersion) {
                toVersion = curVersion; //如果代码里面配置比本地配置高，则用高版本
                break;
            }
            toVersion = cifVersion; //否则用本地配置版本
        }while(0);
        return toVersion;
    },
    setHotfixVersionOctFunc(version){
        this.setKeyOctFunc("CIFHotFixVersion", version+"");
        this.flushOctFunc();
    },
    getKeyOctFunc(key, defaultData){
        this._checkLoadConfigOctFunc();
        if(!exConfigDataTab[key]){
            exConfigDataTab[key] = defaultData;
        }
        return exConfigDataTab[key];
    },
    
    setKeyOctFunc(key, data, autoflush){
        console.log("======g_ConfigManager==setKeyOctFunc===========", key, data);
        this._checkLoadConfigOctFunc();
        exConfigDataTab[key] = data;
        if(autoflush){
            this.flushOctFunc();
        }
    },
    
    flushOctFunc(){
        fwriteStorageTabOctFunc(exConfigDataTab);
    },
    /////////////////////////////////////////////////////////////////////////
    //登陆相关
    setLoginAccountOctFunc(account, pwd){
        this.setKeyOctFunc("TLOGINACCOUNT", account);
        this.setKeyOctFunc("TLOGINPWD", pwd);
        this.flushOctFunc();
    },
    getLoginAccountOctFunc(){
        let loginAcc = this.getKeyOctFunc("TLOGINACCOUNT", "")
        let loginPwd = this.getKeyOctFunc("TLOGINPWD", "")
        return [loginAcc, loginPwd];
    },
    setIsAlreadyLoginOctFunc(flag){
        this.m_bIsAlreadyLogin = flag;
    },
    getIsAlreadyLoginOctFunc(){
        return this.m_bIsAlreadyLogin;
    },
    checkIsCanLoginLobbyOctFunc(maxWait) {
        if(!this.m_iLoginLobbyFlag){
            this.m_iLoginLobbyFlag = 0;
        }
        this.m_iLoginLobbyFlag = this.m_iLoginLobbyFlag + 1;
        return this.m_iLoginLobbyFlag==maxWait;
    },
    resetIsCanLoginLobbyOctFunc(){
        this.m_iLoginLobbyFlag = 0;
    },
}
