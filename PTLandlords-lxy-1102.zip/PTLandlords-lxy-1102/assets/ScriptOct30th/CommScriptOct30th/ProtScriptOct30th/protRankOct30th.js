
//排行榜
let prottab = {}
module.exports = prottab

prottab.ARank_C2SReqRankList = 10  //请求排行榜

prottab.ARank_S2CReqRankList = 100  //请求排行榜

////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
/*
local C2SReqRankList = {
		
}
local S2CReqRankList = {
	list = {
		//内容如：{rank=1, userId = 0, userName="", headurl="", winNum = 0,},
		//rank排名，winNum本周胜局
	}
	rank = 0, //自己的排名
	winNum = 0, //自己的本周胜局
}
*/