cc.Class({
    extends: cc.Component,

    properties: {
        messageLabel : cc.Label,
    },

    // use this for initialization
    initOctFunc: function (message) {
        if(message){
            this.messageLabel.string = message;
        }
    },

    onCloseClickOctFunc : function () {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        
        this.node.active = false;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
