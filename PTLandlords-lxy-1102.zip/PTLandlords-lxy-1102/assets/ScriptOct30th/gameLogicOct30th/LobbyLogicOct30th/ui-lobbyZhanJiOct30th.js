
cc.Class({
    extends: cc.Component,

    properties: {
        O_zhanjilineprefab : cc.Prefab,
        O_scrollviewnode : cc.Node,
        O_emptytip : cc.Node,
        //-----
        O_zjdetailnode : cc.Node,
        O_zjdetailscrollview : cc.Node,
        O_zjdetailprefab : cc.Prefab,
        ////////////////////////////////////////////////////////
        _zhanjiAllList : [],
        _zhanjiscollscript : null,
        _zjdetailscrollscript : null,
    },

    // use this for initialization
    onLoad: function () {
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_ZhanJi, null, this._onProtGameMessageOctFunc, this);

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ZhanJi, g_ProtDef.AZhanJi_C2SQuery);

        this._zhanjiscollscript = this.O_scrollviewnode.getComponent("ui-scrollViewOct30th");
        this._zjdetailscrollscript = this.O_zjdetailscrollview.getComponent("ui-scrollViewOct30th");
    },

    showUiOctFunc(bVisible){
        this.node.active = bVisible;
        this.O_zjdetailnode.active = false;
    },  

    _onProtGameMessageOctFunc(mainId, assistId, protTab){
        if(assistId==g_ProtDef.AZhanJi_S2CQuery){
            cc.log("=====zhanji====AZhanJi_S2CQuery====", protTab)
            for(let i in protTab){
                this._zhanjiAllList[i] = protTab[i];
            }
            this._updateAllListOctFunc();
        }
    },
    _updateAllListOctFunc(){
        this._zhanjiscollscript.clearAllNodeOctFunc();
        this.O_emptytip.active = true;
        for(let zjId in this._zhanjiAllList){
            let tozjidtab = zjId.split("_");
            cc.log("=======_updateAllListOctFunc=tozjidtab=====11========", zjId, tozjidtab);
            if(!tozjidtab || !tozjidtab[0]){
                this._zhanjiAllList[zjId] = null;
                continue;
            }
            let gameId = tozjidtab[0];
            let roomId = tozjidtab[1];
            let jushu  = tozjidtab[2];
            let tozjdata = this._zhanjiAllList[zjId];

            let zhanjinode = cc.instantiate(this.O_zhanjilineprefab);
            cc.log("============_updateAllListOctFunc=tozjidtab=======22=====", zhanjinode, tozjdata);
            zhanjinode.getComponent("ui-lobbyZhanJiLineOct30th").setDataOctFunc(gameId, roomId, jushu, tozjdata.stime, tozjdata.userlist);
            zhanjinode.off("zhanjiline-event");
            zhanjinode.on("zhanjiline-event", (event)=>{
                cc.log("=======_updateAllListOctFunc=tozjidtab=====33====", event, event.detail);
                this._showDetailNodeOctFunc(true, event.detail);
            }, this);
            this._zhanjiscollscript.addScrollNodeOctFunc(zhanjinode, null, tozjdata.stime);
            this.O_emptytip.active = false;
        }
        //按时间排序
        this._zhanjiscollscript.sortAllNodeListOctFunc((a, b)=>{
            if(a>b) return -1;
            return 1;
        });
    },

    onCloseBtnEventOctFunc(){
        this.node.active = false;
    },

    _showDetailNodeOctFunc(bVisible, userlist){
        cc.log("==========_showDetailNodeOctFunc===11=====", bVisible, userlist);
        this.O_zjdetailnode.active = bVisible;
        if(!bVisible) return ;
        this._zjdetailscrollscript.clearAllNodeOctFunc();
        let selfUserId = g_UserManager.getSelfUserIdOctFunc();
        for(let i=0; i<userlist.length; i++){
            let udata = userlist[i];
            cc.log("==========_showDetailNodeOctFunc===22=====", udata);
            let detailline = cc.instantiate(this.O_zjdetailprefab);
            let dtlinescript = detailline.getComponent("ui-lobbyZhanJidTailOct30th");
            dtlinescript.setDetailOctFunc(udata.userName, udata.userId, udata.score);
            let attdata = udata.userId;
            if(attdata==selfUserId)attdata *= 2;
            this._zjdetailscrollscript.addScrollNodeOctFunc(detailline, null, attdata);
        }
        this._zjdetailscrollscript.sortAllNodeListOctFunc((a, b)=>{
            if(a>b) return -1;
            return 1;
        });
    },
    onCloseDetailBtnEventOctFunc(){
        cc.log("======onCloseDetailBtnEventOctFunc============");
        this._showDetailNodeOctFunc(false);
    },
});
