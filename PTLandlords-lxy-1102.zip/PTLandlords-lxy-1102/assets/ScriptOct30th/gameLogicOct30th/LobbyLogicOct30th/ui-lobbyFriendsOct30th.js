cc.Class({
    extends: cc.Component,

    properties: {

        O_friendsLayer : cc.Node,
        O_addFriendsLayer : cc.Node,
        O_applyLayer : cc.Node,
        O_addFriendContent : cc.Node,
        O_manLayer : cc.Node,
        O_shenqingTipsNode:cc.Node,


        //玩家本人信息
        O_headImg : cc.Sprite,
        O_userName : cc.Label,
        O_userID : cc.Label,

        O_searchEditbox : cc.EditBox,

        O_curFriendsCount : cc.Label,
        O_curApplyNum : cc.Label,
        O_limitFriendNum : cc.Label,

        O_friendsLinePrefab : cc.Prefab,
        O_addFriendsLinePrefab : cc.Prefab,
        O_otherApplyFriendPrefab:cc.Prefab,

        O_roomToggle : cc.Toggle,

        _isOnline : null,

        _friendLayerScorllScript : null,
        _applyLayerScorllScript : null,

        _ftabList : [],
        _reqtabList : [],
    },

    // use this for initialization
    onLoad: function () {
        //接收协议显示好友人数
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Friend,g_ProtDef.AFriend_S2CQueryFriend,this._onProtQueryAllFriendEventOctFunc,this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Friend,g_ProtDef.AFriend_S2CQueryUser,this._onProtQueryUserEventOctFunc,this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Friend,g_ProtDef.AFriend_S2CDeleteFriend,this._onProtDeleteFriendOctFunc,this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Friend,g_ProtDef.AFriend_S2CLoginStatus,this._onProtLoginStatusOctFunc,this);

        this.O_curFriendsCount.string = 0;
        this.O_curApplyNum.string = 0;
        this.O_limitFriendNum.string = 0; 

        let userInfo = g_UserManager.getSelfUserInfoOctFunc();
        this.O_userID.string = userInfo.getUserIdOctFunc();
        this.O_userName.string = userInfo.getUserNameOctFunc();
        let headImgUrl = userInfo.getHeadUrlOctFunc();

        let headImg = this.O_headImg.spriteFrame;
        if(headImgUrl && headImgUrl.length > 0) {
            let imgType = "png";
            if(headImgUrl.indexOf(".jpg")) {
                imgType = "jpg";
            }

            cc.loader.load({ type : imgType,url : headImgUrl},(err,texture) => {
                if(!err) {
                    headImg = new cc.SpriteFrame(texture);
                }
            });
        }

        this._friendLayerScorllScript = this.O_friendsLayer.getChildByName('scrollView').getComponent('ui-scrollViewOct30th');
        cc.log("==========this._friendLayerScorllScript========",this._friendLayerScorllScript);
        this._friendLayerScorllScript._setHeightInterOctFunc(10);
        this._applyLayerScorllScript = this.O_applyLayer.getChildByName('scrollView').getComponent('ui-scrollViewOct30th');
        this._applyLayerScorllScript._setHeightInterOctFunc(10);
    },

    openFriendsViewOctFunc() {
        this.node.active = true;
        if(this.O_roomToggle.isChecked){
            this.O_shenqingTipsNode.active = false;
        }
    },

    onToggleFriendsEventOctFunc : function (event) {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        
        this.O_friendsLayer.active = true;
        this.O_addFriendsLayer.active = false;
        this.O_applyLayer.active = false;

        this.O_addFriendContent.removeAllChildren();
    },

    onToggleAddFriendEventOctFunc : function (event) {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        this.O_friendsLayer.active = false;
        this.O_addFriendsLayer.active = true;
        this.O_applyLayer.active = false;

        this.O_addFriendContent.removeAllChildren();
    },

    onToggleApplyEventOctFunc : function(event) {
        this.O_shenqingTipsNode.active = false;
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        //别人申请成为玩家本人的好友

        this.O_friendsLayer.active = false;
        this.O_addFriendsLayer.active = false;
        this.O_applyLayer.active = true;

        this.O_addFriendContent.removeAllChildren();
        if(this.O_curApplyNum.string == 0) {
            this.O_manLayer.active = true;
            this._applyLayerScorllScript.clearAllNodeOctFunc();
        }
    },
    _onFriendButtonEventOctFunc(detail){
        cc.log("====_onFriendButtonEventOctFunc======", detail);
        this._applyLayerScorllScript.rmScrollNodeOctFunc(detail.node);
        this.O_curApplyNum.string = this._applyLayerScorllScript.getListSizeOctFunc();

        let toReqList =[];
        if(detail.flag == 2) {
            for(let i = 0;i < this._reqtabList.length;i++){

                if(detail.userId != this._reqtabList[i].userId){
                    toReqList.push(this._reqtabList[i]);
                }
            }
            this._reqtabList = toReqList;
        }
    },
    ///////////////////////////////////////////////////////////////////////
    _onProtLoginStatusOctFunc:function (mainId, assistId, protTab){

        //this._isOnline = protTab.online;
    },

    _onProtQueryAllFriendEventOctFunc : function(mainId, assistId, protTab){
        if(protTab.limit){
            this.O_limitFriendNum.string = protTab.limit;            
        }
        
        //this.O_content.removeAllChildren();
        cc.log("====ui-lobbyFriendsOct30th.js=======_onProtQueryAllFriendEventOctFunc======protTab======",protTab);
        //获取玩家好友数量
        //初始化好友列表
        if(protTab.ftab && protTab.ftab.length > 0){
            for(let i = 0;i < protTab.ftab.length ;i++){
                let isalreadyin = false;
                for(let j = 0;j < this._ftabList.length;j++){
                    if(protTab.ftab[i].userId == this._ftabList[j].userId){
                        isalreadyin = true;
                        break;
                    }
                }
                if(!isalreadyin) this._ftabList.push(protTab.ftab[i])
            }
        }
        //初始化申请列表
        //this._reqtabList = [];
        if(protTab.reqtab && protTab.reqtab.length > 0) {
            for(let i = 0;i < protTab.reqtab.length ;i++){
                let isalreadyin = false;
                for(let j = 0;j < this._reqtabList.length;j++){
                    if(protTab.reqtab[i].userId == this._reqtabList[j].userId){
                        isalreadyin = true;
                        break;
                    }
                }

                if(!isalreadyin) this._reqtabList.push(protTab.reqtab[i])
            }
        }    
        //删掉在好友列表里面存在得好友
        let toReqList =[];
        for(let i=0; i<this._reqtabList.length; i++){
            let isalreadyin = false;
            for(let j = 0;j < this._ftabList.length;j++){
                if(this._ftabList[j].userId == this._reqtabList[i].userId){
                    isalreadyin = true;
                    break;
                }
            }
            if(!isalreadyin) toReqList.push(this._reqtabList[i]);
        }
        this._reqtabList = toReqList;
        cc.log("=========this is friendList=========",this._ftabList, this._reqtabList);
        //初始化UI
        this._friendLayerScorllScript.clearAllNodeOctFunc();
        for(let i=0;i<this._ftabList.length;i++){
            let fdata = this._ftabList[i];

            let headUrl = fdata.headurl;
            let name = fdata.userName;
            let id = fdata.userId;
            let onORoutline = fdata.online;
            
            let newFriend = cc.instantiate(this.O_friendsLinePrefab);
            newFriend.off("friend-btnMusicOct30th");
            newFriend.on("friend-btnMusicOct30th", (event)=>{
                this._onFriendButtonEventOctFunc(event.detail);
            }, this);
            let newFriendScript = newFriend.getComponent('ui-lobbyFriendsLineOct30th');

            newFriendScript.initOctFunc(headUrl,name,id,onORoutline);
            let nodedata = {};
            nodedata.userId = fdata.userId;
            nodedata.online = fdata.online;
            if(!nodedata.online) nodedata.online = 0;
            this._friendLayerScorllScript.addScrollNodeOctFunc(newFriend, null,nodedata);
        }
        this._friendLayerScorllScript.sortAllNodeListOctFunc(function(a, b){
            if(a.online>b.online) return -1; //表示要交换
            return 1; //不用交换
        });
        this._applyLayerScorllScript.setMoveAddNodeOctFunc(true);
        this._applyLayerScorllScript.clearAllNodeOctFunc();
        for(let i=0;i<this._reqtabList.length;i++){
            let toReqData = this._reqtabList[i];

            let headUrl = toReqData.headurl;
            let name = toReqData.userName;
            let id = toReqData.userId;
            let onORoutline = toReqData.online;
            
            let newFriend = cc.instantiate(this.O_otherApplyFriendPrefab);
            newFriend.off("friend-btnMusicOct30th");
            newFriend.on("friend-btnMusicOct30th", (event)=>{
                this._onFriendButtonEventOctFunc(event.detail);
            }, this);
            let newFriendScript = newFriend.getComponent('ui-lobbyFriendsLineOct30th');

            newFriendScript.initOctFunc(headUrl,name,id,onORoutline);
            this._applyLayerScorllScript.addScrollNodeOctFunc(newFriend, null,onORoutline);
        }
        cc.log("======_onProtQueryAllFriendEventOctFunc==O_curApplyNum==========", this.O_curApplyNum);
        this.O_manLayer.active = false;
        this.O_curFriendsCount.string = this._friendLayerScorllScript.getListSizeOctFunc();
        this.O_curApplyNum.string = this._applyLayerScorllScript.getListSizeOctFunc();
        if(this.O_curApplyNum.string == 0) {
            this.O_manLayer.active = true;
        }   

    },
    _onProtQueryUserEventOctFunc : function(mainId, assistId, protTab){
        cc.log("====ui-lobbyFriendsOct30th.js=======_onProtQueryUserEventOctFunc======protTab======",protTab);
        //获取好友信息
        let friends = protTab.info;

        let headUrl = friends.headurl;
        let name = friends.userName;
        let id = friends.userId;
        let onORoutline = friends.online;
        
        let newFriend = cc.instantiate(this.O_addFriendsLinePrefab);
        newFriend.setPositionX(0);
        newFriend.parent = this.O_addFriendContent;
        let newFriendScript = newFriend.getComponent('ui-lobbyFriendsLineOct30th');

        newFriendScript.initOctFunc(headUrl,name,id,onORoutline);
    },

    _onProtDeleteFriendOctFunc : function(mainId, assistId, protTab) {
        
        let userid = protTab.userId;

        this._friendLayerScorllScript.rmScrollNodeByOctFunc((object) => {
            if(object.userId == userid){
                return 1;
            }
            else
                return 0;
        });
        let toflist = [];
        for(let i = 0;i < this._ftabList.length;i++){
            if(this._ftabList[i].userId != userid){
                toflist.push(this._ftabList[i]);
            }
        }
        this._ftabList = toflist;

        this.O_curFriendsCount.string -= 1;
    },

    onSearchEventOctFunc : function() {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        //点击搜索时发送协议
        let searchId = this.O_searchEditbox.string;
        if(!searchId)return;
        let idtoProt = {};
        idtoProt.userId = searchId;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Friend,g_ProtDef.AFriend_C2SQueryUser,idtoProt);
        cc.log("========onSearchEventOctFunc=======idtoProt======",idtoProt);
        this.O_searchEditbox.string = ""

        this.O_addFriendContent.removeAllChildren();

    },

    showApplyTipsOctFunc : function(flag){
        if(flag == 1){
            this.O_shenqingTipsNode.active = true;
        }
    },

    onCloseClickOctFunc : function () {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        
        this.node.active =false;
        this.O_addFriendContent.removeAllChildren();

        this._applyLayerScorllScript.clearAllNodeOctFunc();
        this._friendLayerScorllScript.clearAllNodeOctFunc();

        this._ftabList = [];
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
