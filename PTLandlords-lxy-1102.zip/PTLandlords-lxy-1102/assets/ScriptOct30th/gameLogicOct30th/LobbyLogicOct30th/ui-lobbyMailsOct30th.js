
let utilIconv = require("util-iconvOct30th")
cc.Class({
    extends: cc.Component,

    properties: {
        O_mailprefab : cc.Prefab,

        O_scrollview : cc.Node,
        
        O_maildetailnode : cc.Node,
        O_labelcontent : cc.Label,
        O_emptytip : cc.Node,

        _scrollscript : null,
        _detailnode : null,
    },
    onLoad(){
        this.O_maildetailnode.active = false;
        this._scrollscript = this.O_scrollview.getComponent("ui-scrollViewOct30th");
        this._scrollscript._setHeightInterOctFunc(0);
        this.__checkEmptyTipOctFunc();
    },

    _showBoxOctFunc(bVisible, bClear){
        cc.log("=========setMailBox===========");
        this.node.active = bVisible;
        if(bClear) this._scrollscript.clearAllNodeOctFunc();
    },
    setBoxMailOctFunc(maillist){
        if(!maillist) return ;
        for(let i=0; i<maillist.length; i++){
            let maildata = maillist[i];
            if(!maildata) continue;
            //let iconvlite = require('iconv-lite');
            //let toData = iconvlite.decode(toTempArray, 'UTF8');
            maildata.title = utilIconv.GBKToUTF8(maildata.title);
            maildata.content = utilIconv.GBKToUTF8(maildata.content);
            let mailnode = cc.instantiate(this.O_mailprefab);
            cc.log("======setBoxMailOctFunc===title===", maildata.title);
            mailnode.getComponent("ui-lobbyMailLineOct30th").initOctFunc(maildata.mailId, maildata.title, maildata.stime);
            mailnode.on("mailbox-readmail", ()=>{
                this.O_labelcontent.string = maildata.content;
                this.O_maildetailnode.active = true;
                this._detailnode = mailnode;
            }, this);
            this._scrollscript.addScrollNodeOctFunc(mailnode, null, maildata.stime);
        }
        this._scrollscript.sortAllNodeListOctFunc((a, b)=>{
            if(a>b) return -1;
            return 1;
        });
        this.__checkEmptyTipOctFunc();
    },

    onCloseDetailClickOctFunc(node) {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        cc.log("========onCloseDetailClickOctFunc=========", node);
        this.O_maildetailnode.active = false;
        this._scrollscript.rmScrollNodeOctFunc(this._detailnode);
        this.__checkEmptyTipOctFunc();
    },
    onCloseOctFunc(){
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        this._showBoxOctFunc(false);
    },
    
    __checkEmptyTipOctFunc(){
        if(this._scrollscript.getListSizeOctFunc()<=0){
            this.O_emptytip.active = true;
        }else{
            this.O_emptytip.active = false;            
        }
    },
});
