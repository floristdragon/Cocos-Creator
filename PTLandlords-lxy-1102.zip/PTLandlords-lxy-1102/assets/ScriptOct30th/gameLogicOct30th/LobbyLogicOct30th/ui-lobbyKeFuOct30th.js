cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // use this for initialization
    onLoad: function () {

    },

    onCloseClickOctFunc : function () {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        
        this.node.active = false;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
