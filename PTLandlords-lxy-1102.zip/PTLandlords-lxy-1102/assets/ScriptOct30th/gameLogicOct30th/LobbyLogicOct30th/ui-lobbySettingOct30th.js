cc.Class({
    extends: cc.Component,

    properties: {

        O_musicToggle : cc.Toggle,
        O_effectToggle :cc.Toggle,
        
        _isCheckToggleClick : true,
    },
    onLoad(){
        this._isCheckToggleClick = false;
        if(g_SoundManager.isMusicOpenOctFunc()){
            cc.log("=======onLoad===11================");
            this.O_musicToggle.check();
        }else{
            cc.log("=======onLoad===22================");
            this.O_musicToggle.uncheck();
        }
        if(g_SoundManager.isEffectOpenOctFunc()){
            cc.log("=======onLoad===33================");
            this.O_effectToggle.check();
        }else{
            cc.log("=======onLoad===44================");
            this.O_effectToggle.uncheck();
        }
        this._isCheckToggleClick = true;
    },

    showSettingNodeOctFunc : function() {
        this.node.active = true;
    },

    onMusicToggleClickOctFunc(toggle) {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        cc.log("================onMusicToggleClickOctFunc======================", toggle, toggle.isChecked)
        if(!this._isCheckToggleClick) return ;
        if (toggle.isChecked) {
            g_SoundManager.setMusicOpenOctFunc(true);
            g_SoundManager.playMusicOctFunc("DdzResOct30th/soundResOct30th/musicResOct30th/bg_happyOct30th");
        }
        else {
            g_SoundManager.setMusicOpenOctFunc(false);
        }
    },

    onEffectToggleClickOctFunc(toggle) {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        cc.log("==========================onEffectClickOctFunc===============", toggle, toggle.isChecked);
        if(!this._isCheckToggleClick) return ;
        if (toggle.isChecked) {
            g_SoundManager.setEffectOpenOctFunc(true);
        }
        else {
            g_SoundManager.setEffectOpenOctFunc(false);
        }
    },

    onCloseClickOctFunc() {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        
        this.node.active = false;
    },
});
