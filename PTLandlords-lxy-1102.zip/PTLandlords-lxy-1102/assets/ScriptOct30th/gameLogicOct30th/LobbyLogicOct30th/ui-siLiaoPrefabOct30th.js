cc.Class({
    extends: cc.Component,

    properties: {
        O_editBox : cc.EditBox,
        O_chatLinePrefab : cc.Prefab,
        O_toUserId : cc.Label,

        _toUserId : 0,
    
    },

    onCloseBtnOctFunc : function () {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        this.node.active = false;
    },

    initOctFunc : function (toUserid) {
        //
        //this._scrollScript = this.scrollViewNode.getComponent('ui-scrollViewOct30th');
        this.O_toUserId.string = toUserid;
        this._toUserId = toUserid;
    },

    onSendEventOctFunc : function () {
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        if(g_GameScene.rejectClickEventOctFunc(3)) return ;
        var userstr = this.O_editBox.string;
        this.O_editBox.string = "";

        //发送协议
        let toChattab = {};
        toChattab.toUserId = this._toUserId;
        toChattab.ctype = 4;
        toChattab.content = userstr;
        toChattab.msgtype = 3;

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Broadcast,g_ProtDef.ABroadcast_C2SSendChatMsg,toChattab);

        cc.log("========onSendEventOctFunc=========toChattab==========",toChattab);
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
