
require("includeOct30th");
let gameconfig = require("gameConfigOct30th");
let GameRuleConfig =  require("DdzRuleConfigOct30th");

//在两个数之间随机一个整数
var MathRandomOctFunc = function(min, max){
    if(min>max) return min;
    let to = Math.random() * (max-min) + min;
    let toi = Math.floor(to);
    if(to < toi + 0.5) return toi;
    return toi + 1;
};  
window.g_CLDDZGameData = {
    _gameId : 0,
    _roomId : 0,

    _playerUIArray : [],
    _seatToUIArray : [],

    _selfSeatNo : 0,

    _handCardTab : [],
    _outCardTab : [],
    _tuoguanTab : [],
    _curOutCardTab : [],
    _backCardTab : [],
    _dizhuSeatNo : -1,

    _mingpaiCardId : 0,
    _qiangRangNum : 0,
    _ishandcardSort : false,
    _isrequestStatus : false,
    //------------------------------------
    //------------------------------------
    initOctFunc(gameId, roomId, selfSeatNo){
        this._gameId = gameId;
        this._roomId = roomId;
        this._selfSeatNo = selfSeatNo;
        this._resetInitOctFunc();
    },
    _resetInitOctFunc(){
        this._handCardTab = [];
        this._outCardTab = [];
        this._tuoguanTab = [];
        this._curOutCardTab = [];
        this._backCardTab = [];
        this._dizhuSeatNo = -1;

        this._mingpaiCardId = 0;
        this._qiangRangNum = 0;
        this._ishandcardSort = false;
        this._isrequestStatus = false;
    },
    setPlayerUIOctFunc(playerui, index, seatNo){
        this._playerUIArray[index] = playerui;
        this._seatToUIArray[seatNo] = index;
    },
    getPlayerUIBySeatNoOctFunc(seatNo){
        let index = this._seatToUIArray[seatNo];
        return this._playerUIArray[index];
    },
    getPlayerUIByUserIdOctFunc(userId){
        let roominfo = this.getRoomInfoOctFunc();
        let seatNo = roominfo.findUserSeatNoOctFunc(userId);
        return this.getPlayerUIBySeatNoOctFunc(seatNo);
    },
    ///////////////////////////////////////////////////
    getSelfSeatNoOctFunc(){
        return this._selfSeatNo;
    },
    getNextSeatNoOctFunc(curSeatNo){
        if(curSeatNo==null) curSeatNo = this._selfSeatNo;
        let maxPeople = this.getMaxPlayerOctFunc();
        curSeatNo = curSeatNo + 1;
        if(curSeatNo>=maxPeople)curSeatNo = 0; //下标从0开始
        return curSeatNo;
    },
    getLastSeatNoOctFunc(curSeatNo){
        if(curSeatNo==null) curSeatNo = this._selfSeatNo;
        let maxPeople = this.getMaxPlayerOctFunc();
        curSeatNo = curSeatNo - 1;
        if(curSeatNo<0)curSeatNo = maxPeople;
        return curSeatNo;
    },
    setDiZhuSeatNoOctFunc(seatNo){
        this._dizhuSeatNo = seatNo;
    },
    getDiZhuSeatNoOctFunc(){
        return this._dizhuSeatNo;
    },
    ////////////////////////////////////////////////////
    getRoomInfoOctFunc(){
        return g_RoomManager.getGameRoomInfoOctFunc(this._gameId, this._roomId);
    },
    getGameIdOctFunc(){
        return this._gameId;
    },
    getRoomIdOctFunc(){
        return this._roomId;
    },
    //------------------------------------
    getMaxPlayerOctFunc(){
        if(!this._gameId) this._gameId = g_ProtDef.MID_Protocol_ClassicDDZ;
        console.log("====getMaxPlayerOctFunc===========", gameconfig, this._gameId, g_ProtDef.MID_Protocol_ClassicDDZ);
        return gameconfig[this._gameId].maxPlayer;
    },
    //------------------------------------
    setHandCardTabOctFunc(seatNo, cardtab, isCopy){
        let toTab = cardtab;
        if(isCopy){
            toTab = [];
            for(let i=0; i<cardtab.length; i++){
                toTab[i] = cardtab[i];
            }
        }
        this._handCardTab[seatNo] = toTab;
        this.setHandCardSortOctFunc(this._ishandcardSort);
    },
    setHandCardSortOctFunc(isSort){
        this._ishandcardSort = isSort;
        if(this._ishandcardSort){
            let sortOctFunc = (a, b)=>{
                if(a>b) return -1;
                return 1;
            };
            for(let i=0; i<this.getMaxPlayerOctFunc();i++){
                if(this._handCardTab[i]){
                    this._handCardTab[i].sort(sortOctFunc);
                }
            }
        }
    },
    addHandCardTabOctFunc(seatNo, cardtab){
        if(!this._handCardTab[seatNo])this._handCardTab[seatNo] = {};
        for(let i=0; i<cardtab.length; i++){
            this._handCardTab[seatNo].push(cardtab[i]);
        }
        this.setHandCardSortOctFunc(this._ishandcardSort);
    },
    getHandCardTabOctFunc(seatNo, isCopy){
        let toTab = [];
        if(isCopy){
            if(this._handCardTab[seatNo]){
                for(let i=0; i<this._handCardTab[seatNo].length; i++){
                    toTab[i] = this._handCardTab[i];
                }
            }
        }else{
            toTab = this._handCardTab[seatNo];
        }
        console.log("========getHandCardTabOctFunc===========", seatNo, toTab);
        return toTab;
    },
    getHandCardCountOctFunc(seatNo){
        if(!this._handCardTab[seatNo]) return 0;
        return this._handCardTab[seatNo].length;
    },
    removeCardTabOctFunc(seatNo, rmCardTab) {
        let toHandTab = this._handCardTab[seatNo];
        let removeNum = 0;
        for(let i=0; i<rmCardTab.length; i++){
            for(let j=0; j<toHandTab.length; j++){
                if(toHandTab[j]==rmCardTab[i]){
                    toHandTab.splice(j, 1);
                    removeNum++;
                    break;
                }
            }
        }
        cc.log("=====removeCardTabOctFunc=======", toHandTab);
        return removeNum;
    },
    //------------------------------------
    addOutCardTabOctFunc(seatNo, outTab){
        if(!this._outCardTab[seatNo]) this._outCardTab[seatNo] = [];
        this._outCardTab[seatNo].push(outTab);
    },
    getAllOutCardTabOctFunc(seatNo){
        if(!seatNo) return this._outCardTab;
        return this._outCardTab[seatNo];
    },
    setCurOutCardTabOctFunc(outTab){
        this._curOutCardTab = [];
        if(outTab){
            for(let i in outTab){
                this._curOutCardTab[i] = outTab[i];
            }
        }
    },
    getCurOutCardTabOctFunc(isCopy){
        if(!isCopy) this._curOutCardTab;
        let totab = [];
        for(let i=0; i<this._curOutCardTab.length; i++){
            totab[i] = this._curOutCardTab[i];
        }
        return totab;
    },
    //------------------------------------
    //三张底牌
    setBackCardOctFunc(card1, card2, card3){
        this._backCardTab = [];
        this._backCardTab.push(card1);
        this._backCardTab.push(card2);
        this._backCardTab.push(card3);
    },
    getBackCardOctFunc(){
        return this._backCardTab;
    },
    //------------------------------------
    //明牌id
    setMingPaiIdOctFunc(cardId){
        this._mingpaiCardId = cardId;
    },
    getMingPaiIdOctFunc(){
        return this._mingpaiCardId;
    },
    //抢地主数量
    setQiangRangNumOctFunc(num){
        this._qiangRangNum = num;
    },
    getQiangRangNumOctFunc(){
        return this._qiangRangNum;
    },
    //------------------------------------
    //--托管
    setTuoGuanOctFunc(seatNo, bTuoGuan){
        this._tuoguanTab[seatNo] = bTuoGuan;
    },
    isTuoGuanOctFunc(seatNo){
        return this._tuoguanTab[seatNo];
    },
    //////////////////////////////////////////////
    //value为空，表示背牌
    getPokerFramePathOctFunc(isBigPoker, value, bRawPath){
        let topath = "DdzResOct30th/smallPokerResOct30th/smallPoker_";
        if(isBigPoker){
            topath = "DdzResOct30th/bigPokerResOct30th/bigPoker_";
        }
        do{
            if(!value || value<=0){
                topath = topath + "cardback";
                break;
            }
            let cindex = GameRuleConfig.GetCardIndexOctFunc(value);
            if(cindex==GameRuleConfig.CardType.XiaoWangID){
                topath = topath + "xiaowang";
                break;
            }else if(cindex==GameRuleConfig.CardType.DaWangID){
                topath = topath + "dawang";
                break;
            }
            if(cindex <= GameRuleConfig.CardType.KID){
                cindex += 2;
            }else if(cindex==GameRuleConfig.CardType.ErID){
                cindex = 2;
            }else if(cindex==GameRuleConfig.CardType.YiID){
                cindex = 1;
            }
            let ccolor = GameRuleConfig.GetCardColorOctFunc(value);
            topath += ccolor;
            topath += "_";
            topath += cindex;
        }while(0);
        if(bRawPath){
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },
    getRangPokerFramePathOctFunc(bRawPath){
        let topath = "DdzResOct30th/bigPokerResOct30th/bigPoker_rangpai";
        if(bRawPath){
            topath = cc.url.raw("resources/" + topath + ".png");
        }
        return topath;
    },
    //////////////////////////////////////////////////////////////////
    playBackgroundMusicOctFunc(){
        g_SoundManager.playMusicOctFunc("DdzResOct30th/soundResOct30th/musicResOct30th/bg_happyOct30th");
    },
    _getCardIdIndexOctFunc(value){
        let cindex = GameRuleConfig.GetCardIndexOctFunc(value);
        if(cindex==GameRuleConfig.CardType.XiaoWangID){
            return cindex;
        }else if(cindex==GameRuleConfig.CardType.DaWangID){
            return cindex;
        }
        if(cindex <= GameRuleConfig.CardType.KID){
            cindex += 2;
        }else if(cindex==GameRuleConfig.CardType.ErID){
            cindex = 2;
        }else if(cindex==GameRuleConfig.CardType.YiID){
            cindex = 1;
        }
        return cindex;
    },
    _getBaseEffectPathOctFunc(userId){
        let userinfo = this.getRoomInfoOctFunc().getUserInfoByUserIdOctFunc(userId);
        if(!userinfo) return ;
        let effectpath = "DdzResOct30th/soundResOct30th/effectResOct30th/";
        if(userinfo.isBoy==1){
            effectpath += "boySound/";
        }else{
            effectpath += "girlSound/";            
        }
        return effectpath;
    },
    playGameStartOctFunc(){
        g_SoundManager.playEffectOctFunc("DdzResOct30th/soundResOct30th/effectResOct30th/gameStartMusic");
    },
    playSendCardOctFunc(){
        g_SoundManager.playEffectOctFunc("DdzResOct30th/soundResOct30th/effectResOct30th/sendCardMusic");
    },
    playGameResultOctFunc(isWin){
        if(isWin){
            g_SoundManager.playEffectOctFunc("DdzResOct30th/soundResOct30th/effectResOct30th/winMusic");
        }else{
            g_SoundManager.playEffectOctFunc("DdzResOct30th/soundResOct30th/effectResOct30th/failedMusic");
        }
    },
    playJiaoDiZhuOctFunc(userId, isJiao){
        let effectpath = this._getBaseEffectPathOctFunc(userId);
        if(isJiao){
            effectpath += "jiaodizhu";
        }else{
            effectpath += "bujiao" + MathRandomOctFunc(1, 2);
        }
        g_SoundManager.playEffectOctFunc(effectpath);
    },
    playQiangDiZhuOctFunc(userId, isQiang){
        let effectpath = this._getBaseEffectPathOctFunc(userId);
        if(isQiang){
            if(MathRandomOctFunc(1, 100)<50){
                effectpath += "qiangdizhu";
            }else{
                effectpath += "woqiang";                
            }
        }else{
            effectpath += "buqiang";
        }
        g_SoundManager.playEffectOctFunc(effectpath);
    },
    playNotOutOctFunc(userId){
        let effectpath = this._getBaseEffectPathOctFunc(userId);
        effectpath += "buyao" + MathRandomOctFunc(1, 4);
        g_SoundManager.playEffectOctFunc(effectpath);
    },
    playEatCardDaniOctFunc(userId){
        let effectpath = this._getBaseEffectPathOctFunc(userId);
        effectpath += "dani" + MathRandomOctFunc(1, 3);
        g_SoundManager.playEffectOctFunc(effectpath);
    },
    playOutTypeOctFunc(cardtype){
        if(cardtype==GameRuleConfig.CardType.FeiJiNoPai ||
            cardtype==GameRuleConfig.CardType.FeiJiDanPai ||
            cardtype==GameRuleConfig.CardType.FeiJiDuiPai){
                g_SoundManager.playEffectOctFunc("DdzResOct30th/soundResOct30th/effectResOct30th/feiJiSoundMusic");
        }else if(cardtype==GameRuleConfig.CardType.WangZha){
            g_SoundManager.playEffectOctFunc("DdzResOct30th/soundResOct30th/effectResOct30th/rocketMusic");
        }
    },
    playOutCardOctFunc(userId, cardId, cardtype){
        g_SoundManager.playEffectOctFunc("DdzResOct30th/soundResOct30th/effectResOct30th/outCardMusic");
        let effectpath = this._getBaseEffectPathOctFunc(userId);
        let cindex = this._getCardIdIndexOctFunc(cardId);
        if(cardtype==GameRuleConfig.CardType.DanPai){
            effectpath += cindex;
        }else if(cardtype==GameRuleConfig.CardType.DuiZi){
            effectpath += "dui" + this._getCardIdIndexOctFunc(cardId);
        }else if(cardtype==GameRuleConfig.CardType.SanTiao){
            if(MathRandomOctFunc(1, 100)<50){
                effectpath += "sange";
            }else{
                effectpath += "sanzhang";
            }
        }else if(cardtype==GameRuleConfig.CardType.SanDaiYi){
            effectpath += "sandaiyi";
        }else if(cardtype==GameRuleConfig.CardType.SanDaiYiDui){
            effectpath += "sandaiyidui";
        }else if(cardtype==GameRuleConfig.CardType.ShunZi){
            if(MathRandomOctFunc(1, 100)<50){
                effectpath += "shunzi";
            }else{
                effectpath += "danshun";
            }
        }else if(cardtype==GameRuleConfig.CardType.ZhaDan){
            effectpath += "zhadan";
        }else if(cardtype==GameRuleConfig.CardType.SiDaiDanPai){
            effectpath += "sidaier";
        }else if(cardtype==GameRuleConfig.CardType.SiDaiErDui){
            effectpath += "sidailiangdui";
        }else if(cardtype==GameRuleConfig.CardType.WangZha){
            effectpath += "wangzha";
        }else if(cardtype==GameRuleConfig.CardType.FeiJiNoPai){
            effectpath += "feiji";
        }else if(cardtype==GameRuleConfig.CardType.FeiJiDanPai){
            effectpath += "feijichibang";
        }else if(cardtype==GameRuleConfig.CardType.FeiJiDuiPai){
            effectpath += "feijichibang";
        }else if(cardtype==GameRuleConfig.CardType.LianDui){
            effectpath += "liandui";
        }else{
            effectpath = null;
        }
        if(effectpath){
            g_SoundManager.playEffectOctFunc(effectpath);
        }
    },
};