

require("ErRenDdzGameDataOct30th");

let GameRuleLogic =  require("DdzRuleLogicOct30th");
let STATUS_READY = 0;		//准备
let STATUS_SENDCARD = 1;	//发牌
let STATUS_QIANGDIZHU = 2; //抢地主
let STATUS_OUTCARD = 3;	    //出牌
let STATUS_GAMEFINISH = 4; //游戏结束
cc.Class({
    extends: require("ui-roomSceneOct30th"),

    properties: {
        O_controlbtnprefab : cc.Prefab,
        O_gameresultprefab : cc.Prefab,

        O_userInfoPrefab:cc.Prefab,

        O_settingPrefab : cc.Prefab,

        //////////////////////////////////////
        _backgroundScipt : null,
        _ctlbuttonScript : null,
        _rangtipScript : null,
        _gameresultScript : null,
        _dispcardScript : null,

    },

    // use this for initialization
    onLoad:function(){
        this._super(); //调用父类的onLoad
        this._setChatRoomStateOctFunc(true);
        //背景音乐
        g_ERDDZGameData.playBackgroundMusicOctFunc();

        let gameId = g_RoomManager.getCurGameIdOctFunc();
        let roomId = g_RoomManager.getCurRoomIdOctFunc();
        let selfUserId = g_UserManager.getSelfUserIdOctFunc();
        let roominfo = g_RoomManager.getGameRoomInfoOctFunc(gameId, roomId);
        
        let selfSeatNo = roominfo.findUserSeatNoOctFunc(selfUserId);
        g_ERDDZGameData.initOctFunc(gameId, roomId, selfSeatNo);
        cc.log("=======DdzResOct30th==mainscene=11====", gameId, roomId, selfUserId);

        //////////////////////////////////////////////////////////
        this._cplayerArray = [];
        let maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        let toSeatNo = selfSeatNo;
        for(let i=0; i<maxPlayer; i++){
            let playerNo = i + 1;
            let playerNode = this.node.getChildByName("player"+playerNo);
            playerNode.setLocalZOrder(100);
            console.log("=====111111=======", toSeatNo, selfSeatNo, playerNo);
            let cplayerhandler = playerNode.getComponent("ui-erRenDdzPlayerOct30th");
            cplayerhandler.initUIOctFunc(toSeatNo, playerNode);            
            g_ERDDZGameData.setPlayerUIOctFunc(cplayerhandler, i, toSeatNo);

            toSeatNo = g_ERDDZGameData.getNextSeatNoOctFunc(toSeatNo);
        };
        this._backgroundScipt = this.getComponent("ui-erRenDdzBackgroundOct30th");
        this._backgroundScipt.showBaseTipOctFunc();

        this._rangtipScript = this.getComponent("ui-erRenDdzRangTipOct30th");
        this._rangtipScript.showQiangDZTipOctFunc(false);

        this._dispcardScript = this.getComponent("ui-erRenDdzDispcardOct30th");
        cc.log("=========DdzResOct30th==mainscene====22====", this._dispcardScript);
        /////////////////////////////////////////////////////////////////
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_ErRenDDZ, null, this._onProtSocketMessageOctFunc, this);
        
        /////////////////////////////////////////////////////////////////
        //场景加载完毕，开始请求场景协议
        let toProtData = {};
        toProtData.gameId = g_ERDDZGameData.getGameIdOctFunc();
        toProtData.roomId = g_ERDDZGameData.getRoomIdOctFunc();
        cc.log("=========requestGameStatus===", toProtData);
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqGameStatus, toProtData);
    },
    onDestroyOctFunc() {
        cc.log("=============onDestroyOctFunc==============");
    },
    _resetAllUIOctFunc(){
        if(this._ctlbuttonScript){
            this._getControlBtnOctFunc().hideAllButtonOctFunc();
        }
        if(this._gameresultScript){
            this._getGameResultOctFunc().showResultOctFunc(false);
        }
        g_ERDDZGameData._resetInitOctFunc();
        this._rangtipScript.hideAllTipOctFunc();
        this._backgroundScipt.showThreeBackCardOctFunc(false);
        this._backgroundScipt.showSmallBackCardOctFunc(false);
        this._backgroundScipt.showBaseTipOctFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        let maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        for(let i=0; i<maxPlayer; i++){
            let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
            playerui.resetUIOctFunc();
            
            let userinfo = roominfo.getUserInfoOctFunc(i);
            cc.log("======_resetAllUIOctFunc====111=======", i, userinfo);
            if(userinfo){
                playerui.showUserInfoOctFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
            }else{
                playerui.showUserInfoOctFunc(false);
            }
        }
    },
    _requestGameReadyOctFunc(delaytime){
        let self = this;
        let readyOctFunc = function(){
            //在这里进入房间后要发协议，自己默认进入房间就准备
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SReady);
        };
        if(!delaytime || delaytime<=0){
            readyOctFunc();
        }else{
            this.scheduleOnce(readyOctFunc, delaytime);
        }
    },
    onSettingBtnEventOctFunc(event){
        var settingPlane = cc.instantiate(this.O_settingPrefab);
        this.node.addChild(settingPlane, 1000);
    },
    onShowUserInfoPanelOctFunc(node, detail) {
        cc.log("========onShowUserInfoPanelOctFunc=========", node, detail);
        let seatNo = g_ERDDZGameData.getSelfSeatNoOctFunc();
        if(detail==2){
            seatNo = g_ERDDZGameData.getNextSeatNoOctFunc(seatNo);
        }
        let roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        if(roominfo.getUserInfoOctFunc(seatNo)){
            var userInfoNode = cc.instantiate(this.O_userInfoPrefab);
            userInfoNode.parent = this.node;
            userInfoNode.setLocalZOrder(200);
            userInfoNode.getComponent("ui-erRenDdzUserInfoOct30th").showInfoOctFunc(seatNo);
        }
    },
    //////////////////////////////////////////////////////////////////////////////
    _getControlBtnOctFunc(){
        if(!this._ctlbuttonScript){
            let ctrbtn = cc.instantiate(this.O_controlbtnprefab);
            ctrbtn.parent = this.node;
            ctrbtn.setLocalZOrder(150);
            this._ctlbuttonScript = ctrbtn.getComponent("ui-erRenDdzControllbtnOct30th");
            ctrbtn.off("outbtn-buchu");
            ctrbtn.off("outbtn-tishi");
            ctrbtn.off("outbtn-chupai");
            ctrbtn.on("outbtn-buchu", (event)=>{
                this._OutCardBuChuOctFunc();
            }, this);
            ctrbtn.on("outbtn-tishi", (event)=>{
                this._OutCardTiShiOctFunc();
            }, this);
            ctrbtn.on("outbtn-chupai", (event)=>{
                this.OutCardChuPaiOctFunc();
            }, this);
        }
        return this._ctlbuttonScript;
    },
    _getGameResultOctFunc(){
        if(!this._gameresultScript){
            let resultnode = cc.instantiate(this.O_gameresultprefab);
            resultnode.parent = this.node;
            resultnode.setLocalZOrder(200);
            this._gameresultScript = resultnode.getComponent("ui-erRenDdzGameResultOct30th");
        }
        return this._gameresultScript;
    },
    _OutCardBuChuOctFunc(){
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoOctFunc();
        let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(selfSeatNo);
        playerui.getHandCardOctFunc().clearTiShiHandCardOctFunc();

        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SBuChu);
    },
    _OutCardTiShiOctFunc(){
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoOctFunc();
        let outCardTab = g_ERDDZGameData.getCurOutCardTabOctFunc(true);
        let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(selfSeatNo);
        playerui.getHandCardOctFunc().moveTiShiHandCardOctFunc(outCardTab);
    },
    OutCardChuPaiOctFunc(){
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoOctFunc();
        let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(selfSeatNo);
        playerui.getHandCardOctFunc().clearTiShiHandCardOctFunc();
        let outCardTab = g_ERDDZGameData.getCurOutCardTabOctFunc(true);
        let outTab = playerui.getHandCardOctFunc().getMoveUpCardTabOctFunc(outCardTab);
        if(outTab && outTab.length>0){
            let toProtTab = {};
            toProtTab.cardTab = outTab;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SOutCard, toProtTab);
        }else{
            this.showPopupWindowOctFunc(true, false, "提示", "出牌不符合规则！");
        }
    },
    ////////////////////////////////////////////////////////////////////////////////
    onRecvErrcodeOctFunc(errcode, attachtab){
        cc.log("=======onRecvErrcodeOctFunc============", errcode, attachtab);
        this.showPopupWindowOctFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },
    //其他玩家进入房间会调用这里, 进入房间协议比场景协议要先到来
    onRecvEnterRoomOctFunc(gameId, roomId, userId){
        //let selfUserId = g_UserManager.getSelfUserIdOctFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        let seatNo = roominfo.findUserSeatNoOctFunc(userId);
        let userinfo = roominfo.getUserInfoOctFunc(seatNo);
        let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(seatNo);
        cc.log("==============onRecvEnterRoomOctFunc==========", roomId, userId, typeof(userId), roominfo);
        playerui.showUserInfoOctFunc(true, userinfo.userName, userinfo.gold, userinfo.headurl);
    },
    onRecvJieSanDeskOctFunc(gameId, roomId, userId, userName, isAuto){
        cc.log("======onRecvJieSanDeskOctFunc==========", gameId, roomId, userId, userName, isAuto);
        if(!isAuto){
            this.showPopupWindowOctFunc(true, false, "提示", "房主已经解散了房间！", (flag)=>{
                this.switchLobbySceneOctFunc();
            }, this);
        }else{
            this.showPopupWindowOctFunc(true, false, "提示", "房间局数已尽！", (flag)=>{
                this.switchLobbySceneOctFunc();
            }, this);            
        }
    },
    onRecvLeaveDeskOctFunc(gameId, roomId, userId){
        cc.log("======onRecvLeaveDeskOctFunc==========", gameId, roomId, userId);
        if(userId==g_UserManager.getSelfUserIdOctFunc()){
            // this.showPopupWindowOctFunc(true, false, "提示", "您已经离开房间！", (flag)=>{
            //     this.switchLobbySceneOctFunc();
            // }, this);
            this.switchLobbySceneOctFunc();
        }
    },
    ////////////////////////////////////////////////////////////////////////////////
    _startDispCardOctFunc(beginSeatNo){
        let maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        let eachNumArray = [];
        let eachPosArray = [];
        for(let i=0; i<maxPlayer; i++){
            let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
            eachNumArray.push(17);
            eachPosArray.push(playerui.getHandCardPosOctFunc());
        }
        let self = this;
        this._dispcardScript.sendAllCardOctFunc(beginSeatNo, eachNumArray, eachPosArray, (seatNo, num, isEnd)=>{
            if(!isEnd){
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(seatNo);
                playerui.getHandCardOctFunc().drawHandCardOctFunc(num);
            }else{
                g_ERDDZGameData.setHandCardSortOctFunc(true);
                self._backgroundScipt.showThreeBackCardOctFunc(true);
                self._backgroundScipt.showSmallBackCardOctFunc(false);
                let maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
                for(let i=0; i<maxPlayer; i++){
                    let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                    playerui.getHandCardOctFunc().drawHandCardOctFunc();
                }
                g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SSendCardFinish);
            }
        });
    },
    ////////////////////////////////////////////////////////////////////////////////
    onRecvGameStatusOctFunc(protTab){
        cc.log("==========onRecvGameStatusOctFunc====11=========", protTab);
        let maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        let selfUserId = g_UserManager.getSelfUserIdOctFunc();
        let selfSeatNo = roominfo.findUserSeatNoOctFunc(selfUserId);
        this._resetAllUIOctFunc();
        cc.log("==========onRecvGameStatusOctFunc====22=========");
        if(protTab.status == STATUS_READY){
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                let isReady = protTab.readyTab[i];
                if(i==selfSeatNo) isReady = true;
                playerui.showReadyTipOctFunc(isReady);
            }
            this._requestGameReadyOctFunc();
        }else if(protTab.status == STATUS_SENDCARD){
            for(let i=0; i<maxPlayer; i++){
                g_ERDDZGameData.setHandCardTabOctFunc(i, protTab.handCardTab[i], true);
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                let leftnum = g_ERDDZGameData.getHandCardCountOctFunc(i);
                playerui.showUserLeftCardOctFunc(true, leftnum);
                playerui.getHandCardOctFunc().drawHandCardOctFunc();
            }
            this._startDispCardOctFunc(selfSeatNo);
        }else if(protTab.status == STATUS_QIANGDIZHU){
            let turnSeatNo = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumOctFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            if(protTab.bankerUserId) {
                let bankSeatNo = roominfo.findUserSeatNoOctFunc(protTab.bankerUserId);
                g_ERDDZGameData.setDiZhuSeatNoOctFunc(bankSeatNo);
            } 
            for(let i=0; i<maxPlayer; i++){
                g_ERDDZGameData.setHandCardTabOctFunc(i, protTab.handCardTab[i], true);
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                let leftnum = g_ERDDZGameData.getHandCardCountOctFunc(i);
                playerui.showUserLeftCardOctFunc(true, leftnum);
                playerui.getHandCardOctFunc().drawHandCardOctFunc();
                if(turnSeatNo==i && turnSeatNo!=selfSeatNo){
                    playerui.showTimeWaitTipOctFunc(true);
                }else{
                    playerui.showTimeWaitTipOctFunc(false);
                }
            }
            this._rangtipScript.showQiangDZTipOctFunc(false);
            this._rangtipScript.showRangTipOctFunc();
            this._backgroundScipt.showThreeBackCardOctFunc(true);
            this._backgroundScipt.showSmallBackCardOctFunc(false);
            if(protTab.turnUserId==selfUserId){
                if(protTab.isTurnJiaoDZ==1){
                    this._getControlBtnOctFunc().showJiaoDZBtnOctFunc();
                }else{
                    this._getControlBtnOctFunc().showQiangDZBtnOctFunc();
                    this._rangtipScript.showQiangDZTipOctFunc(true);
                }
            }
            if(protTab.lastUserId!=null){
                let playerui = g_ERDDZGameData.getPlayerUIByUserIdOctFunc(protTab.lastUserId);
                if(protTab.isJiaoDZ==1){
                    playerui.speekJiaoDiZhuOctFunc(true);
                }else{
                    playerui.speekQiangDiZhuOctFunc(true);
                }
            }
        }else if(protTab.status == STATUS_OUTCARD){
            g_ERDDZGameData.setBackCardOctFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            let bankerSeatNo = roominfo.findUserSeatNoOctFunc(protTab.bankerUserId);
            let outSeatNo = roominfo.findUserSeatNoOctFunc(protTab.outUserId);
            let turnSeatNo = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            g_ERDDZGameData.setDiZhuSeatNoOctFunc(bankerSeatNo);
            g_ERDDZGameData.setCurOutCardTabOctFunc(protTab.outTab);
            g_ERDDZGameData.setQiangRangNumOctFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            for(let i=0; i<maxPlayer; i++){
                g_ERDDZGameData.setHandCardTabOctFunc(i, protTab.handCardTab[i], true);
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                playerui.getHandCardOctFunc().drawHandCardOctFunc();
                playerui.showDiZhuTipOctFunc(false);
                if(bankerSeatNo==i){
                    playerui.showDiZhuTipOctFunc(true);
                }
                if(i==outSeatNo){
                    playerui.getHandCardOctFunc().drawOutCardOctFunc(protTab.outTab);
                    playerui.getHandCardOctFunc().drawHandCardOctFunc();
                }else{
                    playerui.getHandCardOctFunc().clearOutCardOctFunc();
                }
                if(turnSeatNo==i && turnSeatNo!=selfSeatNo){
                    playerui.showTimeWaitTipOctFunc(true);
                }else{
                    playerui.showTimeWaitTipOctFunc(false);
                }
                let leftnum = g_ERDDZGameData.getHandCardCountOctFunc(i);
                playerui.showUserLeftCardOctFunc(true, leftnum);
                if(leftnum<=3){
                    playerui.showBaoJingTipOctFunc(true)
                }
            }
            this._backgroundScipt.showSmallBackCardOctFunc(true);
            this._rangtipScript.showQiangDZTipOctFunc(false);
            this._rangtipScript.showRangTipOctFunc();
            if(protTab.turnUserId==selfUserId){
                this._getControlBtnOctFunc().showOutCardBtnOctFunc(protTab.mustOut==1);
            }
        }else if(protTab.status == STATUS_GAMEFINISH){
            //this._requestGameReadyOctFunc(3);
            this._onShowGameResultOctFunc(protTab.finishdata);
        }
    },
    _onProtSocketMessageOctFunc(mainId, assistId, protTab){
        cc.log("==========_onProtSocketMessageOctFunc=============", mainId, assistId, protTab);
        // AErRenDDZ_S2CBeginOut = 201;   //开始出牌
        // AErRenDDZ_S2CCallLandlord = 202;  //叫地主
        // AErRenDDZ_S2COutCard    = 203;    //出牌
        // AErRenDDZ_S2CBuChu  = 204;   //不出
        // AErRenDDZ_S2CSendCard  = 205;  //发牌
        // AErRenDDZ_S2CTuoGuan = 207;   //托管
        // AErRenDDZ_S2CGameFinish = 208;    //游戏结束
        let maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        let selfUserId = g_UserManager.getSelfUserIdOctFunc();
        let selfSeatNo = roominfo.findUserSeatNoOctFunc(selfUserId);
        for(let i=0; i<maxPlayer; i++){
            let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
            playerui.showReadyTipOctFunc(false);
            playerui.showTimeWaitTipOctFunc(false);
            playerui.speekNothingOctFunc();
        }
        this._backgroundScipt.showBaseTipOctFunc();
        if(assistId==g_ProtDef.AErRenDDZ_S2CReady){
            if(protTab.userId==selfUserId){
                this._resetAllUIOctFunc();
            }
            let playerui = g_ERDDZGameData.getPlayerUIByUserIdOctFunc(protTab.userId);
            playerui.showReadyTipOctFunc(true);
        }else if(assistId==g_ProtDef.AErRenDDZ_S2CSendCard){
            let jiaoSeatNo = roominfo.findUserSeatNoOctFunc(protTab.jiaoUserId);
            for(let i=0; i<maxPlayer; i++){
                g_ERDDZGameData.setHandCardTabOctFunc(i, protTab.handCardTab[i], false);
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                playerui.getHandCardOctFunc().drawHandCardOctFunc();
                if(i==jiaoSeatNo && jiaoSeatNo!=selfSeatNo){
                    playerui.showTimeWaitTipOctFunc(true);
                }
            }
            this._startDispCardOctFunc(selfSeatNo);
        }else if(assistId==g_ProtDef.AErRenDDZ_S2CCallLandlord){
            let turnSeatNo = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            g_ERDDZGameData.setQiangRangNumOctFunc(protTab.qiangCount);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            this._getControlBtnOctFunc().hideAllButtonOctFunc();
            this._backgroundScipt.showThreeBackCardOctFunc(true);
            this._backgroundScipt.showSmallBackCardOctFunc(false);
            
            let jiaoSeatNo = -1;
            if (protTab.userId) {
                //当发牌完成后，会发送一个userId为空的首次叫地主的协议过来，通知开始叫地主
                jiaoSeatNo = roominfo.findUserSeatNoOctFunc(protTab.userId);
                this._rangtipScript.showQiangDZTipOctFunc(true);
            }
            if(turnSeatNo==selfSeatNo && !protTab.isEnd){
                if(protTab.isTurnJiaoDZ==1){
                    this._getControlBtnOctFunc().showJiaoDZBtnOctFunc();
                }else{
                    this._getControlBtnOctFunc().showQiangDZBtnOctFunc();
                }
            }
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);

                let leftnum = g_ERDDZGameData.getHandCardCountOctFunc(i);
                playerui.showUserLeftCardOctFunc(true, leftnum);
                if(i==turnSeatNo && turnSeatNo!=selfSeatNo){
                    playerui.showTimeWaitTipOctFunc(true);
                }
                playerui.speekNothingOctFunc();
                if(i==jiaoSeatNo && protTab.isJiaoDZ!=null){
                    if(protTab.isJiaoDZ==1){
                        playerui.speekJiaoDiZhuOctFunc(protTab.isCall==1);
                        g_ERDDZGameData.playJiaoDiZhuOctFunc(protTab.userId, protTab.isCall==1);
                    }else{
                        playerui.speekQiangDiZhuOctFunc(protTab.isCall==1);
                        g_ERDDZGameData.playQiangDiZhuOctFunc(protTab.userId, protTab.isCall==1);
                    }
                }
            }
            this._rangtipScript.showRangTipOctFunc();
        }else if(assistId==g_ProtDef.AErRenDDZ_S2CBeginOut){
            g_ERDDZGameData.setBackCardOctFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
            let bankSeatNo = roominfo.findUserSeatNoOctFunc(protTab.bankerUserId);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            g_ERDDZGameData.setDiZhuSeatNoOctFunc(bankSeatNo);
            g_ERDDZGameData.addHandCardTabOctFunc(bankSeatNo, protTab.backCardTab);
            g_ERDDZGameData.playGameStartOctFunc();
            this._rangtipScript.showQiangDZTipOctFunc(false);
            this._rangtipScript.showRangTipOctFunc();
            this._backgroundScipt.showThreeBackCardOctFunc(true);
            this._backgroundScipt.recoverBackCardOctFunc();
            if(selfSeatNo==bankSeatNo){
                this._getControlBtnOctFunc().showOutCardBtnOctFunc(true);
            }
            
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                playerui.showDiZhuTipOctFunc(false);
                playerui.getHandCardOctFunc().drawHandCardOctFunc();
                if(i==bankSeatNo){
                    playerui.showDiZhuTipOctFunc(true);
                    playerui.getHandCardOctFunc().moveAddActionCardOctFunc(protTab.backCardTab);
                    if(i==selfSeatNo){
                        playerui.showTimeWaitTipOctFunc(false);
                    }else{
                        playerui.showTimeWaitTipOctFunc(true);
                    }
                }
            }
        }else if(assistId==g_ProtDef.AErRenDDZ_S2COutCard){
            let outSeatNo = roominfo.findUserSeatNoOctFunc(protTab.userId);
            let turnSeatNo = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            let outtype = GameRuleLogic.getCardTabCardTypeOctFunc(protTab.cardTab);
            if(protTab.newTurn==1 || Math.random()*100 < 50){
                g_ERDDZGameData.playOutCardOctFunc(protTab.userId, protTab.cardTab[0], outtype);
            }else{
                g_ERDDZGameData.playEatCardDaniOctFunc(protTab.userId);
            }
            g_ERDDZGameData.playOutTypeOctFunc(outtype);

            g_ERDDZGameData.setCurOutCardTabOctFunc(protTab.cardTab);
            g_ERDDZGameData.removeCardTabOctFunc(outSeatNo, protTab.cardTab);
            g_ERDDZGameData.setHandCardSortOctFunc(true);
            this._backgroundScipt.showThreeBackCardOctFunc(false);
            this._rangtipScript.showQiangDZTipOctFunc(false);
            this._getControlBtnOctFunc().hideAllButtonOctFunc();
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                if(i==outSeatNo){
                    playerui.getHandCardOctFunc().drawOutCardOctFunc(protTab.cardTab);
                    playerui.getHandCardOctFunc().drawHandCardOctFunc();
                }else{
                    playerui.getHandCardOctFunc().clearOutCardOctFunc();
                }
                if(i==turnSeatNo && turnSeatNo==selfSeatNo || i==outSeatNo){
                    playerui.showTimeWaitTipOctFunc(false);
                }else{
                    playerui.showTimeWaitTipOctFunc(true);
                }
                let leftnum = g_ERDDZGameData.getHandCardCountOctFunc(i);
                playerui.showUserLeftCardOctFunc(true, leftnum);
                if(leftnum<=3){
                    playerui.showBaoJingTipOctFunc(true)
                }
            }
            if(turnSeatNo==selfSeatNo){
                this._getControlBtnOctFunc().showOutCardBtnOctFunc(false);
            }
        }else if(assistId==g_ProtDef.AErRenDDZ_S2CBuChu){
            let theSeatNo = roominfo.findUserSeatNoOctFunc(protTab.userId);
            let turnSeatNo = roominfo.findUserSeatNoOctFunc(protTab.turnUserId);
            g_ERDDZGameData.setCurOutCardTabOctFunc(null);
            g_ERDDZGameData.playNotOutOctFunc(protTab.userId);
            this._getControlBtnOctFunc().hideAllButtonOctFunc();
            for(let i=0; i<maxPlayer; i++){
                let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
                if(i==theSeatNo){
                    playerui.speekBuChuOctFunc();
                }
                playerui.getHandCardOctFunc().clearOutCardOctFunc();
            }
            if(turnSeatNo==selfSeatNo){
                this._getControlBtnOctFunc().showOutCardBtnOctFunc(true);
            }
        }else if(assistId==g_ProtDef.AErRenDDZ_S2CTuoGuan){
        }else if(assistId==g_ProtDef.AErRenDDZ_S2CGameFinish){
            g_ERDDZGameData.playGameResultOctFunc(protTab.winUserId == selfUserId);
            this._onShowGameResultOctFunc(protTab);
            //游戏正常结束，调用基类函数
            let gameId = roominfo.getGameIdOctFunc();
            let roomId = roominfo.getRoomIdOctFunc();
            this.onBaseGameFinishOctFunc(gameId, roomId);
        }
    },
    ////////////////////////////////////////////////////////////////////
    _onShowGameResultOctFunc(protTab){
        this._resetAllUIOctFunc();
        g_ERDDZGameData.setHandCardSortOctFunc(true);
        g_ERDDZGameData.setBackCardOctFunc(protTab.backCardTab[0], protTab.backCardTab[1], protTab.backCardTab[2]);
        this._backgroundScipt.showSmallBackCardOctFunc(true);
        let maxPlayer = g_ERDDZGameData.getMaxPlayerOctFunc();
        let roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        let bankerSeatNo = roominfo.findUserSeatNoOctFunc(protTab.bankerUserId);
        let winSeatNo = roominfo.findUserSeatNoOctFunc(protTab.winUserId);
        for(let i=0; i<maxPlayer; i++){
            g_ERDDZGameData.setHandCardTabOctFunc(i, protTab.handCardTab[i], true);
            let playerui = g_ERDDZGameData.getPlayerUIBySeatNoOctFunc(i);
            playerui.getHandCardOctFunc().drawHandCardOctFunc(null, true);
            playerui.showDiZhuTipOctFunc(false);
            if(bankerSeatNo==i){
                playerui.showDiZhuTipOctFunc(true);
            }
            if(i==winSeatNo) {
                playerui.getHandCardOctFunc().drawOutCardOctFunc(protTab.lastOutTab);
            }
            roominfo.updateUserGoldOctFunc(i, protTab.winScore[i]);
            playerui.showTotalScoreOctFunc(true, protTab.winScore[i]);
        }
        this._getGameResultOctFunc().showResultOctFunc(true, protTab);
    },
});
