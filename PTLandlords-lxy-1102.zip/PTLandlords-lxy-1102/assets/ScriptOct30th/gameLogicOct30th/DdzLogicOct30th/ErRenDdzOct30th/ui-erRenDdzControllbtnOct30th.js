cc.Class({
    extends: cc.Component,

    properties: {
        O_outcardbtnnode : cc.Node,
        O_qiangdzbtnnode : cc.Node,
        O_jiaodzbtnnode : cc.Node,

        O_buchubtn : cc.Button,
    },

    // use this for initialization
    onLoad: function () {
        this.hideAllButtonOctFunc();
    },
    hideAllButtonOctFunc : function(){
        this.O_outcardbtnnode.active = false;
        this.O_qiangdzbtnnode.active = false;
        this.O_jiaodzbtnnode.active = false;
    },
    showOutCardBtnOctFunc : function(bMustOut){
        this.hideAllButtonOctFunc();
        this.O_outcardbtnnode.active = true;
        this.O_buchubtn.interactable = !bMustOut;
    },
    showQiangDZBtnOctFunc : function(){
        this.hideAllButtonOctFunc();
        this.O_qiangdzbtnnode.active = true;
    },
    showJiaoDZBtnOctFunc : function(){
        this.hideAllButtonOctFunc();
        this.O_jiaodzbtnnode.active = true;
    },
    ////////////////////////////////////////////////////
    onBuChuBtnEventOctFunc : function(event){
        this.node.emit("outbtn-buchu");
    },
    onLastHandBtnEventOctFunc : function(event){
        //this.node.emit("outbtn-lasthand");
    },
    onTiShiBtnEventOctFunc : function(event){
        this.node.emit("outbtn-tishi");
    },
    onChuPaiBtnEventOctFunc : function(event){
        this.node.emit("outbtn-chupai");
    },
    /////////////////////////////////////////////////
    _priCallProtocolDiZhuOctFunc : function(isCall){
        this.hideAllButtonOctFunc();
        let toProtData = {};
        toProtData.isCall = isCall,
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_ErRenDDZ, g_ProtDef.AErRenDDZ_C2SCallLandlord, toProtData);
    },
    onBuQiangBtnEventOctFunc : function(event){
        cc.log("=========onBuQiangBtnEventOctFunc===");
        this._priCallProtocolDiZhuOctFunc(0);
    },
    onQiangDZBtnEventOctFunc : function(event){
        cc.log("=========onQiangDZBtnEventOctFunc===");
        this._priCallProtocolDiZhuOctFunc(1);
    },
    /////////////////////////////////////////////////
    onBuJiaoBtnEventOctFunc : function(event){
        cc.log("=========onBuJiaoBtnEventOctFunc===");
        this._priCallProtocolDiZhuOctFunc(0);
    },
    onJiaoDZBtnEventOctFunc : function(event){
        cc.log("=========onJiaoDZBtnEventOctFunc===");
        this._priCallProtocolDiZhuOctFunc(1);
    },
});
