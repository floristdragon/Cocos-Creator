cc.Class({
    extends: cc.Component,

    properties: {
        _seatNo : 0,
        _handCardHandler : null,
    },
    onLoad(){
        //this.resetUIOctFunc();
    },
    initUIOctFunc(seatNo){
        this._seatNo = seatNo;

        this._handCardHandler = this.getComponent("ui-erRenDdzHandCardOct30th");
        this._handCardHandler.initUIOctFunc(this._seatNo);

        this.resetUIOctFunc();
        cc.log("=========player===initUIOctFunc===========", seatNo, g_ERDDZGameData.getSelfSeatNoOctFunc());
    },
    resetUIOctFunc(){
        this.speekNothingOctFunc();
        this.showUserInfoOctFunc(false);
        this.showDiZhuTipOctFunc(false);
        this.showUserLeftCardOctFunc(false, 0);
        this.showBaoJingTipOctFunc(false);
        this.showTotalScoreOctFunc(false,0);
        this.showTimeWaitTipOctFunc(false);
        this._showTuoGuanOctFunc(false);
        this.showReadyTipOctFunc(false);
        this._handCardHandler.resetUIOctFunc();
    },
    getSeatNoOctFunc(){
        return this._seatNo;
    },
    getHandCardOctFunc(){
        return this._handCardHandler;
    },
    getHandCardPosOctFunc(){
        let toNode = this.node.getChildByName("handcard");
        return toNode.convertToWorldSpaceAR(cc.Vec2.ZERO);
    },
    showUserInfoOctFunc(isVisible, name, score, headurl){
        let nameNode = this.node.getChildByName("name");
        let scoreNode = this.node.getChildByName("score");
        let faceNode = this.node.getChildByName("playerface");
        nameNode.active = isVisible;
        scoreNode.active = isVisible;
        faceNode.active = isVisible;
        if(!isVisible) return ;
        cc.log("=======showUserInfoOctFunc=======", name, score, headurl);
        if(!name) name = "";
        if(!score) score = "0";
        let nametext = nameNode.getComponent(cc.RichText);
        let scoretext = scoreNode.getComponent(cc.RichText);
        nametext.string = name;
        scoretext.string = score+"";

        faceNode.scaleY = 1;
        faceNode.scaleX = 1;
        if (headurl && headurl.length > 0) {
            let toSprite = faceNode.getComponent(cc.Sprite);
            let toType = "png";
            if(headurl.indexOf(".jpg")){
                toType = "jpg";
            }
            cc.loader.load({ type: toType, url: headurl }, (err, texture) => {
                if (!err) {
                    toSprite.spriteFrame = new cc.SpriteFrame(texture);
                }
            });
        }
    },
    showDiZhuTipOctFunc(isDiZhu){
        let tipNode = this.node.getChildByName("dizhutip");
        tipNode.active = isDiZhu;
    },
    showUserLeftCardOctFunc(isVisible, leftnum){
        let tipNode = this.node.getChildByName("leftnum");
        tipNode.active = isVisible;
        let ctext = tipNode.getComponent(cc.RichText);
        if(!leftnum) leftnum = "0";
        ctext.string = leftnum+"";
    },
    showBaoJingTipOctFunc(isVisible){
        let tipNode = this.node.getChildByName("baojingtip");
        tipNode.active  = isVisible;
    },
    showTotalScoreOctFunc(isVisible, totalscore){
        let tipNode = this.node.getChildByName("totalscore");
        tipNode.active = isVisible;
        let ctext = tipNode.getComponent(cc.Label);
        if(!totalscore) totalscore = "0";
        ctext.string = totalscore+"";
    },
    showTimeWaitTipOctFunc(isVisible){
        let tipNode = this.node.getChildByName("timewaittip");
        tipNode.active  = isVisible;
    },
    _showTuoGuanOctFunc(istuoguan){
        let tipNode = this.node.getChildByName("tuoguantip");
        tipNode.active  = istuoguan;
    },
    showReadyTipOctFunc(isVisible){
        let tipNode = this.node.getChildByName("readytip");
        tipNode.active  = isVisible;
    },
    /////////////////////////////////////////////////////////
    _priSpeakThingOctFunc(flag){
        let loadurl = "DdzResOct30th/speakTipResOct30th/tp_speakOct30th_"+flag;
        let tipNode = this.node.getChildByName("speaktip");
        tipNode.active = true;
        let spNode = tipNode.getComponent(cc.Sprite);
        cc.loader.loadRes(loadurl, function(err, texture){
            spNode.spriteFrame = new cc.SpriteFrame(texture);
        });
    },
    speekNothingOctFunc(){
        let tipNode = this.node.getChildByName("speaktip");
        tipNode.active = false;
    },
    speekBuChuOctFunc(){
        this._priSpeakThingOctFunc(1);
    },
    speekJiaoDiZhuOctFunc(isCall){
        if(isCall){
            this._priSpeakThingOctFunc(5);
        }else{
            this._priSpeakThingOctFunc(2);
        }
    },
    speekQiangDiZhuOctFunc(isCall){
        if(isCall){
            this._priSpeakThingOctFunc(6);
        }else{
            this._priSpeakThingOctFunc(3);
        }
    },
    speekRangPaiOctFunc(isRang){
        if(isRang){
            this._priSpeakThingOctFunc(7);
        }else{
            this._priSpeakThingOctFunc(4);
        }
    },
});
