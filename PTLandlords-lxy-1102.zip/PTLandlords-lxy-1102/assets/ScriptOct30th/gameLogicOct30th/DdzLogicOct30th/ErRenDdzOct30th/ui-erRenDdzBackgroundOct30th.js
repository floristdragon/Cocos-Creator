var exFangHaoNodePos = null;
var exJuShuNodePos = null;
cc.Class({
    extends: cc.Component,

    properties: {
        O_basescorenode : cc.Node,
        O_beilvnode : cc.Node,
        O_fanghaonode : cc.Node,
        O_jushunode : cc.Node,

        O_timetext : cc.Label,
        
        O_smallcardparent : cc.Node,
        O_smallcardArray : {
            default : [],
            type : cc.Node
        },
        O_beilvtip : cc.Node,
        O_typetip : cc.Node,
        O_backcardprefab : cc.Prefab,
        
        _backcardparent : null,
    },

    // use this for initialization
    onLoad: function () {
        this._setBaseNumOctFunc(this.O_fanghaonode, 0);
        this._setBaseNumOctFunc(this.O_basescorenode, 0);
        this._setBaseNumOctFunc(this.O_beilvnode, 0);

        let self = this;
        let uptimerOctFunc = function(dt){
            let date = new Date();
            let tostr = "";
            if(date.getHours()<10){
                tostr += "0";
            }
            tostr += date.getHours();
            tostr += ":";
            if(date.getMinutes()<10){
                tostr += "0";
            }
            tostr += date.getMinutes();
            self.O_timetext.string = tostr;
        };
        uptimerOctFunc();
        this.schedule(uptimerOctFunc, 1);
        this.showThreeBackCardOctFunc(false);

        this.O_smallcardparent.active = false;

        // this.scheduleOnce(()=>{
        //     self.recoverBackCardOctFunc();
        // }, 2);
    },

    showBaseTipOctFunc(){
        let roominfo = g_ERDDZGameData.getRoomInfoOctFunc();
        if(roominfo){
            this._setBaseNumOctFunc(this.O_fanghaonode, roominfo.getRoomIdOctFunc());
            this._setBaseNumOctFunc(this.O_basescorenode, roominfo.getBaseScoreOctFunc());
            this._setBaseNumOctFunc(this.O_beilvnode, roominfo.getBaseBeiLvOctFunc());
            
            if(!exFangHaoNodePos){
                exFangHaoNodePos = new cc.Vec2(this.O_fanghaonode.position.x, this.O_fanghaonode.position.y);
            }
            if(!exJuShuNodePos){
                exJuShuNodePos = new cc.Vec2(this.O_jushunode.position.x, this.O_jushunode.position.y);
            }
            let curjushu = roominfo.getCurJuShuOctFunc();
            let maxjushu = roominfo.getMaxJuShuOctFunc();
            if(maxjushu>0){
                this._setBaseNumOctFunc(this.O_jushunode, curjushu + "/" + maxjushu);
            }else{
                this.O_jushunode.active = false;
                this.O_fanghaonode.position = exJuShuNodePos; 
            }
        }
        cc.log("======ScoreTip===resetTip=============", roominfo);
    },    
    showSmallBackCardOctFunc(bVisible){
        cc.log("=======showSmallBackCardOctFunc=======", bVisible);
        this.O_smallcardparent.active = bVisible;
        if(!bVisible) return ;
        this.O_beilvtip.active = false;
        this.O_typetip.active = false;
        let backCardTab = g_ERDDZGameData.getBackCardOctFunc();
        for(let i=0; i<this.O_smallcardArray.length; i++){
            let toSpUrl = g_ERDDZGameData.getPokerFramePathOctFunc(false, backCardTab[i]);
            let toSprite = this.O_smallcardArray[i].getComponent(cc.Sprite);
            cc.loader.loadRes(toSpUrl, function(err, texture){
                toSprite.spriteFrame = new cc.SpriteFrame(texture);
            });
        }
    },
    showThreeBackCardOctFunc(bVisible){
        if(!this._backcardparent && !bVisible) return ;
        if(this._backcardparent) this._backcardparent.destroy();
        
        this._backcardparent = cc.instantiate(this.O_backcardprefab);
        this._backcardparent.parent = this.node;
        this._backcardparent.active = bVisible;
        cc.log("========showThreeBackCardOctFunc=============", this._backcardparent);
    },
    recoverBackCardOctFunc(){
        cc.log("=======recoverBackCardOctFunc=======");
        this.showThreeBackCardOctFunc(true);
        this.O_smallcardparent.active = false;
        let backCardTab = g_ERDDZGameData.getBackCardOctFunc();
        let toshowOctFunc = function(){
            cc.log("=======toshowOctFunc=======");
            if(this.O_smallcardparent.active) return ;
            this._backcardparent.active = false;
            this.showSmallBackCardOctFunc(true);
        };
        let backcardArray = [];
        let toPosArray = [];
        let toSpFrameArray = [];
        for(let i=1; i<=3; i++){
            let toCard = this._backcardparent.getChildByName("card" + i);
            backcardArray.push(toCard);
        }
        for(let i=0; i<backCardTab.length; i++){
            let toSpUrl = g_ERDDZGameData.getPokerFramePathOctFunc(true, backCardTab[i], true);
            var texture = cc.textureCache.addImage(toSpUrl);
            toSpFrameArray.push(texture);
            let toPosEx = this.O_smallcardArray[i].convertToWorldSpaceAR(cc.Vec2.ZERO);
            let toNodePos = this._backcardparent.convertToNodeSpaceAR(toPosEx);
            toPosArray.push(toNodePos);
        }
        for(let i=0; i<backcardArray.length; i++){
            let toRotateOctFunc = ()=>{
                cc.log("====toRotateOctFunc=========", i);
                let toSprite = backcardArray[i].getComponent(cc.Sprite);
                toSprite.spriteFrame = new cc.SpriteFrame(toSpFrameArray[i]);
            };
            backcardArray[i].runAction(cc.sequence(cc.scaleTo(0.5, 0, 1), cc.callFunc(toRotateOctFunc, this), 
                cc.scaleTo(0.5, 1, 1), cc.moveTo(0.5, toPosArray[i]), cc.callFunc(toshowOctFunc, this), cc.hide()));
        }
    },

    /////////////////////////////////////////////////////////////////////////////
    _setBaseNumOctFunc(node, str){
        node.getChildByName("num").getComponent(cc.Label).string = str;
    },
});
