cc.Class({
    extends: cc.Component,

    properties: {
        O_ifrangxiantip : cc.Node,
        O_ninbeirangtip : cc.Node,
        O_ninrangtip : cc.Node,
        O_qiangdizhutip : cc.Node,
    },

    // use this for initialization
    onLoad: function () {
        this.hideAllTipOctFunc();
    },
    hideAllTipOctFunc(){
        this.O_ifrangxiantip.active = false;
        this.O_ninbeirangtip.active = false;
        this.O_ninrangtip.active = false;
        this.O_qiangdizhutip.active = false;
    },
    showQiangDZTipOctFunc(bVisible) {
        let qiangNum = g_ERDDZGameData.getQiangRangNumOctFunc();
        cc.log("==========showQiangDZTipOctFunc=========", qiangNum);
        if(!qiangNum) qiangNum = "0";
        this.O_qiangdizhutip.active = bVisible;
        if(bVisible){
            let numlabel = this.O_qiangdizhutip.getChildByName("num").getComponent(cc.Label);
            numlabel.string = qiangNum;
        }
    },
    showRangTipOctFunc(){
        this.O_ifrangxiantip.active = false;
        this.O_ninbeirangtip.active = false;
        this.O_ninrangtip.active = false;

        let qiangNum = g_ERDDZGameData.getQiangRangNumOctFunc();
        let selfSeatNo = g_ERDDZGameData.getSelfSeatNoOctFunc();
        let isDiZhu = (g_ERDDZGameData.getDiZhuSeatNoOctFunc()==selfSeatNo);

        let nodzleftnum = 0;
        if(isDiZhu) {
            let duijiaSeatNo = g_ERDDZGameData.getNextSeatNoOctFunc(selfSeatNo);
            nodzleftnum = g_ERDDZGameData.getHandCardCountOctFunc(duijiaSeatNo);
        }else{
            nodzleftnum = g_ERDDZGameData.getHandCardCountOctFunc(selfSeatNo);
        }
        let toleftnum = nodzleftnum - qiangNum;
        cc.log("=========showRangTipOctFunc================", nodzleftnum, qiangNum, isDiZhu);
        if(toleftnum<0) toleftnum = 0;
        if(isDiZhu){
            this.O_ninrangtip.active = true;
            let numlabel1 = this.O_ninrangtip.getChildByName("num1").getComponent(cc.Label);
            let numlabel2 = this.O_ninrangtip.getChildByName("num2").getComponent(cc.Label);
            numlabel1.string = qiangNum + "";
            numlabel2.string = toleftnum + "";
        }else{
            this.O_ninbeirangtip.active = true;
            let numlabel1 = this.O_ninbeirangtip.getChildByName("num1").getComponent(cc.Label);
            let numlabel2 = this.O_ninbeirangtip.getChildByName("num2").getComponent(cc.Label);
            numlabel1.string = qiangNum + "";
            numlabel2.string = toleftnum + "";
        }

    },
});
