
let GameRuleData = require("DdzRuleDataOct30th");
let GameRuleConfig = require("DdzRuleConfigOct30th");

module.exports = {
	//卡组1能否吃掉卡组2
	IsCardTab1CanEatCardTab2OctFunc(cardTab1, cardTab2){
		console.log("=====IsCardTab1CanEatCardTab2OctFunc===11=======", cardTab1, cardTab2);
		if(!cardTab1 || cardTab1.length<=0) return false;
		if(!cardTab2 || cardTab2.length<=0) return true;
		let gamedata1 = new GameRuleData(cardTab1);
		let ctype1 = gamedata1.getSelfCardTypeOctFunc();
		if(ctype1==GameRuleConfig.CardType.ErrorType) return false;
		let gamedata2 = new GameRuleData(cardTab2);
		let ctype2 = gamedata2.getSelfCardTypeOctFunc();
		console.log("=====IsCardTab1CanEatCardTab2OctFunc===22=======", ctype1, ctype2);
		if(ctype1!=ctype2) {
			if(GameRuleConfig.IsType1CanEatType2OctFunc(ctype1, ctype2)) return true;
			return false;
		}
		let eatcardtab1 = gamedata1.getCardTypeMinEatIdOrLinkCountOctFunc(ctype1);
		let eatcardtab2 = gamedata2.getCardTypeMinEatIdOrLinkCountOctFunc(ctype2);
		console.log("=====IsCardTab1CanEatCardTab2OctFunc===33=======", eatcardtab1, eatcardtab2);
		if(!eatcardtab2) return true;
		if(!eatcardtab1) return false;
		
		return eatcardtab1[0]>eatcardtab2[0] && eatcardtab1[1]==eatcardtab2[1];
	},
	//获取卡组的类型
	getCardTabCardTypeOctFunc(cardTab){
		let gamedata = new GameRuleData(cardTab);
		return gamedata.getSelfCardTypeOctFunc();
	},
	//从手牌中获取能吃掉eatCardTab的卡组
	getOutTipCardTabOctFunc(handCardTab, eatCardTab){
		console.log("=====getOutTipCardTabOctFunc===11=======", handCardTab, eatCardTab);
		let handdata = new GameRuleData(handCardTab);
		if(!eatCardTab || eatCardTab.length<=0){
			let tishitab = handdata.getMaxLengthCardTypeTabOctFunc();
			return GameRuleConfig.exchangeIndexToCardIdOctFunc(handCardTab, tishitab);
		}
		let eatdata = new GameRuleData(eatCardTab);
		let eattype = eatdata.getSelfCardTypeOctFunc();
		console.log("=====getOutTipCardTabOctFunc===22=======", eattype);
		let eatcardtab = eatdata.getCardTypeMinEatIdOrLinkCountOctFunc(eattype);
		console.log("=====getOutTipCardTabOctFunc===33=======", eatcardtab);
		if(!eatcardtab) return [];
		let tishiTab = handdata.getEatCardTypeCardTabOctFunc(eattype, eatcardtab[0], eatcardtab[1]);
		console.log("=====getOutTipCardTabOctFunc===44=======", tishiTab);
		return GameRuleConfig.exchangeIndexToCardIdOctFunc(handCardTab, tishiTab);
	},
};