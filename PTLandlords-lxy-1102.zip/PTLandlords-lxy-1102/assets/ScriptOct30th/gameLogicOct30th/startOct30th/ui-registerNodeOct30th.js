
cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function () {

    },

    onCancelBtnEventOctFunc : function(){
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");

        console.log("====onCancelBtnEventOctFunc=======");
        this.node.emit("register-hideregnode");
    },
    onOkBtnEventOctFunc : function(){
        g_SoundManager.playEffectOctFunc("CommonResOct30th/btnMusicOct30th");
        
        let accText = this.node.getChildByName("enteracc").getComponent(cc.EditBox).string;
        let pwdText = this.node.getChildByName("enterpwd").getComponent(cc.EditBox).string;
        let eventparam = {acc : accText, pwd : pwdText};
        console.log("====onOkBtnEventOctFunc=======", eventparam);
        this.node.emit("register-regaccount", eventparam);
    },
});
