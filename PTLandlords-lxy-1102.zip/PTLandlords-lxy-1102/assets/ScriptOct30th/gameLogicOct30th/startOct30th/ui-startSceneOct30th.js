let HttpRequest = require("httpRequestOct30th");
cc.Class({
    extends: require("ui-baseSceneOct30th"),

    properties: {
        O_videoplayer : cc.Node,

        O_loginprefab : cc.Prefab,
        O_registerprefab : cc.Prefab,
        O_loginloadprefab : cc.Prefab,
        O_xieyiprefab : cc.Prefab,
        O_leafparticlenode : cc.Node,

        
        O_hotfixVersionLabel : cc.Label,
        O_hotfixnode : cc.Node,
        ////////////////////////////////////////
        _loginNode : null,
        _registerNode : null,
        _loginloadNode : null,
        _isLoadingScene : false,
    },
    // use this for initialization
    onLoad : function(){
        this._super(); //调用父类的onLoad
        this.O_videoplayer.setLocalZOrder(1000);
        //this.O_videoplayer.active = true;

        let writepath = 0;//cc.FileUtils.getInstance().getWritablePath();
        cc.log("===writepath===", cc, cc.jsb, writepath);
        this.O_leafparticlenode.setLocalZOrder(100);
        
        this._showHotfixNodeOctFunc(true);

        //md5 32位小写加密测试
        //let utilmd5 = require("utilMd5Oct30th");
        //cc.log("==========md5==test====", utilmd5.md5("fanfangyou"));
        cc.log("=====ui-start===onLoad=============");
        //音频操作
        g_SoundManager.setMusicOpenOctFunc(true);
        g_SoundManager.setEffectOpenOctFunc(true);
        g_SoundManager.playMusicOctFunc("CommonResOct30th/bg-welcome");
        /*
        g_SoundManager.pauseAll();
        g_SoundManager.playMusicOctFunc("DdzResOct30th/soundResOct30th/musicResOct30th/bg_happyOct30th");
        let self = this;
        self.intervalVolumn = 1;
        this.schedule(function(){
            if(self.intervalVolumn>=0){
                cc.log("========update===volum==========", self.intervalVolumn);
                self.intervalVolumn -= 0.02;
                g_SoundManager.setMusicVolumeOctFunc(self.intervalVolumn);
                g_SoundManager.setEffectVolumeOctFunc(self.intervalVolumn);
            }
        }, 0.1);
        this.scheduleOnce(function(){
            g_SoundManager.stopMusicOctFunc();
        }, 1);
        g_SoundManager.playEffectOctFunc("DdzResOct30th/soundResOct30th/effectResOct30th/winMusic", (path, dur)=>{
            cc.log("========playEffectOctFunc===========", path, dur);
        });
        */
        let curhotVersion = g_ConfigManager.getHotfixVersionOctFunc();
        this.O_hotfixVersionLabel.string = curhotVersion+"";
        //检测更新
        let self = this;
        let onErrorHandleOctFunc = ()=>{
            cc.log("=====hotfix====onErrorHandleOctFunc=========");
            self.node.runAction(cc.sequence(cc.delayTime(2), cc.callFunc(self._onAllInitOctFunc, self)));
        }
        let onSuccessHandleOctFunc = (response)=>{
            let jsonData = JSON.parse(response);
            cc.log("=====hotfix====onSuccessHandleOctFunc=========", jsonData, response);
            if(true || !jsonData || !jsonData.version){
                return onErrorHandleOctFunc();
            }
            let jsonVersion = jsonData.version;
            if(jsonVersion == curhotVersion){
                return onErrorHandleOctFunc();
            }
            g_ConfigManager.setHotfixVersionOctFunc(jsonData.version);
            self.O_hotfixVersionLabel.string = jsonData.version;
            self._startHotFixUpdateOctFunc();
        }
        /////
        let isHaveHotfix =false;
        if(isHaveHotfix){
            let hotfixVerUrl = g_ConfigManager.getGlobalConfigOctFunc("HotFixUrl");
            let httpHandler = new HttpRequest();
            httpHandler.onError = onErrorHandleOctFunc;
            httpHandler.onSuccess = onSuccessHandleOctFunc;
            httpHandler.sendGet(hotfixVerUrl);
        }else{
            onErrorHandleOctFunc();
        }
    },
    _onPreLoadResourceOctFunc(){
        //预加载资源
        cc.log("========_onPreLoadResourceOctFunc=================");
        let self = this;
        self._loadResourceMax = 2;
        let toloadOctFunc = ()=>{
            self._loadResourceMax--;
            if(self._loadResourceMax==0){
                self._onLoadLobbySceneOctFunc();
            }
        };
        let pokersmallOctFunc = toloadOctFunc;
        let pokerbigOctFunc = toloadOctFunc;
        cc.loader.loadResDir("DdzResOct30th/smallPokerResOct30th", (err, arraytex)=>{
            cc.log("===loadResDir==DdzResOct30th/smallPokerResOct30th===", arraytex);
            if(pokersmallOctFunc)pokersmallOctFunc();
            pokersmallOctFunc = null;
        });
        cc.loader.loadResDir("DdzResOct30th/bigPokerResOct30th", (err, arraytex)=>{
            cc.log("===loadResDir==DdzResOct30th/bigPokerResOct30th===", arraytex);
            if(pokerbigOctFunc)pokerbigOctFunc();
            pokerbigOctFunc = null;
        });
        // this.scheduleOnce(function(){
        //     if(pokersmallOctFunc)pokersmallOctFunc();
        //     if(pokerbigOctFunc)pokerbigOctFunc();
        //     pokersmallOctFunc = null;
        //     pokerbigOctFunc = null;
        // }, 5);
        
    },
    _onAllInitOctFunc(){
        //所有初始化都在这里
        this.O_videoplayer.destroy();
        this._showHotfixNodeOctFunc(false);
        this._showLoginNodeOctFunc();
        this._initNetWorkOctFunc();
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_S2CSignIN, this._onProtSignInOctFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_S2CRegAccount, this._onProtRegAccountOctFunc, this);
        //请求登陆大厅
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqLoginIn, this._onProtLoginLobbyOctFunc, this);
        g_NetManager.regCommandListener(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_S2CReqUserInfo, this._onProtLoginLobbyInfoOctFunc, this);
    },
    _initNetWorkOctFunc(){
        let serverIp = g_ConfigManager.getGlobalConfigOctFunc("ServerIP");
        let serverPort = g_ConfigManager.getGlobalConfigOctFunc("ServerPort");
        cc.log("=======_initNetWorkOctFunc=============", serverIp, serverPort);
        g_NetManager.connect(serverIp, serverPort);
        let self = this;
        self._isLoadingScene = false;
        g_NetManager.onopen = function(){
            console.log("=========g_NetManager.onopen=============");
            self.showLoadFlowerOctFunc(false);
            //如果在加载资源时候重连
            if(self._isLoadingScene){
                self._onProtSignInOctFunc(null, null, {isSuccess:1});
            }
        };
    },
    _onLoadLobbySceneOctFunc(){
        cc.log("=========_onLoadLobbySceneOctFunc=======11========");
        //检测能否切换大厅场景，
        //1、是否服务器已经发送完所有数据过来
        //2、是否进度条已经到了最后
        //3、是否预加载资源已经加载完成了。
        if(g_ConfigManager.checkIsCanLoginLobbyOctFunc(3)){
            cc.log("=========_onLoadLobbySceneOctFunc=======22========");
            g_ConfigManager.resetIsCanLoginLobbyOctFunc();
            g_GameScene.switchLobbySceneOctFunc();
        }
    },
    _startHotFixUpdateOctFunc(){
        let self = this;
        let finishUpdateOctFunc = function(){
            cc.log("=========finishUpdateOctFunc==========")
            self.node.runAction(cc.sequence(cc.delayTime(2), cc.callFunc(self._onAllInitOctFunc, self)));
        };
        this.getComponent('hotFixUpdateOct30th').initOctFunc(finishUpdateOctFunc);
    },
    /////////////////////////////////////////////////////
    onRecvErrcodeOctFunc(errcode, attachtab){
        cc.log("=======onRecvErrcodeOctFunc============", errcode, attachtab);
        this.showPopupWindowOctFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode(errcode));
    },
    /////////////////////////////////////////////////////
    //协议回调
    _onProtSignInOctFunc(mainId, assistId, protTab){
        cc.log("======_onProtSignInOctFunc=============", protTab);
        if(protTab.isSuccess!=1){
            return this.showPopupWindowOctFunc(true, false, "提示", "登陆失败！");
        }
        this._isLoadingScene = true;
        //登陆成功
        this._showLoadingNodeOctFunc();
        this._onPreLoadResourceOctFunc();
        g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Lobby, g_ProtDef.ALobby_C2SReqLoginIn)
    },
    _onProtRegAccountOctFunc(mainId, assistId, protTab){
        cc.log("======_onProtRegAccountOctFunc=============", protTab);
        if(protTab.isSuccess!=1){
            this.showPopupWindowOctFunc(true, false, "提示", "注册失败！");
        }else{
            this.showPopupWindowOctFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_REGISTER_SUCCESS_ACC"), (flag)=>{
                this._showLoginNodeOctFunc(true);
            }, this);
        }
    },
    _onProtLoginLobbyOctFunc(mainId, assistId, protTab){
        cc.log("======_onProtLoginLobbyOctFunc=============", protTab);
        if(protTab.isSuccess==1){
            this._onLoadLobbySceneOctFunc();
        }else{
            this.showPopupWindowOctFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_REGISTER_LOGIN_LOBBY_FAILED"));
        }
    },
    _onProtLoginLobbyInfoOctFunc(mainId, assistId, protTab){
        cc.log("======_onProtLoginLobbyInfoOctFunc=============", protTab);
        //在ALobby_S2CReqLoginIn登陆大厅成功的协议返回前，返回玩家数据
        let userinfo = g_UserManager.newUserOctFunc(protTab.userId, protTab.userName, true)
        userinfo.setUserInfoPackageOctFunc(protTab)
    },
    /////////////////////////////////////////////////////
    _showHotfixNodeOctFunc(isVisible){
        this.O_hotfixnode.active = isVisible;
        if(isVisible){
            this._showLoginRegLoadVisibleOctFunc(false, false, false);
        }
    },
    _showLoginRegLoadVisibleOctFunc(isLogin, isReg, isLoad){
        if(this._loginNode) {
            this._loginNode.destroy();
            this._loginNode = null;
        }
        if(this._registerNode){
            this._registerNode.destroy();
            this._registerNode = null;
        }
        if(isLogin){
            this._loginNode = cc.instantiate(this.O_loginprefab);
            this._loginNode.parent = this.node;
        }else if(isReg){
            this._registerNode = cc.instantiate(this.O_registerprefab);
            this._registerNode.parent = this.node;
        }else if(isLoad){
            if(!this._loginloadNode) {
                this._loginloadNode = cc.instantiate(this.O_loginloadprefab);
                this._loginloadNode.parent = this.node;
            }
        }
        if(this._loginNode) this._loginNode.active = isLogin;
        if(this._registerNode) this._registerNode.active = isReg;
        if(this._loginloadNode) this._loginloadNode.active = isLoad;
    },
    _showLoginNodeOctFunc(){
        this._showLoginRegLoadVisibleOctFunc(true, false, false);
        //on接收事件，其事件的emit必定是在这个节点内部发射
        //移除同类型的事件监听，否则on会递增, 最好在on之前调用，不要在时间响应后调用，保持有且仅有一个同类事件
        this._loginNode.off("login-loginacc"); 
        this._loginNode.off("login-showregister"); 
        this._loginNode.off("login-xieyi-not-select");
        this._loginNode.off("login-showxieyi");

        this._loginNode.on("login-loginacc", (event)=>{
            console.log("=======login-loginacc======", event.detail);
            let toAcc = String(event.detail.acc);
            let toPwd = String(event.detail.pwd);
            if(toAcc.length<=0 || toPwd.length<=0){
                return this.showPopupWindowOctFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_LOGIN_ACC_PWD_EMPTY"));
            }
            else if(toAcc.length<6 || toPwd.length<6){
                return this.showPopupWindowOctFunc(true, false, "提示", g_ProtDef.GetErrDiscByCode("M_REGISTER_LONGERR_ACC"));
            }
            let protTab = {};
            protTab.accName = toAcc;
            protTab.accPwd = toPwd;
            protTab.platform = 0;
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_C2SSignIN, protTab);
            g_ConfigManager.setLoginAccountOctFunc(toAcc, toPwd);
        }, this);
        this._loginNode.on("login-showregister", (event)=>{
            console.log("=======login-showregister======", event.detail);
            this._showRegisterNodeOctFunc();
        }, this);


        this._loginNode.on("login-xieyi-not-select", (event)=>{
            console.log("=======login-xieyi-not-select======", event.detail);
            this.showPopupWindowOctFunc(true, false, "提示", "继续游戏需要同意用户协议");
        }, this);

        this._loginNode.on("login-showxieyi", (event)=>{
            console.log("=======login-showxieyi======", event.detail);
            this._showXieYiNodeOctFunc();
        }, this);

        
        /////////////////////////////
    },
    _showRegisterNodeOctFunc(){
        this._showLoginRegLoadVisibleOctFunc(false, true, false);
        //on接收事件，其事件的emit必定是在这个节点内部发射
        //移除同类型的事件监听，否则on会递增, 最好在on之前调用，不要在时间响应后调用，保持有且仅有一个同类事件
        this._registerNode.off("register-regaccount"); 
        this._registerNode.off("register-hideregnode"); 
        this._registerNode.on("register-regaccount", (event)=>{
            console.log("=======login-regaccount======", event, event.detail);
            let toAcc = String(event.detail.acc);
            let toPwd = String(event.detail.pwd);
            if(toAcc.length<=0 || toPwd.length<=0){
                return this.showPopupWindowOctFunc(true, false, "错误", g_ProtDef.GetErrDiscByCode("M_LOGIN_ACC_PWD_EMPTY"));
            }
            else if(toAcc.length<6 || toPwd.length<6){
                return this.showPopupWindowOctFunc(true, false, "错误", g_ProtDef.GetErrDiscByCode("M_REGISTER_LONGERR_ACC"));
            }
            let protTab = {};
            protTab.accName = toAcc;
            protTab.accPwd = toPwd;
            protTab.userName = toAcc;
            protTab.headUrl = ""
            protTab.isBoy = 1
            protTab.platform = 0 //普通注册
            g_NetManager.sendCommand(g_ProtDef.MID_Protocol_Login, g_ProtDef.ALogin_C2SRegAccount, protTab);
        }, this);
        this._registerNode.on("register-hideregnode", (event)=>{
            console.log("=======login-hideregnode======", event, event.detail);
            this._showLoginNodeOctFunc();
        }, this);
    },
    _showLoadingNodeOctFunc(){
        this._showLoginRegLoadVisibleOctFunc(false, false, true);
        let toPreLoadNode = this._loginloadNode.getChildByName("proloadbar");
        let toProgressBar = toPreLoadNode.getComponent(cc.ProgressBar);
        cc.log("====_showLoadingNodeOctFunc=====", toPreLoadNode, toProgressBar);
        toProgressBar.progress = 0;
        let self = this;
        let loginUPloadCallBackOctFunc = function(dt){
            let topercent = dt * (Math.random() * 100 + 40);
            toProgressBar.progress += topercent / 100.0;
            //cc.log("========loginUPloadCallBackOctFunc=========", toProgressBar.progress,  dt, topercent);
            if(toProgressBar.progress>=1) {
                cc.log("========loginUPloadCallBackOctFunc====end=====");
                toProgressBar.progress = 1;
                self.unschedule(loginUPloadCallBackOctFunc);
                self._onLoadLobbySceneOctFunc();
            }
        };
        this.schedule(loginUPloadCallBackOctFunc, 0);
    },

    _showXieYiNodeOctFunc:function(){
        if(this._xieYiNode != null){
            return;
        }
        this._xieYiNode = cc.instantiate(this.O_xieyiprefab);
        this._xieYiNode.parent = this.node;

        this._xieYiNode.on("login-hidexieyi", (event)=>{
            console.log("=======login-hidexieyi======", event.detail);
            this._hideXieYiNodeOctFunc();
        }, this);
    },

    _hideXieYiNodeOctFunc:function(){
        if(this._xieYiNode != null){
            this._xieYiNode.destroy();
            this._xieYiNode = null;
        }
    },

    onRegisterBtnEventOctFunc(event){
        this._showRegisterNodeOctFunc();
    },
});
